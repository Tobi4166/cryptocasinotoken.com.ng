# $CASINO PRESALE TERMS OF USE

Please read these Terms of Use carefully before you start using the Website. By accessing or using the Website, you agree to be bound by these Terms of Use. If you do not agree to these Terms of Use, you must not access or use the Website.

YOU MAY LOSE ALL MONIES THAT YOU SPEND PURCHASING $CASINO TOKENS. IN THE EVENT THAT YOU DO PURCHASE TOKENS, YOUR PURCHASE CANNOT BE REFUNDED OR EXCHANGED.  
YOU ARE WAIVING YOUR RIGHTS BY AGREEING TO THESE TERMS OF USE AND PARTICIPATING IN THE $CASINO TOKEN SALE. BY PARTICIPATING IN THE $CASINO TOKEN SALE YOU ARE AGREE TO HAVE NO RECOURSE, CLAIM, ACTION, JUDGEMENT OR REMEDY AGAINST THE COMPANY IF THE UTILITY OF THE $CASINO TOKENS OR IF THE PROJECT DESCRIBED IN THIS WHITE PAPER IS NOT DELIVERED OR REALISED.  
IF YOU ARE UNCERTAIN AS TO ANYTHING IN THIS WHITE PAPER OR YOU ARE NOT PREPARED TO LOSE ALL MONIES THAT YOU SPEND PURCHASING $CASINO TOKENS, WE STRONGLY ADVISE YOU NOT TO PURCHASE ANY $CASINO TOKENS.  
WE ALWAYS RECOMMEND YOU CONSULT LEGAL, FINANCIAL, TAX AND OTHER PROFESSIONAL ADVISORS OR EXPERTS FOR FURTHER GUIDANCE BEFORE PARTICIPATING IN THE $CASINO TOKEN SALE OUTLINED IN THIS WHITE PAPER. YOU ARE STRONGLY ADVISED AND ENCOURAGED TO TAKE INDEPENDENT LEGAL ADVICE IN RESPECT OF THE LEGALITY IN YOUR JURISDICTION OF PARTICIPATION IN THE TOKEN SALE.  
$CASINO TOKENS ARE NOT SHARES OR SECURITIES OF ANY TYPE. THEY DO NOT ENTITLE YOU TO ANY OWNERSHIP OR OTHER INTEREST IN $CASINO. THEY ARE MERELY A MEANS BY WHICH YOU MAY BE ABLE TO UTILISE CERTAIN SERVICES ON A PLATFORM THAT IS BEING FURTHER DEVELOPED.

These “Terms of Use” apply to this White Paper and any and all information available on the Token sale website. The contents of these “Terms of Use” outline the Terms of Use applicable to you in connection with (i) your use of this White Paper and of any and all information available on the Token sale website; and (ii) your participation in the Token Sale, in each case in addition to any other Terms of Use that we may publish from time to time relating to this White Paper, the Token sale website and the Token Sale (such terms hereinafter referred to as the “Terms”). These Terms may be updated from time to time and will be published as part of the latest version of the White Paper which shall be available on the Token sale website. Your continued use of the Website following the posting of revised Terms of Use constitutes your acceptance of those changes. We recommend you review this page regularly to stay informed of any updates, as they are binding on you.

The information set forth in these Terms may not be exhaustive and does not imply any elements of a contractual relationship. While we make every reasonable effort to ensure that all information: (i) in the White Paper; and (ii) available on the Token sale website (all the information in the White Paper and all information available on the Token sale website hereinafter referred to as the “Available Information”) is accurate and up to date, such material in no way constitutes professional advice by us. Individuals intending to participate in the Token Sale should always seek independent professional advice prior to acting on any of the Available Information.

**LEGAL CONSIDERATIONS**

The Tokens are functional utility tokens designed for use initially on the CryptoCasino platform that is being further developed. The Tokens are not securities. In the event that you purchase Tokens, your purchase cannot be refunded or exchanged. The Company does not recommend purchasing Tokens for speculative investment purposes. Tokens do not entitle you to any equity, governance, voting or similar right or entitlement in the Company or in any of its affiliated companies.

The Company may choose to make the Available Information in a number of different languages. In the event of any conflict between the English version of the Available Information and any foreign language version, the English language version shall prevail.

**REGIONAL AND AGE RESTRICTIONS**

Citizens, nationals residents (tax or otherwise) of each of: (i) The United States of America and its territories; (ii) The United Kingdom and its territories; (iii) The Netherlands and its territories (iv) any other jurisdiction which prohibits or requires any supervision, oversight, licensing, regulatory compliance and/or approval from any regulatory (or similar) authority or body or from any monetary or securities body or authority or any other Restricted Persons are NOT permitted to participate in the Token Sale. The term “Restricted Persons” includes any firm, company, partnership, trust, corporation, entity, government, state or agency of a state that is established and/or lawfully existing under the laws of a Restricted Jurisdiction (including in the case of United States of America, under the federal laws of the United States of America or under the laws of any of its States).

This White Paper does not constitute a prospectus or offer document of any sort and the Available Information is not intended to constitute an offer of securities or a solicitation for investment in securities in any jurisdiction. The Company does not provide any opinion or any advice to purchase, sell, or otherwise transact with Tokens and the presentation, publication or communication of all or any part of the Available Information shall not form the basis of, or be relied upon in connection with, any contract or investment decision.

The Service is not for use by (i) individuals under 18 years of age, (ii) individuals under the legal age of majority in their jurisdiction and (iii) individuals accessing the Service from jurisdictions from which it is illegal to do so. We are not able to verify the legality of the Service in each jurisdiction and it is the User’s responsibility to ensure that their use of the Service is lawful.

**NO ADVICE**

No part of the white paper, or Company websites should be considered to be business, legal, financial or tax advice regarding the Company, the Tokens, the Token Sale or any of the matters to which all or any part of those sources relate. We recommend you consult legal, financial, tax and other professional advisors or experts for further guidance before participating in the $CASINO token sale outlined in this white paper. We strongly advise that you take independent legal advice in respect of the legality in your jurisdiction of your participation in the token sale.

**TERMS OF ACCESS**

To access certain services on the Website, you may be required to provide specific data or other information. It is a condition of access that all information you provide is accurate, current, and complete. We reserve the right to disable access if we believe you have violated any provision of these Terms of Use.

You agree not to use the Website:

- In any way that violates applicable laws or regulations, including those concerning data export.
- To exploit or harm minors by exposing them to inappropriate content or soliciting personal information.
- To send, receive, upload, download, or use any material that does not comply with global web content standards and good practice.
- To transmit or procure the sending of unsolicited promotional material, including "junk mail," "chain letters," or "spam," without our prior written consent.
- To impersonate the Platform, another user, or any other person or entity.
- To engage in any conduct that restricts or inhibits the use or enjoyment of the Website by others, or that could harm the Platform or its users.

Additionally, you agree not to:

- Use the Website in a way that disables, overburdens, damages, or impairs it or interferes with others' ability to use it.
- Use automated processes or devices to access the Website for any purpose, including monitoring or copying materials.
- Use manual processes to monitor or copy materials from the Website without our prior written consent.
- Introduce viruses, Trojans, worms, or other harmful materials.
- Attempt to gain unauthorized access or disrupt any part of the Website or its related servers and databases.
- Attack the Website via denial-of-service attacks or any other disruptive methods.

**USER CONTRIBUTIONS**

The Website may feature interactive elements allowing users to post content or materials ("User Contributions"). All User Contributions must comply with global web content standards and good practice. By posting User Contributions, you grant us and our affiliates and service providers, including their respective licensees, successors, and assigns, the right to use, reproduce, modify, perform, display, distribute, and disclose such materials.

You represent and warrant that:

- You own or control all rights to the User Contributions and have the authority to grant the above license.
- All User Contributions comply with these Terms of Use.

You are responsible for the legality, reliability, accuracy, and appropriateness of your User Contributions. The Platform is not liable for the content or accuracy of User Contributions posted by you or other users.

We reserve the right to:

- Remove or refuse to post any User Contributions at our discretion.
- Take any necessary action with respect to User Contributions if we believe they violate the Terms of Use, infringe on any intellectual property rights, or pose risks to users' safety or liability for the Platform.
- Disclose your identity or other information to third parties who claim that your material infringes their rights.
- Take legal action, including referral to law enforcement, for illegal or unauthorized use of the Website.
- Suspend or terminate your access to the Website for violations of these Terms of Use.

We do not review material before it is posted and cannot ensure the prompt removal of objectionable content. We assume no liability for any actions regarding user communications or content.

**INTELLECTUAL PROPERTY RIGHTS**

The Website and its entire content, including but not limited to all information, software, text, displays, images, video, audio, and their design, selection, and arrangement, are owned by the Platform, its licensors, or other content providers and are protected by international intellectual property laws.

These Terms of Use allow you to use the Website for personal, non-commercial purposes only. You may not:

- Reproduce, distribute, modify, create derivative works from, publicly display, perform, republish, download, store, or transmit any of the materials from the Website except as follows:
- Modify materials from the Website.
- Use any graphics, illustrations, photographs, videos, or audio separately from the text.
- Remove or alter any copyright, trademark, or other proprietary notices from materials on the Website.
- Use any part of the Website or its services for commercial purposes.

Any unauthorized use of the Website is a breach of these Terms of Use and may violate copyright, trademark, or other laws.

**TRADEMARKS**

The Platform name, logo, and related names, logos, products and service names, designs, and slogans are trademarks of the Platform or its affiliates or licensors. You may not use these trademarks without prior written permission. All other names, logos, product and service names, designs, and slogans on the Website are trademarks of their respective owners.

You may link to the homepage in a fair and legal manner that does not damage our reputation or imply endorsement. However, you may not link in a way that suggests any form of association without our express written consent.

The Website may offer social media features allowing you to:

- Link from your site to content on our Website.
- Send communications with links to our Website's content.
- Display portions of our Website's content on other sites.

You may only use these features as provided and in accordance with additional terms we provide. You must not:

- Establish links from non-owned websites.
- Frame or deep-link to our Website inappropriately.
- Link to any part of the Website other than the homepage.

The website you link from must comply with global web content standards and good practice. We reserve the right to withdraw linking permissions without notice.

**LIMITATION OF LIABILITY**

In no event shall the Company or any of its respective past, present and future employees, officers, directors, contractors, consultants, equity holders, suppliers, vendors, service providers, joint ventures, parent companies, subsidiaries, affiliates, agents, representatives, predecessors, successors and assigns (hereinafter the “Affiliates”) be responsible, accountable or liable in any way whatsoever (to any purchaser of Tokens), for any loss of profits or otherwise or for any lost savings or for any incidental direct indirect special or consequential damages in each case arising out of or from or in connection with:

1. any failure by the Company or any of its Affiliates to deliver or realise all or any part of the project or the platform or the membership network or the Token features described in or envisaged by the Available Information;
2. your use or inability to use at any time the services or the products or the platform or the membership network or Tokens offered by the Company;
3. the breach of any of these Terms by the Company or by the Affiliates or by you or by any third party;
4. any security risk or security breach or security threat or security attack or any theft or loss of data including but not limited to hacker attacks, losses of password, losses of private keys, or anything similar;
5. mistakes or errors in code, text, or images involved in the Token Sale or in any of the Available Information;
6. any information contained in or omitted from the Available Information;
7. any expectation promise representation or warranty arising (or purportedly arising) from the Available Information;
8. the volatility in pricing of Tokens in any countries and/or on any exchange or market (regulated, unregulated, primary, secondary or otherwise);
9. the purchase use sale resale redemption or otherwise of the Tokens;
10. your failure to properly secure any private key to a wallet containing Tokens,

(collectively, the “Excluded Liability Matters”).

The Available Information (including the Token sale website and the White Paper) and the Tokens are provided on an “as is” basis and without any representations or warranties of any kind, either express or implied. You assume all responsibility and risk with respect to your use of the Available Information and purchasing of any amount of Tokens and their use. If applicable law does not allow all or any part of the above limitation of liability to apply to you, the limitations will apply to you only to the maximum extent permitted by applicable law.

To the maximum extent permitted by applicable law, you hereby irrevocably and unconditionally waive: (i) all and any claims (whether actual or contingent and whether as an employee, office holder, trustee, agent, principal or in any other capacity whatsoever or howsoever arising) including, without limitation, claims for or relating to the Excluded Liability Matters, any payment or repayment of monies, indemnity or otherwise that you may have against the Company or against any Affiliate; and (ii) release and discharge the Company and all of the Affiliates from any and all liability (of whatsoever nature or howsoever arising) it or they may have to you. If for any reason hereafter you bring or commence any action or legal proceeding in respect of any claim purported to be released and discharged pursuant to this paragraph or these Terms, or otherwise attempt to pursue any such claim against the Company or any Affiliates then you hereby irrevocably and unconditionally undertake to indemnify, and keep indemnified the Company and all Affiliates fully on demand from and against:

1. all liabilities or losses suffered by the Company or any of its Affiliates; and
2. all reasonable costs, charges and reasonable expenses (including without limitation reasonable legal costs and expenses) reasonably and properly incurred by the Company or any of its Affiliates, in each case by reason of or in connection with the bringing or commencement of such action or pursuit of such claim by you.

If any provision or part-provision of these Terms is or becomes invalid, illegal or unenforceable, it shall be deemed modified to the minimum extent necessary to make it valid, legal and enforceable. If such a modification is not possible, the relevant provision or part-provision shall be deemed deleted. Any modification to or deletion of a provision or part-provision under these Terms shall not affect the enforceability and validity of the rest of these Terms.

**NO REPRESENTATION & WARRANTIES**

Notwithstanding any other provision of these Terms or any statement made expressly or impliedly in the Available Information, the Company does not make or purport to make, and hereby disclaims, any representation warranty undertaking or covenant in any form whatsoever to any entity or person, including any representation warranty undertaking or covenant in relation to the truth, accuracy and completeness of any of the information set out in the Available Information.

**REPRESENTATION & WARRANTIES BY YOU**

By howsoever accessing and/or accepting possession or communication of all or any part of the Available Information, you represent and warrant (and shall be deemed to represent and warrant) to the Company on the date of such access or on the latest date on which you retain possession of all or any part of the Available Information as follows:

1. you are over 18 (eighteen) years of age or the corresponding minimum age in your jurisdiction;
2. you agree and acknowledge that the Tokens do not constitute shares or equities or securities or financial instruments or investments in any form in any jurisdiction;
3. you agree and acknowledge that the Available Information (including the White Paper and the Token sale website) does not constitute a prospectus or offer document of any sort and is not intended to constitute an offer of securities in any jurisdiction or a solicitation for investment in securities and you are not bound to enter into any contract or binding legal commitment and no cryptocurrency or other form of payment is to be accepted on the basis of the Available Information;
4. you agree and acknowledge that no regulatory authority has examined or approved of the Available Information, no action has been or will be taken under the laws, regulatory requirements or rules of any jurisdiction and the publication, distribution or dissemination of all or any part of the Available Information to you does not imply that the applicable laws, regulatory requirements or rules have been complied with;
5. you agree and acknowledge that the Available Information, the undertaking and/or the completion of the Token Sale, or future trading of the Tokens on any exchange or market (regulated, unregulated, primary, secondary or otherwise), shall not be interpreted, construed or deemed by you as an indication of the merits of the Company, the Tokens, the Token Sale or the Available Information;
6. the distribution or dissemination of the Available Information any part thereof or any copy thereof, or acceptance of the same by you, is not prohibited or restricted by the applicable laws, regulations or rules in your jurisdiction, and where any restrictions in relation to possession are applicable, you have observed and complied with all such restrictions at your own expense and without liability to the Company;
7. you are fully aware of and understand that you are not eligible to purchase any Tokens or access the Available Information if you are a citizen, national, resident (tax or otherwise) and/or green card holder of a Restricted Jurisdiction or if you are a Restricted Person;
8. you have a basic degree of understanding of the operation, functionality, usage, storage, transmission mechanisms and other material characteristics of cryptocurrencies, blockchain-based software systems, cryptocurrency wallets or other related token storage mechanisms, blockchain technology and smart contract technology;
9. you are fully aware and understand that in the case where you wish to purchase any Tokens, there are risks associated with: (A) the Company and its business and operations; (B) the Tokens; (C) the Token Sale; and (D) relying or acting on all or any part of the Available Information;
10. you agree and acknowledge that the Company is not liable for any direct indirect special incidental consequential or other losses of any kind in tort contract or otherwise (including but not limited to loss of revenue income or profits or loss of use or data or loss of reputation or loss of any economic or other opportunity of whatsoever nature or howsoever arising) arising out of or in connection with any acceptance of or reliance on the Available Information or any part thereof by you; and
11. all of the above representations and warranties are true, complete, accurate and not misleading from the time of your last access to and/or possession of (as the case may be) the Available Information.

**RISK FACTORS**

You should carefully consider and evaluate each of the following risk factors and all other information contained in these Terms before deciding to participate in the Token Sale. To the best of the Company’s knowledge and belief, all risk factors which are material to you in making an informed judgment to participate in the Token Sale have been set out below. If any of the following considerations, uncertainties or material risks develops into actual events, the business, financial position and/or results of operations of the Company and the maintenance and level of usage of the Tokens could be materially and adversely affected. In such cases, the trading price of Tokens could decline due to any of these considerations, uncertainties or material risks, and you may lose all or part of your Tokens or the economic value of them.

**RISKS RELATING TO PARTICIPATION IN THE TOKEN SALE**

The Token Sale may not result in an active or liquid market for the Tokens.

In the event that the Company ever decides to seek the approval for availability of the Tokens for trading on any cryptocurrency exchange, there is no assurance that such approval will be obtained. Furthermore, even if such approval is granted by a cryptocurrency exchange, there is no assurance that an active or liquid trading market for the Tokens will develop, or if developed, will be sustained after the Tokens have been made available for trading on such market. There is also no assurance that the market price of the Tokens will not decline below the original or issue purchase price/Token Private Sale Price (the “Purchase Price”). The Purchase Price may not be indicative of the market price of the Tokens after they have been made available for trading on a market.

The Token is not a currency issued by any central bank or national, supra-national or quasi-national organisation, nor is it backed by any hard assets or other credit nor is it a commodity in the traditional sense of that word. The Company is not responsible for, nor does it pursue, the circulation and trading of Tokens on any market. Trading of Tokens will merely depend on the consensus on its value between the relevant market participants. No one is obliged to purchase any Token from any holder of the Token, including the purchasers, nor does anyone guarantee the liquidity or market price of Tokens to any extent at any time. Furthermore, Tokens may not be resold to purchasers who are citizens, nationals, residents (tax or otherwise) and/or green card holders of Restricted Jurisdictions or to Restricted Persons or to purchasers in any other jurisdiction where the purchase of Tokens may be in violation of applicable laws. Accordingly, the Company cannot ensure that there will be any demand or market for Tokens, or that the Purchase Price is indicative of the market price of Tokens after they have been made available for trading on any cryptocurrency exchange or market.

Future sales or issuance of the Tokens could materially and adversely affect the market price of Tokens.

Any future sale of the Tokens would increase the supply of Tokens in the market and this may result in a downward price pressure on the Token. The sale or distribution of a significant number of Tokens outside of the Token Sale (including but not limited to transfer of Tokens to persons other than purchasers for purposes of community initiatives, business development and market expansion and issuance of Tokens as a reward to users of the CryptoCasino platform that is being further developed or otherwise), or the perception that such further sales may occur, could adversely affect the trading price of the Tokens.  
Negative publicity (relating to the company or otherwise) may materially and adversely affect the price of the Tokens.  
There is no assurance of any success of the Company’s Token Sale or business platform that is being further developed as envisaged by the Available Information.

The value of, and demand for, the Tokens hinges heavily on the performance of the Company’s Token Sale and CryptoCasino platform that is being further developed and the continuous active engagement of its users and success of its contemplated business lines. There is no assurance that the Company’s Token Sale will be successful or that the CryptoCasino platform that is being further developed will gain or continue to gain traction. While the Company has made every effort to provide a realistic estimate, there is also no assurance that the cryptocurrencies raised in the Token Sale will be sufficient for the development of the CryptoCasino platform. For the foregoing or any other reason, the development of the CryptoCasino platform and launch of the anticipated Token functionality may not be completed and there is no assurance that it will be launched at all. As such, distributed Tokens may hold little or no worth or value and this would impact any trading price and/or use of the Tokens.

**TOKEN DETAILS**

The website offers $CASINO tokens which are digital assets based on Ethereum. $CASINO Tokens are designed to be used primarily within the CryptoCasino ecosystem. They are not redeemable for cash, and their value may fluctuate.

Participants of the $CASINO token sale can connect their wallets to the presale purchase site and buy tokens using Ethereum, BNB, and USDT.

All transfers of funds to purchase $CASINO tokens are the responsibility of the participant. There will be no refunds or reversal of transactions for any amounts of money that have been sent in error or of incorrect amounts.

All token purchases are final and will not be changed, reversed or refunded under any circumstances.

All participants of the $CASINO token sale will be able to redeem their $CASINO tokens upon completion of the presale.

The tokens will be available for redemption on the date set out by the project and will be redeemable using the same wallet that was connected to the purchase site originally.

Only the original wallet which was connected and made the transfer of the tokens to purchase $CASINO can redeem those tokens. Any non-accessible wallets cannot redeem tokens purchased during the presale. No transfer of ownership of purchased $CASINO tokens will be allowed.

**REFERRAL BONUSES**

All participants of the $CASINO presale are eligible to earn a referral bonus of 10% of the $CASINO tokens purchased by those who register for the presale via wallet connection using the participant’s unique tracking link.

All referrals are tracked by the presale referral system. All references to token purchases are stored in said system and will automatically update withing a minute or so upon the completion of a purchase by the referred party.

Any discrepancies in referral bonuses will be settled by the amount of tokens granted in the referral bonus. Players can connect their wallet and view all referral reward bonuses in their user dashboard.

Participants cannot refer themselves via their own referral link to obtain bonuses. Any participant discovered to have referred themselves via the same IP address will LOSE ANY AND ALL PURCAHSED AND REFERRAL TOKENS accumulated during the presale.

**AIRDROP REWARDS**

Airdrop campaigns which allow participants to complete objectives to be eligible for rewards Will be conducted. Each participant is eligible for ONE (1) set of airdrop rewards per campaign. If it is discovered that a participant has registered for multiple airdrop rewards, they will have all airdrop rewards revoked and be prohibited from taking part in any future campaigns and other promotions. All airdrop terms and conditions will be posted along with each campaign.

**SECURITY**

You are responsible for securing your Token wallet and private keys. We are not liable for any unauthorized access or loss of Tokens.

**RISKS RELATING TO THE COMPANY**

The CryptoCasino platform continues to be developed.

Any events or circumstances which adversely affect the Company or any of its Affiliates may have a corresponding adverse effect on the CryptoCasino platform that is being further developed, including but not limited to the development, structuring the CryptoCasino platform. Such adverse effects would correspondingly have an impact on the utility, liquidity, and the trading price of the Tokens.  
The Company may experience system failures, unplanned interruptions in its network or services, hardware or software defects, security breaches or other causes that could adversely affect the Company’s infrastructure network, and/or the CryptoCasino platform that is being further developed.  
The Company and/or its Affiliates are not able to anticipate when there would be occurrences of hacks, cyber-attacks, distributed denials-of-service or errors, vulnerabilities or defects in: the CryptoCasino platform that is being further developed, in the smart contracts on which the Company and/or its Affiliates or the CryptoCasino platform relies, or on the Ethereum or any other blockchain. Such events may include, for example, flaws in programming or source code leading to exploitation or abuse thereof. The Company and/or its Affiliates may not be able to detect such hacks, cyber-attacks, distributed denials-of-service errors vulnerabilities or defects in a timely manner, and may not have sufficient resources to efficiently cope with multiple service incidents happening simultaneously or in rapid succession.

**DISCLAIMER**

The presentation of the Available Information is solely for informational purposes. Anyone interested in purchasing Tokens and participating in the Token Sale should consider the various risks prior to making any kind of decision in respect of the Token Sale. The Available Information does not comprise any advice by the Company or by any of its Affiliates, or any recommendation to any recipient of the Available Information, by the virtue of any participation in the Token Sale or otherwise. The Available Information does not necessarily identify, or claim to identify, all the risk factors connected with the Company, the CryptoCasino platform that is being further developed, the Tokens, the Token Sale, any future Token functionality or the Available Information. All the participants must make their own independent evaluation, after making such investigations as they consider essential, of the merits of participating in the Token Sale and after taking their own independent professional advice. Any participant in the Token Sale should check with and rely upon their own investment, accounting, legal and tax representatives and consultants in respect of such matters concerning the Company, the CryptoCasino platform that is being further developed, the Tokens, the Token Sale, any future Token functionality and the Available Information and to assess separately the financial risks, consequences and appropriateness of the purchase of Tokens, or if in any doubt about the facts set out in the Available Information. A purchase of Tokens comprises considerable risk and might involve extraordinary risks that may lead to a loss of all or a significant portion of monies or monetary value utilised to acquire Tokens. Participants in the Token Sale are urged to completely understand, be aware of and accept the characteristics of the Company, the CryptoCasino platform that is being further developed, the Tokens, the Token Sale, any future Token functionality and the Available Information. If you are not prepared to accept any or all of these Terms or the risks set out in these Terms then YOU ARE URGED NOT TO PARTICIPATE IN THE TOKEN SALE. No guarantee or assurance is given by the Company or by any of its Affiliates that the Company’s proposals, objectives and/or outcomes set out in the Available Information will be achieved in whole or in part. You are urged to consider whether participation in the Token Sale is suitable for you having regard to your personal and financial circumstances and your financial resources.

**RESTRICTIONS ON DISTRIBUTION AND DISSEMINATION OF  
THE AVAILABLE INFORMATION**

The distribution or dissemination howsoever of all or any part of the Available Information may be prohibited or restricted by the laws, regulatory requirements and rules of certain jurisdictions. In the case where any such restriction applies, you are responsible for informing yourself in respect of the same and for observing any such restrictions which are applicable to your possession and/or dissemination of all or any part of the Available Information at your own expense and without liability to the Company and/or its Affiliates.

Persons to whom a copy of all or any part of the Available Information has been distributed or disseminated, provided access to or who otherwise have all or any part of the Available Information in their possession shall not circulate it to any other persons, reproduce or otherwise distribute any information contained herein for any purpose whatsoever nor permit or cause the same to occur.

**CONTACT INFORMATION**

For any questions, concerns, or feedback regarding these Terms of Use or the Website, please contact us at: [info@cryptocasino.com](mailto:info@cryptocasino.com).

**EFFECTIVE DATE**

These Terms of Use are effective as of August 20, 2024.

Armchair Online BV

Registered office: 9 Abraham de Veerstraat, Willemstad, Curaçao
