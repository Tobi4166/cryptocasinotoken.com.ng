const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/index-CD0hpVXv.js", "assets/index-B7sV4wI7.js", "assets/index-4hOFjoLC.css"]))) => i.map(i => d[i]);
import {
    o as wi,
    w as ko,
    x as yo,
    y as p2,
    d as Wa,
    g as g2,
    z as od,
    G as ku,
    B as m2
} from "./index-B7sV4wI7.js";
import {
    i as v2,
    b as y2,
    a as w2,
    c as b2,
    d as _2,
    e as A2,
    f as E2,
    g as I2,
    h as S2,
    j as x2,
    k as lt,
    l as P2,
    w as i0,
    r as Mc,
    m as M2,
    n as n0,
    o as s0,
    s as Lu,
    x as o0,
    H as C2,
    p as a0,
    q as gc,
    t as N2
} from "./json-BFlzM5yj.js";
import "./___vite-browser-external_commonjs-proxy-C_4t5wKq.js";
var ad = function(r, t, e) {
        if (e || arguments.length === 2)
            for (var n = 0, o = t.length, a; n < o; n++)(a || !(n in t)) && (a || (a = Array.prototype.slice.call(t, 0, n)), a[n] = t[n]);
        return r.concat(a || Array.prototype.slice.call(t))
    },
    R2 = function() {
        function r(t, e, n) {
            this.name = t, this.version = e, this.os = n, this.type = "browser"
        }
        return r
    }(),
    O2 = function() {
        function r(t) {
            this.version = t, this.type = "node", this.name = "node", this.os = process.platform
        }
        return r
    }(),
    T2 = function() {
        function r(t, e, n, o) {
            this.name = t, this.version = e, this.os = n, this.bot = o, this.type = "bot-device"
        }
        return r
    }(),
    D2 = function() {
        function r() {
            this.type = "bot", this.bot = !0, this.name = "bot", this.version = null, this.os = null
        }
        return r
    }(),
    q2 = function() {
        function r() {
            this.type = "react-native", this.name = "react-native", this.version = null, this.os = null
        }
        return r
    }(),
    B2 = /alexa|bot|crawl(er|ing)|facebookexternalhit|feedburner|google web preview|nagios|postrank|pingdom|slurp|spider|yahoo!|yandex/,
    U2 = /(nuhk|curl|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask\ Jeeves\/Teoma|ia_archiver)/,
    cd = 3,
    k2 = [
        ["aol", /AOLShield\/([0-9\._]+)/],
        ["edge", /Edge\/([0-9\._]+)/],
        ["edge-ios", /EdgiOS\/([0-9\._]+)/],
        ["yandexbrowser", /YaBrowser\/([0-9\._]+)/],
        ["kakaotalk", /KAKAOTALK\s([0-9\.]+)/],
        ["samsung", /SamsungBrowser\/([0-9\.]+)/],
        ["silk", /\bSilk\/([0-9._-]+)\b/],
        ["miui", /MiuiBrowser\/([0-9\.]+)$/],
        ["beaker", /BeakerBrowser\/([0-9\.]+)/],
        ["edge-chromium", /EdgA?\/([0-9\.]+)/],
        ["chromium-webview", /(?!Chrom.*OPR)wv\).*Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
        ["chrome", /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
        ["phantomjs", /PhantomJS\/([0-9\.]+)(:?\s|$)/],
        ["crios", /CriOS\/([0-9\.]+)(:?\s|$)/],
        ["firefox", /Firefox\/([0-9\.]+)(?:\s|$)/],
        ["fxios", /FxiOS\/([0-9\.]+)/],
        ["opera-mini", /Opera Mini.*Version\/([0-9\.]+)/],
        ["opera", /Opera\/([0-9\.]+)(?:\s|$)/],
        ["opera", /OPR\/([0-9\.]+)(:?\s|$)/],
        ["pie", /^Microsoft Pocket Internet Explorer\/(\d+\.\d+)$/],
        ["pie", /^Mozilla\/\d\.\d+\s\(compatible;\s(?:MSP?IE|MSInternet Explorer) (\d+\.\d+);.*Windows CE.*\)$/],
        ["netfront", /^Mozilla\/\d\.\d+.*NetFront\/(\d.\d)/],
        ["ie", /Trident\/7\.0.*rv\:([0-9\.]+).*\).*Gecko$/],
        ["ie", /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
        ["ie", /MSIE\s(7\.0)/],
        ["bb10", /BB10;\sTouch.*Version\/([0-9\.]+)/],
        ["android", /Android\s([0-9\.]+)/],
        ["ios", /Version\/([0-9\._]+).*Mobile.*Safari.*/],
        ["safari", /Version\/([0-9\._]+).*Safari/],
        ["facebook", /FB[AS]V\/([0-9\.]+)/],
        ["instagram", /Instagram\s([0-9\.]+)/],
        ["ios-webview", /AppleWebKit\/([0-9\.]+).*Mobile/],
        ["ios-webview", /AppleWebKit\/([0-9\.]+).*Gecko\)$/],
        ["curl", /^curl\/([0-9\.]+)$/],
        ["searchbot", B2]
    ],
    hd = [
        ["iOS", /iP(hone|od|ad)/],
        ["Android OS", /Android/],
        ["BlackBerry OS", /BlackBerry|BB10/],
        ["Windows Mobile", /IEMobile/],
        ["Amazon OS", /Kindle/],
        ["Windows 3.11", /Win16/],
        ["Windows 95", /(Windows 95)|(Win95)|(Windows_95)/],
        ["Windows 98", /(Windows 98)|(Win98)/],
        ["Windows 2000", /(Windows NT 5.0)|(Windows 2000)/],
        ["Windows XP", /(Windows NT 5.1)|(Windows XP)/],
        ["Windows Server 2003", /(Windows NT 5.2)/],
        ["Windows Vista", /(Windows NT 6.0)/],
        ["Windows 7", /(Windows NT 6.1)/],
        ["Windows 8", /(Windows NT 6.2)/],
        ["Windows 8.1", /(Windows NT 6.3)/],
        ["Windows 10", /(Windows NT 10.0)/],
        ["Windows ME", /Windows ME/],
        ["Windows CE", /Windows CE|WinCE|Microsoft Pocket Internet Explorer/],
        ["Open BSD", /OpenBSD/],
        ["Sun OS", /SunOS/],
        ["Chrome OS", /CrOS/],
        ["Linux", /(Linux)|(X11)/],
        ["Mac OS", /(Mac_PowerPC)|(Macintosh)/],
        ["QNX", /QNX/],
        ["BeOS", /BeOS/],
        ["OS/2", /OS\/2/]
    ];

function L2(r) {
    return typeof document > "u" && typeof navigator < "u" && navigator.product === "ReactNative" ? new q2 : typeof navigator < "u" ? j2(navigator.userAgent) : F2()
}

function $2(r) {
    return r !== "" && k2.reduce(function(t, e) {
        var n = e[0],
            o = e[1];
        if (t) return t;
        var a = o.exec(r);
        return !!a && [n, a]
    }, !1)
}

function j2(r) {
    var t = $2(r);
    if (!t) return null;
    var e = t[0],
        n = t[1];
    if (e === "searchbot") return new D2;
    var o = n[1] && n[1].split(".").join("_").split("_").slice(0, 3);
    o ? o.length < cd && (o = ad(ad([], o, !0), H2(cd - o.length), !0)) : o = [];
    var a = o.join("."),
        h = z2(r),
        g = U2.exec(r);
    return g && g[1] ? new T2(e, a, h, g[1]) : new R2(e, a, h)
}

function z2(r) {
    for (var t = 0, e = hd.length; t < e; t++) {
        var n = hd[t],
            o = n[0],
            a = n[1],
            h = a.exec(r);
        if (h) return o
    }
    return null
}

function F2() {
    var r = typeof process < "u" && process.version;
    return r ? new O2(process.version.slice(1)) : null
}

function H2(r) {
    for (var t = [], e = 0; e < r; e++) t.push("0");
    return t
}

function c0(r = 0) {
    return globalThis.Buffer != null && globalThis.Buffer.allocUnsafe != null ? globalThis.Buffer.allocUnsafe(r) : new Uint8Array(r)
}

function _u(r, t) {
    t || (t = r.reduce((o, a) => o + a.length, 0));
    const e = c0(t);
    let n = 0;
    for (const o of r) e.set(o, n), n += o.length;
    return e
}
const ud = { ...v2,
    ...y2,
    ...w2,
    ...b2,
    ..._2,
    ...A2,
    ...E2,
    ...I2,
    ...S2,
    ...x2
};

function h0(r, t, e, n) {
    return {
        name: r,
        prefix: t,
        encoder: {
            name: r,
            prefix: t,
            encode: e
        },
        decoder: {
            decode: n
        }
    }
}
const ld = h0("utf8", "u", r => "u" + new TextDecoder("utf8").decode(r), r => new TextEncoder().encode(r.substring(1))),
    Kh = h0("ascii", "a", r => {
        let t = "a";
        for (let e = 0; e < r.length; e++) t += String.fromCharCode(r[e]);
        return t
    }, r => {
        r = r.substring(1);
        const t = c0(r.length);
        for (let e = 0; e < r.length; e++) t[e] = r.charCodeAt(e);
        return t
    }),
    u0 = {
        utf8: ld,
        "utf-8": ld,
        hex: ud.base16,
        latin1: Kh,
        ascii: Kh,
        binary: Kh,
        ...ud
    };

function $r(r, t = "utf8") {
    const e = u0[t];
    if (!e) throw new Error(`Unsupported encoding "${t}"`);
    return (t === "utf8" || t === "utf-8") && globalThis.Buffer != null && globalThis.Buffer.from != null ? globalThis.Buffer.from(r, "utf8") : e.decoder.decode(`${e.prefix}${r}`)
}

function Pr(r, t = "utf8") {
    const e = u0[t];
    if (!e) throw new Error(`Unsupported encoding "${t}"`);
    return (t === "utf8" || t === "utf-8") && globalThis.Buffer != null && globalThis.Buffer.from != null ? globalThis.Buffer.from(r.buffer, r.byteOffset, r.byteLength).toString("utf8") : e.encoder.encode(r).substring(1)
}
const K2 = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/,
    V2 = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/,
    G2 = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;

function Q2(r, t) {
    if (r === "__proto__" || r === "constructor" && t && typeof t == "object" && "prototype" in t) {
        W2(r);
        return
    }
    return t
}

function W2(r) {
    console.warn(`[destr] Dropping "${r}" key to prevent prototype pollution.`)
}

function Ja(r, t = {}) {
    if (typeof r != "string") return r;
    const e = r.trim();
    if (r[0] === '"' && r.endsWith('"') && !r.includes("\\")) return e.slice(1, -1);
    if (e.length <= 9) {
        const n = e.toLowerCase();
        if (n === "true") return !0;
        if (n === "false") return !1;
        if (n === "undefined") return;
        if (n === "null") return null;
        if (n === "nan") return Number.NaN;
        if (n === "infinity") return Number.POSITIVE_INFINITY;
        if (n === "-infinity") return Number.NEGATIVE_INFINITY
    }
    if (!G2.test(r)) {
        if (t.strict) throw new SyntaxError("[destr] Invalid JSON");
        return r
    }
    try {
        if (K2.test(r) || V2.test(r)) {
            if (t.strict) throw new Error("[destr] Possible prototype pollution");
            return JSON.parse(r, Q2)
        }
        return JSON.parse(r)
    } catch (n) {
        if (t.strict) throw n;
        return r
    }
}

function J2(r) {
    return !r || typeof r.then != "function" ? Promise.resolve(r) : r
}

function cr(r, ...t) {
    try {
        return J2(r(...t))
    } catch (e) {
        return Promise.reject(e)
    }
}

function Y2(r) {
    const t = typeof r;
    return r === null || t !== "object" && t !== "function"
}

function X2(r) {
    const t = Object.getPrototypeOf(r);
    return !t || t.isPrototypeOf(Object)
}

function oc(r) {
    if (Y2(r)) return String(r);
    if (X2(r) || Array.isArray(r)) return JSON.stringify(r);
    if (typeof r.toJSON == "function") return oc(r.toJSON());
    throw new Error("[unstorage] Cannot stringify value!")
}

function l0() {
    if (typeof Buffer === void 0) throw new TypeError("[unstorage] Buffer is not supported!")
}
const Au = "base64:";

function Z2(r) {
    if (typeof r == "string") return r;
    l0();
    const t = Buffer.from(r).toString("base64");
    return Au + t
}

function t6(r) {
    return typeof r != "string" || !r.startsWith(Au) ? r : (l0(), Buffer.from(r.slice(Au.length), "base64"))
}

function qr(r) {
    return r ? r.split("?")[0].replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") : ""
}

function e6(...r) {
    return qr(r.join(":"))
}

function Ya(r) {
    return r = qr(r), r ? r + ":" : ""
}
const r6 = "memory",
    i6 = () => {
        const r = new Map;
        return {
            name: r6,
            options: {},
            hasItem(t) {
                return r.has(t)
            },
            getItem(t) {
                return r.get(t) ? ? null
            },
            getItemRaw(t) {
                return r.get(t) ? ? null
            },
            setItem(t, e) {
                r.set(t, e)
            },
            setItemRaw(t, e) {
                r.set(t, e)
            },
            removeItem(t) {
                r.delete(t)
            },
            getKeys() {
                return Array.from(r.keys())
            },
            clear() {
                r.clear()
            },
            dispose() {
                r.clear()
            }
        }
    };

function n6(r = {}) {
    const t = {
            mounts: {
                "": r.driver || i6()
            },
            mountpoints: [""],
            watching: !1,
            watchListeners: [],
            unwatch: {}
        },
        e = m => {
            for (const _ of t.mountpoints)
                if (m.startsWith(_)) return {
                    base: _,
                    relativeKey: m.slice(_.length),
                    driver: t.mounts[_]
                };
            return {
                base: "",
                relativeKey: m,
                driver: t.mounts[""]
            }
        },
        n = (m, _) => t.mountpoints.filter(S => S.startsWith(m) || _ && m.startsWith(S)).map(S => ({
            relativeBase: m.length > S.length ? m.slice(S.length) : void 0,
            mountpoint: S,
            driver: t.mounts[S]
        })),
        o = (m, _) => {
            if (t.watching) {
                _ = qr(_);
                for (const S of t.watchListeners) S(m, _)
            }
        },
        a = async () => {
            if (!t.watching) {
                t.watching = !0;
                for (const m in t.mounts) t.unwatch[m] = await fd(t.mounts[m], o, m)
            }
        },
        h = async () => {
            if (t.watching) {
                for (const m in t.unwatch) await t.unwatch[m]();
                t.unwatch = {}, t.watching = !1
            }
        },
        g = (m, _, S) => {
            const B = new Map,
                k = L => {
                    let K = B.get(L.base);
                    return K || (K = {
                        driver: L.driver,
                        base: L.base,
                        items: []
                    }, B.set(L.base, K)), K
                };
            for (const L of m) {
                const K = typeof L == "string",
                    Q = qr(K ? L : L.key),
                    et = K ? void 0 : L.value,
                    at = K || !L.options ? _ : { ..._,
                        ...L.options
                    },
                    ut = e(Q);
                k(ut).items.push({
                    key: Q,
                    value: et,
                    relativeKey: ut.relativeKey,
                    options: at
                })
            }
            return Promise.all([...B.values()].map(L => S(L))).then(L => L.flat())
        },
        b = {
            hasItem(m, _ = {}) {
                m = qr(m);
                const {
                    relativeKey: S,
                    driver: B
                } = e(m);
                return cr(B.hasItem, S, _)
            },
            getItem(m, _ = {}) {
                m = qr(m);
                const {
                    relativeKey: S,
                    driver: B
                } = e(m);
                return cr(B.getItem, S, _).then(k => Ja(k))
            },
            getItems(m, _) {
                return g(m, _, S => S.driver.getItems ? cr(S.driver.getItems, S.items.map(B => ({
                    key: B.relativeKey,
                    options: B.options
                })), _).then(B => B.map(k => ({
                    key: e6(S.base, k.key),
                    value: Ja(k.value)
                }))) : Promise.all(S.items.map(B => cr(S.driver.getItem, B.relativeKey, B.options).then(k => ({
                    key: B.key,
                    value: Ja(k)
                })))))
            },
            getItemRaw(m, _ = {}) {
                m = qr(m);
                const {
                    relativeKey: S,
                    driver: B
                } = e(m);
                return B.getItemRaw ? cr(B.getItemRaw, S, _) : cr(B.getItem, S, _).then(k => t6(k))
            },
            async setItem(m, _, S = {}) {
                if (_ === void 0) return b.removeItem(m);
                m = qr(m);
                const {
                    relativeKey: B,
                    driver: k
                } = e(m);
                k.setItem && (await cr(k.setItem, B, oc(_), S), k.watch || o("update", m))
            },
            async setItems(m, _) {
                await g(m, _, async S => {
                    if (S.driver.setItems) return cr(S.driver.setItems, S.items.map(B => ({
                        key: B.relativeKey,
                        value: oc(B.value),
                        options: B.options
                    })), _);
                    S.driver.setItem && await Promise.all(S.items.map(B => cr(S.driver.setItem, B.relativeKey, oc(B.value), B.options)))
                })
            },
            async setItemRaw(m, _, S = {}) {
                if (_ === void 0) return b.removeItem(m, S);
                m = qr(m);
                const {
                    relativeKey: B,
                    driver: k
                } = e(m);
                if (k.setItemRaw) await cr(k.setItemRaw, B, _, S);
                else if (k.setItem) await cr(k.setItem, B, Z2(_), S);
                else return;
                k.watch || o("update", m)
            },
            async removeItem(m, _ = {}) {
                typeof _ == "boolean" && (_ = {
                    removeMeta: _
                }), m = qr(m);
                const {
                    relativeKey: S,
                    driver: B
                } = e(m);
                B.removeItem && (await cr(B.removeItem, S, _), (_.removeMeta || _.removeMata) && await cr(B.removeItem, S + "$", _), B.watch || o("remove", m))
            },
            async getMeta(m, _ = {}) {
                typeof _ == "boolean" && (_ = {
                    nativeOnly: _
                }), m = qr(m);
                const {
                    relativeKey: S,
                    driver: B
                } = e(m), k = Object.create(null);
                if (B.getMeta && Object.assign(k, await cr(B.getMeta, S, _)), !_.nativeOnly) {
                    const L = await cr(B.getItem, S + "$", _).then(K => Ja(K));
                    L && typeof L == "object" && (typeof L.atime == "string" && (L.atime = new Date(L.atime)), typeof L.mtime == "string" && (L.mtime = new Date(L.mtime)), Object.assign(k, L))
                }
                return k
            },
            setMeta(m, _, S = {}) {
                return this.setItem(m + "$", _, S)
            },
            removeMeta(m, _ = {}) {
                return this.removeItem(m + "$", _)
            },
            async getKeys(m, _ = {}) {
                m = Ya(m);
                const S = n(m, !0);
                let B = [];
                const k = [];
                for (const L of S) {
                    const Q = (await cr(L.driver.getKeys, L.relativeBase, _)).map(et => L.mountpoint + qr(et)).filter(et => !B.some(at => et.startsWith(at)));
                    k.push(...Q), B = [L.mountpoint, ...B.filter(et => !et.startsWith(L.mountpoint))]
                }
                return m ? k.filter(L => L.startsWith(m) && !L.endsWith("$")) : k.filter(L => !L.endsWith("$"))
            },
            async clear(m, _ = {}) {
                m = Ya(m), await Promise.all(n(m, !1).map(async S => {
                    if (S.driver.clear) return cr(S.driver.clear, S.relativeBase, _);
                    if (S.driver.removeItem) {
                        const B = await S.driver.getKeys(S.relativeBase || "", _);
                        return Promise.all(B.map(k => S.driver.removeItem(k, _)))
                    }
                }))
            },
            async dispose() {
                await Promise.all(Object.values(t.mounts).map(m => dd(m)))
            },
            async watch(m) {
                return await a(), t.watchListeners.push(m), async () => {
                    t.watchListeners = t.watchListeners.filter(_ => _ !== m), t.watchListeners.length === 0 && await h()
                }
            },
            async unwatch() {
                t.watchListeners = [], await h()
            },
            mount(m, _) {
                if (m = Ya(m), m && t.mounts[m]) throw new Error(`already mounted at ${m}`);
                return m && (t.mountpoints.push(m), t.mountpoints.sort((S, B) => B.length - S.length)), t.mounts[m] = _, t.watching && Promise.resolve(fd(_, o, m)).then(S => {
                    t.unwatch[m] = S
                }).catch(console.error), b
            },
            async unmount(m, _ = !0) {
                m = Ya(m), !(!m || !t.mounts[m]) && (t.watching && m in t.unwatch && (t.unwatch[m](), delete t.unwatch[m]), _ && await dd(t.mounts[m]), t.mountpoints = t.mountpoints.filter(S => S !== m), delete t.mounts[m])
            },
            getMount(m = "") {
                m = qr(m) + ":";
                const _ = e(m);
                return {
                    driver: _.driver,
                    base: _.base
                }
            },
            getMounts(m = "", _ = {}) {
                return m = qr(m), n(m, _.parents).map(B => ({
                    driver: B.driver,
                    base: B.mountpoint
                }))
            }
        };
    return b
}

function fd(r, t, e) {
    return r.watch ? r.watch((n, o) => t(n, e + o)) : () => {}
}
async function dd(r) {
    typeof r.dispose == "function" && await cr(r.dispose)
}

function fs(r) {
    return new Promise((t, e) => {
        r.oncomplete = r.onsuccess = () => t(r.result), r.onabort = r.onerror = () => e(r.error)
    })
}

function f0(r, t) {
    const e = indexedDB.open(r);
    e.onupgradeneeded = () => e.result.createObjectStore(t);
    const n = fs(e);
    return (o, a) => n.then(h => a(h.transaction(t, o).objectStore(t)))
}
let Vh;

function Lo() {
    return Vh || (Vh = f0("keyval-store", "keyval")), Vh
}

function pd(r, t = Lo()) {
    return t("readonly", e => fs(e.get(r)))
}

function s6(r, t, e = Lo()) {
    return e("readwrite", n => (n.put(t, r), fs(n.transaction)))
}

function o6(r, t = Lo()) {
    return t("readwrite", e => (e.delete(r), fs(e.transaction)))
}

function a6(r = Lo()) {
    return r("readwrite", t => (t.clear(), fs(t.transaction)))
}

function c6(r, t) {
    return r.openCursor().onsuccess = function() {
        this.result && (t(this.result), this.result.continue())
    }, fs(r.transaction)
}

function h6(r = Lo()) {
    return r("readonly", t => {
        if (t.getAllKeys) return fs(t.getAllKeys());
        const e = [];
        return c6(t, n => e.push(n.key)).then(() => e)
    })
}
const u6 = r => JSON.stringify(r, (t, e) => typeof e == "bigint" ? e.toString() + "n" : e),
    l6 = r => {
        const t = /([\[:])?(\d{17,}|(?:[9](?:[1-9]07199254740991|0[1-9]7199254740991|00[8-9]199254740991|007[2-9]99254740991|007199[3-9]54740991|0071992[6-9]4740991|00719925[5-9]740991|007199254[8-9]40991|0071992547[5-9]0991|00719925474[1-9]991|00719925474099[2-9])))([,\}\]])/g,
            e = r.replace(t, '$1"$2n"$3');
        return JSON.parse(e, (n, o) => typeof o == "string" && o.match(/^\d+n$/) ? BigInt(o.substring(0, o.length - 1)) : o)
    };

function $o(r) {
    if (typeof r != "string") throw new Error(`Cannot safe json parse value of type ${typeof r}`);
    try {
        return l6(r)
    } catch {
        return r
    }
}

function wn(r) {
    return typeof r == "string" ? r : u6(r) || ""
}
const f6 = "idb-keyval";
var d6 = (r = {}) => {
    const t = r.base && r.base.length > 0 ? `${r.base}:` : "",
        e = o => t + o;
    let n;
    return r.dbName && r.storeName && (n = f0(r.dbName, r.storeName)), {
        name: f6,
        options: r,
        async hasItem(o) {
            return !(typeof await pd(e(o), n) > "u")
        },
        async getItem(o) {
            return await pd(e(o), n) ? ? null
        },
        setItem(o, a) {
            return s6(e(o), a, n)
        },
        removeItem(o) {
            return o6(e(o), n)
        },
        getKeys() {
            return h6(n)
        },
        clear() {
            return a6(n)
        }
    }
};
const p6 = "WALLET_CONNECT_V2_INDEXED_DB",
    g6 = "keyvaluestorage";
let m6 = class {
    constructor() {
        this.indexedDb = n6({
            driver: d6({
                dbName: p6,
                storeName: g6
            })
        })
    }
    async getKeys() {
        return this.indexedDb.getKeys()
    }
    async getEntries() {
        return (await this.indexedDb.getItems(await this.indexedDb.getKeys())).map(t => [t.key, t.value])
    }
    async getItem(t) {
        const e = await this.indexedDb.getItem(t);
        if (e !== null) return e
    }
    async setItem(t, e) {
        await this.indexedDb.setItem(t, wn(e))
    }
    async removeItem(t) {
        await this.indexedDb.removeItem(t)
    }
};
var Gh = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    ac = {
        exports: {}
    };
(function() {
    let r;

    function t() {}
    r = t, r.prototype.getItem = function(e) {
        return this.hasOwnProperty(e) ? String(this[e]) : null
    }, r.prototype.setItem = function(e, n) {
        this[e] = String(n)
    }, r.prototype.removeItem = function(e) {
        delete this[e]
    }, r.prototype.clear = function() {
        const e = this;
        Object.keys(e).forEach(function(n) {
            e[n] = void 0, delete e[n]
        })
    }, r.prototype.key = function(e) {
        return e = e || 0, Object.keys(this)[e]
    }, r.prototype.__defineGetter__("length", function() {
        return Object.keys(this).length
    }), typeof Gh < "u" && Gh.localStorage ? ac.exports = Gh.localStorage : typeof window < "u" && window.localStorage ? ac.exports = window.localStorage : ac.exports = new t
})();

function v6(r) {
    var t;
    return [r[0], $o((t = r[1]) != null ? t : "")]
}
let y6 = class {
    constructor() {
        this.localStorage = ac.exports
    }
    async getKeys() {
        return Object.keys(this.localStorage)
    }
    async getEntries() {
        return Object.entries(this.localStorage).map(v6)
    }
    async getItem(t) {
        const e = this.localStorage.getItem(t);
        if (e !== null) return $o(e)
    }
    async setItem(t, e) {
        this.localStorage.setItem(t, wn(e))
    }
    async removeItem(t) {
        this.localStorage.removeItem(t)
    }
};
const w6 = "wc_storage_version",
    gd = 1,
    b6 = async (r, t, e) => {
        const n = w6,
            o = await t.getItem(n);
        if (o && o >= gd) {
            e(t);
            return
        }
        const a = await r.getKeys();
        if (!a.length) {
            e(t);
            return
        }
        const h = [];
        for (; a.length;) {
            const g = a.shift();
            if (!g) continue;
            const b = g.toLowerCase();
            if (b.includes("wc@") || b.includes("walletconnect") || b.includes("wc_") || b.includes("wallet_connect")) {
                const m = await r.getItem(g);
                await t.setItem(g, m), h.push(g)
            }
        }
        await t.setItem(n, gd), e(t), _6(r, h)
    },
    _6 = async (r, t) => {
        t.length && t.forEach(async e => {
            await r.removeItem(e)
        })
    };
let A6 = class {
    constructor() {
        this.initialized = !1, this.setInitialized = e => {
            this.storage = e, this.initialized = !0
        };
        const t = new y6;
        this.storage = t;
        try {
            const e = new m6;
            b6(t, e, this.setInitialized)
        } catch {
            this.initialized = !0
        }
    }
    async getKeys() {
        return await this.initialize(), this.storage.getKeys()
    }
    async getEntries() {
        return await this.initialize(), this.storage.getEntries()
    }
    async getItem(t) {
        return await this.initialize(), this.storage.getItem(t)
    }
    async setItem(t, e) {
        return await this.initialize(), this.storage.setItem(t, e)
    }
    async removeItem(t) {
        return await this.initialize(), this.storage.removeItem(t)
    }
    async initialize() {
        this.initialized || await new Promise(t => {
            const e = setInterval(() => {
                this.initialized && (clearInterval(e), t())
            }, 20)
        })
    }
};
class ds {}
let E6 = class extends ds {
    constructor(t) {
        super()
    }
};
const md = lt.FIVE_SECONDS,
    jo = {
        pulse: "heartbeat_pulse"
    };
let I6 = class d0 extends E6 {
    constructor(t) {
        super(t), this.events = new wi.EventEmitter, this.interval = md, this.interval = (t == null ? void 0 : t.interval) || md
    }
    static async init(t) {
        const e = new d0(t);
        return await e.init(), e
    }
    async init() {
        await this.initialize()
    }
    stop() {
        clearInterval(this.intervalRef)
    }
    on(t, e) {
        this.events.on(t, e)
    }
    once(t, e) {
        this.events.once(t, e)
    }
    off(t, e) {
        this.events.off(t, e)
    }
    removeListener(t, e) {
        this.events.removeListener(t, e)
    }
    async initialize() {
        this.intervalRef = setInterval(() => this.pulse(), lt.toMiliseconds(this.interval))
    }
    pulse() {
        this.events.emit(jo.pulse)
    }
};
const S6 = {
        level: "info"
    },
    zo = "custom_context",
    $u = 1e3 * 1024;
let x6 = class {
        constructor(t) {
            this.nodeValue = t, this.sizeInBytes = new TextEncoder().encode(this.nodeValue).length, this.next = null
        }
        get value() {
            return this.nodeValue
        }
        get size() {
            return this.sizeInBytes
        }
    },
    vd = class {
        constructor(t) {
            this.head = null, this.tail = null, this.lengthInNodes = 0, this.maxSizeInBytes = t, this.sizeInBytes = 0
        }
        append(t) {
            const e = new x6(t);
            if (e.size > this.maxSizeInBytes) throw new Error(`[LinkedList] Value too big to insert into list: ${t} with size ${e.size}`);
            for (; this.size + e.size > this.maxSizeInBytes;) this.shift();
            this.head ? (this.tail && (this.tail.next = e), this.tail = e) : (this.head = e, this.tail = e), this.lengthInNodes++, this.sizeInBytes += e.size
        }
        shift() {
            if (!this.head) return;
            const t = this.head;
            this.head = this.head.next, this.head || (this.tail = null), this.lengthInNodes--, this.sizeInBytes -= t.size
        }
        toArray() {
            const t = [];
            let e = this.head;
            for (; e !== null;) t.push(e.value), e = e.next;
            return t
        }
        get length() {
            return this.lengthInNodes
        }
        get size() {
            return this.sizeInBytes
        }
        toOrderedArray() {
            return Array.from(this)
        }[Symbol.iterator]() {
            let t = this.head;
            return {
                next: () => {
                    if (!t) return {
                        done: !0,
                        value: null
                    };
                    const e = t.value;
                    return t = t.next, {
                        done: !1,
                        value: e
                    }
                }
            }
        }
    },
    p0 = class {
        constructor(t, e = $u) {
            this.level = t ? ? "error", this.levelValue = yo.levels.values[this.level], this.MAX_LOG_SIZE_IN_BYTES = e, this.logs = new vd(this.MAX_LOG_SIZE_IN_BYTES)
        }
        forwardToConsole(t, e) {
            e === yo.levels.values.error ? console.error(t) : e === yo.levels.values.warn ? console.warn(t) : e === yo.levels.values.debug ? console.debug(t) : e === yo.levels.values.trace ? console.trace(t) : console.log(t)
        }
        appendToLogs(t) {
            this.logs.append(wn({
                timestamp: new Date().toISOString(),
                log: t
            }));
            const e = typeof t == "string" ? JSON.parse(t).level : t.level;
            e >= this.levelValue && this.forwardToConsole(t, e)
        }
        getLogs() {
            return this.logs
        }
        clearLogs() {
            this.logs = new vd(this.MAX_LOG_SIZE_IN_BYTES)
        }
        getLogArray() {
            return Array.from(this.logs)
        }
        logsToBlob(t) {
            const e = this.getLogArray();
            return e.push(wn({
                extraMetadata: t
            })), new Blob(e, {
                type: "application/json"
            })
        }
    },
    P6 = class {
        constructor(t, e = $u) {
            this.baseChunkLogger = new p0(t, e)
        }
        write(t) {
            this.baseChunkLogger.appendToLogs(t)
        }
        getLogs() {
            return this.baseChunkLogger.getLogs()
        }
        clearLogs() {
            this.baseChunkLogger.clearLogs()
        }
        getLogArray() {
            return this.baseChunkLogger.getLogArray()
        }
        logsToBlob(t) {
            return this.baseChunkLogger.logsToBlob(t)
        }
        downloadLogsBlobInBrowser(t) {
            const e = URL.createObjectURL(this.logsToBlob(t)),
                n = document.createElement("a");
            n.href = e, n.download = `walletconnect-logs-${new Date().toISOString()}.txt`, document.body.appendChild(n), n.click(), document.body.removeChild(n), URL.revokeObjectURL(e)
        }
    },
    M6 = class {
        constructor(t, e = $u) {
            this.baseChunkLogger = new p0(t, e)
        }
        write(t) {
            this.baseChunkLogger.appendToLogs(t)
        }
        getLogs() {
            return this.baseChunkLogger.getLogs()
        }
        clearLogs() {
            this.baseChunkLogger.clearLogs()
        }
        getLogArray() {
            return this.baseChunkLogger.getLogArray()
        }
        logsToBlob(t) {
            return this.baseChunkLogger.logsToBlob(t)
        }
    };
var C6 = Object.defineProperty,
    N6 = Object.defineProperties,
    R6 = Object.getOwnPropertyDescriptors,
    yd = Object.getOwnPropertySymbols,
    O6 = Object.prototype.hasOwnProperty,
    T6 = Object.prototype.propertyIsEnumerable,
    wd = (r, t, e) => t in r ? C6(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    mc = (r, t) => {
        for (var e in t || (t = {})) O6.call(t, e) && wd(r, e, t[e]);
        if (yd)
            for (var e of yd(t)) T6.call(t, e) && wd(r, e, t[e]);
        return r
    },
    vc = (r, t) => N6(r, R6(t));

function Cc(r) {
    return vc(mc({}, r), {
        level: (r == null ? void 0 : r.level) || S6.level
    })
}

function D6(r, t = zo) {
    return r[t] || ""
}

function q6(r, t, e = zo) {
    return r[e] = t, r
}

function zr(r, t = zo) {
    let e = "";
    return typeof r.bindings > "u" ? e = D6(r, t) : e = r.bindings().context || "", e
}

function B6(r, t, e = zo) {
    const n = zr(r, e);
    return n.trim() ? `${n}/${t}` : t
}

function Fr(r, t, e = zo) {
    const n = B6(r, t, e),
        o = r.child({
            context: n
        });
    return q6(o, n, e)
}

function U6(r) {
    var t, e;
    const n = new P6((t = r.opts) == null ? void 0 : t.level, r.maxSizeInBytes);
    return {
        logger: ko(vc(mc({}, r.opts), {
            level: "trace",
            browser: vc(mc({}, (e = r.opts) == null ? void 0 : e.browser), {
                write: o => n.write(o)
            })
        })),
        chunkLoggerController: n
    }
}

function k6(r) {
    var t;
    const e = new M6((t = r.opts) == null ? void 0 : t.level, r.maxSizeInBytes);
    return {
        logger: ko(vc(mc({}, r.opts), {
            level: "trace"
        }), e),
        chunkLoggerController: e
    }
}

function L6(r) {
    return typeof r.loggerOverride < "u" && typeof r.loggerOverride != "string" ? {
        logger: r.loggerOverride,
        chunkLoggerController: null
    } : typeof window < "u" ? U6(r) : k6(r)
}
var ju = {},
    g0 = {};
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var t = P2,
        e = i0;
    r.DIGEST_LENGTH = 64, r.BLOCK_SIZE = 128;
    var n = function() {
        function g() {
            this.digestLength = r.DIGEST_LENGTH, this.blockSize = r.BLOCK_SIZE, this._stateHi = new Int32Array(8), this._stateLo = new Int32Array(8), this._tempHi = new Int32Array(16), this._tempLo = new Int32Array(16), this._buffer = new Uint8Array(256), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this.reset()
        }
        return g.prototype._initState = function() {
            this._stateHi[0] = 1779033703, this._stateHi[1] = 3144134277, this._stateHi[2] = 1013904242, this._stateHi[3] = 2773480762, this._stateHi[4] = 1359893119, this._stateHi[5] = 2600822924, this._stateHi[6] = 528734635, this._stateHi[7] = 1541459225, this._stateLo[0] = 4089235720, this._stateLo[1] = 2227873595, this._stateLo[2] = 4271175723, this._stateLo[3] = 1595750129, this._stateLo[4] = 2917565137, this._stateLo[5] = 725511199, this._stateLo[6] = 4215389547, this._stateLo[7] = 327033209
        }, g.prototype.reset = function() {
            return this._initState(), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this
        }, g.prototype.clean = function() {
            e.wipe(this._buffer), e.wipe(this._tempHi), e.wipe(this._tempLo), this.reset()
        }, g.prototype.update = function(b, m) {
            if (m === void 0 && (m = b.length), this._finished) throw new Error("SHA512: can't update because hash was finished.");
            var _ = 0;
            if (this._bytesHashed += m, this._bufferLength > 0) {
                for (; this._bufferLength < r.BLOCK_SIZE && m > 0;) this._buffer[this._bufferLength++] = b[_++], m--;
                this._bufferLength === this.blockSize && (a(this._tempHi, this._tempLo, this._stateHi, this._stateLo, this._buffer, 0, this.blockSize), this._bufferLength = 0)
            }
            for (m >= this.blockSize && (_ = a(this._tempHi, this._tempLo, this._stateHi, this._stateLo, b, _, m), m %= this.blockSize); m > 0;) this._buffer[this._bufferLength++] = b[_++], m--;
            return this
        }, g.prototype.finish = function(b) {
            if (!this._finished) {
                var m = this._bytesHashed,
                    _ = this._bufferLength,
                    S = m / 536870912 | 0,
                    B = m << 3,
                    k = m % 128 < 112 ? 128 : 256;
                this._buffer[_] = 128;
                for (var L = _ + 1; L < k - 8; L++) this._buffer[L] = 0;
                t.writeUint32BE(S, this._buffer, k - 8), t.writeUint32BE(B, this._buffer, k - 4), a(this._tempHi, this._tempLo, this._stateHi, this._stateLo, this._buffer, 0, k), this._finished = !0
            }
            for (var L = 0; L < this.digestLength / 8; L++) t.writeUint32BE(this._stateHi[L], b, L * 8), t.writeUint32BE(this._stateLo[L], b, L * 8 + 4);
            return this
        }, g.prototype.digest = function() {
            var b = new Uint8Array(this.digestLength);
            return this.finish(b), b
        }, g.prototype.saveState = function() {
            if (this._finished) throw new Error("SHA256: cannot save finished state");
            return {
                stateHi: new Int32Array(this._stateHi),
                stateLo: new Int32Array(this._stateLo),
                buffer: this._bufferLength > 0 ? new Uint8Array(this._buffer) : void 0,
                bufferLength: this._bufferLength,
                bytesHashed: this._bytesHashed
            }
        }, g.prototype.restoreState = function(b) {
            return this._stateHi.set(b.stateHi), this._stateLo.set(b.stateLo), this._bufferLength = b.bufferLength, b.buffer && this._buffer.set(b.buffer), this._bytesHashed = b.bytesHashed, this._finished = !1, this
        }, g.prototype.cleanSavedState = function(b) {
            e.wipe(b.stateHi), e.wipe(b.stateLo), b.buffer && e.wipe(b.buffer), b.bufferLength = 0, b.bytesHashed = 0
        }, g
    }();
    r.SHA512 = n;
    var o = new Int32Array([1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591]);

    function a(g, b, m, _, S, B, k) {
        for (var L = m[0], K = m[1], Q = m[2], et = m[3], at = m[4], ut = m[5], ft = m[6], st = m[7], ot = _[0], it = _[1], mt = _[2], Zt = _[3], oe = _[4], Tt = _[5], ve = _[6], u = _[7], p, v, P, C, R, T, E, f; k >= 128;) {
            for (var x = 0; x < 16; x++) {
                var ht = 8 * x + B;
                g[x] = t.readUint32BE(S, ht), b[x] = t.readUint32BE(S, ht + 4)
            }
            for (var x = 0; x < 80; x++) {
                var gt = L,
                    y = K,
                    V = Q,
                    O = et,
                    D = at,
                    U = ut,
                    d = ft,
                    N = st,
                    W = ot,
                    rt = it,
                    Z = mt,
                    wt = Zt,
                    bt = oe,
                    vt = Tt,
                    Re = ve,
                    Lt = u;
                if (p = st, v = u, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = (at >>> 14 | oe << 18) ^ (at >>> 18 | oe << 14) ^ (oe >>> 9 | at << 23), v = (oe >>> 14 | at << 18) ^ (oe >>> 18 | at << 14) ^ (at >>> 9 | oe << 23), R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, p = at & ut ^ ~at & ft, v = oe & Tt ^ ~oe & ve, R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, p = o[x * 2], v = o[x * 2 + 1], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, p = g[x % 16], v = b[x % 16], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, P = E & 65535 | f << 16, C = R & 65535 | T << 16, p = P, v = C, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = (L >>> 28 | ot << 4) ^ (ot >>> 2 | L << 30) ^ (ot >>> 7 | L << 25), v = (ot >>> 28 | L << 4) ^ (L >>> 2 | ot << 30) ^ (L >>> 7 | ot << 25), R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, p = L & K ^ L & Q ^ K & Q, v = ot & it ^ ot & mt ^ it & mt, R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, N = E & 65535 | f << 16, Lt = R & 65535 | T << 16, p = O, v = wt, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = P, v = C, R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, O = E & 65535 | f << 16, wt = R & 65535 | T << 16, K = gt, Q = y, et = V, at = O, ut = D, ft = U, st = d, L = N, it = W, mt = rt, Zt = Z, oe = wt, Tt = bt, ve = vt, u = Re, ot = Lt, x % 16 === 15)
                    for (var ht = 0; ht < 16; ht++) p = g[ht], v = b[ht], R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = g[(ht + 9) % 16], v = b[(ht + 9) % 16], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, P = g[(ht + 1) % 16], C = b[(ht + 1) % 16], p = (P >>> 1 | C << 31) ^ (P >>> 8 | C << 24) ^ P >>> 7, v = (C >>> 1 | P << 31) ^ (C >>> 8 | P << 24) ^ (C >>> 7 | P << 25), R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, P = g[(ht + 14) % 16], C = b[(ht + 14) % 16], p = (P >>> 19 | C << 13) ^ (C >>> 29 | P << 3) ^ P >>> 6, v = (C >>> 19 | P << 13) ^ (P >>> 29 | C << 3) ^ (C >>> 6 | P << 26), R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, g[ht] = E & 65535 | f << 16, b[ht] = R & 65535 | T << 16
            }
            p = L, v = ot, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[0], v = _[0], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[0] = L = E & 65535 | f << 16, _[0] = ot = R & 65535 | T << 16, p = K, v = it, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[1], v = _[1], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[1] = K = E & 65535 | f << 16, _[1] = it = R & 65535 | T << 16, p = Q, v = mt, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[2], v = _[2], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[2] = Q = E & 65535 | f << 16, _[2] = mt = R & 65535 | T << 16, p = et, v = Zt, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[3], v = _[3], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[3] = et = E & 65535 | f << 16, _[3] = Zt = R & 65535 | T << 16, p = at, v = oe, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[4], v = _[4], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[4] = at = E & 65535 | f << 16, _[4] = oe = R & 65535 | T << 16, p = ut, v = Tt, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[5], v = _[5], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[5] = ut = E & 65535 | f << 16, _[5] = Tt = R & 65535 | T << 16, p = ft, v = ve, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[6], v = _[6], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[6] = ft = E & 65535 | f << 16, _[6] = ve = R & 65535 | T << 16, p = st, v = u, R = v & 65535, T = v >>> 16, E = p & 65535, f = p >>> 16, p = m[7], v = _[7], R += v & 65535, T += v >>> 16, E += p & 65535, f += p >>> 16, T += R >>> 16, E += T >>> 16, f += E >>> 16, m[7] = st = E & 65535 | f << 16, _[7] = u = R & 65535 | T << 16, B += 128, k -= 128
        }
        return B
    }

    function h(g) {
        var b = new n;
        b.update(g);
        var m = b.digest();
        return b.clean(), m
    }
    r.hash = h
})(g0);
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.convertSecretKeyToX25519 = r.convertPublicKeyToX25519 = r.verify = r.sign = r.extractPublicKeyFromSecretKey = r.generateKeyPair = r.generateKeyPairFromSeed = r.SEED_LENGTH = r.SECRET_KEY_LENGTH = r.PUBLIC_KEY_LENGTH = r.SIGNATURE_LENGTH = void 0;
    const t = Mc,
        e = g0,
        n = i0;
    r.SIGNATURE_LENGTH = 64, r.PUBLIC_KEY_LENGTH = 32, r.SECRET_KEY_LENGTH = 64, r.SEED_LENGTH = 32;

    function o(O) {
        const D = new Float64Array(16);
        if (O)
            for (let U = 0; U < O.length; U++) D[U] = O[U];
        return D
    }
    const a = new Uint8Array(32);
    a[0] = 9;
    const h = o(),
        g = o([1]),
        b = o([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]),
        m = o([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]),
        _ = o([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]),
        S = o([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]),
        B = o([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);

    function k(O, D) {
        for (let U = 0; U < 16; U++) O[U] = D[U] | 0
    }

    function L(O) {
        let D = 1;
        for (let U = 0; U < 16; U++) {
            let d = O[U] + D + 65535;
            D = Math.floor(d / 65536), O[U] = d - D * 65536
        }
        O[0] += D - 1 + 37 * (D - 1)
    }

    function K(O, D, U) {
        const d = ~(U - 1);
        for (let N = 0; N < 16; N++) {
            const W = d & (O[N] ^ D[N]);
            O[N] ^= W, D[N] ^= W
        }
    }

    function Q(O, D) {
        const U = o(),
            d = o();
        for (let N = 0; N < 16; N++) d[N] = D[N];
        L(d), L(d), L(d);
        for (let N = 0; N < 2; N++) {
            U[0] = d[0] - 65517;
            for (let rt = 1; rt < 15; rt++) U[rt] = d[rt] - 65535 - (U[rt - 1] >> 16 & 1), U[rt - 1] &= 65535;
            U[15] = d[15] - 32767 - (U[14] >> 16 & 1);
            const W = U[15] >> 16 & 1;
            U[14] &= 65535, K(d, U, 1 - W)
        }
        for (let N = 0; N < 16; N++) O[2 * N] = d[N] & 255, O[2 * N + 1] = d[N] >> 8
    }

    function et(O, D) {
        let U = 0;
        for (let d = 0; d < 32; d++) U |= O[d] ^ D[d];
        return (1 & U - 1 >>> 8) - 1
    }

    function at(O, D) {
        const U = new Uint8Array(32),
            d = new Uint8Array(32);
        return Q(U, O), Q(d, D), et(U, d)
    }

    function ut(O) {
        const D = new Uint8Array(32);
        return Q(D, O), D[0] & 1
    }

    function ft(O, D) {
        for (let U = 0; U < 16; U++) O[U] = D[2 * U] + (D[2 * U + 1] << 8);
        O[15] &= 32767
    }

    function st(O, D, U) {
        for (let d = 0; d < 16; d++) O[d] = D[d] + U[d]
    }

    function ot(O, D, U) {
        for (let d = 0; d < 16; d++) O[d] = D[d] - U[d]
    }

    function it(O, D, U) {
        let d, N, W = 0,
            rt = 0,
            Z = 0,
            wt = 0,
            bt = 0,
            vt = 0,
            Re = 0,
            Lt = 0,
            Rt = 0,
            ne = 0,
            It = 0,
            St = 0,
            be = 0,
            _t = 0,
            xt = 0,
            te = 0,
            At = 0,
            Dt = 0,
            ae = 0,
            $t = 0,
            Kt = 0,
            ke = 0,
            Qt = 0,
            Vt = 0,
            ze = 0,
            ee = 0,
            ue = 0,
            Fe = 0,
            pe = 0,
            ye = 0,
            yr = 0,
            qt = U[0],
            Mt = U[1],
            Ae = U[2],
            Bt = U[3],
            Ot = U[4],
            we = U[5],
            jt = U[6],
            zt = U[7],
            Ee = U[8],
            Ft = U[9],
            Ut = U[10],
            xe = U[11],
            kt = U[12],
            Et = U[13],
            Oe = U[14],
            Ht = U[15];
        d = D[0], W += d * qt, rt += d * Mt, Z += d * Ae, wt += d * Bt, bt += d * Ot, vt += d * we, Re += d * jt, Lt += d * zt, Rt += d * Ee, ne += d * Ft, It += d * Ut, St += d * xe, be += d * kt, _t += d * Et, xt += d * Oe, te += d * Ht, d = D[1], rt += d * qt, Z += d * Mt, wt += d * Ae, bt += d * Bt, vt += d * Ot, Re += d * we, Lt += d * jt, Rt += d * zt, ne += d * Ee, It += d * Ft, St += d * Ut, be += d * xe, _t += d * kt, xt += d * Et, te += d * Oe, At += d * Ht, d = D[2], Z += d * qt, wt += d * Mt, bt += d * Ae, vt += d * Bt, Re += d * Ot, Lt += d * we, Rt += d * jt, ne += d * zt, It += d * Ee, St += d * Ft, be += d * Ut, _t += d * xe, xt += d * kt, te += d * Et, At += d * Oe, Dt += d * Ht, d = D[3], wt += d * qt, bt += d * Mt, vt += d * Ae, Re += d * Bt, Lt += d * Ot, Rt += d * we, ne += d * jt, It += d * zt, St += d * Ee, be += d * Ft, _t += d * Ut, xt += d * xe, te += d * kt, At += d * Et, Dt += d * Oe, ae += d * Ht, d = D[4], bt += d * qt, vt += d * Mt, Re += d * Ae, Lt += d * Bt, Rt += d * Ot, ne += d * we, It += d * jt, St += d * zt, be += d * Ee, _t += d * Ft, xt += d * Ut, te += d * xe, At += d * kt, Dt += d * Et, ae += d * Oe, $t += d * Ht, d = D[5], vt += d * qt, Re += d * Mt, Lt += d * Ae, Rt += d * Bt, ne += d * Ot, It += d * we, St += d * jt, be += d * zt, _t += d * Ee, xt += d * Ft, te += d * Ut, At += d * xe, Dt += d * kt, ae += d * Et, $t += d * Oe, Kt += d * Ht, d = D[6], Re += d * qt, Lt += d * Mt, Rt += d * Ae, ne += d * Bt, It += d * Ot, St += d * we, be += d * jt, _t += d * zt, xt += d * Ee, te += d * Ft, At += d * Ut, Dt += d * xe, ae += d * kt, $t += d * Et, Kt += d * Oe, ke += d * Ht, d = D[7], Lt += d * qt, Rt += d * Mt, ne += d * Ae, It += d * Bt, St += d * Ot, be += d * we, _t += d * jt, xt += d * zt, te += d * Ee, At += d * Ft, Dt += d * Ut, ae += d * xe, $t += d * kt, Kt += d * Et, ke += d * Oe, Qt += d * Ht, d = D[8], Rt += d * qt, ne += d * Mt, It += d * Ae, St += d * Bt, be += d * Ot, _t += d * we, xt += d * jt, te += d * zt, At += d * Ee, Dt += d * Ft, ae += d * Ut, $t += d * xe, Kt += d * kt, ke += d * Et, Qt += d * Oe, Vt += d * Ht, d = D[9], ne += d * qt, It += d * Mt, St += d * Ae, be += d * Bt, _t += d * Ot, xt += d * we, te += d * jt, At += d * zt, Dt += d * Ee, ae += d * Ft, $t += d * Ut, Kt += d * xe, ke += d * kt, Qt += d * Et, Vt += d * Oe, ze += d * Ht, d = D[10], It += d * qt, St += d * Mt, be += d * Ae, _t += d * Bt, xt += d * Ot, te += d * we, At += d * jt, Dt += d * zt, ae += d * Ee, $t += d * Ft, Kt += d * Ut, ke += d * xe, Qt += d * kt, Vt += d * Et, ze += d * Oe, ee += d * Ht, d = D[11], St += d * qt, be += d * Mt, _t += d * Ae, xt += d * Bt, te += d * Ot, At += d * we, Dt += d * jt, ae += d * zt, $t += d * Ee, Kt += d * Ft, ke += d * Ut, Qt += d * xe, Vt += d * kt, ze += d * Et, ee += d * Oe, ue += d * Ht, d = D[12], be += d * qt, _t += d * Mt, xt += d * Ae, te += d * Bt, At += d * Ot, Dt += d * we, ae += d * jt, $t += d * zt, Kt += d * Ee, ke += d * Ft, Qt += d * Ut, Vt += d * xe, ze += d * kt, ee += d * Et, ue += d * Oe, Fe += d * Ht, d = D[13], _t += d * qt, xt += d * Mt, te += d * Ae, At += d * Bt, Dt += d * Ot, ae += d * we, $t += d * jt, Kt += d * zt, ke += d * Ee, Qt += d * Ft, Vt += d * Ut, ze += d * xe, ee += d * kt, ue += d * Et, Fe += d * Oe, pe += d * Ht, d = D[14], xt += d * qt, te += d * Mt, At += d * Ae, Dt += d * Bt, ae += d * Ot, $t += d * we, Kt += d * jt, ke += d * zt, Qt += d * Ee, Vt += d * Ft, ze += d * Ut, ee += d * xe, ue += d * kt, Fe += d * Et, pe += d * Oe, ye += d * Ht, d = D[15], te += d * qt, At += d * Mt, Dt += d * Ae, ae += d * Bt, $t += d * Ot, Kt += d * we, ke += d * jt, Qt += d * zt, Vt += d * Ee, ze += d * Ft, ee += d * Ut, ue += d * xe, Fe += d * kt, pe += d * Et, ye += d * Oe, yr += d * Ht, W += 38 * At, rt += 38 * Dt, Z += 38 * ae, wt += 38 * $t, bt += 38 * Kt, vt += 38 * ke, Re += 38 * Qt, Lt += 38 * Vt, Rt += 38 * ze, ne += 38 * ee, It += 38 * ue, St += 38 * Fe, be += 38 * pe, _t += 38 * ye, xt += 38 * yr, N = 1, d = W + N + 65535, N = Math.floor(d / 65536), W = d - N * 65536, d = rt + N + 65535, N = Math.floor(d / 65536), rt = d - N * 65536, d = Z + N + 65535, N = Math.floor(d / 65536), Z = d - N * 65536, d = wt + N + 65535, N = Math.floor(d / 65536), wt = d - N * 65536, d = bt + N + 65535, N = Math.floor(d / 65536), bt = d - N * 65536, d = vt + N + 65535, N = Math.floor(d / 65536), vt = d - N * 65536, d = Re + N + 65535, N = Math.floor(d / 65536), Re = d - N * 65536, d = Lt + N + 65535, N = Math.floor(d / 65536), Lt = d - N * 65536, d = Rt + N + 65535, N = Math.floor(d / 65536), Rt = d - N * 65536, d = ne + N + 65535, N = Math.floor(d / 65536), ne = d - N * 65536, d = It + N + 65535, N = Math.floor(d / 65536), It = d - N * 65536, d = St + N + 65535, N = Math.floor(d / 65536), St = d - N * 65536, d = be + N + 65535, N = Math.floor(d / 65536), be = d - N * 65536, d = _t + N + 65535, N = Math.floor(d / 65536), _t = d - N * 65536, d = xt + N + 65535, N = Math.floor(d / 65536), xt = d - N * 65536, d = te + N + 65535, N = Math.floor(d / 65536), te = d - N * 65536, W += N - 1 + 37 * (N - 1), N = 1, d = W + N + 65535, N = Math.floor(d / 65536), W = d - N * 65536, d = rt + N + 65535, N = Math.floor(d / 65536), rt = d - N * 65536, d = Z + N + 65535, N = Math.floor(d / 65536), Z = d - N * 65536, d = wt + N + 65535, N = Math.floor(d / 65536), wt = d - N * 65536, d = bt + N + 65535, N = Math.floor(d / 65536), bt = d - N * 65536, d = vt + N + 65535, N = Math.floor(d / 65536), vt = d - N * 65536, d = Re + N + 65535, N = Math.floor(d / 65536), Re = d - N * 65536, d = Lt + N + 65535, N = Math.floor(d / 65536), Lt = d - N * 65536, d = Rt + N + 65535, N = Math.floor(d / 65536), Rt = d - N * 65536, d = ne + N + 65535, N = Math.floor(d / 65536), ne = d - N * 65536, d = It + N + 65535, N = Math.floor(d / 65536), It = d - N * 65536, d = St + N + 65535, N = Math.floor(d / 65536), St = d - N * 65536, d = be + N + 65535, N = Math.floor(d / 65536), be = d - N * 65536, d = _t + N + 65535, N = Math.floor(d / 65536), _t = d - N * 65536, d = xt + N + 65535, N = Math.floor(d / 65536), xt = d - N * 65536, d = te + N + 65535, N = Math.floor(d / 65536), te = d - N * 65536, W += N - 1 + 37 * (N - 1), O[0] = W, O[1] = rt, O[2] = Z, O[3] = wt, O[4] = bt, O[5] = vt, O[6] = Re, O[7] = Lt, O[8] = Rt, O[9] = ne, O[10] = It, O[11] = St, O[12] = be, O[13] = _t, O[14] = xt, O[15] = te
    }

    function mt(O, D) {
        it(O, D, D)
    }

    function Zt(O, D) {
        const U = o();
        let d;
        for (d = 0; d < 16; d++) U[d] = D[d];
        for (d = 253; d >= 0; d--) mt(U, U), d !== 2 && d !== 4 && it(U, U, D);
        for (d = 0; d < 16; d++) O[d] = U[d]
    }

    function oe(O, D) {
        const U = o();
        let d;
        for (d = 0; d < 16; d++) U[d] = D[d];
        for (d = 250; d >= 0; d--) mt(U, U), d !== 1 && it(U, U, D);
        for (d = 0; d < 16; d++) O[d] = U[d]
    }

    function Tt(O, D) {
        const U = o(),
            d = o(),
            N = o(),
            W = o(),
            rt = o(),
            Z = o(),
            wt = o(),
            bt = o(),
            vt = o();
        ot(U, O[1], O[0]), ot(vt, D[1], D[0]), it(U, U, vt), st(d, O[0], O[1]), st(vt, D[0], D[1]), it(d, d, vt), it(N, O[3], D[3]), it(N, N, m), it(W, O[2], D[2]), st(W, W, W), ot(rt, d, U), ot(Z, W, N), st(wt, W, N), st(bt, d, U), it(O[0], rt, Z), it(O[1], bt, wt), it(O[2], wt, Z), it(O[3], rt, bt)
    }

    function ve(O, D, U) {
        for (let d = 0; d < 4; d++) K(O[d], D[d], U)
    }

    function u(O, D) {
        const U = o(),
            d = o(),
            N = o();
        Zt(N, D[2]), it(U, D[0], N), it(d, D[1], N), Q(O, d), O[31] ^= ut(U) << 7
    }

    function p(O, D, U) {
        k(O[0], h), k(O[1], g), k(O[2], g), k(O[3], h);
        for (let d = 255; d >= 0; --d) {
            const N = U[d / 8 | 0] >> (d & 7) & 1;
            ve(O, D, N), Tt(D, O), Tt(O, O), ve(O, D, N)
        }
    }

    function v(O, D) {
        const U = [o(), o(), o(), o()];
        k(U[0], _), k(U[1], S), k(U[2], g), it(U[3], _, S), p(O, U, D)
    }

    function P(O) {
        if (O.length !== r.SEED_LENGTH) throw new Error(`ed25519: seed must be ${r.SEED_LENGTH} bytes`);
        const D = (0, e.hash)(O);
        D[0] &= 248, D[31] &= 127, D[31] |= 64;
        const U = new Uint8Array(32),
            d = [o(), o(), o(), o()];
        v(d, D), u(U, d);
        const N = new Uint8Array(64);
        return N.set(O), N.set(U, 32), {
            publicKey: U,
            secretKey: N
        }
    }
    r.generateKeyPairFromSeed = P;

    function C(O) {
        const D = (0, t.randomBytes)(32, O),
            U = P(D);
        return (0, n.wipe)(D), U
    }
    r.generateKeyPair = C;

    function R(O) {
        if (O.length !== r.SECRET_KEY_LENGTH) throw new Error(`ed25519: secret key must be ${r.SECRET_KEY_LENGTH} bytes`);
        return new Uint8Array(O.subarray(32))
    }
    r.extractPublicKeyFromSecretKey = R;
    const T = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);

    function E(O, D) {
        let U, d, N, W;
        for (d = 63; d >= 32; --d) {
            for (U = 0, N = d - 32, W = d - 12; N < W; ++N) D[N] += U - 16 * D[d] * T[N - (d - 32)], U = Math.floor((D[N] + 128) / 256), D[N] -= U * 256;
            D[N] += U, D[d] = 0
        }
        for (U = 0, N = 0; N < 32; N++) D[N] += U - (D[31] >> 4) * T[N], U = D[N] >> 8, D[N] &= 255;
        for (N = 0; N < 32; N++) D[N] -= U * T[N];
        for (d = 0; d < 32; d++) D[d + 1] += D[d] >> 8, O[d] = D[d] & 255
    }

    function f(O) {
        const D = new Float64Array(64);
        for (let U = 0; U < 64; U++) D[U] = O[U];
        for (let U = 0; U < 64; U++) O[U] = 0;
        E(O, D)
    }

    function x(O, D) {
        const U = new Float64Array(64),
            d = [o(), o(), o(), o()],
            N = (0, e.hash)(O.subarray(0, 32));
        N[0] &= 248, N[31] &= 127, N[31] |= 64;
        const W = new Uint8Array(64);
        W.set(N.subarray(32), 32);
        const rt = new e.SHA512;
        rt.update(W.subarray(32)), rt.update(D);
        const Z = rt.digest();
        rt.clean(), f(Z), v(d, Z), u(W, d), rt.reset(), rt.update(W.subarray(0, 32)), rt.update(O.subarray(32)), rt.update(D);
        const wt = rt.digest();
        f(wt);
        for (let bt = 0; bt < 32; bt++) U[bt] = Z[bt];
        for (let bt = 0; bt < 32; bt++)
            for (let vt = 0; vt < 32; vt++) U[bt + vt] += wt[bt] * N[vt];
        return E(W.subarray(32), U), W
    }
    r.sign = x;

    function ht(O, D) {
        const U = o(),
            d = o(),
            N = o(),
            W = o(),
            rt = o(),
            Z = o(),
            wt = o();
        return k(O[2], g), ft(O[1], D), mt(N, O[1]), it(W, N, b), ot(N, N, O[2]), st(W, O[2], W), mt(rt, W), mt(Z, rt), it(wt, Z, rt), it(U, wt, N), it(U, U, W), oe(U, U), it(U, U, N), it(U, U, W), it(U, U, W), it(O[0], U, W), mt(d, O[0]), it(d, d, W), at(d, N) && it(O[0], O[0], B), mt(d, O[0]), it(d, d, W), at(d, N) ? -1 : (ut(O[0]) === D[31] >> 7 && ot(O[0], h, O[0]), it(O[3], O[0], O[1]), 0)
    }

    function gt(O, D, U) {
        const d = new Uint8Array(32),
            N = [o(), o(), o(), o()],
            W = [o(), o(), o(), o()];
        if (U.length !== r.SIGNATURE_LENGTH) throw new Error(`ed25519: signature must be ${r.SIGNATURE_LENGTH} bytes`);
        if (ht(W, O)) return !1;
        const rt = new e.SHA512;
        rt.update(U.subarray(0, 32)), rt.update(O), rt.update(D);
        const Z = rt.digest();
        return f(Z), p(N, W, Z), v(W, U.subarray(32)), Tt(N, W), u(d, N), !et(U, d)
    }
    r.verify = gt;

    function y(O) {
        let D = [o(), o(), o(), o()];
        if (ht(D, O)) throw new Error("Ed25519: invalid public key");
        let U = o(),
            d = o(),
            N = D[1];
        st(U, g, N), ot(d, g, N), Zt(d, d), it(U, U, d);
        let W = new Uint8Array(32);
        return Q(W, U), W
    }
    r.convertPublicKeyToX25519 = y;

    function V(O) {
        const D = (0, e.hash)(O.subarray(0, 32));
        D[0] &= 248, D[31] &= 127, D[31] |= 64;
        const U = new Uint8Array(D.subarray(0, 32));
        return (0, n.wipe)(D), U
    }
    r.convertSecretKeyToX25519 = V
})(ju);
const $6 = "EdDSA",
    j6 = "JWT",
    m0 = ".",
    v0 = "base64url",
    z6 = "utf8",
    F6 = "utf8",
    H6 = ":",
    K6 = "did",
    V6 = "key",
    bd = "base58btc",
    G6 = "z",
    Q6 = "K36",
    W6 = 32;

function yc(r) {
    return Pr($r(wn(r), z6), v0)
}

function y0(r) {
    const t = $r(Q6, bd),
        e = G6 + Pr(_u([t, r]), bd);
    return [K6, V6, e].join(H6)
}

function J6(r) {
    return Pr(r, v0)
}

function Y6(r) {
    return $r([yc(r.header), yc(r.payload)].join(m0), F6)
}

function X6(r) {
    return [yc(r.header), yc(r.payload), J6(r.signature)].join(m0)
}

function _d(r = Mc.randomBytes(W6)) {
    return ju.generateKeyPairFromSeed(r)
}
async function Z6(r, t, e, n, o = lt.fromMiliseconds(Date.now())) {
    const a = {
            alg: $6,
            typ: j6
        },
        h = y0(n.publicKey),
        g = o + e,
        b = {
            iss: h,
            sub: r,
            aud: t,
            iat: o,
            exp: g
        },
        m = Y6({
            header: a,
            payload: b
        }),
        _ = ju.sign(n.secretKey, m);
    return X6({
        header: a,
        payload: b,
        signature: _
    })
}
const t3 = "PARSE_ERROR",
    e3 = "INVALID_REQUEST",
    r3 = "METHOD_NOT_FOUND",
    i3 = "INVALID_PARAMS",
    w0 = "INTERNAL_ERROR",
    zu = "SERVER_ERROR",
    n3 = [-32700, -32600, -32601, -32602, -32603],
    No = {
        [t3]: {
            code: -32700,
            message: "Parse error"
        },
        [e3]: {
            code: -32600,
            message: "Invalid Request"
        },
        [r3]: {
            code: -32601,
            message: "Method not found"
        },
        [i3]: {
            code: -32602,
            message: "Invalid params"
        },
        [w0]: {
            code: -32603,
            message: "Internal error"
        },
        [zu]: {
            code: -32e3,
            message: "Server error"
        }
    },
    b0 = zu;

function s3(r) {
    return n3.includes(r)
}

function Ad(r) {
    return Object.keys(No).includes(r) ? No[r] : No[b0]
}

function o3(r) {
    const t = Object.values(No).find(e => e.code === r);
    return t || No[b0]
}

function _0(r, t, e) {
    return r.message.includes("getaddrinfo ENOTFOUND") || r.message.includes("connect ECONNREFUSED") ? new Error(`Unavailable ${e} RPC url at ${t}`) : r
}

function Tn(r = 3) {
    const t = Date.now() * Math.pow(10, r),
        e = Math.floor(Math.random() * Math.pow(10, r));
    return t + e
}

function as(r = 6) {
    return BigInt(Tn(r))
}

function Ls(r, t, e) {
    return {
        id: e || Tn(),
        jsonrpc: "2.0",
        method: r,
        params: t
    }
}

function Nc(r, t) {
    return {
        id: r,
        jsonrpc: "2.0",
        result: t
    }
}

function Rc(r, t, e) {
    return {
        id: r,
        jsonrpc: "2.0",
        error: a3(t)
    }
}

function a3(r, t) {
    return typeof r > "u" ? Ad(w0) : (typeof r == "string" && (r = Object.assign(Object.assign({}, Ad(zu)), {
        message: r
    })), s3(r.code) && (r = o3(r.code)), r)
}
class c3 {}
let h3 = class extends c3 {
    constructor() {
        super()
    }
};
class u3 extends h3 {
    constructor(t) {
        super()
    }
}
const l3 = "^https?:",
    f3 = "^wss?:";

function d3(r) {
    const t = r.match(new RegExp(/^\w+:/, "gi"));
    if (!(!t || !t.length)) return t[0]
}

function A0(r, t) {
    const e = d3(r);
    return typeof e > "u" ? !1 : new RegExp(t).test(e)
}

function Ed(r) {
    return A0(r, l3)
}

function Id(r) {
    return A0(r, f3)
}

function p3(r) {
    return new RegExp("wss?://localhost(:d{2,5})?").test(r)
}

function E0(r) {
    return typeof r == "object" && "id" in r && "jsonrpc" in r && r.jsonrpc === "2.0"
}

function Fu(r) {
    return E0(r) && "method" in r
}

function Oc(r) {
    return E0(r) && (Hi(r) || vi(r))
}

function Hi(r) {
    return "result" in r
}

function vi(r) {
    return "error" in r
}
class Ti extends u3 {
    constructor(t) {
        super(t), this.events = new wi.EventEmitter, this.hasRegisteredEventListeners = !1, this.connection = this.setConnection(t), this.connection.connected && this.registerEventListeners()
    }
    async connect(t = this.connection) {
        await this.open(t)
    }
    async disconnect() {
        await this.close()
    }
    on(t, e) {
        this.events.on(t, e)
    }
    once(t, e) {
        this.events.once(t, e)
    }
    off(t, e) {
        this.events.off(t, e)
    }
    removeListener(t, e) {
        this.events.removeListener(t, e)
    }
    async request(t, e) {
        return this.requestStrict(Ls(t.method, t.params || [], t.id || as().toString()), e)
    }
    async requestStrict(t, e) {
        return new Promise(async (n, o) => {
            if (!this.connection.connected) try {
                await this.open()
            } catch (a) {
                o(a)
            }
            this.events.on(`${t.id}`, a => {
                vi(a) ? o(a.error) : n(a.result)
            });
            try {
                await this.connection.send(t, e)
            } catch (a) {
                o(a)
            }
        })
    }
    setConnection(t = this.connection) {
        return t
    }
    onPayload(t) {
        this.events.emit("payload", t), Oc(t) ? this.events.emit(`${t.id}`, t) : this.events.emit("message", {
            type: t.method,
            data: t.params
        })
    }
    onClose(t) {
        t && t.code === 3e3 && this.events.emit("error", new Error(`WebSocket connection closed abnormally with code: ${t.code} ${t.reason?`(${t.reason})`:""}`)), this.events.emit("disconnect")
    }
    async open(t = this.connection) {
        this.connection === t && this.connection.connected || (this.connection.connected && this.close(), typeof t == "string" && (await this.connection.open(t), t = this.connection), this.connection = this.setConnection(t), await this.connection.open(), this.registerEventListeners(), this.events.emit("connect"))
    }
    async close() {
        await this.connection.close()
    }
    registerEventListeners() {
        this.hasRegisteredEventListeners || (this.connection.on("payload", t => this.onPayload(t)), this.connection.on("close", t => this.onClose(t)), this.connection.on("error", t => this.events.emit("error", t)), this.connection.on("register_error", t => this.onClose()), this.hasRegisteredEventListeners = !0)
    }
}
const g3 = () => typeof WebSocket < "u" ? WebSocket : typeof global < "u" && typeof global.WebSocket < "u" ? global.WebSocket : typeof window < "u" && typeof window.WebSocket < "u" ? window.WebSocket : typeof self < "u" && typeof self.WebSocket < "u" ? self.WebSocket : require("ws"),
    m3 = () => typeof WebSocket < "u" || typeof global < "u" && typeof global.WebSocket < "u" || typeof window < "u" && typeof window.WebSocket < "u" || typeof self < "u" && typeof self.WebSocket < "u",
    Sd = r => r.split("?")[0],
    xd = 10,
    v3 = g3();
let y3 = class {
    constructor(t) {
        if (this.url = t, this.events = new wi.EventEmitter, this.registering = !1, !Id(t)) throw new Error(`Provided URL is not compatible with WebSocket connection: ${t}`);
        this.url = t
    }
    get connected() {
        return typeof this.socket < "u"
    }
    get connecting() {
        return this.registering
    }
    on(t, e) {
        this.events.on(t, e)
    }
    once(t, e) {
        this.events.once(t, e)
    }
    off(t, e) {
        this.events.off(t, e)
    }
    removeListener(t, e) {
        this.events.removeListener(t, e)
    }
    async open(t = this.url) {
        await this.register(t)
    }
    async close() {
        return new Promise((t, e) => {
            if (typeof this.socket > "u") {
                e(new Error("Connection already closed"));
                return
            }
            this.socket.onclose = n => {
                this.onClose(n), t()
            }, this.socket.close()
        })
    }
    async send(t) {
        typeof this.socket > "u" && (this.socket = await this.register());
        try {
            this.socket.send(wn(t))
        } catch (e) {
            this.onError(t.id, e)
        }
    }
    register(t = this.url) {
        if (!Id(t)) throw new Error(`Provided URL is not compatible with WebSocket connection: ${t}`);
        if (this.registering) {
            const e = this.events.getMaxListeners();
            return (this.events.listenerCount("register_error") >= e || this.events.listenerCount("open") >= e) && this.events.setMaxListeners(e + 1), new Promise((n, o) => {
                this.events.once("register_error", a => {
                    this.resetMaxListeners(), o(a)
                }), this.events.once("open", () => {
                    if (this.resetMaxListeners(), typeof this.socket > "u") return o(new Error("WebSocket connection is missing or invalid"));
                    n(this.socket)
                })
            })
        }
        return this.url = t, this.registering = !0, new Promise((e, n) => {
            const o = new URLSearchParams(t).get("origin"),
                a = p2.isReactNative() ? {
                    headers: {
                        origin: o
                    }
                } : {
                    rejectUnauthorized: !p3(t)
                },
                h = new v3(t, [], a);
            m3() ? h.onerror = g => {
                const b = g;
                n(this.emitError(b.error))
            } : h.on("error", g => {
                n(this.emitError(g))
            }), h.onopen = () => {
                this.onOpen(h), e(h)
            }
        })
    }
    onOpen(t) {
        t.onmessage = e => this.onPayload(e), t.onclose = e => this.onClose(e), this.socket = t, this.registering = !1, this.events.emit("open")
    }
    onClose(t) {
        this.socket = void 0, this.registering = !1, this.events.emit("close", t)
    }
    onPayload(t) {
        if (typeof t.data > "u") return;
        const e = typeof t.data == "string" ? $o(t.data) : t.data;
        this.events.emit("payload", e)
    }
    onError(t, e) {
        const n = this.parseError(e),
            o = n.message || n.toString(),
            a = Rc(t, o);
        this.events.emit("payload", a)
    }
    parseError(t, e = this.url) {
        return _0(t, Sd(e), "WS")
    }
    resetMaxListeners() {
        this.events.getMaxListeners() > xd && this.events.setMaxListeners(xd)
    }
    emitError(t) {
        const e = this.parseError(new Error((t == null ? void 0 : t.message) || `WebSocket connection failed for host: ${Sd(this.url)}`));
        return this.events.emit("register_error", e), e
    }
};
var wc = {
    exports: {}
};
wc.exports;
(function(r, t) {
    var e = 200,
        n = "__lodash_hash_undefined__",
        o = 1,
        a = 2,
        h = 9007199254740991,
        g = "[object Arguments]",
        b = "[object Array]",
        m = "[object AsyncFunction]",
        _ = "[object Boolean]",
        S = "[object Date]",
        B = "[object Error]",
        k = "[object Function]",
        L = "[object GeneratorFunction]",
        K = "[object Map]",
        Q = "[object Number]",
        et = "[object Null]",
        at = "[object Object]",
        ut = "[object Promise]",
        ft = "[object Proxy]",
        st = "[object RegExp]",
        ot = "[object Set]",
        it = "[object String]",
        mt = "[object Symbol]",
        Zt = "[object Undefined]",
        oe = "[object WeakMap]",
        Tt = "[object ArrayBuffer]",
        ve = "[object DataView]",
        u = "[object Float32Array]",
        p = "[object Float64Array]",
        v = "[object Int8Array]",
        P = "[object Int16Array]",
        C = "[object Int32Array]",
        R = "[object Uint8Array]",
        T = "[object Uint8ClampedArray]",
        E = "[object Uint16Array]",
        f = "[object Uint32Array]",
        x = /[\\^$.*+?()[\]{}|]/g,
        ht = /^\[object .+?Constructor\]$/,
        gt = /^(?:0|[1-9]\d*)$/,
        y = {};
    y[u] = y[p] = y[v] = y[P] = y[C] = y[R] = y[T] = y[E] = y[f] = !0, y[g] = y[b] = y[Tt] = y[_] = y[ve] = y[S] = y[B] = y[k] = y[K] = y[Q] = y[at] = y[st] = y[ot] = y[it] = y[oe] = !1;
    var V = typeof Wa == "object" && Wa && Wa.Object === Object && Wa,
        O = typeof self == "object" && self && self.Object === Object && self,
        D = V || O || Function("return this")(),
        U = t && !t.nodeType && t,
        d = U && !0 && r && !r.nodeType && r,
        N = d && d.exports === U,
        W = N && V.process,
        rt = function() {
            try {
                return W && W.binding && W.binding("util")
            } catch {}
        }(),
        Z = rt && rt.isTypedArray;

    function wt(M, j) {
        for (var X = -1, dt = M == null ? 0 : M.length, qe = 0, Wt = []; ++X < dt;) {
            var Le = M[X];
            j(Le, X, M) && (Wt[qe++] = Le)
        }
        return Wt
    }

    function bt(M, j) {
        for (var X = -1, dt = j.length, qe = M.length; ++X < dt;) M[qe + X] = j[X];
        return M
    }

    function vt(M, j) {
        for (var X = -1, dt = M == null ? 0 : M.length; ++X < dt;)
            if (j(M[X], X, M)) return !0;
        return !1
    }

    function Re(M, j) {
        for (var X = -1, dt = Array(M); ++X < M;) dt[X] = j(X);
        return dt
    }

    function Lt(M) {
        return function(j) {
            return M(j)
        }
    }

    function Rt(M, j) {
        return M.has(j)
    }

    function ne(M, j) {
        return M == null ? void 0 : M[j]
    }

    function It(M) {
        var j = -1,
            X = Array(M.size);
        return M.forEach(function(dt, qe) {
            X[++j] = [qe, dt]
        }), X
    }

    function St(M, j) {
        return function(X) {
            return M(j(X))
        }
    }

    function be(M) {
        var j = -1,
            X = Array(M.size);
        return M.forEach(function(dt) {
            X[++j] = dt
        }), X
    }
    var _t = Array.prototype,
        xt = Function.prototype,
        te = Object.prototype,
        At = D["__core-js_shared__"],
        Dt = xt.toString,
        ae = te.hasOwnProperty,
        $t = function() {
            var M = /[^.]+$/.exec(At && At.keys && At.keys.IE_PROTO || "");
            return M ? "Symbol(src)_1." + M : ""
        }(),
        Kt = te.toString,
        ke = RegExp("^" + Dt.call(ae).replace(x, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
        Qt = N ? D.Buffer : void 0,
        Vt = D.Symbol,
        ze = D.Uint8Array,
        ee = te.propertyIsEnumerable,
        ue = _t.splice,
        Fe = Vt ? Vt.toStringTag : void 0,
        pe = Object.getOwnPropertySymbols,
        ye = Qt ? Qt.isBuffer : void 0,
        yr = St(Object.keys, Object),
        qt = Hr(D, "DataView"),
        Mt = Hr(D, "Map"),
        Ae = Hr(D, "Promise"),
        Bt = Hr(D, "Set"),
        Ot = Hr(D, "WeakMap"),
        we = Hr(Object, "create"),
        jt = nn(qt),
        zt = nn(Mt),
        Ee = nn(Ae),
        Ft = nn(Bt),
        Ut = nn(Ot),
        xe = Vt ? Vt.prototype : void 0,
        kt = xe ? xe.valueOf : void 0;

    function Et(M) {
        var j = -1,
            X = M == null ? 0 : M.length;
        for (this.clear(); ++j < X;) {
            var dt = M[j];
            this.set(dt[0], dt[1])
        }
    }

    function Oe() {
        this.__data__ = we ? we(null) : {}, this.size = 0
    }

    function Ht(M) {
        var j = this.has(M) && delete this.__data__[M];
        return this.size -= j ? 1 : 0, j
    }

    function Pe(M) {
        var j = this.__data__;
        if (we) {
            var X = j[M];
            return X === n ? void 0 : X
        }
        return ae.call(j, M) ? j[M] : void 0
    }

    function bi(M) {
        var j = this.__data__;
        return we ? j[M] !== void 0 : ae.call(j, M)
    }

    function Me(M, j) {
        var X = this.__data__;
        return this.size += this.has(M) ? 0 : 1, X[M] = we && j === void 0 ? n : j, this
    }
    Et.prototype.clear = Oe, Et.prototype.delete = Ht, Et.prototype.get = Pe, Et.prototype.has = bi, Et.prototype.set = Me;

    function se(M) {
        var j = -1,
            X = M == null ? 0 : M.length;
        for (this.clear(); ++j < X;) {
            var dt = M[j];
            this.set(dt[0], dt[1])
        }
    }

    function Zr() {
        this.__data__ = [], this.size = 0
    }

    function ti(M) {
        var j = this.__data__,
            X = Vn(j, M);
        if (X < 0) return !1;
        var dt = j.length - 1;
        return X == dt ? j.pop() : ue.call(j, X, 1), --this.size, !0
    }

    function ei(M) {
        var j = this.__data__,
            X = Vn(j, M);
        return X < 0 ? void 0 : j[X][1]
    }

    function ri(M) {
        return Vn(this.__data__, M) > -1
    }

    function ii(M, j) {
        var X = this.__data__,
            dt = Vn(X, M);
        return dt < 0 ? (++this.size, X.push([M, j])) : X[dt][1] = j, this
    }
    se.prototype.clear = Zr, se.prototype.delete = ti, se.prototype.get = ei, se.prototype.has = ri, se.prototype.set = ii;

    function nr(M) {
        var j = -1,
            X = M == null ? 0 : M.length;
        for (this.clear(); ++j < X;) {
            var dt = M[j];
            this.set(dt[0], dt[1])
        }
    }

    function qi() {
        this.size = 0, this.__data__ = {
            hash: new Et,
            map: new(Mt || se),
            string: new Et
        }
    }

    function Ln(M) {
        var j = An(this, M).delete(M);
        return this.size -= j ? 1 : 0, j
    }

    function Bi(M) {
        return An(this, M).get(M)
    }

    function $n(M) {
        return An(this, M).has(M)
    }

    function jn(M, j) {
        var X = An(this, M),
            dt = X.size;
        return X.set(M, j), this.size += X.size == dt ? 0 : 1, this
    }
    nr.prototype.clear = qi, nr.prototype.delete = Ln, nr.prototype.get = Bi, nr.prototype.has = $n, nr.prototype.set = jn;

    function Ui(M) {
        var j = -1,
            X = M == null ? 0 : M.length;
        for (this.__data__ = new nr; ++j < X;) this.add(M[j])
    }

    function bn(M) {
        return this.__data__.set(M, n), this
    }

    function _n(M) {
        return this.__data__.has(M)
    }
    Ui.prototype.add = Ui.prototype.push = bn, Ui.prototype.has = _n;

    function wr(M) {
        var j = this.__data__ = new se(M);
        this.size = j.size
    }

    function zn() {
        this.__data__ = new se, this.size = 0
    }

    function Fn(M) {
        var j = this.__data__,
            X = j.delete(M);
        return this.size = j.size, X
    }

    function Hn(M) {
        return this.__data__.get(M)
    }

    function Kn(M) {
        return this.__data__.has(M)
    }

    function Go(M, j) {
        var X = this.__data__;
        if (X instanceof se) {
            var dt = X.__data__;
            if (!Mt || dt.length < e - 1) return dt.push([M, j]), this.size = ++X.size, this;
            X = this.__data__ = new nr(dt)
        }
        return X.set(M, j), this.size = X.size, this
    }
    wr.prototype.clear = zn, wr.prototype.delete = Fn, wr.prototype.get = Hn, wr.prototype.has = Kn, wr.prototype.set = Go;

    function Qo(M, j) {
        var X = ws(M),
            dt = !X && oa(M),
            qe = !X && !dt && to(M),
            Wt = !X && !dt && !qe && ha(M),
            Le = X || dt || qe || Wt,
            Xe = Le ? Re(M.length, String) : [],
            ge = Xe.length;
        for (var Be in M) ae.call(M, Be) && !(Le && (Be == "length" || qe && (Be == "offset" || Be == "parent") || Wt && (Be == "buffer" || Be == "byteLength" || Be == "byteOffset") || ea(Be, ge))) && Xe.push(Be);
        return Xe
    }

    function Vn(M, j) {
        for (var X = M.length; X--;)
            if (sa(M[X][0], j)) return X;
        return -1
    }

    function Xs(M, j, X) {
        var dt = j(M);
        return ws(M) ? dt : bt(dt, X(M))
    }

    function Gn(M) {
        return M == null ? M === void 0 ? Zt : et : Fe && Fe in Object(M) ? Zo(M) : kc(M)
    }

    function Zs(M) {
        return Wn(M) && Gn(M) == g
    }

    function Qn(M, j, X, dt, qe) {
        return M === j ? !0 : M == null || j == null || !Wn(M) && !Wn(j) ? M !== M && j !== j : Wo(M, j, X, dt, Qn, qe)
    }

    function Wo(M, j, X, dt, qe, Wt) {
        var Le = ws(M),
            Xe = ws(j),
            ge = Le ? b : ki(M),
            Be = Xe ? b : ki(j);
        ge = ge == g ? at : ge, Be = Be == g ? at : Be;
        var Ge = ge == at,
            Cr = Be == at,
            Ze = ge == Be;
        if (Ze && to(M)) {
            if (!to(j)) return !1;
            Le = !0, Ge = !1
        }
        if (Ze && !Ge) return Wt || (Wt = new wr), Le || ha(M) ? vs(M, j, X, dt, qe, Wt) : Uc(M, j, ge, X, dt, qe, Wt);
        if (!(X & o)) {
            var $e = Ge && ae.call(M, "__wrapped__"),
                br = Cr && ae.call(j, "__wrapped__");
            if ($e || br) {
                var _i = $e ? M.value() : M,
                    ni = br ? j.value() : j;
                return Wt || (Wt = new wr), qe(_i, ni, X, dt, Wt)
            }
        }
        return Ze ? (Wt || (Wt = new wr), Xo(M, j, X, dt, qe, Wt)) : !1
    }

    function Bc(M) {
        if (!ca(M) || ia(M)) return !1;
        var j = bs(M) ? ke : ht;
        return j.test(nn(M))
    }

    function Jo(M) {
        return Wn(M) && aa(M.length) && !!y[Gn(M)]
    }

    function Yo(M) {
        if (!na(M)) return yr(M);
        var j = [];
        for (var X in Object(M)) ae.call(M, X) && X != "constructor" && j.push(X);
        return j
    }

    function vs(M, j, X, dt, qe, Wt) {
        var Le = X & o,
            Xe = M.length,
            ge = j.length;
        if (Xe != ge && !(Le && ge > Xe)) return !1;
        var Be = Wt.get(M);
        if (Be && Wt.get(j)) return Be == j;
        var Ge = -1,
            Cr = !0,
            Ze = X & a ? new Ui : void 0;
        for (Wt.set(M, j), Wt.set(j, M); ++Ge < Xe;) {
            var $e = M[Ge],
                br = j[Ge];
            if (dt) var _i = Le ? dt(br, $e, Ge, j, M, Wt) : dt($e, br, Ge, M, j, Wt);
            if (_i !== void 0) {
                if (_i) continue;
                Cr = !1;
                break
            }
            if (Ze) {
                if (!vt(j, function(ni, Li) {
                        if (!Rt(Ze, Li) && ($e === ni || qe($e, ni, X, dt, Wt))) return Ze.push(Li)
                    })) {
                    Cr = !1;
                    break
                }
            } else if (!($e === br || qe($e, br, X, dt, Wt))) {
                Cr = !1;
                break
            }
        }
        return Wt.delete(M), Wt.delete(j), Cr
    }

    function Uc(M, j, X, dt, qe, Wt, Le) {
        switch (X) {
            case ve:
                if (M.byteLength != j.byteLength || M.byteOffset != j.byteOffset) return !1;
                M = M.buffer, j = j.buffer;
            case Tt:
                return !(M.byteLength != j.byteLength || !Wt(new ze(M), new ze(j)));
            case _:
            case S:
            case Q:
                return sa(+M, +j);
            case B:
                return M.name == j.name && M.message == j.message;
            case st:
            case it:
                return M == j + "";
            case K:
                var Xe = It;
            case ot:
                var ge = dt & o;
                if (Xe || (Xe = be), M.size != j.size && !ge) return !1;
                var Be = Le.get(M);
                if (Be) return Be == j;
                dt |= a, Le.set(M, j);
                var Ge = vs(Xe(M), Xe(j), dt, qe, Wt, Le);
                return Le.delete(M), Ge;
            case mt:
                if (kt) return kt.call(M) == kt.call(j)
        }
        return !1
    }

    function Xo(M, j, X, dt, qe, Wt) {
        var Le = X & o,
            Xe = ys(M),
            ge = Xe.length,
            Be = ys(j),
            Ge = Be.length;
        if (ge != Ge && !Le) return !1;
        for (var Cr = ge; Cr--;) {
            var Ze = Xe[Cr];
            if (!(Le ? Ze in j : ae.call(j, Ze))) return !1
        }
        var $e = Wt.get(M);
        if ($e && Wt.get(j)) return $e == j;
        var br = !0;
        Wt.set(M, j), Wt.set(j, M);
        for (var _i = Le; ++Cr < ge;) {
            Ze = Xe[Cr];
            var ni = M[Ze],
                Li = j[Ze];
            if (dt) var eo = Le ? dt(Li, ni, Ze, j, M, Wt) : dt(ni, Li, Ze, M, j, Wt);
            if (!(eo === void 0 ? ni === Li || qe(ni, Li, X, dt, Wt) : eo)) {
                br = !1;
                break
            }
            _i || (_i = Ze == "constructor")
        }
        if (br && !_i) {
            var Jn = M.constructor,
                sr = j.constructor;
            Jn != sr && "constructor" in M && "constructor" in j && !(typeof Jn == "function" && Jn instanceof Jn && typeof sr == "function" && sr instanceof sr) && (br = !1)
        }
        return Wt.delete(M), Wt.delete(j), br
    }

    function ys(M) {
        return Xs(M, jc, ta)
    }

    function An(M, j) {
        var X = M.__data__;
        return ra(j) ? X[typeof j == "string" ? "string" : "hash"] : X.map
    }

    function Hr(M, j) {
        var X = ne(M, j);
        return Bc(X) ? X : void 0
    }

    function Zo(M) {
        var j = ae.call(M, Fe),
            X = M[Fe];
        try {
            M[Fe] = void 0;
            var dt = !0
        } catch {}
        var qe = Kt.call(M);
        return dt && (j ? M[Fe] = X : delete M[Fe]), qe
    }
    var ta = pe ? function(M) {
            return M == null ? [] : (M = Object(M), wt(pe(M), function(j) {
                return ee.call(M, j)
            }))
        } : De,
        ki = Gn;
    (qt && ki(new qt(new ArrayBuffer(1))) != ve || Mt && ki(new Mt) != K || Ae && ki(Ae.resolve()) != ut || Bt && ki(new Bt) != ot || Ot && ki(new Ot) != oe) && (ki = function(M) {
        var j = Gn(M),
            X = j == at ? M.constructor : void 0,
            dt = X ? nn(X) : "";
        if (dt) switch (dt) {
            case jt:
                return ve;
            case zt:
                return K;
            case Ee:
                return ut;
            case Ft:
                return ot;
            case Ut:
                return oe
        }
        return j
    });

    function ea(M, j) {
        return j = j ? ? h, !!j && (typeof M == "number" || gt.test(M)) && M > -1 && M % 1 == 0 && M < j
    }

    function ra(M) {
        var j = typeof M;
        return j == "string" || j == "number" || j == "symbol" || j == "boolean" ? M !== "__proto__" : M === null
    }

    function ia(M) {
        return !!$t && $t in M
    }

    function na(M) {
        var j = M && M.constructor,
            X = typeof j == "function" && j.prototype || te;
        return M === X
    }

    function kc(M) {
        return Kt.call(M)
    }

    function nn(M) {
        if (M != null) {
            try {
                return Dt.call(M)
            } catch {}
            try {
                return M + ""
            } catch {}
        }
        return ""
    }

    function sa(M, j) {
        return M === j || M !== M && j !== j
    }
    var oa = Zs(function() {
            return arguments
        }()) ? Zs : function(M) {
            return Wn(M) && ae.call(M, "callee") && !ee.call(M, "callee")
        },
        ws = Array.isArray;

    function Lc(M) {
        return M != null && aa(M.length) && !bs(M)
    }
    var to = ye || Te;

    function $c(M, j) {
        return Qn(M, j)
    }

    function bs(M) {
        if (!ca(M)) return !1;
        var j = Gn(M);
        return j == k || j == L || j == m || j == ft
    }

    function aa(M) {
        return typeof M == "number" && M > -1 && M % 1 == 0 && M <= h
    }

    function ca(M) {
        var j = typeof M;
        return M != null && (j == "object" || j == "function")
    }

    function Wn(M) {
        return M != null && typeof M == "object"
    }
    var ha = Z ? Lt(Z) : Jo;

    function jc(M) {
        return Lc(M) ? Qo(M) : Yo(M)
    }

    function De() {
        return []
    }

    function Te() {
        return !1
    }
    r.exports = $c
})(wc, wc.exports);
var w3 = wc.exports;
const b3 = g2(w3);
var _3 = Object.defineProperty,
    A3 = Object.defineProperties,
    E3 = Object.getOwnPropertyDescriptors,
    Pd = Object.getOwnPropertySymbols,
    I3 = Object.prototype.hasOwnProperty,
    S3 = Object.prototype.propertyIsEnumerable,
    Md = (r, t, e) => t in r ? _3(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Cd = (r, t) => {
        for (var e in t || (t = {})) I3.call(t, e) && Md(r, e, t[e]);
        if (Pd)
            for (var e of Pd(t)) S3.call(t, e) && Md(r, e, t[e]);
        return r
    },
    Nd = (r, t) => A3(r, E3(t));
const x3 = {
        Accept: "application/json",
        "Content-Type": "application/json"
    },
    P3 = "POST",
    Rd = {
        headers: x3,
        method: P3
    },
    Od = 10;
let en = class {
    constructor(t, e = !1) {
        if (this.url = t, this.disableProviderPing = e, this.events = new wi.EventEmitter, this.isAvailable = !1, this.registering = !1, !Ed(t)) throw new Error(`Provided URL is not compatible with HTTP connection: ${t}`);
        this.url = t, this.disableProviderPing = e
    }
    get connected() {
        return this.isAvailable
    }
    get connecting() {
        return this.registering
    }
    on(t, e) {
        this.events.on(t, e)
    }
    once(t, e) {
        this.events.once(t, e)
    }
    off(t, e) {
        this.events.off(t, e)
    }
    removeListener(t, e) {
        this.events.removeListener(t, e)
    }
    async open(t = this.url) {
        await this.register(t)
    }
    async close() {
        if (!this.isAvailable) throw new Error("Connection already closed");
        this.onClose()
    }
    async send(t) {
        this.isAvailable || await this.register();
        try {
            const e = wn(t),
                n = await (await od(this.url, Nd(Cd({}, Rd), {
                    body: e
                }))).json();
            this.onPayload({
                data: n
            })
        } catch (e) {
            this.onError(t.id, e)
        }
    }
    async register(t = this.url) {
        if (!Ed(t)) throw new Error(`Provided URL is not compatible with HTTP connection: ${t}`);
        if (this.registering) {
            const e = this.events.getMaxListeners();
            return (this.events.listenerCount("register_error") >= e || this.events.listenerCount("open") >= e) && this.events.setMaxListeners(e + 1), new Promise((n, o) => {
                this.events.once("register_error", a => {
                    this.resetMaxListeners(), o(a)
                }), this.events.once("open", () => {
                    if (this.resetMaxListeners(), typeof this.isAvailable > "u") return o(new Error("HTTP connection is missing or invalid"));
                    n()
                })
            })
        }
        this.url = t, this.registering = !0;
        try {
            if (!this.disableProviderPing) {
                const e = wn({
                    id: 1,
                    jsonrpc: "2.0",
                    method: "test",
                    params: []
                });
                await od(t, Nd(Cd({}, Rd), {
                    body: e
                }))
            }
            this.onOpen()
        } catch (e) {
            const n = this.parseError(e);
            throw this.events.emit("register_error", n), this.onClose(), n
        }
    }
    onOpen() {
        this.isAvailable = !0, this.registering = !1, this.events.emit("open")
    }
    onClose() {
        this.isAvailable = !1, this.registering = !1, this.events.emit("close")
    }
    onPayload(t) {
        if (typeof t.data > "u") return;
        const e = typeof t.data == "string" ? $o(t.data) : t.data;
        this.events.emit("payload", e)
    }
    onError(t, e) {
        const n = this.parseError(e),
            o = n.message || n.toString(),
            a = Rc(t, o);
        this.events.emit("payload", a)
    }
    parseError(t, e = this.url) {
        return _0(t, e, "HTTP")
    }
    resetMaxListeners() {
        this.events.getMaxListeners() > Od && this.events.setMaxListeners(Od)
    }
};
const M3 = {
        waku: {
            publish: "waku_publish",
            batchPublish: "waku_batchPublish",
            subscribe: "waku_subscribe",
            batchSubscribe: "waku_batchSubscribe",
            subscription: "waku_subscription",
            unsubscribe: "waku_unsubscribe",
            batchUnsubscribe: "waku_batchUnsubscribe",
            batchFetchMessages: "waku_batchFetchMessages"
        },
        irn: {
            publish: "irn_publish",
            batchPublish: "irn_batchPublish",
            subscribe: "irn_subscribe",
            batchSubscribe: "irn_batchSubscribe",
            subscription: "irn_subscription",
            unsubscribe: "irn_unsubscribe",
            batchUnsubscribe: "irn_batchUnsubscribe",
            batchFetchMessages: "irn_batchFetchMessages"
        },
        iridium: {
            publish: "iridium_publish",
            batchPublish: "iridium_batchPublish",
            subscribe: "iridium_subscribe",
            batchSubscribe: "iridium_batchSubscribe",
            subscription: "iridium_subscription",
            unsubscribe: "iridium_unsubscribe",
            batchUnsubscribe: "iridium_batchUnsubscribe",
            batchFetchMessages: "iridium_batchFetchMessages"
        }
    },
    C3 = ":";

function Ro(r) {
    const [t, e] = r.split(C3);
    return {
        namespace: t,
        reference: e
    }
}

function Td(r, t = []) {
    const e = [];
    return Object.keys(r).forEach(n => {
        if (t.length && !t.includes(n)) return;
        const o = r[n];
        e.push(...o.accounts)
    }), e
}

function I0(r, t) {
    return r.includes(":") ? [r] : t.chains || []
}
var N3 = Object.defineProperty,
    Dd = Object.getOwnPropertySymbols,
    R3 = Object.prototype.hasOwnProperty,
    O3 = Object.prototype.propertyIsEnumerable,
    qd = (r, t, e) => t in r ? N3(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Bd = (r, t) => {
        for (var e in t || (t = {})) R3.call(t, e) && qd(r, e, t[e]);
        if (Dd)
            for (var e of Dd(t)) O3.call(t, e) && qd(r, e, t[e]);
        return r
    };
const T3 = "ReactNative",
    Jr = {
        reactNative: "react-native",
        node: "node",
        browser: "browser",
        unknown: "unknown"
    },
    D3 = "js";

function Do() {
    return typeof process < "u" && typeof process.versions < "u" && typeof process.versions.node < "u"
}

function Ks() {
    return !s0() && !!n0() && navigator.product === T3
}

function Vs() {
    return !Do() && !!n0() && !!s0()
}

function Fo() {
    return Ks() ? Jr.reactNative : Do() ? Jr.node : Vs() ? Jr.browser : Jr.unknown
}

function q3() {
    var r;
    try {
        return Ks() && typeof global < "u" && typeof(global == null ? void 0 : global.Application) < "u" ? (r = global.Application) == null ? void 0 : r.applicationId : void 0
    } catch {
        return
    }
}

function B3(r, t) {
    let e = gc.parse(r);
    return e = Bd(Bd({}, e), t), r = gc.stringify(e), r
}

function U3() {
    return M2() || {
        name: "",
        description: "",
        url: "",
        icons: [""]
    }
}

function k3() {
    if (Fo() === Jr.reactNative && typeof global < "u" && typeof(global == null ? void 0 : global.Platform) < "u") {
        const {
            OS: e,
            Version: n
        } = global.Platform;
        return [e, n].join("-")
    }
    const r = L2();
    if (r === null) return "unknown";
    const t = r.os ? r.os.replace(" ", "").toLowerCase() : "unknown";
    return r.type === "browser" ? [t, r.name, r.version].join("-") : [t, r.version].join("-")
}

function L3() {
    var r;
    const t = Fo();
    return t === Jr.browser ? [t, ((r = N2()) == null ? void 0 : r.host) || "unknown"].join(":") : t
}

function $3(r, t, e) {
    const n = k3(),
        o = L3();
    return [
        [r, t].join("-"), [D3, e].join("-"), n, o
    ].join("/")
}

function j3({
    protocol: r,
    version: t,
    relayUrl: e,
    sdkVersion: n,
    auth: o,
    projectId: a,
    useOnCloseEvent: h,
    bundleId: g
}) {
    const b = e.split("?"),
        m = $3(r, t, n),
        _ = {
            auth: o,
            ua: m,
            projectId: a,
            useOnCloseEvent: h || void 0,
            origin: g || void 0
        },
        S = B3(b[1] || "", _);
    return b[0] + "?" + S
}

function cs(r, t) {
    return r.filter(e => t.includes(e)).length === r.length
}

function S0(r) {
    return Object.fromEntries(r.entries())
}

function x0(r) {
    return new Map(Object.entries(r))
}

function os(r = lt.FIVE_MINUTES, t) {
    const e = lt.toMiliseconds(r || lt.FIVE_MINUTES);
    let n, o, a;
    return {
        resolve: h => {
            a && n && (clearTimeout(a), n(h))
        },
        reject: h => {
            a && o && (clearTimeout(a), o(h))
        },
        done: () => new Promise((h, g) => {
            a = setTimeout(() => {
                g(new Error(t))
            }, e), n = h, o = g
        })
    }
}

function $s(r, t, e) {
    return new Promise(async (n, o) => {
        const a = setTimeout(() => o(new Error(e)), t);
        try {
            const h = await r;
            n(h)
        } catch (h) {
            o(h)
        }
        clearTimeout(a)
    })
}

function P0(r, t) {
    if (typeof t == "string" && t.startsWith(`${r}:`)) return t;
    if (r.toLowerCase() === "topic") {
        if (typeof t != "string") throw new Error('Value must be "string" for expirer target type: topic');
        return `topic:${t}`
    } else if (r.toLowerCase() === "id") {
        if (typeof t != "number") throw new Error('Value must be "number" for expirer target type: id');
        return `id:${t}`
    }
    throw new Error(`Unknown expirer target type: ${r}`)
}

function z3(r) {
    return P0("topic", r)
}

function F3(r) {
    return P0("id", r)
}

function M0(r) {
    const [t, e] = r.split(":"), n = {
        id: void 0,
        topic: void 0
    };
    if (t === "topic" && typeof e == "string") n.topic = e;
    else if (t === "id" && Number.isInteger(Number(e))) n.id = Number(e);
    else throw new Error(`Invalid target, expected id:number or topic:string, got ${t}:${e}`);
    return n
}

function fr(r, t) {
    return lt.fromMiliseconds(Date.now() + lt.toMiliseconds(r))
}

function Dn(r) {
    return Date.now() >= lt.toMiliseconds(r)
}

function he(r, t) {
    return `${r}${t?`:${t}`:""}`
}

function cc(r = [], t = []) {
    return [...new Set([...r, ...t])]
}
async function H3({
    id: r,
    topic: t,
    wcDeepLink: e
}) {
    try {
        if (!e) return;
        const n = typeof e == "string" ? JSON.parse(e) : e;
        let o = n == null ? void 0 : n.href;
        if (typeof o != "string") return;
        o.endsWith("/") && (o = o.slice(0, -1));
        const a = `${o}/wc?requestId=${r}&sessionTopic=${t}`,
            h = Fo();
        h === Jr.browser ? a.startsWith("https://") || a.startsWith("http://") ? window.open(a, "_blank", "noreferrer noopener") : window.open(a, "_self", "noreferrer noopener") : h === Jr.reactNative && typeof(global == null ? void 0 : global.Linking) < "u" && await global.Linking.openURL(a)
    } catch (n) {
        console.error(n)
    }
}
async function K3(r, t) {
    try {
        return await r.getItem(t) || (Vs() ? localStorage.getItem(t) : void 0)
    } catch (e) {
        console.error(e)
    }
}
var C0 = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

function V3(r) {
    var t = r.default;
    if (typeof t == "function") {
        var e = function() {
            return t.apply(this, arguments)
        };
        e.prototype = t.prototype
    } else e = {};
    return Object.defineProperty(e, "__esModule", {
        value: !0
    }), Object.keys(r).forEach(function(n) {
        var o = Object.getOwnPropertyDescriptor(r, n);
        Object.defineProperty(e, n, o.get ? o : {
            enumerable: !0,
            get: function() {
                return r[n]
            }
        })
    }), e
}
var N0 = {
    exports: {}
};
/**
 * [js-sha3]{@link https://github.com/emn178/js-sha3}
 *
 * @version 0.8.0
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2015-2018
 * @license MIT
 */
(function(r) {
    (function() {
        var t = "input is invalid type",
            e = "finalize already called",
            n = typeof window == "object",
            o = n ? window : {};
        o.JS_SHA3_NO_WINDOW && (n = !1);
        var a = !n && typeof self == "object",
            h = !o.JS_SHA3_NO_NODE_JS && typeof process == "object" && process.versions && process.versions.node;
        h ? o = C0 : a && (o = self);
        var g = !o.JS_SHA3_NO_COMMON_JS && !0 && r.exports,
            b = !o.JS_SHA3_NO_ARRAY_BUFFER && typeof ArrayBuffer < "u",
            m = "0123456789abcdef".split(""),
            _ = [31, 7936, 2031616, 520093696],
            S = [4, 1024, 262144, 67108864],
            B = [1, 256, 65536, 16777216],
            k = [6, 1536, 393216, 100663296],
            L = [0, 8, 16, 24],
            K = [1, 0, 32898, 0, 32906, 2147483648, 2147516416, 2147483648, 32907, 0, 2147483649, 0, 2147516545, 2147483648, 32777, 2147483648, 138, 0, 136, 0, 2147516425, 0, 2147483658, 0, 2147516555, 0, 139, 2147483648, 32905, 2147483648, 32771, 2147483648, 32770, 2147483648, 128, 2147483648, 32778, 0, 2147483658, 2147483648, 2147516545, 2147483648, 32896, 2147483648, 2147483649, 0, 2147516424, 2147483648],
            Q = [224, 256, 384, 512],
            et = [128, 256],
            at = ["hex", "buffer", "arrayBuffer", "array", "digest"],
            ut = {
                128: 168,
                256: 136
            };
        (o.JS_SHA3_NO_NODE_JS || !Array.isArray) && (Array.isArray = function(y) {
            return Object.prototype.toString.call(y) === "[object Array]"
        }), b && (o.JS_SHA3_NO_ARRAY_BUFFER_IS_VIEW || !ArrayBuffer.isView) && (ArrayBuffer.isView = function(y) {
            return typeof y == "object" && y.buffer && y.buffer.constructor === ArrayBuffer
        });
        for (var ft = function(y, V, O) {
                return function(D) {
                    return new x(y, V, y).update(D)[O]()
                }
            }, st = function(y, V, O) {
                return function(D, U) {
                    return new x(y, V, U).update(D)[O]()
                }
            }, ot = function(y, V, O) {
                return function(D, U, d, N) {
                    return p["cshake" + y].update(D, U, d, N)[O]()
                }
            }, it = function(y, V, O) {
                return function(D, U, d, N) {
                    return p["kmac" + y].update(D, U, d, N)[O]()
                }
            }, mt = function(y, V, O, D) {
                for (var U = 0; U < at.length; ++U) {
                    var d = at[U];
                    y[d] = V(O, D, d)
                }
                return y
            }, Zt = function(y, V) {
                var O = ft(y, V, "hex");
                return O.create = function() {
                    return new x(y, V, y)
                }, O.update = function(D) {
                    return O.create().update(D)
                }, mt(O, ft, y, V)
            }, oe = function(y, V) {
                var O = st(y, V, "hex");
                return O.create = function(D) {
                    return new x(y, V, D)
                }, O.update = function(D, U) {
                    return O.create(U).update(D)
                }, mt(O, st, y, V)
            }, Tt = function(y, V) {
                var O = ut[y],
                    D = ot(y, V, "hex");
                return D.create = function(U, d, N) {
                    return !d && !N ? p["shake" + y].create(U) : new x(y, V, U).bytepad([d, N], O)
                }, D.update = function(U, d, N, W) {
                    return D.create(d, N, W).update(U)
                }, mt(D, ot, y, V)
            }, ve = function(y, V) {
                var O = ut[y],
                    D = it(y, V, "hex");
                return D.create = function(U, d, N) {
                    return new ht(y, V, d).bytepad(["KMAC", N], O).bytepad([U], O)
                }, D.update = function(U, d, N, W) {
                    return D.create(U, N, W).update(d)
                }, mt(D, it, y, V)
            }, u = [{
                name: "keccak",
                padding: B,
                bits: Q,
                createMethod: Zt
            }, {
                name: "sha3",
                padding: k,
                bits: Q,
                createMethod: Zt
            }, {
                name: "shake",
                padding: _,
                bits: et,
                createMethod: oe
            }, {
                name: "cshake",
                padding: S,
                bits: et,
                createMethod: Tt
            }, {
                name: "kmac",
                padding: S,
                bits: et,
                createMethod: ve
            }], p = {}, v = [], P = 0; P < u.length; ++P)
            for (var C = u[P], R = C.bits, T = 0; T < R.length; ++T) {
                var E = C.name + "_" + R[T];
                if (v.push(E), p[E] = C.createMethod(R[T], C.padding), C.name !== "sha3") {
                    var f = C.name + R[T];
                    v.push(f), p[f] = p[E]
                }
            }

        function x(y, V, O) {
            this.blocks = [], this.s = [], this.padding = V, this.outputBits = O, this.reset = !0, this.finalized = !1, this.block = 0, this.start = 0, this.blockCount = 1600 - (y << 1) >> 5, this.byteCount = this.blockCount << 2, this.outputBlocks = O >> 5, this.extraBytes = (O & 31) >> 3;
            for (var D = 0; D < 50; ++D) this.s[D] = 0
        }
        x.prototype.update = function(y) {
            if (this.finalized) throw new Error(e);
            var V, O = typeof y;
            if (O !== "string") {
                if (O === "object") {
                    if (y === null) throw new Error(t);
                    if (b && y.constructor === ArrayBuffer) y = new Uint8Array(y);
                    else if (!Array.isArray(y) && (!b || !ArrayBuffer.isView(y))) throw new Error(t)
                } else throw new Error(t);
                V = !0
            }
            for (var D = this.blocks, U = this.byteCount, d = y.length, N = this.blockCount, W = 0, rt = this.s, Z, wt; W < d;) {
                if (this.reset)
                    for (this.reset = !1, D[0] = this.block, Z = 1; Z < N + 1; ++Z) D[Z] = 0;
                if (V)
                    for (Z = this.start; W < d && Z < U; ++W) D[Z >> 2] |= y[W] << L[Z++ & 3];
                else
                    for (Z = this.start; W < d && Z < U; ++W) wt = y.charCodeAt(W), wt < 128 ? D[Z >> 2] |= wt << L[Z++ & 3] : wt < 2048 ? (D[Z >> 2] |= (192 | wt >> 6) << L[Z++ & 3], D[Z >> 2] |= (128 | wt & 63) << L[Z++ & 3]) : wt < 55296 || wt >= 57344 ? (D[Z >> 2] |= (224 | wt >> 12) << L[Z++ & 3], D[Z >> 2] |= (128 | wt >> 6 & 63) << L[Z++ & 3], D[Z >> 2] |= (128 | wt & 63) << L[Z++ & 3]) : (wt = 65536 + ((wt & 1023) << 10 | y.charCodeAt(++W) & 1023), D[Z >> 2] |= (240 | wt >> 18) << L[Z++ & 3], D[Z >> 2] |= (128 | wt >> 12 & 63) << L[Z++ & 3], D[Z >> 2] |= (128 | wt >> 6 & 63) << L[Z++ & 3], D[Z >> 2] |= (128 | wt & 63) << L[Z++ & 3]);
                if (this.lastByteIndex = Z, Z >= U) {
                    for (this.start = Z - U, this.block = D[N], Z = 0; Z < N; ++Z) rt[Z] ^= D[Z];
                    gt(rt), this.reset = !0
                } else this.start = Z
            }
            return this
        }, x.prototype.encode = function(y, V) {
            var O = y & 255,
                D = 1,
                U = [O];
            for (y = y >> 8, O = y & 255; O > 0;) U.unshift(O), y = y >> 8, O = y & 255, ++D;
            return V ? U.push(D) : U.unshift(D), this.update(U), U.length
        }, x.prototype.encodeString = function(y) {
            var V, O = typeof y;
            if (O !== "string") {
                if (O === "object") {
                    if (y === null) throw new Error(t);
                    if (b && y.constructor === ArrayBuffer) y = new Uint8Array(y);
                    else if (!Array.isArray(y) && (!b || !ArrayBuffer.isView(y))) throw new Error(t)
                } else throw new Error(t);
                V = !0
            }
            var D = 0,
                U = y.length;
            if (V) D = U;
            else
                for (var d = 0; d < y.length; ++d) {
                    var N = y.charCodeAt(d);
                    N < 128 ? D += 1 : N < 2048 ? D += 2 : N < 55296 || N >= 57344 ? D += 3 : (N = 65536 + ((N & 1023) << 10 | y.charCodeAt(++d) & 1023), D += 4)
                }
            return D += this.encode(D * 8), this.update(y), D
        }, x.prototype.bytepad = function(y, V) {
            for (var O = this.encode(V), D = 0; D < y.length; ++D) O += this.encodeString(y[D]);
            var U = V - O % V,
                d = [];
            return d.length = U, this.update(d), this
        }, x.prototype.finalize = function() {
            if (!this.finalized) {
                this.finalized = !0;
                var y = this.blocks,
                    V = this.lastByteIndex,
                    O = this.blockCount,
                    D = this.s;
                if (y[V >> 2] |= this.padding[V & 3], this.lastByteIndex === this.byteCount)
                    for (y[0] = y[O], V = 1; V < O + 1; ++V) y[V] = 0;
                for (y[O - 1] |= 2147483648, V = 0; V < O; ++V) D[V] ^= y[V];
                gt(D)
            }
        }, x.prototype.toString = x.prototype.hex = function() {
            this.finalize();
            for (var y = this.blockCount, V = this.s, O = this.outputBlocks, D = this.extraBytes, U = 0, d = 0, N = "", W; d < O;) {
                for (U = 0; U < y && d < O; ++U, ++d) W = V[U], N += m[W >> 4 & 15] + m[W & 15] + m[W >> 12 & 15] + m[W >> 8 & 15] + m[W >> 20 & 15] + m[W >> 16 & 15] + m[W >> 28 & 15] + m[W >> 24 & 15];
                d % y === 0 && (gt(V), U = 0)
            }
            return D && (W = V[U], N += m[W >> 4 & 15] + m[W & 15], D > 1 && (N += m[W >> 12 & 15] + m[W >> 8 & 15]), D > 2 && (N += m[W >> 20 & 15] + m[W >> 16 & 15])), N
        }, x.prototype.arrayBuffer = function() {
            this.finalize();
            var y = this.blockCount,
                V = this.s,
                O = this.outputBlocks,
                D = this.extraBytes,
                U = 0,
                d = 0,
                N = this.outputBits >> 3,
                W;
            D ? W = new ArrayBuffer(O + 1 << 2) : W = new ArrayBuffer(N);
            for (var rt = new Uint32Array(W); d < O;) {
                for (U = 0; U < y && d < O; ++U, ++d) rt[d] = V[U];
                d % y === 0 && gt(V)
            }
            return D && (rt[U] = V[U], W = W.slice(0, N)), W
        }, x.prototype.buffer = x.prototype.arrayBuffer, x.prototype.digest = x.prototype.array = function() {
            this.finalize();
            for (var y = this.blockCount, V = this.s, O = this.outputBlocks, D = this.extraBytes, U = 0, d = 0, N = [], W, rt; d < O;) {
                for (U = 0; U < y && d < O; ++U, ++d) W = d << 2, rt = V[U], N[W] = rt & 255, N[W + 1] = rt >> 8 & 255, N[W + 2] = rt >> 16 & 255, N[W + 3] = rt >> 24 & 255;
                d % y === 0 && gt(V)
            }
            return D && (W = d << 2, rt = V[U], N[W] = rt & 255, D > 1 && (N[W + 1] = rt >> 8 & 255), D > 2 && (N[W + 2] = rt >> 16 & 255)), N
        };

        function ht(y, V, O) {
            x.call(this, y, V, O)
        }
        ht.prototype = new x, ht.prototype.finalize = function() {
            return this.encode(this.outputBits, !0), x.prototype.finalize.call(this)
        };
        var gt = function(y) {
            var V, O, D, U, d, N, W, rt, Z, wt, bt, vt, Re, Lt, Rt, ne, It, St, be, _t, xt, te, At, Dt, ae, $t, Kt, ke, Qt, Vt, ze, ee, ue, Fe, pe, ye, yr, qt, Mt, Ae, Bt, Ot, we, jt, zt, Ee, Ft, Ut, xe, kt, Et, Oe, Ht, Pe, bi, Me, se, Zr, ti, ei, ri, ii, nr;
            for (D = 0; D < 48; D += 2) U = y[0] ^ y[10] ^ y[20] ^ y[30] ^ y[40], d = y[1] ^ y[11] ^ y[21] ^ y[31] ^ y[41], N = y[2] ^ y[12] ^ y[22] ^ y[32] ^ y[42], W = y[3] ^ y[13] ^ y[23] ^ y[33] ^ y[43], rt = y[4] ^ y[14] ^ y[24] ^ y[34] ^ y[44], Z = y[5] ^ y[15] ^ y[25] ^ y[35] ^ y[45], wt = y[6] ^ y[16] ^ y[26] ^ y[36] ^ y[46], bt = y[7] ^ y[17] ^ y[27] ^ y[37] ^ y[47], vt = y[8] ^ y[18] ^ y[28] ^ y[38] ^ y[48], Re = y[9] ^ y[19] ^ y[29] ^ y[39] ^ y[49], V = vt ^ (N << 1 | W >>> 31), O = Re ^ (W << 1 | N >>> 31), y[0] ^= V, y[1] ^= O, y[10] ^= V, y[11] ^= O, y[20] ^= V, y[21] ^= O, y[30] ^= V, y[31] ^= O, y[40] ^= V, y[41] ^= O, V = U ^ (rt << 1 | Z >>> 31), O = d ^ (Z << 1 | rt >>> 31), y[2] ^= V, y[3] ^= O, y[12] ^= V, y[13] ^= O, y[22] ^= V, y[23] ^= O, y[32] ^= V, y[33] ^= O, y[42] ^= V, y[43] ^= O, V = N ^ (wt << 1 | bt >>> 31), O = W ^ (bt << 1 | wt >>> 31), y[4] ^= V, y[5] ^= O, y[14] ^= V, y[15] ^= O, y[24] ^= V, y[25] ^= O, y[34] ^= V, y[35] ^= O, y[44] ^= V, y[45] ^= O, V = rt ^ (vt << 1 | Re >>> 31), O = Z ^ (Re << 1 | vt >>> 31), y[6] ^= V, y[7] ^= O, y[16] ^= V, y[17] ^= O, y[26] ^= V, y[27] ^= O, y[36] ^= V, y[37] ^= O, y[46] ^= V, y[47] ^= O, V = wt ^ (U << 1 | d >>> 31), O = bt ^ (d << 1 | U >>> 31), y[8] ^= V, y[9] ^= O, y[18] ^= V, y[19] ^= O, y[28] ^= V, y[29] ^= O, y[38] ^= V, y[39] ^= O, y[48] ^= V, y[49] ^= O, Lt = y[0], Rt = y[1], Ee = y[11] << 4 | y[10] >>> 28, Ft = y[10] << 4 | y[11] >>> 28, ke = y[20] << 3 | y[21] >>> 29, Qt = y[21] << 3 | y[20] >>> 29, ei = y[31] << 9 | y[30] >>> 23, ri = y[30] << 9 | y[31] >>> 23, Ot = y[40] << 18 | y[41] >>> 14, we = y[41] << 18 | y[40] >>> 14, Fe = y[2] << 1 | y[3] >>> 31, pe = y[3] << 1 | y[2] >>> 31, ne = y[13] << 12 | y[12] >>> 20, It = y[12] << 12 | y[13] >>> 20, Ut = y[22] << 10 | y[23] >>> 22, xe = y[23] << 10 | y[22] >>> 22, Vt = y[33] << 13 | y[32] >>> 19, ze = y[32] << 13 | y[33] >>> 19, ii = y[42] << 2 | y[43] >>> 30, nr = y[43] << 2 | y[42] >>> 30, Pe = y[5] << 30 | y[4] >>> 2, bi = y[4] << 30 | y[5] >>> 2, ye = y[14] << 6 | y[15] >>> 26, yr = y[15] << 6 | y[14] >>> 26, St = y[25] << 11 | y[24] >>> 21, be = y[24] << 11 | y[25] >>> 21, kt = y[34] << 15 | y[35] >>> 17, Et = y[35] << 15 | y[34] >>> 17, ee = y[45] << 29 | y[44] >>> 3, ue = y[44] << 29 | y[45] >>> 3, Dt = y[6] << 28 | y[7] >>> 4, ae = y[7] << 28 | y[6] >>> 4, Me = y[17] << 23 | y[16] >>> 9, se = y[16] << 23 | y[17] >>> 9, qt = y[26] << 25 | y[27] >>> 7, Mt = y[27] << 25 | y[26] >>> 7, _t = y[36] << 21 | y[37] >>> 11, xt = y[37] << 21 | y[36] >>> 11, Oe = y[47] << 24 | y[46] >>> 8, Ht = y[46] << 24 | y[47] >>> 8, jt = y[8] << 27 | y[9] >>> 5, zt = y[9] << 27 | y[8] >>> 5, $t = y[18] << 20 | y[19] >>> 12, Kt = y[19] << 20 | y[18] >>> 12, Zr = y[29] << 7 | y[28] >>> 25, ti = y[28] << 7 | y[29] >>> 25, Ae = y[38] << 8 | y[39] >>> 24, Bt = y[39] << 8 | y[38] >>> 24, te = y[48] << 14 | y[49] >>> 18, At = y[49] << 14 | y[48] >>> 18, y[0] = Lt ^ ~ne & St, y[1] = Rt ^ ~It & be, y[10] = Dt ^ ~$t & ke, y[11] = ae ^ ~Kt & Qt, y[20] = Fe ^ ~ye & qt, y[21] = pe ^ ~yr & Mt, y[30] = jt ^ ~Ee & Ut, y[31] = zt ^ ~Ft & xe, y[40] = Pe ^ ~Me & Zr, y[41] = bi ^ ~se & ti, y[2] = ne ^ ~St & _t, y[3] = It ^ ~be & xt, y[12] = $t ^ ~ke & Vt, y[13] = Kt ^ ~Qt & ze, y[22] = ye ^ ~qt & Ae, y[23] = yr ^ ~Mt & Bt, y[32] = Ee ^ ~Ut & kt, y[33] = Ft ^ ~xe & Et, y[42] = Me ^ ~Zr & ei, y[43] = se ^ ~ti & ri, y[4] = St ^ ~_t & te, y[5] = be ^ ~xt & At, y[14] = ke ^ ~Vt & ee, y[15] = Qt ^ ~ze & ue, y[24] = qt ^ ~Ae & Ot, y[25] = Mt ^ ~Bt & we, y[34] = Ut ^ ~kt & Oe, y[35] = xe ^ ~Et & Ht, y[44] = Zr ^ ~ei & ii, y[45] = ti ^ ~ri & nr, y[6] = _t ^ ~te & Lt, y[7] = xt ^ ~At & Rt, y[16] = Vt ^ ~ee & Dt, y[17] = ze ^ ~ue & ae, y[26] = Ae ^ ~Ot & Fe, y[27] = Bt ^ ~we & pe, y[36] = kt ^ ~Oe & jt, y[37] = Et ^ ~Ht & zt, y[46] = ei ^ ~ii & Pe, y[47] = ri ^ ~nr & bi, y[8] = te ^ ~Lt & ne, y[9] = At ^ ~Rt & It, y[18] = ee ^ ~Dt & $t, y[19] = ue ^ ~ae & Kt, y[28] = Ot ^ ~Fe & ye, y[29] = we ^ ~pe & yr, y[38] = Oe ^ ~jt & Ee, y[39] = Ht ^ ~zt & Ft, y[48] = ii ^ ~Pe & Me, y[49] = nr ^ ~bi & se, y[0] ^= K[D], y[1] ^= K[D + 1]
        };
        if (g) r.exports = p;
        else
            for (P = 0; P < v.length; ++P) o[v[P]] = p[v[P]]
    })()
})(N0);
var G3 = N0.exports;
const Q3 = "logger/5.7.0";
let Ud = !1,
    kd = !1;
const hc = {
    debug: 1,
    default: 2,
    info: 2,
    warning: 3,
    error: 4,
    off: 5
};
let Ld = hc.default,
    Qh = null;

function W3() {
    try {
        const r = [];
        if (["NFD", "NFC", "NFKD", "NFKC"].forEach(t => {
                try {
                    if ("test".normalize(t) !== "test") throw new Error("bad normalize")
                } catch {
                    r.push(t)
                }
            }), r.length) throw new Error("missing " + r.join(", "));
        if ("é".normalize("NFD") !== "é") throw new Error("broken implementation")
    } catch (r) {
        return r.message
    }
    return null
}
const $d = W3();
var Eu;
(function(r) {
    r.DEBUG = "DEBUG", r.INFO = "INFO", r.WARNING = "WARNING", r.ERROR = "ERROR", r.OFF = "OFF"
})(Eu || (Eu = {}));
var Ci;
(function(r) {
    r.UNKNOWN_ERROR = "UNKNOWN_ERROR", r.NOT_IMPLEMENTED = "NOT_IMPLEMENTED", r.UNSUPPORTED_OPERATION = "UNSUPPORTED_OPERATION", r.NETWORK_ERROR = "NETWORK_ERROR", r.SERVER_ERROR = "SERVER_ERROR", r.TIMEOUT = "TIMEOUT", r.BUFFER_OVERRUN = "BUFFER_OVERRUN", r.NUMERIC_FAULT = "NUMERIC_FAULT", r.MISSING_NEW = "MISSING_NEW", r.INVALID_ARGUMENT = "INVALID_ARGUMENT", r.MISSING_ARGUMENT = "MISSING_ARGUMENT", r.UNEXPECTED_ARGUMENT = "UNEXPECTED_ARGUMENT", r.CALL_EXCEPTION = "CALL_EXCEPTION", r.INSUFFICIENT_FUNDS = "INSUFFICIENT_FUNDS", r.NONCE_EXPIRED = "NONCE_EXPIRED", r.REPLACEMENT_UNDERPRICED = "REPLACEMENT_UNDERPRICED", r.UNPREDICTABLE_GAS_LIMIT = "UNPREDICTABLE_GAS_LIMIT", r.TRANSACTION_REPLACED = "TRANSACTION_REPLACED", r.ACTION_REJECTED = "ACTION_REJECTED"
})(Ci || (Ci = {}));
const jd = "0123456789abcdef";
let dr = class ir {
    constructor(t) {
        Object.defineProperty(this, "version", {
            enumerable: !0,
            value: t,
            writable: !1
        })
    }
    _log(t, e) {
        const n = t.toLowerCase();
        hc[n] == null && this.throwArgumentError("invalid log level name", "logLevel", t), !(Ld > hc[n]) && console.log.apply(console, e)
    }
    debug(...t) {
        this._log(ir.levels.DEBUG, t)
    }
    info(...t) {
        this._log(ir.levels.INFO, t)
    }
    warn(...t) {
        this._log(ir.levels.WARNING, t)
    }
    makeError(t, e, n) {
        if (kd) return this.makeError("censored error", e, {});
        e || (e = ir.errors.UNKNOWN_ERROR), n || (n = {});
        const o = [];
        Object.keys(n).forEach(b => {
            const m = n[b];
            try {
                if (m instanceof Uint8Array) {
                    let _ = "";
                    for (let S = 0; S < m.length; S++) _ += jd[m[S] >> 4], _ += jd[m[S] & 15];
                    o.push(b + "=Uint8Array(0x" + _ + ")")
                } else o.push(b + "=" + JSON.stringify(m))
            } catch {
                o.push(b + "=" + JSON.stringify(n[b].toString()))
            }
        }), o.push(`code=${e}`), o.push(`version=${this.version}`);
        const a = t;
        let h = "";
        switch (e) {
            case Ci.NUMERIC_FAULT:
                {
                    h = "NUMERIC_FAULT";
                    const b = t;
                    switch (b) {
                        case "overflow":
                        case "underflow":
                        case "division-by-zero":
                            h += "-" + b;
                            break;
                        case "negative-power":
                        case "negative-width":
                            h += "-unsupported";
                            break;
                        case "unbound-bitwise-result":
                            h += "-unbound-result";
                            break
                    }
                    break
                }
            case Ci.CALL_EXCEPTION:
            case Ci.INSUFFICIENT_FUNDS:
            case Ci.MISSING_NEW:
            case Ci.NONCE_EXPIRED:
            case Ci.REPLACEMENT_UNDERPRICED:
            case Ci.TRANSACTION_REPLACED:
            case Ci.UNPREDICTABLE_GAS_LIMIT:
                h = e;
                break
        }
        h && (t += " [ See: https://links.ethers.org/v5-errors-" + h + " ]"), o.length && (t += " (" + o.join(", ") + ")");
        const g = new Error(t);
        return g.reason = a, g.code = e, Object.keys(n).forEach(function(b) {
            g[b] = n[b]
        }), g
    }
    throwError(t, e, n) {
        throw this.makeError(t, e, n)
    }
    throwArgumentError(t, e, n) {
        return this.throwError(t, ir.errors.INVALID_ARGUMENT, {
            argument: e,
            value: n
        })
    }
    assert(t, e, n, o) {
        t || this.throwError(e, n, o)
    }
    assertArgument(t, e, n, o) {
        t || this.throwArgumentError(e, n, o)
    }
    checkNormalize(t) {
        $d && this.throwError("platform missing String.prototype.normalize", ir.errors.UNSUPPORTED_OPERATION, {
            operation: "String.prototype.normalize",
            form: $d
        })
    }
    checkSafeUint53(t, e) {
        typeof t == "number" && (e == null && (e = "value not safe"), (t < 0 || t >= 9007199254740991) && this.throwError(e, ir.errors.NUMERIC_FAULT, {
            operation: "checkSafeInteger",
            fault: "out-of-safe-range",
            value: t
        }), t % 1 && this.throwError(e, ir.errors.NUMERIC_FAULT, {
            operation: "checkSafeInteger",
            fault: "non-integer",
            value: t
        }))
    }
    checkArgumentCount(t, e, n) {
        n ? n = ": " + n : n = "", t < e && this.throwError("missing argument" + n, ir.errors.MISSING_ARGUMENT, {
            count: t,
            expectedCount: e
        }), t > e && this.throwError("too many arguments" + n, ir.errors.UNEXPECTED_ARGUMENT, {
            count: t,
            expectedCount: e
        })
    }
    checkNew(t, e) {
        (t === Object || t == null) && this.throwError("missing new", ir.errors.MISSING_NEW, {
            name: e.name
        })
    }
    checkAbstract(t, e) {
        t === e ? this.throwError("cannot instantiate abstract class " + JSON.stringify(e.name) + " directly; use a sub-class", ir.errors.UNSUPPORTED_OPERATION, {
            name: t.name,
            operation: "new"
        }) : (t === Object || t == null) && this.throwError("missing new", ir.errors.MISSING_NEW, {
            name: e.name
        })
    }
    static globalLogger() {
        return Qh || (Qh = new ir(Q3)), Qh
    }
    static setCensorship(t, e) {
        if (!t && e && this.globalLogger().throwError("cannot permanently disable censorship", ir.errors.UNSUPPORTED_OPERATION, {
                operation: "setCensorship"
            }), Ud) {
            if (!t) return;
            this.globalLogger().throwError("error censorship permanent", ir.errors.UNSUPPORTED_OPERATION, {
                operation: "setCensorship"
            })
        }
        kd = !!t, Ud = !!e
    }
    static setLogLevel(t) {
        const e = hc[t.toLowerCase()];
        if (e == null) {
            ir.globalLogger().warn("invalid log level - " + t);
            return
        }
        Ld = e
    }
    static from(t) {
        return new ir(t)
    }
};
dr.errors = Ci, dr.levels = Eu;
const J3 = "bytes/5.7.0",
    Je = new dr(J3);

function R0(r) {
    return !!r.toHexString
}

function js(r) {
    return r.slice || (r.slice = function() {
        const t = Array.prototype.slice.call(arguments);
        return js(new Uint8Array(Array.prototype.slice.apply(r, t)))
    }), r
}

function Y3(r) {
    return Yr(r) && !(r.length % 2) || Gs(r)
}

function zd(r) {
    return typeof r == "number" && r == r && r % 1 === 0
}

function Gs(r) {
    if (r == null) return !1;
    if (r.constructor === Uint8Array) return !0;
    if (typeof r == "string" || !zd(r.length) || r.length < 0) return !1;
    for (let t = 0; t < r.length; t++) {
        const e = r[t];
        if (!zd(e) || e < 0 || e >= 256) return !1
    }
    return !0
}

function Ve(r, t) {
    if (t || (t = {}), typeof r == "number") {
        Je.checkSafeUint53(r, "invalid arrayify value");
        const e = [];
        for (; r;) e.unshift(r & 255), r = parseInt(String(r / 256));
        return e.length === 0 && e.push(0), js(new Uint8Array(e))
    }
    if (t.allowMissingPrefix && typeof r == "string" && r.substring(0, 2) !== "0x" && (r = "0x" + r), R0(r) && (r = r.toHexString()), Yr(r)) {
        let e = r.substring(2);
        e.length % 2 && (t.hexPad === "left" ? e = "0" + e : t.hexPad === "right" ? e += "0" : Je.throwArgumentError("hex data is odd-length", "value", r));
        const n = [];
        for (let o = 0; o < e.length; o += 2) n.push(parseInt(e.substring(o, o + 2), 16));
        return js(new Uint8Array(n))
    }
    return Gs(r) ? js(new Uint8Array(r)) : Je.throwArgumentError("invalid arrayify value", "value", r)
}

function X3(r) {
    const t = r.map(o => Ve(o)),
        e = t.reduce((o, a) => o + a.length, 0),
        n = new Uint8Array(e);
    return t.reduce((o, a) => (n.set(a, o), o + a.length), 0), js(n)
}

function Z3(r, t) {
    r = Ve(r), r.length > t && Je.throwArgumentError("value out of range", "value", arguments[0]);
    const e = new Uint8Array(t);
    return e.set(r, t - r.length), js(e)
}

function Yr(r, t) {
    return !(typeof r != "string" || !r.match(/^0x[0-9A-Fa-f]*$/) || t && r.length !== 2 + 2 * t)
}
const Wh = "0123456789abcdef";

function Ur(r, t) {
    if (t || (t = {}), typeof r == "number") {
        Je.checkSafeUint53(r, "invalid hexlify value");
        let e = "";
        for (; r;) e = Wh[r & 15] + e, r = Math.floor(r / 16);
        return e.length ? (e.length % 2 && (e = "0" + e), "0x" + e) : "0x00"
    }
    if (typeof r == "bigint") return r = r.toString(16), r.length % 2 ? "0x0" + r : "0x" + r;
    if (t.allowMissingPrefix && typeof r == "string" && r.substring(0, 2) !== "0x" && (r = "0x" + r), R0(r)) return r.toHexString();
    if (Yr(r)) return r.length % 2 && (t.hexPad === "left" ? r = "0x0" + r.substring(2) : t.hexPad === "right" ? r += "0" : Je.throwArgumentError("hex data is odd-length", "value", r)), r.toLowerCase();
    if (Gs(r)) {
        let e = "0x";
        for (let n = 0; n < r.length; n++) {
            let o = r[n];
            e += Wh[(o & 240) >> 4] + Wh[o & 15]
        }
        return e
    }
    return Je.throwArgumentError("invalid hexlify value", "value", r)
}

function t_(r) {
    if (typeof r != "string") r = Ur(r);
    else if (!Yr(r) || r.length % 2) return null;
    return (r.length - 2) / 2
}

function Fd(r, t, e) {
    return typeof r != "string" ? r = Ur(r) : (!Yr(r) || r.length % 2) && Je.throwArgumentError("invalid hexData", "value", r), t = 2 + 2 * t, e != null ? "0x" + r.substring(t, 2 + 2 * e) : "0x" + r.substring(t)
}

function Ji(r, t) {
    for (typeof r != "string" ? r = Ur(r) : Yr(r) || Je.throwArgumentError("invalid hex string", "value", r), r.length > 2 * t + 2 && Je.throwArgumentError("value out of range", "value", arguments[1]); r.length < 2 * t + 2;) r = "0x0" + r.substring(2);
    return r
}

function O0(r) {
    const t = {
        r: "0x",
        s: "0x",
        _vs: "0x",
        recoveryParam: 0,
        v: 0,
        yParityAndS: "0x",
        compact: "0x"
    };
    if (Y3(r)) {
        let e = Ve(r);
        e.length === 64 ? (t.v = 27 + (e[32] >> 7), e[32] &= 127, t.r = Ur(e.slice(0, 32)), t.s = Ur(e.slice(32, 64))) : e.length === 65 ? (t.r = Ur(e.slice(0, 32)), t.s = Ur(e.slice(32, 64)), t.v = e[64]) : Je.throwArgumentError("invalid signature string", "signature", r), t.v < 27 && (t.v === 0 || t.v === 1 ? t.v += 27 : Je.throwArgumentError("signature invalid v byte", "signature", r)), t.recoveryParam = 1 - t.v % 2, t.recoveryParam && (e[32] |= 128), t._vs = Ur(e.slice(32, 64))
    } else {
        if (t.r = r.r, t.s = r.s, t.v = r.v, t.recoveryParam = r.recoveryParam, t._vs = r._vs, t._vs != null) {
            const o = Z3(Ve(t._vs), 32);
            t._vs = Ur(o);
            const a = o[0] >= 128 ? 1 : 0;
            t.recoveryParam == null ? t.recoveryParam = a : t.recoveryParam !== a && Je.throwArgumentError("signature recoveryParam mismatch _vs", "signature", r), o[0] &= 127;
            const h = Ur(o);
            t.s == null ? t.s = h : t.s !== h && Je.throwArgumentError("signature v mismatch _vs", "signature", r)
        }
        if (t.recoveryParam == null) t.v == null ? Je.throwArgumentError("signature missing v and recoveryParam", "signature", r) : t.v === 0 || t.v === 1 ? t.recoveryParam = t.v : t.recoveryParam = 1 - t.v % 2;
        else if (t.v == null) t.v = 27 + t.recoveryParam;
        else {
            const o = t.v === 0 || t.v === 1 ? t.v : 1 - t.v % 2;
            t.recoveryParam !== o && Je.throwArgumentError("signature recoveryParam mismatch v", "signature", r)
        }
        t.r == null || !Yr(t.r) ? Je.throwArgumentError("signature missing or invalid r", "signature", r) : t.r = Ji(t.r, 32), t.s == null || !Yr(t.s) ? Je.throwArgumentError("signature missing or invalid s", "signature", r) : t.s = Ji(t.s, 32);
        const e = Ve(t.s);
        e[0] >= 128 && Je.throwArgumentError("signature s out of range", "signature", r), t.recoveryParam && (e[0] |= 128);
        const n = Ur(e);
        t._vs && (Yr(t._vs) || Je.throwArgumentError("signature invalid _vs", "signature", r), t._vs = Ji(t._vs, 32)), t._vs == null ? t._vs = n : t._vs !== n && Je.throwArgumentError("signature _vs mismatch v and s", "signature", r)
    }
    return t.yParityAndS = t._vs, t.compact = t.r + t.yParityAndS.substring(2), t
}

function Hu(r) {
    return "0x" + G3.keccak_256(Ve(r))
}
var T0 = {
        exports: {}
    },
    e_ = {},
    r_ = Object.freeze({
        __proto__: null,
        default: e_
    }),
    i_ = V3(r_);
(function(r) {
    (function(t, e) {
        function n(u, p) {
            if (!u) throw new Error(p || "Assertion failed")
        }

        function o(u, p) {
            u.super_ = p;
            var v = function() {};
            v.prototype = p.prototype, u.prototype = new v, u.prototype.constructor = u
        }

        function a(u, p, v) {
            if (a.isBN(u)) return u;
            this.negative = 0, this.words = null, this.length = 0, this.red = null, u !== null && ((p === "le" || p === "be") && (v = p, p = 10), this._init(u || 0, p || 10, v || "be"))
        }
        typeof t == "object" ? t.exports = a : e.BN = a, a.BN = a, a.wordSize = 26;
        var h;
        try {
            typeof window < "u" && typeof window.Buffer < "u" ? h = window.Buffer : h = i_.Buffer
        } catch {}
        a.isBN = function(u) {
            return u instanceof a ? !0 : u !== null && typeof u == "object" && u.constructor.wordSize === a.wordSize && Array.isArray(u.words)
        }, a.max = function(u, p) {
            return u.cmp(p) > 0 ? u : p
        }, a.min = function(u, p) {
            return u.cmp(p) < 0 ? u : p
        }, a.prototype._init = function(u, p, v) {
            if (typeof u == "number") return this._initNumber(u, p, v);
            if (typeof u == "object") return this._initArray(u, p, v);
            p === "hex" && (p = 16), n(p === (p | 0) && p >= 2 && p <= 36), u = u.toString().replace(/\s+/g, "");
            var P = 0;
            u[0] === "-" && (P++, this.negative = 1), P < u.length && (p === 16 ? this._parseHex(u, P, v) : (this._parseBase(u, p, P), v === "le" && this._initArray(this.toArray(), p, v)))
        }, a.prototype._initNumber = function(u, p, v) {
            u < 0 && (this.negative = 1, u = -u), u < 67108864 ? (this.words = [u & 67108863], this.length = 1) : u < 4503599627370496 ? (this.words = [u & 67108863, u / 67108864 & 67108863], this.length = 2) : (n(u < 9007199254740992), this.words = [u & 67108863, u / 67108864 & 67108863, 1], this.length = 3), v === "le" && this._initArray(this.toArray(), p, v)
        }, a.prototype._initArray = function(u, p, v) {
            if (n(typeof u.length == "number"), u.length <= 0) return this.words = [0], this.length = 1, this;
            this.length = Math.ceil(u.length / 3), this.words = new Array(this.length);
            for (var P = 0; P < this.length; P++) this.words[P] = 0;
            var C, R, T = 0;
            if (v === "be")
                for (P = u.length - 1, C = 0; P >= 0; P -= 3) R = u[P] | u[P - 1] << 8 | u[P - 2] << 16, this.words[C] |= R << T & 67108863, this.words[C + 1] = R >>> 26 - T & 67108863, T += 24, T >= 26 && (T -= 26, C++);
            else if (v === "le")
                for (P = 0, C = 0; P < u.length; P += 3) R = u[P] | u[P + 1] << 8 | u[P + 2] << 16, this.words[C] |= R << T & 67108863, this.words[C + 1] = R >>> 26 - T & 67108863, T += 24, T >= 26 && (T -= 26, C++);
            return this._strip()
        };

        function g(u, p) {
            var v = u.charCodeAt(p);
            if (v >= 48 && v <= 57) return v - 48;
            if (v >= 65 && v <= 70) return v - 55;
            if (v >= 97 && v <= 102) return v - 87;
            n(!1, "Invalid character in " + u)
        }

        function b(u, p, v) {
            var P = g(u, v);
            return v - 1 >= p && (P |= g(u, v - 1) << 4), P
        }
        a.prototype._parseHex = function(u, p, v) {
            this.length = Math.ceil((u.length - p) / 6), this.words = new Array(this.length);
            for (var P = 0; P < this.length; P++) this.words[P] = 0;
            var C = 0,
                R = 0,
                T;
            if (v === "be")
                for (P = u.length - 1; P >= p; P -= 2) T = b(u, p, P) << C, this.words[R] |= T & 67108863, C >= 18 ? (C -= 18, R += 1, this.words[R] |= T >>> 26) : C += 8;
            else {
                var E = u.length - p;
                for (P = E % 2 === 0 ? p + 1 : p; P < u.length; P += 2) T = b(u, p, P) << C, this.words[R] |= T & 67108863, C >= 18 ? (C -= 18, R += 1, this.words[R] |= T >>> 26) : C += 8
            }
            this._strip()
        };

        function m(u, p, v, P) {
            for (var C = 0, R = 0, T = Math.min(u.length, v), E = p; E < T; E++) {
                var f = u.charCodeAt(E) - 48;
                C *= P, f >= 49 ? R = f - 49 + 10 : f >= 17 ? R = f - 17 + 10 : R = f, n(f >= 0 && R < P, "Invalid character"), C += R
            }
            return C
        }
        a.prototype._parseBase = function(u, p, v) {
            this.words = [0], this.length = 1;
            for (var P = 0, C = 1; C <= 67108863; C *= p) P++;
            P--, C = C / p | 0;
            for (var R = u.length - v, T = R % P, E = Math.min(R, R - T) + v, f = 0, x = v; x < E; x += P) f = m(u, x, x + P, p), this.imuln(C), this.words[0] + f < 67108864 ? this.words[0] += f : this._iaddn(f);
            if (T !== 0) {
                var ht = 1;
                for (f = m(u, x, u.length, p), x = 0; x < T; x++) ht *= p;
                this.imuln(ht), this.words[0] + f < 67108864 ? this.words[0] += f : this._iaddn(f)
            }
            this._strip()
        }, a.prototype.copy = function(u) {
            u.words = new Array(this.length);
            for (var p = 0; p < this.length; p++) u.words[p] = this.words[p];
            u.length = this.length, u.negative = this.negative, u.red = this.red
        };

        function _(u, p) {
            u.words = p.words, u.length = p.length, u.negative = p.negative, u.red = p.red
        }
        if (a.prototype._move = function(u) {
                _(u, this)
            }, a.prototype.clone = function() {
                var u = new a(null);
                return this.copy(u), u
            }, a.prototype._expand = function(u) {
                for (; this.length < u;) this.words[this.length++] = 0;
                return this
            }, a.prototype._strip = function() {
                for (; this.length > 1 && this.words[this.length - 1] === 0;) this.length--;
                return this._normSign()
            }, a.prototype._normSign = function() {
                return this.length === 1 && this.words[0] === 0 && (this.negative = 0), this
            }, typeof Symbol < "u" && typeof Symbol.for == "function") try {
            a.prototype[Symbol.for("nodejs.util.inspect.custom")] = S
        } catch {
            a.prototype.inspect = S
        } else a.prototype.inspect = S;

        function S() {
            return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">"
        }
        var B = ["", "0", "00", "000", "0000", "00000", "000000", "0000000", "00000000", "000000000", "0000000000", "00000000000", "000000000000", "0000000000000", "00000000000000", "000000000000000", "0000000000000000", "00000000000000000", "000000000000000000", "0000000000000000000", "00000000000000000000", "000000000000000000000", "0000000000000000000000", "00000000000000000000000", "000000000000000000000000", "0000000000000000000000000"],
            k = [0, 0, 25, 16, 12, 11, 10, 9, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
            L = [0, 0, 33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216, 43046721, 1e7, 19487171, 35831808, 62748517, 7529536, 11390625, 16777216, 24137569, 34012224, 47045881, 64e6, 4084101, 5153632, 6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149, 243e5, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176];
        a.prototype.toString = function(u, p) {
            u = u || 10, p = p | 0 || 1;
            var v;
            if (u === 16 || u === "hex") {
                v = "";
                for (var P = 0, C = 0, R = 0; R < this.length; R++) {
                    var T = this.words[R],
                        E = ((T << P | C) & 16777215).toString(16);
                    C = T >>> 24 - P & 16777215, P += 2, P >= 26 && (P -= 26, R--), C !== 0 || R !== this.length - 1 ? v = B[6 - E.length] + E + v : v = E + v
                }
                for (C !== 0 && (v = C.toString(16) + v); v.length % p !== 0;) v = "0" + v;
                return this.negative !== 0 && (v = "-" + v), v
            }
            if (u === (u | 0) && u >= 2 && u <= 36) {
                var f = k[u],
                    x = L[u];
                v = "";
                var ht = this.clone();
                for (ht.negative = 0; !ht.isZero();) {
                    var gt = ht.modrn(x).toString(u);
                    ht = ht.idivn(x), ht.isZero() ? v = gt + v : v = B[f - gt.length] + gt + v
                }
                for (this.isZero() && (v = "0" + v); v.length % p !== 0;) v = "0" + v;
                return this.negative !== 0 && (v = "-" + v), v
            }
            n(!1, "Base should be between 2 and 36")
        }, a.prototype.toNumber = function() {
            var u = this.words[0];
            return this.length === 2 ? u += this.words[1] * 67108864 : this.length === 3 && this.words[2] === 1 ? u += 4503599627370496 + this.words[1] * 67108864 : this.length > 2 && n(!1, "Number can only safely store up to 53 bits"), this.negative !== 0 ? -u : u
        }, a.prototype.toJSON = function() {
            return this.toString(16, 2)
        }, h && (a.prototype.toBuffer = function(u, p) {
            return this.toArrayLike(h, u, p)
        }), a.prototype.toArray = function(u, p) {
            return this.toArrayLike(Array, u, p)
        };
        var K = function(u, p) {
            return u.allocUnsafe ? u.allocUnsafe(p) : new u(p)
        };
        a.prototype.toArrayLike = function(u, p, v) {
            this._strip();
            var P = this.byteLength(),
                C = v || Math.max(1, P);
            n(P <= C, "byte array longer than desired length"), n(C > 0, "Requested array length <= 0");
            var R = K(u, C),
                T = p === "le" ? "LE" : "BE";
            return this["_toArrayLike" + T](R, P), R
        }, a.prototype._toArrayLikeLE = function(u, p) {
            for (var v = 0, P = 0, C = 0, R = 0; C < this.length; C++) {
                var T = this.words[C] << R | P;
                u[v++] = T & 255, v < u.length && (u[v++] = T >> 8 & 255), v < u.length && (u[v++] = T >> 16 & 255), R === 6 ? (v < u.length && (u[v++] = T >> 24 & 255), P = 0, R = 0) : (P = T >>> 24, R += 2)
            }
            if (v < u.length)
                for (u[v++] = P; v < u.length;) u[v++] = 0
        }, a.prototype._toArrayLikeBE = function(u, p) {
            for (var v = u.length - 1, P = 0, C = 0, R = 0; C < this.length; C++) {
                var T = this.words[C] << R | P;
                u[v--] = T & 255, v >= 0 && (u[v--] = T >> 8 & 255), v >= 0 && (u[v--] = T >> 16 & 255), R === 6 ? (v >= 0 && (u[v--] = T >> 24 & 255), P = 0, R = 0) : (P = T >>> 24, R += 2)
            }
            if (v >= 0)
                for (u[v--] = P; v >= 0;) u[v--] = 0
        }, Math.clz32 ? a.prototype._countBits = function(u) {
            return 32 - Math.clz32(u)
        } : a.prototype._countBits = function(u) {
            var p = u,
                v = 0;
            return p >= 4096 && (v += 13, p >>>= 13), p >= 64 && (v += 7, p >>>= 7), p >= 8 && (v += 4, p >>>= 4), p >= 2 && (v += 2, p >>>= 2), v + p
        }, a.prototype._zeroBits = function(u) {
            if (u === 0) return 26;
            var p = u,
                v = 0;
            return p & 8191 || (v += 13, p >>>= 13), p & 127 || (v += 7, p >>>= 7), p & 15 || (v += 4, p >>>= 4), p & 3 || (v += 2, p >>>= 2), p & 1 || v++, v
        }, a.prototype.bitLength = function() {
            var u = this.words[this.length - 1],
                p = this._countBits(u);
            return (this.length - 1) * 26 + p
        };

        function Q(u) {
            for (var p = new Array(u.bitLength()), v = 0; v < p.length; v++) {
                var P = v / 26 | 0,
                    C = v % 26;
                p[v] = u.words[P] >>> C & 1
            }
            return p
        }
        a.prototype.zeroBits = function() {
            if (this.isZero()) return 0;
            for (var u = 0, p = 0; p < this.length; p++) {
                var v = this._zeroBits(this.words[p]);
                if (u += v, v !== 26) break
            }
            return u
        }, a.prototype.byteLength = function() {
            return Math.ceil(this.bitLength() / 8)
        }, a.prototype.toTwos = function(u) {
            return this.negative !== 0 ? this.abs().inotn(u).iaddn(1) : this.clone()
        }, a.prototype.fromTwos = function(u) {
            return this.testn(u - 1) ? this.notn(u).iaddn(1).ineg() : this.clone()
        }, a.prototype.isNeg = function() {
            return this.negative !== 0
        }, a.prototype.neg = function() {
            return this.clone().ineg()
        }, a.prototype.ineg = function() {
            return this.isZero() || (this.negative ^= 1), this
        }, a.prototype.iuor = function(u) {
            for (; this.length < u.length;) this.words[this.length++] = 0;
            for (var p = 0; p < u.length; p++) this.words[p] = this.words[p] | u.words[p];
            return this._strip()
        }, a.prototype.ior = function(u) {
            return n((this.negative | u.negative) === 0), this.iuor(u)
        }, a.prototype.or = function(u) {
            return this.length > u.length ? this.clone().ior(u) : u.clone().ior(this)
        }, a.prototype.uor = function(u) {
            return this.length > u.length ? this.clone().iuor(u) : u.clone().iuor(this)
        }, a.prototype.iuand = function(u) {
            var p;
            this.length > u.length ? p = u : p = this;
            for (var v = 0; v < p.length; v++) this.words[v] = this.words[v] & u.words[v];
            return this.length = p.length, this._strip()
        }, a.prototype.iand = function(u) {
            return n((this.negative | u.negative) === 0), this.iuand(u)
        }, a.prototype.and = function(u) {
            return this.length > u.length ? this.clone().iand(u) : u.clone().iand(this)
        }, a.prototype.uand = function(u) {
            return this.length > u.length ? this.clone().iuand(u) : u.clone().iuand(this)
        }, a.prototype.iuxor = function(u) {
            var p, v;
            this.length > u.length ? (p = this, v = u) : (p = u, v = this);
            for (var P = 0; P < v.length; P++) this.words[P] = p.words[P] ^ v.words[P];
            if (this !== p)
                for (; P < p.length; P++) this.words[P] = p.words[P];
            return this.length = p.length, this._strip()
        }, a.prototype.ixor = function(u) {
            return n((this.negative | u.negative) === 0), this.iuxor(u)
        }, a.prototype.xor = function(u) {
            return this.length > u.length ? this.clone().ixor(u) : u.clone().ixor(this)
        }, a.prototype.uxor = function(u) {
            return this.length > u.length ? this.clone().iuxor(u) : u.clone().iuxor(this)
        }, a.prototype.inotn = function(u) {
            n(typeof u == "number" && u >= 0);
            var p = Math.ceil(u / 26) | 0,
                v = u % 26;
            this._expand(p), v > 0 && p--;
            for (var P = 0; P < p; P++) this.words[P] = ~this.words[P] & 67108863;
            return v > 0 && (this.words[P] = ~this.words[P] & 67108863 >> 26 - v), this._strip()
        }, a.prototype.notn = function(u) {
            return this.clone().inotn(u)
        }, a.prototype.setn = function(u, p) {
            n(typeof u == "number" && u >= 0);
            var v = u / 26 | 0,
                P = u % 26;
            return this._expand(v + 1), p ? this.words[v] = this.words[v] | 1 << P : this.words[v] = this.words[v] & ~(1 << P), this._strip()
        }, a.prototype.iadd = function(u) {
            var p;
            if (this.negative !== 0 && u.negative === 0) return this.negative = 0, p = this.isub(u), this.negative ^= 1, this._normSign();
            if (this.negative === 0 && u.negative !== 0) return u.negative = 0, p = this.isub(u), u.negative = 1, p._normSign();
            var v, P;
            this.length > u.length ? (v = this, P = u) : (v = u, P = this);
            for (var C = 0, R = 0; R < P.length; R++) p = (v.words[R] | 0) + (P.words[R] | 0) + C, this.words[R] = p & 67108863, C = p >>> 26;
            for (; C !== 0 && R < v.length; R++) p = (v.words[R] | 0) + C, this.words[R] = p & 67108863, C = p >>> 26;
            if (this.length = v.length, C !== 0) this.words[this.length] = C, this.length++;
            else if (v !== this)
                for (; R < v.length; R++) this.words[R] = v.words[R];
            return this
        }, a.prototype.add = function(u) {
            var p;
            return u.negative !== 0 && this.negative === 0 ? (u.negative = 0, p = this.sub(u), u.negative ^= 1, p) : u.negative === 0 && this.negative !== 0 ? (this.negative = 0, p = u.sub(this), this.negative = 1, p) : this.length > u.length ? this.clone().iadd(u) : u.clone().iadd(this)
        }, a.prototype.isub = function(u) {
            if (u.negative !== 0) {
                u.negative = 0;
                var p = this.iadd(u);
                return u.negative = 1, p._normSign()
            } else if (this.negative !== 0) return this.negative = 0, this.iadd(u), this.negative = 1, this._normSign();
            var v = this.cmp(u);
            if (v === 0) return this.negative = 0, this.length = 1, this.words[0] = 0, this;
            var P, C;
            v > 0 ? (P = this, C = u) : (P = u, C = this);
            for (var R = 0, T = 0; T < C.length; T++) p = (P.words[T] | 0) - (C.words[T] | 0) + R, R = p >> 26, this.words[T] = p & 67108863;
            for (; R !== 0 && T < P.length; T++) p = (P.words[T] | 0) + R, R = p >> 26, this.words[T] = p & 67108863;
            if (R === 0 && T < P.length && P !== this)
                for (; T < P.length; T++) this.words[T] = P.words[T];
            return this.length = Math.max(this.length, T), P !== this && (this.negative = 1), this._strip()
        }, a.prototype.sub = function(u) {
            return this.clone().isub(u)
        };

        function et(u, p, v) {
            v.negative = p.negative ^ u.negative;
            var P = u.length + p.length | 0;
            v.length = P, P = P - 1 | 0;
            var C = u.words[0] | 0,
                R = p.words[0] | 0,
                T = C * R,
                E = T & 67108863,
                f = T / 67108864 | 0;
            v.words[0] = E;
            for (var x = 1; x < P; x++) {
                for (var ht = f >>> 26, gt = f & 67108863, y = Math.min(x, p.length - 1), V = Math.max(0, x - u.length + 1); V <= y; V++) {
                    var O = x - V | 0;
                    C = u.words[O] | 0, R = p.words[V] | 0, T = C * R + gt, ht += T / 67108864 | 0, gt = T & 67108863
                }
                v.words[x] = gt | 0, f = ht | 0
            }
            return f !== 0 ? v.words[x] = f | 0 : v.length--, v._strip()
        }
        var at = function(u, p, v) {
            var P = u.words,
                C = p.words,
                R = v.words,
                T = 0,
                E, f, x, ht = P[0] | 0,
                gt = ht & 8191,
                y = ht >>> 13,
                V = P[1] | 0,
                O = V & 8191,
                D = V >>> 13,
                U = P[2] | 0,
                d = U & 8191,
                N = U >>> 13,
                W = P[3] | 0,
                rt = W & 8191,
                Z = W >>> 13,
                wt = P[4] | 0,
                bt = wt & 8191,
                vt = wt >>> 13,
                Re = P[5] | 0,
                Lt = Re & 8191,
                Rt = Re >>> 13,
                ne = P[6] | 0,
                It = ne & 8191,
                St = ne >>> 13,
                be = P[7] | 0,
                _t = be & 8191,
                xt = be >>> 13,
                te = P[8] | 0,
                At = te & 8191,
                Dt = te >>> 13,
                ae = P[9] | 0,
                $t = ae & 8191,
                Kt = ae >>> 13,
                ke = C[0] | 0,
                Qt = ke & 8191,
                Vt = ke >>> 13,
                ze = C[1] | 0,
                ee = ze & 8191,
                ue = ze >>> 13,
                Fe = C[2] | 0,
                pe = Fe & 8191,
                ye = Fe >>> 13,
                yr = C[3] | 0,
                qt = yr & 8191,
                Mt = yr >>> 13,
                Ae = C[4] | 0,
                Bt = Ae & 8191,
                Ot = Ae >>> 13,
                we = C[5] | 0,
                jt = we & 8191,
                zt = we >>> 13,
                Ee = C[6] | 0,
                Ft = Ee & 8191,
                Ut = Ee >>> 13,
                xe = C[7] | 0,
                kt = xe & 8191,
                Et = xe >>> 13,
                Oe = C[8] | 0,
                Ht = Oe & 8191,
                Pe = Oe >>> 13,
                bi = C[9] | 0,
                Me = bi & 8191,
                se = bi >>> 13;
            v.negative = u.negative ^ p.negative, v.length = 19, E = Math.imul(gt, Qt), f = Math.imul(gt, Vt), f = f + Math.imul(y, Qt) | 0, x = Math.imul(y, Vt);
            var Zr = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (Zr >>> 26) | 0, Zr &= 67108863, E = Math.imul(O, Qt), f = Math.imul(O, Vt), f = f + Math.imul(D, Qt) | 0, x = Math.imul(D, Vt), E = E + Math.imul(gt, ee) | 0, f = f + Math.imul(gt, ue) | 0, f = f + Math.imul(y, ee) | 0, x = x + Math.imul(y, ue) | 0;
            var ti = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (ti >>> 26) | 0, ti &= 67108863, E = Math.imul(d, Qt), f = Math.imul(d, Vt), f = f + Math.imul(N, Qt) | 0, x = Math.imul(N, Vt), E = E + Math.imul(O, ee) | 0, f = f + Math.imul(O, ue) | 0, f = f + Math.imul(D, ee) | 0, x = x + Math.imul(D, ue) | 0, E = E + Math.imul(gt, pe) | 0, f = f + Math.imul(gt, ye) | 0, f = f + Math.imul(y, pe) | 0, x = x + Math.imul(y, ye) | 0;
            var ei = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (ei >>> 26) | 0, ei &= 67108863, E = Math.imul(rt, Qt), f = Math.imul(rt, Vt), f = f + Math.imul(Z, Qt) | 0, x = Math.imul(Z, Vt), E = E + Math.imul(d, ee) | 0, f = f + Math.imul(d, ue) | 0, f = f + Math.imul(N, ee) | 0, x = x + Math.imul(N, ue) | 0, E = E + Math.imul(O, pe) | 0, f = f + Math.imul(O, ye) | 0, f = f + Math.imul(D, pe) | 0, x = x + Math.imul(D, ye) | 0, E = E + Math.imul(gt, qt) | 0, f = f + Math.imul(gt, Mt) | 0, f = f + Math.imul(y, qt) | 0, x = x + Math.imul(y, Mt) | 0;
            var ri = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (ri >>> 26) | 0, ri &= 67108863, E = Math.imul(bt, Qt), f = Math.imul(bt, Vt), f = f + Math.imul(vt, Qt) | 0, x = Math.imul(vt, Vt), E = E + Math.imul(rt, ee) | 0, f = f + Math.imul(rt, ue) | 0, f = f + Math.imul(Z, ee) | 0, x = x + Math.imul(Z, ue) | 0, E = E + Math.imul(d, pe) | 0, f = f + Math.imul(d, ye) | 0, f = f + Math.imul(N, pe) | 0, x = x + Math.imul(N, ye) | 0, E = E + Math.imul(O, qt) | 0, f = f + Math.imul(O, Mt) | 0, f = f + Math.imul(D, qt) | 0, x = x + Math.imul(D, Mt) | 0, E = E + Math.imul(gt, Bt) | 0, f = f + Math.imul(gt, Ot) | 0, f = f + Math.imul(y, Bt) | 0, x = x + Math.imul(y, Ot) | 0;
            var ii = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (ii >>> 26) | 0, ii &= 67108863, E = Math.imul(Lt, Qt), f = Math.imul(Lt, Vt), f = f + Math.imul(Rt, Qt) | 0, x = Math.imul(Rt, Vt), E = E + Math.imul(bt, ee) | 0, f = f + Math.imul(bt, ue) | 0, f = f + Math.imul(vt, ee) | 0, x = x + Math.imul(vt, ue) | 0, E = E + Math.imul(rt, pe) | 0, f = f + Math.imul(rt, ye) | 0, f = f + Math.imul(Z, pe) | 0, x = x + Math.imul(Z, ye) | 0, E = E + Math.imul(d, qt) | 0, f = f + Math.imul(d, Mt) | 0, f = f + Math.imul(N, qt) | 0, x = x + Math.imul(N, Mt) | 0, E = E + Math.imul(O, Bt) | 0, f = f + Math.imul(O, Ot) | 0, f = f + Math.imul(D, Bt) | 0, x = x + Math.imul(D, Ot) | 0, E = E + Math.imul(gt, jt) | 0, f = f + Math.imul(gt, zt) | 0, f = f + Math.imul(y, jt) | 0, x = x + Math.imul(y, zt) | 0;
            var nr = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (nr >>> 26) | 0, nr &= 67108863, E = Math.imul(It, Qt), f = Math.imul(It, Vt), f = f + Math.imul(St, Qt) | 0, x = Math.imul(St, Vt), E = E + Math.imul(Lt, ee) | 0, f = f + Math.imul(Lt, ue) | 0, f = f + Math.imul(Rt, ee) | 0, x = x + Math.imul(Rt, ue) | 0, E = E + Math.imul(bt, pe) | 0, f = f + Math.imul(bt, ye) | 0, f = f + Math.imul(vt, pe) | 0, x = x + Math.imul(vt, ye) | 0, E = E + Math.imul(rt, qt) | 0, f = f + Math.imul(rt, Mt) | 0, f = f + Math.imul(Z, qt) | 0, x = x + Math.imul(Z, Mt) | 0, E = E + Math.imul(d, Bt) | 0, f = f + Math.imul(d, Ot) | 0, f = f + Math.imul(N, Bt) | 0, x = x + Math.imul(N, Ot) | 0, E = E + Math.imul(O, jt) | 0, f = f + Math.imul(O, zt) | 0, f = f + Math.imul(D, jt) | 0, x = x + Math.imul(D, zt) | 0, E = E + Math.imul(gt, Ft) | 0, f = f + Math.imul(gt, Ut) | 0, f = f + Math.imul(y, Ft) | 0, x = x + Math.imul(y, Ut) | 0;
            var qi = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (qi >>> 26) | 0, qi &= 67108863, E = Math.imul(_t, Qt), f = Math.imul(_t, Vt), f = f + Math.imul(xt, Qt) | 0, x = Math.imul(xt, Vt), E = E + Math.imul(It, ee) | 0, f = f + Math.imul(It, ue) | 0, f = f + Math.imul(St, ee) | 0, x = x + Math.imul(St, ue) | 0, E = E + Math.imul(Lt, pe) | 0, f = f + Math.imul(Lt, ye) | 0, f = f + Math.imul(Rt, pe) | 0, x = x + Math.imul(Rt, ye) | 0, E = E + Math.imul(bt, qt) | 0, f = f + Math.imul(bt, Mt) | 0, f = f + Math.imul(vt, qt) | 0, x = x + Math.imul(vt, Mt) | 0, E = E + Math.imul(rt, Bt) | 0, f = f + Math.imul(rt, Ot) | 0, f = f + Math.imul(Z, Bt) | 0, x = x + Math.imul(Z, Ot) | 0, E = E + Math.imul(d, jt) | 0, f = f + Math.imul(d, zt) | 0, f = f + Math.imul(N, jt) | 0, x = x + Math.imul(N, zt) | 0, E = E + Math.imul(O, Ft) | 0, f = f + Math.imul(O, Ut) | 0, f = f + Math.imul(D, Ft) | 0, x = x + Math.imul(D, Ut) | 0, E = E + Math.imul(gt, kt) | 0, f = f + Math.imul(gt, Et) | 0, f = f + Math.imul(y, kt) | 0, x = x + Math.imul(y, Et) | 0;
            var Ln = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (Ln >>> 26) | 0, Ln &= 67108863, E = Math.imul(At, Qt), f = Math.imul(At, Vt), f = f + Math.imul(Dt, Qt) | 0, x = Math.imul(Dt, Vt), E = E + Math.imul(_t, ee) | 0, f = f + Math.imul(_t, ue) | 0, f = f + Math.imul(xt, ee) | 0, x = x + Math.imul(xt, ue) | 0, E = E + Math.imul(It, pe) | 0, f = f + Math.imul(It, ye) | 0, f = f + Math.imul(St, pe) | 0, x = x + Math.imul(St, ye) | 0, E = E + Math.imul(Lt, qt) | 0, f = f + Math.imul(Lt, Mt) | 0, f = f + Math.imul(Rt, qt) | 0, x = x + Math.imul(Rt, Mt) | 0, E = E + Math.imul(bt, Bt) | 0, f = f + Math.imul(bt, Ot) | 0, f = f + Math.imul(vt, Bt) | 0, x = x + Math.imul(vt, Ot) | 0, E = E + Math.imul(rt, jt) | 0, f = f + Math.imul(rt, zt) | 0, f = f + Math.imul(Z, jt) | 0, x = x + Math.imul(Z, zt) | 0, E = E + Math.imul(d, Ft) | 0, f = f + Math.imul(d, Ut) | 0, f = f + Math.imul(N, Ft) | 0, x = x + Math.imul(N, Ut) | 0, E = E + Math.imul(O, kt) | 0, f = f + Math.imul(O, Et) | 0, f = f + Math.imul(D, kt) | 0, x = x + Math.imul(D, Et) | 0, E = E + Math.imul(gt, Ht) | 0, f = f + Math.imul(gt, Pe) | 0, f = f + Math.imul(y, Ht) | 0, x = x + Math.imul(y, Pe) | 0;
            var Bi = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (Bi >>> 26) | 0, Bi &= 67108863, E = Math.imul($t, Qt), f = Math.imul($t, Vt), f = f + Math.imul(Kt, Qt) | 0, x = Math.imul(Kt, Vt), E = E + Math.imul(At, ee) | 0, f = f + Math.imul(At, ue) | 0, f = f + Math.imul(Dt, ee) | 0, x = x + Math.imul(Dt, ue) | 0, E = E + Math.imul(_t, pe) | 0, f = f + Math.imul(_t, ye) | 0, f = f + Math.imul(xt, pe) | 0, x = x + Math.imul(xt, ye) | 0, E = E + Math.imul(It, qt) | 0, f = f + Math.imul(It, Mt) | 0, f = f + Math.imul(St, qt) | 0, x = x + Math.imul(St, Mt) | 0, E = E + Math.imul(Lt, Bt) | 0, f = f + Math.imul(Lt, Ot) | 0, f = f + Math.imul(Rt, Bt) | 0, x = x + Math.imul(Rt, Ot) | 0, E = E + Math.imul(bt, jt) | 0, f = f + Math.imul(bt, zt) | 0, f = f + Math.imul(vt, jt) | 0, x = x + Math.imul(vt, zt) | 0, E = E + Math.imul(rt, Ft) | 0, f = f + Math.imul(rt, Ut) | 0, f = f + Math.imul(Z, Ft) | 0, x = x + Math.imul(Z, Ut) | 0, E = E + Math.imul(d, kt) | 0, f = f + Math.imul(d, Et) | 0, f = f + Math.imul(N, kt) | 0, x = x + Math.imul(N, Et) | 0, E = E + Math.imul(O, Ht) | 0, f = f + Math.imul(O, Pe) | 0, f = f + Math.imul(D, Ht) | 0, x = x + Math.imul(D, Pe) | 0, E = E + Math.imul(gt, Me) | 0, f = f + Math.imul(gt, se) | 0, f = f + Math.imul(y, Me) | 0, x = x + Math.imul(y, se) | 0;
            var $n = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + ($n >>> 26) | 0, $n &= 67108863, E = Math.imul($t, ee), f = Math.imul($t, ue), f = f + Math.imul(Kt, ee) | 0, x = Math.imul(Kt, ue), E = E + Math.imul(At, pe) | 0, f = f + Math.imul(At, ye) | 0, f = f + Math.imul(Dt, pe) | 0, x = x + Math.imul(Dt, ye) | 0, E = E + Math.imul(_t, qt) | 0, f = f + Math.imul(_t, Mt) | 0, f = f + Math.imul(xt, qt) | 0, x = x + Math.imul(xt, Mt) | 0, E = E + Math.imul(It, Bt) | 0, f = f + Math.imul(It, Ot) | 0, f = f + Math.imul(St, Bt) | 0, x = x + Math.imul(St, Ot) | 0, E = E + Math.imul(Lt, jt) | 0, f = f + Math.imul(Lt, zt) | 0, f = f + Math.imul(Rt, jt) | 0, x = x + Math.imul(Rt, zt) | 0, E = E + Math.imul(bt, Ft) | 0, f = f + Math.imul(bt, Ut) | 0, f = f + Math.imul(vt, Ft) | 0, x = x + Math.imul(vt, Ut) | 0, E = E + Math.imul(rt, kt) | 0, f = f + Math.imul(rt, Et) | 0, f = f + Math.imul(Z, kt) | 0, x = x + Math.imul(Z, Et) | 0, E = E + Math.imul(d, Ht) | 0, f = f + Math.imul(d, Pe) | 0, f = f + Math.imul(N, Ht) | 0, x = x + Math.imul(N, Pe) | 0, E = E + Math.imul(O, Me) | 0, f = f + Math.imul(O, se) | 0, f = f + Math.imul(D, Me) | 0, x = x + Math.imul(D, se) | 0;
            var jn = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (jn >>> 26) | 0, jn &= 67108863, E = Math.imul($t, pe), f = Math.imul($t, ye), f = f + Math.imul(Kt, pe) | 0, x = Math.imul(Kt, ye), E = E + Math.imul(At, qt) | 0, f = f + Math.imul(At, Mt) | 0, f = f + Math.imul(Dt, qt) | 0, x = x + Math.imul(Dt, Mt) | 0, E = E + Math.imul(_t, Bt) | 0, f = f + Math.imul(_t, Ot) | 0, f = f + Math.imul(xt, Bt) | 0, x = x + Math.imul(xt, Ot) | 0, E = E + Math.imul(It, jt) | 0, f = f + Math.imul(It, zt) | 0, f = f + Math.imul(St, jt) | 0, x = x + Math.imul(St, zt) | 0, E = E + Math.imul(Lt, Ft) | 0, f = f + Math.imul(Lt, Ut) | 0, f = f + Math.imul(Rt, Ft) | 0, x = x + Math.imul(Rt, Ut) | 0, E = E + Math.imul(bt, kt) | 0, f = f + Math.imul(bt, Et) | 0, f = f + Math.imul(vt, kt) | 0, x = x + Math.imul(vt, Et) | 0, E = E + Math.imul(rt, Ht) | 0, f = f + Math.imul(rt, Pe) | 0, f = f + Math.imul(Z, Ht) | 0, x = x + Math.imul(Z, Pe) | 0, E = E + Math.imul(d, Me) | 0, f = f + Math.imul(d, se) | 0, f = f + Math.imul(N, Me) | 0, x = x + Math.imul(N, se) | 0;
            var Ui = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (Ui >>> 26) | 0, Ui &= 67108863, E = Math.imul($t, qt), f = Math.imul($t, Mt), f = f + Math.imul(Kt, qt) | 0, x = Math.imul(Kt, Mt), E = E + Math.imul(At, Bt) | 0, f = f + Math.imul(At, Ot) | 0, f = f + Math.imul(Dt, Bt) | 0, x = x + Math.imul(Dt, Ot) | 0, E = E + Math.imul(_t, jt) | 0, f = f + Math.imul(_t, zt) | 0, f = f + Math.imul(xt, jt) | 0, x = x + Math.imul(xt, zt) | 0, E = E + Math.imul(It, Ft) | 0, f = f + Math.imul(It, Ut) | 0, f = f + Math.imul(St, Ft) | 0, x = x + Math.imul(St, Ut) | 0, E = E + Math.imul(Lt, kt) | 0, f = f + Math.imul(Lt, Et) | 0, f = f + Math.imul(Rt, kt) | 0, x = x + Math.imul(Rt, Et) | 0, E = E + Math.imul(bt, Ht) | 0, f = f + Math.imul(bt, Pe) | 0, f = f + Math.imul(vt, Ht) | 0, x = x + Math.imul(vt, Pe) | 0, E = E + Math.imul(rt, Me) | 0, f = f + Math.imul(rt, se) | 0, f = f + Math.imul(Z, Me) | 0, x = x + Math.imul(Z, se) | 0;
            var bn = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (bn >>> 26) | 0, bn &= 67108863, E = Math.imul($t, Bt), f = Math.imul($t, Ot), f = f + Math.imul(Kt, Bt) | 0, x = Math.imul(Kt, Ot), E = E + Math.imul(At, jt) | 0, f = f + Math.imul(At, zt) | 0, f = f + Math.imul(Dt, jt) | 0, x = x + Math.imul(Dt, zt) | 0, E = E + Math.imul(_t, Ft) | 0, f = f + Math.imul(_t, Ut) | 0, f = f + Math.imul(xt, Ft) | 0, x = x + Math.imul(xt, Ut) | 0, E = E + Math.imul(It, kt) | 0, f = f + Math.imul(It, Et) | 0, f = f + Math.imul(St, kt) | 0, x = x + Math.imul(St, Et) | 0, E = E + Math.imul(Lt, Ht) | 0, f = f + Math.imul(Lt, Pe) | 0, f = f + Math.imul(Rt, Ht) | 0, x = x + Math.imul(Rt, Pe) | 0, E = E + Math.imul(bt, Me) | 0, f = f + Math.imul(bt, se) | 0, f = f + Math.imul(vt, Me) | 0, x = x + Math.imul(vt, se) | 0;
            var _n = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (_n >>> 26) | 0, _n &= 67108863, E = Math.imul($t, jt), f = Math.imul($t, zt), f = f + Math.imul(Kt, jt) | 0, x = Math.imul(Kt, zt), E = E + Math.imul(At, Ft) | 0, f = f + Math.imul(At, Ut) | 0, f = f + Math.imul(Dt, Ft) | 0, x = x + Math.imul(Dt, Ut) | 0, E = E + Math.imul(_t, kt) | 0, f = f + Math.imul(_t, Et) | 0, f = f + Math.imul(xt, kt) | 0, x = x + Math.imul(xt, Et) | 0, E = E + Math.imul(It, Ht) | 0, f = f + Math.imul(It, Pe) | 0, f = f + Math.imul(St, Ht) | 0, x = x + Math.imul(St, Pe) | 0, E = E + Math.imul(Lt, Me) | 0, f = f + Math.imul(Lt, se) | 0, f = f + Math.imul(Rt, Me) | 0, x = x + Math.imul(Rt, se) | 0;
            var wr = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (wr >>> 26) | 0, wr &= 67108863, E = Math.imul($t, Ft), f = Math.imul($t, Ut), f = f + Math.imul(Kt, Ft) | 0, x = Math.imul(Kt, Ut), E = E + Math.imul(At, kt) | 0, f = f + Math.imul(At, Et) | 0, f = f + Math.imul(Dt, kt) | 0, x = x + Math.imul(Dt, Et) | 0, E = E + Math.imul(_t, Ht) | 0, f = f + Math.imul(_t, Pe) | 0, f = f + Math.imul(xt, Ht) | 0, x = x + Math.imul(xt, Pe) | 0, E = E + Math.imul(It, Me) | 0, f = f + Math.imul(It, se) | 0, f = f + Math.imul(St, Me) | 0, x = x + Math.imul(St, se) | 0;
            var zn = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (zn >>> 26) | 0, zn &= 67108863, E = Math.imul($t, kt), f = Math.imul($t, Et), f = f + Math.imul(Kt, kt) | 0, x = Math.imul(Kt, Et), E = E + Math.imul(At, Ht) | 0, f = f + Math.imul(At, Pe) | 0, f = f + Math.imul(Dt, Ht) | 0, x = x + Math.imul(Dt, Pe) | 0, E = E + Math.imul(_t, Me) | 0, f = f + Math.imul(_t, se) | 0, f = f + Math.imul(xt, Me) | 0, x = x + Math.imul(xt, se) | 0;
            var Fn = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (Fn >>> 26) | 0, Fn &= 67108863, E = Math.imul($t, Ht), f = Math.imul($t, Pe), f = f + Math.imul(Kt, Ht) | 0, x = Math.imul(Kt, Pe), E = E + Math.imul(At, Me) | 0, f = f + Math.imul(At, se) | 0, f = f + Math.imul(Dt, Me) | 0, x = x + Math.imul(Dt, se) | 0;
            var Hn = (T + E | 0) + ((f & 8191) << 13) | 0;
            T = (x + (f >>> 13) | 0) + (Hn >>> 26) | 0, Hn &= 67108863, E = Math.imul($t, Me), f = Math.imul($t, se), f = f + Math.imul(Kt, Me) | 0, x = Math.imul(Kt, se);
            var Kn = (T + E | 0) + ((f & 8191) << 13) | 0;
            return T = (x + (f >>> 13) | 0) + (Kn >>> 26) | 0, Kn &= 67108863, R[0] = Zr, R[1] = ti, R[2] = ei, R[3] = ri, R[4] = ii, R[5] = nr, R[6] = qi, R[7] = Ln, R[8] = Bi, R[9] = $n, R[10] = jn, R[11] = Ui, R[12] = bn, R[13] = _n, R[14] = wr, R[15] = zn, R[16] = Fn, R[17] = Hn, R[18] = Kn, T !== 0 && (R[19] = T, v.length++), v
        };
        Math.imul || (at = et);

        function ut(u, p, v) {
            v.negative = p.negative ^ u.negative, v.length = u.length + p.length;
            for (var P = 0, C = 0, R = 0; R < v.length - 1; R++) {
                var T = C;
                C = 0;
                for (var E = P & 67108863, f = Math.min(R, p.length - 1), x = Math.max(0, R - u.length + 1); x <= f; x++) {
                    var ht = R - x,
                        gt = u.words[ht] | 0,
                        y = p.words[x] | 0,
                        V = gt * y,
                        O = V & 67108863;
                    T = T + (V / 67108864 | 0) | 0, O = O + E | 0, E = O & 67108863, T = T + (O >>> 26) | 0, C += T >>> 26, T &= 67108863
                }
                v.words[R] = E, P = T, T = C
            }
            return P !== 0 ? v.words[R] = P : v.length--, v._strip()
        }

        function ft(u, p, v) {
            return ut(u, p, v)
        }
        a.prototype.mulTo = function(u, p) {
            var v, P = this.length + u.length;
            return this.length === 10 && u.length === 10 ? v = at(this, u, p) : P < 63 ? v = et(this, u, p) : P < 1024 ? v = ut(this, u, p) : v = ft(this, u, p), v
        }, a.prototype.mul = function(u) {
            var p = new a(null);
            return p.words = new Array(this.length + u.length), this.mulTo(u, p)
        }, a.prototype.mulf = function(u) {
            var p = new a(null);
            return p.words = new Array(this.length + u.length), ft(this, u, p)
        }, a.prototype.imul = function(u) {
            return this.clone().mulTo(u, this)
        }, a.prototype.imuln = function(u) {
            var p = u < 0;
            p && (u = -u), n(typeof u == "number"), n(u < 67108864);
            for (var v = 0, P = 0; P < this.length; P++) {
                var C = (this.words[P] | 0) * u,
                    R = (C & 67108863) + (v & 67108863);
                v >>= 26, v += C / 67108864 | 0, v += R >>> 26, this.words[P] = R & 67108863
            }
            return v !== 0 && (this.words[P] = v, this.length++), p ? this.ineg() : this
        }, a.prototype.muln = function(u) {
            return this.clone().imuln(u)
        }, a.prototype.sqr = function() {
            return this.mul(this)
        }, a.prototype.isqr = function() {
            return this.imul(this.clone())
        }, a.prototype.pow = function(u) {
            var p = Q(u);
            if (p.length === 0) return new a(1);
            for (var v = this, P = 0; P < p.length && p[P] === 0; P++, v = v.sqr());
            if (++P < p.length)
                for (var C = v.sqr(); P < p.length; P++, C = C.sqr()) p[P] !== 0 && (v = v.mul(C));
            return v
        }, a.prototype.iushln = function(u) {
            n(typeof u == "number" && u >= 0);
            var p = u % 26,
                v = (u - p) / 26,
                P = 67108863 >>> 26 - p << 26 - p,
                C;
            if (p !== 0) {
                var R = 0;
                for (C = 0; C < this.length; C++) {
                    var T = this.words[C] & P,
                        E = (this.words[C] | 0) - T << p;
                    this.words[C] = E | R, R = T >>> 26 - p
                }
                R && (this.words[C] = R, this.length++)
            }
            if (v !== 0) {
                for (C = this.length - 1; C >= 0; C--) this.words[C + v] = this.words[C];
                for (C = 0; C < v; C++) this.words[C] = 0;
                this.length += v
            }
            return this._strip()
        }, a.prototype.ishln = function(u) {
            return n(this.negative === 0), this.iushln(u)
        }, a.prototype.iushrn = function(u, p, v) {
            n(typeof u == "number" && u >= 0);
            var P;
            p ? P = (p - p % 26) / 26 : P = 0;
            var C = u % 26,
                R = Math.min((u - C) / 26, this.length),
                T = 67108863 ^ 67108863 >>> C << C,
                E = v;
            if (P -= R, P = Math.max(0, P), E) {
                for (var f = 0; f < R; f++) E.words[f] = this.words[f];
                E.length = R
            }
            if (R !== 0)
                if (this.length > R)
                    for (this.length -= R, f = 0; f < this.length; f++) this.words[f] = this.words[f + R];
                else this.words[0] = 0, this.length = 1;
            var x = 0;
            for (f = this.length - 1; f >= 0 && (x !== 0 || f >= P); f--) {
                var ht = this.words[f] | 0;
                this.words[f] = x << 26 - C | ht >>> C, x = ht & T
            }
            return E && x !== 0 && (E.words[E.length++] = x), this.length === 0 && (this.words[0] = 0, this.length = 1), this._strip()
        }, a.prototype.ishrn = function(u, p, v) {
            return n(this.negative === 0), this.iushrn(u, p, v)
        }, a.prototype.shln = function(u) {
            return this.clone().ishln(u)
        }, a.prototype.ushln = function(u) {
            return this.clone().iushln(u)
        }, a.prototype.shrn = function(u) {
            return this.clone().ishrn(u)
        }, a.prototype.ushrn = function(u) {
            return this.clone().iushrn(u)
        }, a.prototype.testn = function(u) {
            n(typeof u == "number" && u >= 0);
            var p = u % 26,
                v = (u - p) / 26,
                P = 1 << p;
            if (this.length <= v) return !1;
            var C = this.words[v];
            return !!(C & P)
        }, a.prototype.imaskn = function(u) {
            n(typeof u == "number" && u >= 0);
            var p = u % 26,
                v = (u - p) / 26;
            if (n(this.negative === 0, "imaskn works only with positive numbers"), this.length <= v) return this;
            if (p !== 0 && v++, this.length = Math.min(v, this.length), p !== 0) {
                var P = 67108863 ^ 67108863 >>> p << p;
                this.words[this.length - 1] &= P
            }
            return this._strip()
        }, a.prototype.maskn = function(u) {
            return this.clone().imaskn(u)
        }, a.prototype.iaddn = function(u) {
            return n(typeof u == "number"), n(u < 67108864), u < 0 ? this.isubn(-u) : this.negative !== 0 ? this.length === 1 && (this.words[0] | 0) <= u ? (this.words[0] = u - (this.words[0] | 0), this.negative = 0, this) : (this.negative = 0, this.isubn(u), this.negative = 1, this) : this._iaddn(u)
        }, a.prototype._iaddn = function(u) {
            this.words[0] += u;
            for (var p = 0; p < this.length && this.words[p] >= 67108864; p++) this.words[p] -= 67108864, p === this.length - 1 ? this.words[p + 1] = 1 : this.words[p + 1]++;
            return this.length = Math.max(this.length, p + 1), this
        }, a.prototype.isubn = function(u) {
            if (n(typeof u == "number"), n(u < 67108864), u < 0) return this.iaddn(-u);
            if (this.negative !== 0) return this.negative = 0, this.iaddn(u), this.negative = 1, this;
            if (this.words[0] -= u, this.length === 1 && this.words[0] < 0) this.words[0] = -this.words[0], this.negative = 1;
            else
                for (var p = 0; p < this.length && this.words[p] < 0; p++) this.words[p] += 67108864, this.words[p + 1] -= 1;
            return this._strip()
        }, a.prototype.addn = function(u) {
            return this.clone().iaddn(u)
        }, a.prototype.subn = function(u) {
            return this.clone().isubn(u)
        }, a.prototype.iabs = function() {
            return this.negative = 0, this
        }, a.prototype.abs = function() {
            return this.clone().iabs()
        }, a.prototype._ishlnsubmul = function(u, p, v) {
            var P = u.length + v,
                C;
            this._expand(P);
            var R, T = 0;
            for (C = 0; C < u.length; C++) {
                R = (this.words[C + v] | 0) + T;
                var E = (u.words[C] | 0) * p;
                R -= E & 67108863, T = (R >> 26) - (E / 67108864 | 0), this.words[C + v] = R & 67108863
            }
            for (; C < this.length - v; C++) R = (this.words[C + v] | 0) + T, T = R >> 26, this.words[C + v] = R & 67108863;
            if (T === 0) return this._strip();
            for (n(T === -1), T = 0, C = 0; C < this.length; C++) R = -(this.words[C] | 0) + T, T = R >> 26, this.words[C] = R & 67108863;
            return this.negative = 1, this._strip()
        }, a.prototype._wordDiv = function(u, p) {
            var v = this.length - u.length,
                P = this.clone(),
                C = u,
                R = C.words[C.length - 1] | 0,
                T = this._countBits(R);
            v = 26 - T, v !== 0 && (C = C.ushln(v), P.iushln(v), R = C.words[C.length - 1] | 0);
            var E = P.length - C.length,
                f;
            if (p !== "mod") {
                f = new a(null), f.length = E + 1, f.words = new Array(f.length);
                for (var x = 0; x < f.length; x++) f.words[x] = 0
            }
            var ht = P.clone()._ishlnsubmul(C, 1, E);
            ht.negative === 0 && (P = ht, f && (f.words[E] = 1));
            for (var gt = E - 1; gt >= 0; gt--) {
                var y = (P.words[C.length + gt] | 0) * 67108864 + (P.words[C.length + gt - 1] | 0);
                for (y = Math.min(y / R | 0, 67108863), P._ishlnsubmul(C, y, gt); P.negative !== 0;) y--, P.negative = 0, P._ishlnsubmul(C, 1, gt), P.isZero() || (P.negative ^= 1);
                f && (f.words[gt] = y)
            }
            return f && f._strip(), P._strip(), p !== "div" && v !== 0 && P.iushrn(v), {
                div: f || null,
                mod: P
            }
        }, a.prototype.divmod = function(u, p, v) {
            if (n(!u.isZero()), this.isZero()) return {
                div: new a(0),
                mod: new a(0)
            };
            var P, C, R;
            return this.negative !== 0 && u.negative === 0 ? (R = this.neg().divmod(u, p), p !== "mod" && (P = R.div.neg()), p !== "div" && (C = R.mod.neg(), v && C.negative !== 0 && C.iadd(u)), {
                div: P,
                mod: C
            }) : this.negative === 0 && u.negative !== 0 ? (R = this.divmod(u.neg(), p), p !== "mod" && (P = R.div.neg()), {
                div: P,
                mod: R.mod
            }) : this.negative & u.negative ? (R = this.neg().divmod(u.neg(), p), p !== "div" && (C = R.mod.neg(), v && C.negative !== 0 && C.isub(u)), {
                div: R.div,
                mod: C
            }) : u.length > this.length || this.cmp(u) < 0 ? {
                div: new a(0),
                mod: this
            } : u.length === 1 ? p === "div" ? {
                div: this.divn(u.words[0]),
                mod: null
            } : p === "mod" ? {
                div: null,
                mod: new a(this.modrn(u.words[0]))
            } : {
                div: this.divn(u.words[0]),
                mod: new a(this.modrn(u.words[0]))
            } : this._wordDiv(u, p)
        }, a.prototype.div = function(u) {
            return this.divmod(u, "div", !1).div
        }, a.prototype.mod = function(u) {
            return this.divmod(u, "mod", !1).mod
        }, a.prototype.umod = function(u) {
            return this.divmod(u, "mod", !0).mod
        }, a.prototype.divRound = function(u) {
            var p = this.divmod(u);
            if (p.mod.isZero()) return p.div;
            var v = p.div.negative !== 0 ? p.mod.isub(u) : p.mod,
                P = u.ushrn(1),
                C = u.andln(1),
                R = v.cmp(P);
            return R < 0 || C === 1 && R === 0 ? p.div : p.div.negative !== 0 ? p.div.isubn(1) : p.div.iaddn(1)
        }, a.prototype.modrn = function(u) {
            var p = u < 0;
            p && (u = -u), n(u <= 67108863);
            for (var v = (1 << 26) % u, P = 0, C = this.length - 1; C >= 0; C--) P = (v * P + (this.words[C] | 0)) % u;
            return p ? -P : P
        }, a.prototype.modn = function(u) {
            return this.modrn(u)
        }, a.prototype.idivn = function(u) {
            var p = u < 0;
            p && (u = -u), n(u <= 67108863);
            for (var v = 0, P = this.length - 1; P >= 0; P--) {
                var C = (this.words[P] | 0) + v * 67108864;
                this.words[P] = C / u | 0, v = C % u
            }
            return this._strip(), p ? this.ineg() : this
        }, a.prototype.divn = function(u) {
            return this.clone().idivn(u)
        }, a.prototype.egcd = function(u) {
            n(u.negative === 0), n(!u.isZero());
            var p = this,
                v = u.clone();
            p.negative !== 0 ? p = p.umod(u) : p = p.clone();
            for (var P = new a(1), C = new a(0), R = new a(0), T = new a(1), E = 0; p.isEven() && v.isEven();) p.iushrn(1), v.iushrn(1), ++E;
            for (var f = v.clone(), x = p.clone(); !p.isZero();) {
                for (var ht = 0, gt = 1; !(p.words[0] & gt) && ht < 26; ++ht, gt <<= 1);
                if (ht > 0)
                    for (p.iushrn(ht); ht-- > 0;)(P.isOdd() || C.isOdd()) && (P.iadd(f), C.isub(x)), P.iushrn(1), C.iushrn(1);
                for (var y = 0, V = 1; !(v.words[0] & V) && y < 26; ++y, V <<= 1);
                if (y > 0)
                    for (v.iushrn(y); y-- > 0;)(R.isOdd() || T.isOdd()) && (R.iadd(f), T.isub(x)), R.iushrn(1), T.iushrn(1);
                p.cmp(v) >= 0 ? (p.isub(v), P.isub(R), C.isub(T)) : (v.isub(p), R.isub(P), T.isub(C))
            }
            return {
                a: R,
                b: T,
                gcd: v.iushln(E)
            }
        }, a.prototype._invmp = function(u) {
            n(u.negative === 0), n(!u.isZero());
            var p = this,
                v = u.clone();
            p.negative !== 0 ? p = p.umod(u) : p = p.clone();
            for (var P = new a(1), C = new a(0), R = v.clone(); p.cmpn(1) > 0 && v.cmpn(1) > 0;) {
                for (var T = 0, E = 1; !(p.words[0] & E) && T < 26; ++T, E <<= 1);
                if (T > 0)
                    for (p.iushrn(T); T-- > 0;) P.isOdd() && P.iadd(R), P.iushrn(1);
                for (var f = 0, x = 1; !(v.words[0] & x) && f < 26; ++f, x <<= 1);
                if (f > 0)
                    for (v.iushrn(f); f-- > 0;) C.isOdd() && C.iadd(R), C.iushrn(1);
                p.cmp(v) >= 0 ? (p.isub(v), P.isub(C)) : (v.isub(p), C.isub(P))
            }
            var ht;
            return p.cmpn(1) === 0 ? ht = P : ht = C, ht.cmpn(0) < 0 && ht.iadd(u), ht
        }, a.prototype.gcd = function(u) {
            if (this.isZero()) return u.abs();
            if (u.isZero()) return this.abs();
            var p = this.clone(),
                v = u.clone();
            p.negative = 0, v.negative = 0;
            for (var P = 0; p.isEven() && v.isEven(); P++) p.iushrn(1), v.iushrn(1);
            do {
                for (; p.isEven();) p.iushrn(1);
                for (; v.isEven();) v.iushrn(1);
                var C = p.cmp(v);
                if (C < 0) {
                    var R = p;
                    p = v, v = R
                } else if (C === 0 || v.cmpn(1) === 0) break;
                p.isub(v)
            } while (!0);
            return v.iushln(P)
        }, a.prototype.invm = function(u) {
            return this.egcd(u).a.umod(u)
        }, a.prototype.isEven = function() {
            return (this.words[0] & 1) === 0
        }, a.prototype.isOdd = function() {
            return (this.words[0] & 1) === 1
        }, a.prototype.andln = function(u) {
            return this.words[0] & u
        }, a.prototype.bincn = function(u) {
            n(typeof u == "number");
            var p = u % 26,
                v = (u - p) / 26,
                P = 1 << p;
            if (this.length <= v) return this._expand(v + 1), this.words[v] |= P, this;
            for (var C = P, R = v; C !== 0 && R < this.length; R++) {
                var T = this.words[R] | 0;
                T += C, C = T >>> 26, T &= 67108863, this.words[R] = T
            }
            return C !== 0 && (this.words[R] = C, this.length++), this
        }, a.prototype.isZero = function() {
            return this.length === 1 && this.words[0] === 0
        }, a.prototype.cmpn = function(u) {
            var p = u < 0;
            if (this.negative !== 0 && !p) return -1;
            if (this.negative === 0 && p) return 1;
            this._strip();
            var v;
            if (this.length > 1) v = 1;
            else {
                p && (u = -u), n(u <= 67108863, "Number is too big");
                var P = this.words[0] | 0;
                v = P === u ? 0 : P < u ? -1 : 1
            }
            return this.negative !== 0 ? -v | 0 : v
        }, a.prototype.cmp = function(u) {
            if (this.negative !== 0 && u.negative === 0) return -1;
            if (this.negative === 0 && u.negative !== 0) return 1;
            var p = this.ucmp(u);
            return this.negative !== 0 ? -p | 0 : p
        }, a.prototype.ucmp = function(u) {
            if (this.length > u.length) return 1;
            if (this.length < u.length) return -1;
            for (var p = 0, v = this.length - 1; v >= 0; v--) {
                var P = this.words[v] | 0,
                    C = u.words[v] | 0;
                if (P !== C) {
                    P < C ? p = -1 : P > C && (p = 1);
                    break
                }
            }
            return p
        }, a.prototype.gtn = function(u) {
            return this.cmpn(u) === 1
        }, a.prototype.gt = function(u) {
            return this.cmp(u) === 1
        }, a.prototype.gten = function(u) {
            return this.cmpn(u) >= 0
        }, a.prototype.gte = function(u) {
            return this.cmp(u) >= 0
        }, a.prototype.ltn = function(u) {
            return this.cmpn(u) === -1
        }, a.prototype.lt = function(u) {
            return this.cmp(u) === -1
        }, a.prototype.lten = function(u) {
            return this.cmpn(u) <= 0
        }, a.prototype.lte = function(u) {
            return this.cmp(u) <= 0
        }, a.prototype.eqn = function(u) {
            return this.cmpn(u) === 0
        }, a.prototype.eq = function(u) {
            return this.cmp(u) === 0
        }, a.red = function(u) {
            return new Tt(u)
        }, a.prototype.toRed = function(u) {
            return n(!this.red, "Already a number in reduction context"), n(this.negative === 0, "red works only with positives"), u.convertTo(this)._forceRed(u)
        }, a.prototype.fromRed = function() {
            return n(this.red, "fromRed works only with numbers in reduction context"), this.red.convertFrom(this)
        }, a.prototype._forceRed = function(u) {
            return this.red = u, this
        }, a.prototype.forceRed = function(u) {
            return n(!this.red, "Already a number in reduction context"), this._forceRed(u)
        }, a.prototype.redAdd = function(u) {
            return n(this.red, "redAdd works only with red numbers"), this.red.add(this, u)
        }, a.prototype.redIAdd = function(u) {
            return n(this.red, "redIAdd works only with red numbers"), this.red.iadd(this, u)
        }, a.prototype.redSub = function(u) {
            return n(this.red, "redSub works only with red numbers"), this.red.sub(this, u)
        }, a.prototype.redISub = function(u) {
            return n(this.red, "redISub works only with red numbers"), this.red.isub(this, u)
        }, a.prototype.redShl = function(u) {
            return n(this.red, "redShl works only with red numbers"), this.red.shl(this, u)
        }, a.prototype.redMul = function(u) {
            return n(this.red, "redMul works only with red numbers"), this.red._verify2(this, u), this.red.mul(this, u)
        }, a.prototype.redIMul = function(u) {
            return n(this.red, "redMul works only with red numbers"), this.red._verify2(this, u), this.red.imul(this, u)
        }, a.prototype.redSqr = function() {
            return n(this.red, "redSqr works only with red numbers"), this.red._verify1(this), this.red.sqr(this)
        }, a.prototype.redISqr = function() {
            return n(this.red, "redISqr works only with red numbers"), this.red._verify1(this), this.red.isqr(this)
        }, a.prototype.redSqrt = function() {
            return n(this.red, "redSqrt works only with red numbers"), this.red._verify1(this), this.red.sqrt(this)
        }, a.prototype.redInvm = function() {
            return n(this.red, "redInvm works only with red numbers"), this.red._verify1(this), this.red.invm(this)
        }, a.prototype.redNeg = function() {
            return n(this.red, "redNeg works only with red numbers"), this.red._verify1(this), this.red.neg(this)
        }, a.prototype.redPow = function(u) {
            return n(this.red && !u.red, "redPow(normalNum)"), this.red._verify1(this), this.red.pow(this, u)
        };
        var st = {
            k256: null,
            p224: null,
            p192: null,
            p25519: null
        };

        function ot(u, p) {
            this.name = u, this.p = new a(p, 16), this.n = this.p.bitLength(), this.k = new a(1).iushln(this.n).isub(this.p), this.tmp = this._tmp()
        }
        ot.prototype._tmp = function() {
            var u = new a(null);
            return u.words = new Array(Math.ceil(this.n / 13)), u
        }, ot.prototype.ireduce = function(u) {
            var p = u,
                v;
            do this.split(p, this.tmp), p = this.imulK(p), p = p.iadd(this.tmp), v = p.bitLength(); while (v > this.n);
            var P = v < this.n ? -1 : p.ucmp(this.p);
            return P === 0 ? (p.words[0] = 0, p.length = 1) : P > 0 ? p.isub(this.p) : p.strip !== void 0 ? p.strip() : p._strip(), p
        }, ot.prototype.split = function(u, p) {
            u.iushrn(this.n, 0, p)
        }, ot.prototype.imulK = function(u) {
            return u.imul(this.k)
        };

        function it() {
            ot.call(this, "k256", "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f")
        }
        o(it, ot), it.prototype.split = function(u, p) {
            for (var v = 4194303, P = Math.min(u.length, 9), C = 0; C < P; C++) p.words[C] = u.words[C];
            if (p.length = P, u.length <= 9) {
                u.words[0] = 0, u.length = 1;
                return
            }
            var R = u.words[9];
            for (p.words[p.length++] = R & v, C = 10; C < u.length; C++) {
                var T = u.words[C] | 0;
                u.words[C - 10] = (T & v) << 4 | R >>> 22, R = T
            }
            R >>>= 22, u.words[C - 10] = R, R === 0 && u.length > 10 ? u.length -= 10 : u.length -= 9
        }, it.prototype.imulK = function(u) {
            u.words[u.length] = 0, u.words[u.length + 1] = 0, u.length += 2;
            for (var p = 0, v = 0; v < u.length; v++) {
                var P = u.words[v] | 0;
                p += P * 977, u.words[v] = p & 67108863, p = P * 64 + (p / 67108864 | 0)
            }
            return u.words[u.length - 1] === 0 && (u.length--, u.words[u.length - 1] === 0 && u.length--), u
        };

        function mt() {
            ot.call(this, "p224", "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001")
        }
        o(mt, ot);

        function Zt() {
            ot.call(this, "p192", "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff")
        }
        o(Zt, ot);

        function oe() {
            ot.call(this, "25519", "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed")
        }
        o(oe, ot), oe.prototype.imulK = function(u) {
            for (var p = 0, v = 0; v < u.length; v++) {
                var P = (u.words[v] | 0) * 19 + p,
                    C = P & 67108863;
                P >>>= 26, u.words[v] = C, p = P
            }
            return p !== 0 && (u.words[u.length++] = p), u
        }, a._prime = function(u) {
            if (st[u]) return st[u];
            var p;
            if (u === "k256") p = new it;
            else if (u === "p224") p = new mt;
            else if (u === "p192") p = new Zt;
            else if (u === "p25519") p = new oe;
            else throw new Error("Unknown prime " + u);
            return st[u] = p, p
        };

        function Tt(u) {
            if (typeof u == "string") {
                var p = a._prime(u);
                this.m = p.p, this.prime = p
            } else n(u.gtn(1), "modulus must be greater than 1"), this.m = u, this.prime = null
        }
        Tt.prototype._verify1 = function(u) {
            n(u.negative === 0, "red works only with positives"), n(u.red, "red works only with red numbers")
        }, Tt.prototype._verify2 = function(u, p) {
            n((u.negative | p.negative) === 0, "red works only with positives"), n(u.red && u.red === p.red, "red works only with red numbers")
        }, Tt.prototype.imod = function(u) {
            return this.prime ? this.prime.ireduce(u)._forceRed(this) : (_(u, u.umod(this.m)._forceRed(this)), u)
        }, Tt.prototype.neg = function(u) {
            return u.isZero() ? u.clone() : this.m.sub(u)._forceRed(this)
        }, Tt.prototype.add = function(u, p) {
            this._verify2(u, p);
            var v = u.add(p);
            return v.cmp(this.m) >= 0 && v.isub(this.m), v._forceRed(this)
        }, Tt.prototype.iadd = function(u, p) {
            this._verify2(u, p);
            var v = u.iadd(p);
            return v.cmp(this.m) >= 0 && v.isub(this.m), v
        }, Tt.prototype.sub = function(u, p) {
            this._verify2(u, p);
            var v = u.sub(p);
            return v.cmpn(0) < 0 && v.iadd(this.m), v._forceRed(this)
        }, Tt.prototype.isub = function(u, p) {
            this._verify2(u, p);
            var v = u.isub(p);
            return v.cmpn(0) < 0 && v.iadd(this.m), v
        }, Tt.prototype.shl = function(u, p) {
            return this._verify1(u), this.imod(u.ushln(p))
        }, Tt.prototype.imul = function(u, p) {
            return this._verify2(u, p), this.imod(u.imul(p))
        }, Tt.prototype.mul = function(u, p) {
            return this._verify2(u, p), this.imod(u.mul(p))
        }, Tt.prototype.isqr = function(u) {
            return this.imul(u, u.clone())
        }, Tt.prototype.sqr = function(u) {
            return this.mul(u, u)
        }, Tt.prototype.sqrt = function(u) {
            if (u.isZero()) return u.clone();
            var p = this.m.andln(3);
            if (n(p % 2 === 1), p === 3) {
                var v = this.m.add(new a(1)).iushrn(2);
                return this.pow(u, v)
            }
            for (var P = this.m.subn(1), C = 0; !P.isZero() && P.andln(1) === 0;) C++, P.iushrn(1);
            n(!P.isZero());
            var R = new a(1).toRed(this),
                T = R.redNeg(),
                E = this.m.subn(1).iushrn(1),
                f = this.m.bitLength();
            for (f = new a(2 * f * f).toRed(this); this.pow(f, E).cmp(T) !== 0;) f.redIAdd(T);
            for (var x = this.pow(f, P), ht = this.pow(u, P.addn(1).iushrn(1)), gt = this.pow(u, P), y = C; gt.cmp(R) !== 0;) {
                for (var V = gt, O = 0; V.cmp(R) !== 0; O++) V = V.redSqr();
                n(O < y);
                var D = this.pow(x, new a(1).iushln(y - O - 1));
                ht = ht.redMul(D), x = D.redSqr(), gt = gt.redMul(x), y = O
            }
            return ht
        }, Tt.prototype.invm = function(u) {
            var p = u._invmp(this.m);
            return p.negative !== 0 ? (p.negative = 0, this.imod(p).redNeg()) : this.imod(p)
        }, Tt.prototype.pow = function(u, p) {
            if (p.isZero()) return new a(1).toRed(this);
            if (p.cmpn(1) === 0) return u.clone();
            var v = 4,
                P = new Array(1 << v);
            P[0] = new a(1).toRed(this), P[1] = u;
            for (var C = 2; C < P.length; C++) P[C] = this.mul(P[C - 1], u);
            var R = P[0],
                T = 0,
                E = 0,
                f = p.bitLength() % 26;
            for (f === 0 && (f = 26), C = p.length - 1; C >= 0; C--) {
                for (var x = p.words[C], ht = f - 1; ht >= 0; ht--) {
                    var gt = x >> ht & 1;
                    if (R !== P[0] && (R = this.sqr(R)), gt === 0 && T === 0) {
                        E = 0;
                        continue
                    }
                    T <<= 1, T |= gt, E++, !(E !== v && (C !== 0 || ht !== 0)) && (R = this.mul(R, P[T]), E = 0, T = 0)
                }
                f = 26
            }
            return R
        }, Tt.prototype.convertTo = function(u) {
            var p = u.umod(this.m);
            return p === u ? p.clone() : p
        }, Tt.prototype.convertFrom = function(u) {
            var p = u.clone();
            return p.red = null, p
        }, a.mont = function(u) {
            return new ve(u)
        };

        function ve(u) {
            Tt.call(this, u), this.shift = this.m.bitLength(), this.shift % 26 !== 0 && (this.shift += 26 - this.shift % 26), this.r = new a(1).iushln(this.shift), this.r2 = this.imod(this.r.sqr()), this.rinv = this.r._invmp(this.m), this.minv = this.rinv.mul(this.r).isubn(1).div(this.m), this.minv = this.minv.umod(this.r), this.minv = this.r.sub(this.minv)
        }
        o(ve, Tt), ve.prototype.convertTo = function(u) {
            return this.imod(u.ushln(this.shift))
        }, ve.prototype.convertFrom = function(u) {
            var p = this.imod(u.mul(this.rinv));
            return p.red = null, p
        }, ve.prototype.imul = function(u, p) {
            if (u.isZero() || p.isZero()) return u.words[0] = 0, u.length = 1, u;
            var v = u.imul(p),
                P = v.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m),
                C = v.isub(P).iushrn(this.shift),
                R = C;
            return C.cmp(this.m) >= 0 ? R = C.isub(this.m) : C.cmpn(0) < 0 && (R = C.iadd(this.m)), R._forceRed(this)
        }, ve.prototype.mul = function(u, p) {
            if (u.isZero() || p.isZero()) return new a(0)._forceRed(this);
            var v = u.mul(p),
                P = v.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m),
                C = v.isub(P).iushrn(this.shift),
                R = C;
            return C.cmp(this.m) >= 0 ? R = C.isub(this.m) : C.cmpn(0) < 0 && (R = C.iadd(this.m)), R._forceRed(this)
        }, ve.prototype.invm = function(u) {
            var p = this.imod(u._invmp(this.m).mul(this.r2));
            return p._forceRed(this)
        }
    })(r, C0)
})(T0);
var Yt = T0.exports;
const D0 = "bignumber/5.7.0";
var bc = Yt.BN;
const gn = new dr(D0),
    Jh = {},
    Hd = 9007199254740991;

function n_(r) {
    return r != null && (Mr.isBigNumber(r) || typeof r == "number" && r % 1 === 0 || typeof r == "string" && !!r.match(/^-?[0-9]+$/) || Yr(r) || typeof r == "bigint" || Gs(r))
}
let Kd = !1,
    Mr = class Mi {
        constructor(t, e) {
            t !== Jh && gn.throwError("cannot call constructor directly; use BigNumber.from", dr.errors.UNSUPPORTED_OPERATION, {
                operation: "new (BigNumber)"
            }), this._hex = e, this._isBigNumber = !0, Object.freeze(this)
        }
        fromTwos(t) {
            return Dr(fe(this).fromTwos(t))
        }
        toTwos(t) {
            return Dr(fe(this).toTwos(t))
        }
        abs() {
            return this._hex[0] === "-" ? Mi.from(this._hex.substring(1)) : this
        }
        add(t) {
            return Dr(fe(this).add(fe(t)))
        }
        sub(t) {
            return Dr(fe(this).sub(fe(t)))
        }
        div(t) {
            return Mi.from(t).isZero() && fi("division-by-zero", "div"), Dr(fe(this).div(fe(t)))
        }
        mul(t) {
            return Dr(fe(this).mul(fe(t)))
        }
        mod(t) {
            const e = fe(t);
            return e.isNeg() && fi("division-by-zero", "mod"), Dr(fe(this).umod(e))
        }
        pow(t) {
            const e = fe(t);
            return e.isNeg() && fi("negative-power", "pow"), Dr(fe(this).pow(e))
        }
        and(t) {
            const e = fe(t);
            return (this.isNegative() || e.isNeg()) && fi("unbound-bitwise-result", "and"), Dr(fe(this).and(e))
        }
        or(t) {
            const e = fe(t);
            return (this.isNegative() || e.isNeg()) && fi("unbound-bitwise-result", "or"), Dr(fe(this).or(e))
        }
        xor(t) {
            const e = fe(t);
            return (this.isNegative() || e.isNeg()) && fi("unbound-bitwise-result", "xor"), Dr(fe(this).xor(e))
        }
        mask(t) {
            return (this.isNegative() || t < 0) && fi("negative-width", "mask"), Dr(fe(this).maskn(t))
        }
        shl(t) {
            return (this.isNegative() || t < 0) && fi("negative-width", "shl"), Dr(fe(this).shln(t))
        }
        shr(t) {
            return (this.isNegative() || t < 0) && fi("negative-width", "shr"), Dr(fe(this).shrn(t))
        }
        eq(t) {
            return fe(this).eq(fe(t))
        }
        lt(t) {
            return fe(this).lt(fe(t))
        }
        lte(t) {
            return fe(this).lte(fe(t))
        }
        gt(t) {
            return fe(this).gt(fe(t))
        }
        gte(t) {
            return fe(this).gte(fe(t))
        }
        isNegative() {
            return this._hex[0] === "-"
        }
        isZero() {
            return fe(this).isZero()
        }
        toNumber() {
            try {
                return fe(this).toNumber()
            } catch {
                fi("overflow", "toNumber", this.toString())
            }
            return null
        }
        toBigInt() {
            try {
                return BigInt(this.toString())
            } catch {}
            return gn.throwError("this platform does not support BigInt", dr.errors.UNSUPPORTED_OPERATION, {
                value: this.toString()
            })
        }
        toString() {
            return arguments.length > 0 && (arguments[0] === 10 ? Kd || (Kd = !0, gn.warn("BigNumber.toString does not accept any parameters; base-10 is assumed")) : arguments[0] === 16 ? gn.throwError("BigNumber.toString does not accept any parameters; use bigNumber.toHexString()", dr.errors.UNEXPECTED_ARGUMENT, {}) : gn.throwError("BigNumber.toString does not accept parameters", dr.errors.UNEXPECTED_ARGUMENT, {})), fe(this).toString(10)
        }
        toHexString() {
            return this._hex
        }
        toJSON(t) {
            return {
                type: "BigNumber",
                hex: this.toHexString()
            }
        }
        static from(t) {
            if (t instanceof Mi) return t;
            if (typeof t == "string") return t.match(/^-?0x[0-9a-f]+$/i) ? new Mi(Jh, qo(t)) : t.match(/^-?[0-9]+$/) ? new Mi(Jh, qo(new bc(t))) : gn.throwArgumentError("invalid BigNumber string", "value", t);
            if (typeof t == "number") return t % 1 && fi("underflow", "BigNumber.from", t), (t >= Hd || t <= -Hd) && fi("overflow", "BigNumber.from", t), Mi.from(String(t));
            const e = t;
            if (typeof e == "bigint") return Mi.from(e.toString());
            if (Gs(e)) return Mi.from(Ur(e));
            if (e)
                if (e.toHexString) {
                    const n = e.toHexString();
                    if (typeof n == "string") return Mi.from(n)
                } else {
                    let n = e._hex;
                    if (n == null && e.type === "BigNumber" && (n = e.hex), typeof n == "string" && (Yr(n) || n[0] === "-" && Yr(n.substring(1)))) return Mi.from(n)
                }
            return gn.throwArgumentError("invalid BigNumber value", "value", t)
        }
        static isBigNumber(t) {
            return !!(t && t._isBigNumber)
        }
    };

function qo(r) {
    if (typeof r != "string") return qo(r.toString(16));
    if (r[0] === "-") return r = r.substring(1), r[0] === "-" && gn.throwArgumentError("invalid hex", "value", r), r = qo(r), r === "0x00" ? r : "-" + r;
    if (r.substring(0, 2) !== "0x" && (r = "0x" + r), r === "0x") return "0x00";
    for (r.length % 2 && (r = "0x0" + r.substring(2)); r.length > 4 && r.substring(0, 4) === "0x00";) r = "0x" + r.substring(4);
    return r
}

function Dr(r) {
    return Mr.from(qo(r))
}

function fe(r) {
    const t = Mr.from(r).toHexString();
    return t[0] === "-" ? new bc("-" + t.substring(3), 16) : new bc(t.substring(2), 16)
}

function fi(r, t, e) {
    const n = {
        fault: r,
        operation: t
    };
    return e != null && (n.value = e), gn.throwError(r, dr.errors.NUMERIC_FAULT, n)
}

function s_(r) {
    return new bc(r, 36).toString(16)
}
const Sr = new dr(D0),
    Oo = {},
    q0 = Mr.from(0),
    B0 = Mr.from(-1);

function U0(r, t, e, n) {
    const o = {
        fault: t,
        operation: e
    };
    return n !== void 0 && (o.value = n), Sr.throwError(r, dr.errors.NUMERIC_FAULT, o)
}
let To = "0";
for (; To.length < 256;) To += To;

function Ku(r) {
    if (typeof r != "number") try {
        r = Mr.from(r).toNumber()
    } catch {}
    return typeof r == "number" && r >= 0 && r <= 256 && !(r % 1) ? "1" + To.substring(0, r) : Sr.throwArgumentError("invalid decimal size", "decimals", r)
}

function Yh(r, t) {
    t == null && (t = 0);
    const e = Ku(t);
    r = Mr.from(r);
    const n = r.lt(q0);
    n && (r = r.mul(B0));
    let o = r.mod(e).toString();
    for (; o.length < e.length - 1;) o = "0" + o;
    o = o.match(/^([0-9]*[1-9]|0)(0*)/)[1];
    const a = r.div(e).toString();
    return e.length === 1 ? r = a : r = a + "." + o, n && (r = "-" + r), r
}

function pn(r, t) {
    t == null && (t = 0);
    const e = Ku(t);
    (typeof r != "string" || !r.match(/^-?[0-9.]+$/)) && Sr.throwArgumentError("invalid decimal value", "value", r);
    const n = r.substring(0, 1) === "-";
    n && (r = r.substring(1)), r === "." && Sr.throwArgumentError("missing value", "value", r);
    const o = r.split(".");
    o.length > 2 && Sr.throwArgumentError("too many decimal points", "value", r);
    let a = o[0],
        h = o[1];
    for (a || (a = "0"), h || (h = "0"); h[h.length - 1] === "0";) h = h.substring(0, h.length - 1);
    for (h.length > e.length - 1 && U0("fractional component exceeds decimals", "underflow", "parseFixed"), h === "" && (h = "0"); h.length < e.length - 1;) h += "0";
    const g = Mr.from(a),
        b = Mr.from(h);
    let m = g.mul(e).add(b);
    return n && (m = m.mul(B0)), m
}
let Xh = class Iu {
        constructor(t, e, n, o) {
            t !== Oo && Sr.throwError("cannot use FixedFormat constructor; use FixedFormat.from", dr.errors.UNSUPPORTED_OPERATION, {
                operation: "new FixedFormat"
            }), this.signed = e, this.width = n, this.decimals = o, this.name = (e ? "" : "u") + "fixed" + String(n) + "x" + String(o), this._multiplier = Ku(o), Object.freeze(this)
        }
        static from(t) {
            if (t instanceof Iu) return t;
            typeof t == "number" && (t = `fixed128x${t}`);
            let e = !0,
                n = 128,
                o = 18;
            if (typeof t == "string") {
                if (t !== "fixed")
                    if (t === "ufixed") e = !1;
                    else {
                        const a = t.match(/^(u?)fixed([0-9]+)x([0-9]+)$/);
                        a || Sr.throwArgumentError("invalid fixed format", "format", t), e = a[1] !== "u", n = parseInt(a[2]), o = parseInt(a[3])
                    }
            } else if (t) {
                const a = (h, g, b) => t[h] == null ? b : (typeof t[h] !== g && Sr.throwArgumentError("invalid fixed format (" + h + " not " + g + ")", "format." + h, t[h]), t[h]);
                e = a("signed", "boolean", e), n = a("width", "number", n), o = a("decimals", "number", o)
            }
            return n % 8 && Sr.throwArgumentError("invalid fixed format width (not byte aligned)", "format.width", n), o > 80 && Sr.throwArgumentError("invalid fixed format (decimals too large)", "format.decimals", o), new Iu(Oo, e, n, o)
        }
    },
    k0 = class Ir {
        constructor(t, e, n, o) {
            t !== Oo && Sr.throwError("cannot use FixedNumber constructor; use FixedNumber.from", dr.errors.UNSUPPORTED_OPERATION, {
                operation: "new FixedFormat"
            }), this.format = o, this._hex = e, this._value = n, this._isFixedNumber = !0, Object.freeze(this)
        }
        _checkFormat(t) {
            this.format.name !== t.format.name && Sr.throwArgumentError("incompatible format; use fixedNumber.toFormat", "other", t)
        }
        addUnsafe(t) {
            this._checkFormat(t);
            const e = pn(this._value, this.format.decimals),
                n = pn(t._value, t.format.decimals);
            return Ir.fromValue(e.add(n), this.format.decimals, this.format)
        }
        subUnsafe(t) {
            this._checkFormat(t);
            const e = pn(this._value, this.format.decimals),
                n = pn(t._value, t.format.decimals);
            return Ir.fromValue(e.sub(n), this.format.decimals, this.format)
        }
        mulUnsafe(t) {
            this._checkFormat(t);
            const e = pn(this._value, this.format.decimals),
                n = pn(t._value, t.format.decimals);
            return Ir.fromValue(e.mul(n).div(this.format._multiplier), this.format.decimals, this.format)
        }
        divUnsafe(t) {
            this._checkFormat(t);
            const e = pn(this._value, this.format.decimals),
                n = pn(t._value, t.format.decimals);
            return Ir.fromValue(e.mul(this.format._multiplier).div(n), this.format.decimals, this.format)
        }
        floor() {
            const t = this.toString().split(".");
            t.length === 1 && t.push("0");
            let e = Ir.from(t[0], this.format);
            const n = !t[1].match(/^(0*)$/);
            return this.isNegative() && n && (e = e.subUnsafe(Vd.toFormat(e.format))), e
        }
        ceiling() {
            const t = this.toString().split(".");
            t.length === 1 && t.push("0");
            let e = Ir.from(t[0], this.format);
            const n = !t[1].match(/^(0*)$/);
            return !this.isNegative() && n && (e = e.addUnsafe(Vd.toFormat(e.format))), e
        }
        round(t) {
            t == null && (t = 0);
            const e = this.toString().split(".");
            if (e.length === 1 && e.push("0"), (t < 0 || t > 80 || t % 1) && Sr.throwArgumentError("invalid decimal count", "decimals", t), e[1].length <= t) return this;
            const n = Ir.from("1" + To.substring(0, t), this.format),
                o = o_.toFormat(this.format);
            return this.mulUnsafe(n).addUnsafe(o).floor().divUnsafe(n)
        }
        isZero() {
            return this._value === "0.0" || this._value === "0"
        }
        isNegative() {
            return this._value[0] === "-"
        }
        toString() {
            return this._value
        }
        toHexString(t) {
            if (t == null) return this._hex;
            t % 8 && Sr.throwArgumentError("invalid byte width", "width", t);
            const e = Mr.from(this._hex).fromTwos(this.format.width).toTwos(t).toHexString();
            return Ji(e, t / 8)
        }
        toUnsafeFloat() {
            return parseFloat(this.toString())
        }
        toFormat(t) {
            return Ir.fromString(this._value, t)
        }
        static fromValue(t, e, n) {
            return n == null && e != null && !n_(e) && (n = e, e = null), e == null && (e = 0), n == null && (n = "fixed"), Ir.fromString(Yh(t, e), Xh.from(n))
        }
        static fromString(t, e) {
            e == null && (e = "fixed");
            const n = Xh.from(e),
                o = pn(t, n.decimals);
            !n.signed && o.lt(q0) && U0("unsigned value cannot be negative", "overflow", "value", t);
            let a = null;
            n.signed ? a = o.toTwos(n.width).toHexString() : (a = o.toHexString(), a = Ji(a, n.width / 8));
            const h = Yh(o, n.decimals);
            return new Ir(Oo, a, h, n)
        }
        static fromBytes(t, e) {
            e == null && (e = "fixed");
            const n = Xh.from(e);
            if (Ve(t).length > n.width / 8) throw new Error("overflow");
            let o = Mr.from(t);
            n.signed && (o = o.fromTwos(n.width));
            const a = o.toTwos((n.signed ? 0 : 1) + n.width).toHexString(),
                h = Yh(o, n.decimals);
            return new Ir(Oo, a, h, n)
        }
        static from(t, e) {
            if (typeof t == "string") return Ir.fromString(t, e);
            if (Gs(t)) return Ir.fromBytes(t, e);
            try {
                return Ir.fromValue(t, 0, e)
            } catch (n) {
                if (n.code !== dr.errors.INVALID_ARGUMENT) throw n
            }
            return Sr.throwArgumentError("invalid FixedNumber value", "value", t)
        }
        static isFixedNumber(t) {
            return !!(t && t._isFixedNumber)
        }
    };
const Vd = k0.from(1),
    o_ = k0.from("0.5"),
    a_ = "strings/5.7.0",
    c_ = new dr(a_);
var _c;
(function(r) {
    r.current = "", r.NFC = "NFC", r.NFD = "NFD", r.NFKC = "NFKC", r.NFKD = "NFKD"
})(_c || (_c = {}));
var Gd;
(function(r) {
    r.UNEXPECTED_CONTINUE = "unexpected continuation byte", r.BAD_PREFIX = "bad codepoint prefix", r.OVERRUN = "string overrun", r.MISSING_CONTINUE = "missing continuation byte", r.OUT_OF_RANGE = "out of UTF-8 range", r.UTF16_SURROGATE = "UTF-16 surrogate", r.OVERLONG = "overlong representation"
})(Gd || (Gd = {}));

function Zh(r, t = _c.current) {
    t != _c.current && (c_.checkNormalize(), r = r.normalize(t));
    let e = [];
    for (let n = 0; n < r.length; n++) {
        const o = r.charCodeAt(n);
        if (o < 128) e.push(o);
        else if (o < 2048) e.push(o >> 6 | 192), e.push(o & 63 | 128);
        else if ((o & 64512) == 55296) {
            n++;
            const a = r.charCodeAt(n);
            if (n >= r.length || (a & 64512) !== 56320) throw new Error("invalid utf-8 string");
            const h = 65536 + ((o & 1023) << 10) + (a & 1023);
            e.push(h >> 18 | 240), e.push(h >> 12 & 63 | 128), e.push(h >> 6 & 63 | 128), e.push(h & 63 | 128)
        } else e.push(o >> 12 | 224), e.push(o >> 6 & 63 | 128), e.push(o & 63 | 128)
    }
    return Ve(e)
}

function h_(r) {
    if (r.length % 4 !== 0) throw new Error("bad data");
    let t = [];
    for (let e = 0; e < r.length; e += 4) t.push(parseInt(r.substring(e, e + 4), 16));
    return t
}

function tu(r, t) {
    t || (t = function(o) {
        return [parseInt(o, 16)]
    });
    let e = 0,
        n = {};
    return r.split(",").forEach(o => {
        let a = o.split(":");
        e += parseInt(a[0], 16), n[e] = t(a[1])
    }), n
}

function Qd(r) {
    let t = 0;
    return r.split(",").map(e => {
        let n = e.split("-");
        n.length === 1 ? n[1] = "0" : n[1] === "" && (n[1] = "1");
        let o = t + parseInt(n[0], 16);
        return t = parseInt(n[1], 16), {
            l: o,
            h: t
        }
    })
}
Qd("221,13-1b,5f-,40-10,51-f,11-3,3-3,2-2,2-4,8,2,15,2d,28-8,88,48,27-,3-5,11-20,27-,8,28,3-5,12,18,b-a,1c-4,6-16,2-d,2-2,2,1b-4,17-9,8f-,10,f,1f-2,1c-34,33-14e,4,36-,13-,6-2,1a-f,4,9-,3-,17,8,2-2,5-,2,8-,3-,4-8,2-3,3,6-,16-6,2-,7-3,3-,17,8,3,3,3-,2,6-3,3-,4-a,5,2-6,10-b,4,8,2,4,17,8,3,6-,b,4,4-,2-e,2-4,b-10,4,9-,3-,17,8,3-,5-,9-2,3-,4-7,3-3,3,4-3,c-10,3,7-2,4,5-2,3,2,3-2,3-2,4-2,9,4-3,6-2,4,5-8,2-e,d-d,4,9,4,18,b,6-3,8,4,5-6,3-8,3-3,b-11,3,9,4,18,b,6-3,8,4,5-6,3-6,2,3-3,b-11,3,9,4,18,11-3,7-,4,5-8,2-7,3-3,b-11,3,13-2,19,a,2-,8-2,2-3,7,2,9-11,4-b,3b-3,1e-24,3,2-,3,2-,2-5,5,8,4,2,2-,3,e,4-,6,2,7-,b-,3-21,49,23-5,1c-3,9,25,10-,2-2f,23,6,3,8-2,5-5,1b-45,27-9,2a-,2-3,5b-4,45-4,53-5,8,40,2,5-,8,2,5-,28,2,5-,20,2,5-,8,2,5-,8,8,18,20,2,5-,8,28,14-5,1d-22,56-b,277-8,1e-2,52-e,e,8-a,18-8,15-b,e,4,3-b,5e-2,b-15,10,b-5,59-7,2b-555,9d-3,5b-5,17-,7-,27-,7-,9,2,2,2,20-,36,10,f-,7,14-,4,a,54-3,2-6,6-5,9-,1c-10,13-1d,1c-14,3c-,10-6,32-b,240-30,28-18,c-14,a0,115-,3,66-,b-76,5,5-,1d,24,2,5-2,2,8-,35-2,19,f-10,1d-3,311-37f,1b,5a-b,d7-19,d-3,41,57-,68-4,29-3,5f,29-37,2e-2,25-c,2c-2,4e-3,30,78-3,64-,20,19b7-49,51a7-59,48e-2,38-738,2ba5-5b,222f-,3c-94,8-b,6-4,1b,6,2,3,3,6d-20,16e-f,41-,37-7,2e-2,11-f,5-b,18-,b,14,5-3,6,88-,2,bf-2,7-,7-,7-,4-2,8,8-9,8-2ff,20,5-b,1c-b4,27-,27-cbb1,f7-9,28-2,b5-221,56,48,3-,2-,3-,5,d,2,5,3,42,5-,9,8,1d,5,6,2-2,8,153-3,123-3,33-27fd,a6da-5128,21f-5df,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3-fffd,3,2-1d,61-ff7d"), "ad,34f,1806,180b,180c,180d,200b,200c,200d,2060,feff".split(",").map(r => parseInt(r, 16)), tu("b5:3bc,c3:ff,7:73,2:253,5:254,3:256,1:257,5:259,1:25b,3:260,1:263,2:269,1:268,5:26f,1:272,2:275,7:280,3:283,5:288,3:28a,1:28b,5:292,3f:195,1:1bf,29:19e,125:3b9,8b:3b2,1:3b8,1:3c5,3:3c6,1:3c0,1a:3ba,1:3c1,1:3c3,2:3b8,1:3b5,1bc9:3b9,1c:1f76,1:1f77,f:1f7a,1:1f7b,d:1f78,1:1f79,1:1f7c,1:1f7d,107:63,5:25b,4:68,1:68,1:68,3:69,1:69,1:6c,3:6e,4:70,1:71,1:72,1:72,1:72,7:7a,2:3c9,2:7a,2:6b,1:e5,1:62,1:63,3:65,1:66,2:6d,b:3b3,1:3c0,6:64,1b574:3b8,1a:3c3,20:3b8,1a:3c3,20:3b8,1a:3c3,20:3b8,1a:3c3,20:3b8,1a:3c3"), tu("179:1,2:1,2:1,5:1,2:1,a:4f,a:1,8:1,2:1,2:1,3:1,5:1,3:1,4:1,2:1,3:1,4:1,8:2,1:1,2:2,1:1,2:2,27:2,195:26,2:25,1:25,1:25,2:40,2:3f,1:3f,33:1,11:-6,1:-9,1ac7:-3a,6d:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,9:-8,1:-8,1:-8,1:-8,1:-8,1:-8,b:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,9:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,9:-8,1:-8,1:-8,1:-8,1:-8,1:-8,c:-8,2:-8,2:-8,2:-8,9:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,1:-8,49:-8,1:-8,1:-4a,1:-4a,d:-56,1:-56,1:-56,1:-56,d:-8,1:-8,f:-8,1:-8,3:-7"), tu("df:00730073,51:00690307,19:02BC006E,a7:006A030C,18a:002003B9,16:03B903080301,20:03C503080301,1d7:05650582,190f:00680331,1:00740308,1:0077030A,1:0079030A,1:006102BE,b6:03C50313,2:03C503130300,2:03C503130301,2:03C503130342,2a:1F0003B9,1:1F0103B9,1:1F0203B9,1:1F0303B9,1:1F0403B9,1:1F0503B9,1:1F0603B9,1:1F0703B9,1:1F0003B9,1:1F0103B9,1:1F0203B9,1:1F0303B9,1:1F0403B9,1:1F0503B9,1:1F0603B9,1:1F0703B9,1:1F2003B9,1:1F2103B9,1:1F2203B9,1:1F2303B9,1:1F2403B9,1:1F2503B9,1:1F2603B9,1:1F2703B9,1:1F2003B9,1:1F2103B9,1:1F2203B9,1:1F2303B9,1:1F2403B9,1:1F2503B9,1:1F2603B9,1:1F2703B9,1:1F6003B9,1:1F6103B9,1:1F6203B9,1:1F6303B9,1:1F6403B9,1:1F6503B9,1:1F6603B9,1:1F6703B9,1:1F6003B9,1:1F6103B9,1:1F6203B9,1:1F6303B9,1:1F6403B9,1:1F6503B9,1:1F6603B9,1:1F6703B9,3:1F7003B9,1:03B103B9,1:03AC03B9,2:03B10342,1:03B1034203B9,5:03B103B9,6:1F7403B9,1:03B703B9,1:03AE03B9,2:03B70342,1:03B7034203B9,5:03B703B9,6:03B903080300,1:03B903080301,3:03B90342,1:03B903080342,b:03C503080300,1:03C503080301,1:03C10313,2:03C50342,1:03C503080342,b:1F7C03B9,1:03C903B9,1:03CE03B9,2:03C90342,1:03C9034203B9,5:03C903B9,ac:00720073,5b:00B00063,6:00B00066,d:006E006F,a:0073006D,1:00740065006C,1:0074006D,124f:006800700061,2:00610075,2:006F0076,b:00700061,1:006E0061,1:03BC0061,1:006D0061,1:006B0061,1:006B0062,1:006D0062,1:00670062,3:00700066,1:006E0066,1:03BC0066,4:0068007A,1:006B0068007A,1:006D0068007A,1:00670068007A,1:00740068007A,15:00700061,1:006B00700061,1:006D00700061,1:006700700061,8:00700076,1:006E0076,1:03BC0076,1:006D0076,1:006B0076,1:006D0076,1:00700077,1:006E0077,1:03BC0077,1:006D0077,1:006B0077,1:006D0077,1:006B03C9,1:006D03C9,2:00620071,3:00632215006B0067,1:0063006F002E,1:00640062,1:00670079,2:00680070,2:006B006B,1:006B006D,9:00700068,2:00700070006D,1:00700072,2:00730076,1:00770062,c723:00660066,1:00660069,1:0066006C,1:006600660069,1:00660066006C,1:00730074,1:00730074,d:05740576,1:05740565,1:0574056B,1:057E0576,1:0574056D", h_), Qd("80-20,2a0-,39c,32,f71,18e,7f2-f,19-7,30-4,7-5,f81-b,5,a800-20ff,4d1-1f,110,fa-6,d174-7,2e84-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,ffff-,2,1f-5f,ff7f-20001");

function u_(r) {
    r = atob(r);
    const t = [];
    for (let e = 0; e < r.length; e++) t.push(r.charCodeAt(e));
    return Ve(t)
}

function L0(r, t) {
    t == null && (t = 1);
    const e = [],
        n = e.forEach,
        o = function(a, h) {
            n.call(a, function(g) {
                h > 0 && Array.isArray(g) ? o(g, h - 1) : e.push(g)
            })
        };
    return o(r, t), e
}

function l_(r) {
    const t = {};
    for (let e = 0; e < r.length; e++) {
        const n = r[e];
        t[n[0]] = n[1]
    }
    return t
}

function f_(r) {
    let t = 0;

    function e() {
        return r[t++] << 8 | r[t++]
    }
    let n = e(),
        o = 1,
        a = [0, 1];
    for (let st = 1; st < n; st++) a.push(o += e());
    let h = e(),
        g = t;
    t += h;
    let b = 0,
        m = 0;

    function _() {
        return b == 0 && (m = m << 8 | r[t++], b = 8), m >> --b & 1
    }
    const S = 31,
        B = Math.pow(2, S),
        k = B >>> 1,
        L = k >> 1,
        K = B - 1;
    let Q = 0;
    for (let st = 0; st < S; st++) Q = Q << 1 | _();
    let et = [],
        at = 0,
        ut = B;
    for (;;) {
        let st = Math.floor(((Q - at + 1) * o - 1) / ut),
            ot = 0,
            it = n;
        for (; it - ot > 1;) {
            let oe = ot + it >>> 1;
            st < a[oe] ? it = oe : ot = oe
        }
        if (ot == 0) break;
        et.push(ot);
        let mt = at + Math.floor(ut * a[ot] / o),
            Zt = at + Math.floor(ut * a[ot + 1] / o) - 1;
        for (; !((mt ^ Zt) & k);) Q = Q << 1 & K | _(), mt = mt << 1 & K, Zt = Zt << 1 & K | 1;
        for (; mt & ~Zt & L;) Q = Q & k | Q << 1 & K >>> 1 | _(), mt = mt << 1 ^ k, Zt = (Zt ^ k) << 1 | k | 1;
        at = mt, ut = 1 + Zt - mt
    }
    let ft = n - 4;
    return et.map(st => {
        switch (st - ft) {
            case 3:
                return ft + 65792 + (r[g++] << 16 | r[g++] << 8 | r[g++]);
            case 2:
                return ft + 256 + (r[g++] << 8 | r[g++]);
            case 1:
                return ft + r[g++];
            default:
                return st - 1
        }
    })
}

function d_(r) {
    let t = 0;
    return () => r[t++]
}

function p_(r) {
    return d_(f_(r))
}

function g_(r) {
    return r & 1 ? ~r >> 1 : r >> 1
}

function m_(r, t) {
    let e = Array(r);
    for (let n = 0; n < r; n++) e[n] = 1 + t();
    return e
}

function Wd(r, t) {
    let e = Array(r);
    for (let n = 0, o = -1; n < r; n++) e[n] = o += 1 + t();
    return e
}

function v_(r, t) {
    let e = Array(r);
    for (let n = 0, o = 0; n < r; n++) e[n] = o += g_(t());
    return e
}

function Ac(r, t) {
    let e = Wd(r(), r),
        n = r(),
        o = Wd(n, r),
        a = m_(n, r);
    for (let h = 0; h < n; h++)
        for (let g = 0; g < a[h]; g++) e.push(o[h] + g);
    return t ? e.map(h => t[h]) : e
}

function y_(r) {
    let t = [];
    for (;;) {
        let e = r();
        if (e == 0) break;
        t.push(b_(e, r))
    }
    for (;;) {
        let e = r() - 1;
        if (e < 0) break;
        t.push(__(e, r))
    }
    return l_(L0(t))
}

function w_(r) {
    let t = [];
    for (;;) {
        let e = r();
        if (e == 0) break;
        t.push(e)
    }
    return t
}

function $0(r, t, e) {
    let n = Array(r).fill(void 0).map(() => []);
    for (let o = 0; o < t; o++) v_(r, e).forEach((a, h) => n[h].push(a));
    return n
}

function b_(r, t) {
    let e = 1 + t(),
        n = t(),
        o = w_(t),
        a = $0(o.length, 1 + r, t);
    return L0(a.map((h, g) => {
        const b = h[0],
            m = h.slice(1);
        return Array(o[g]).fill(void 0).map((_, S) => {
            let B = S * n;
            return [b + S * e, m.map(k => k + B)]
        })
    }))
}

function __(r, t) {
    let e = 1 + t();
    return $0(e, 1 + r, t).map(n => [n[0], n.slice(1)])
}

function A_(r) {
    let t = Ac(r).sort((n, o) => n - o);
    return e();

    function e() {
        let n = [];
        for (;;) {
            let m = Ac(r, t);
            if (m.length == 0) break;
            n.push({
                set: new Set(m),
                node: e()
            })
        }
        n.sort((m, _) => _.set.size - m.set.size);
        let o = r(),
            a = o % 3;
        o = o / 3 | 0;
        let h = !!(o & 1);
        o >>= 1;
        let g = o == 1,
            b = o == 2;
        return {
            branches: n,
            valid: a,
            fe0f: h,
            save: g,
            check: b
        }
    }
}

function E_() {
    return p_(u_("AEQF2AO2DEsA2wIrAGsBRABxAN8AZwCcAEwAqgA0AGwAUgByADcATAAVAFYAIQAyACEAKAAYAFgAGwAjABQAMAAmADIAFAAfABQAKwATACoADgAbAA8AHQAYABoAGQAxADgALAAoADwAEwA9ABMAGgARAA4ADwAWABMAFgAIAA8AHgQXBYMA5BHJAS8JtAYoAe4AExozi0UAH21tAaMnBT8CrnIyhrMDhRgDygIBUAEHcoFHUPe8AXBjAewCjgDQR8IICIcEcQLwATXCDgzvHwBmBoHNAqsBdBcUAykgDhAMShskMgo8AY8jqAQfAUAfHw8BDw87MioGlCIPBwZCa4ELatMAAMspJVgsDl8AIhckSg8XAHdvTwBcIQEiDT4OPhUqbyECAEoAS34Aej8Ybx83JgT/Xw8gHxZ/7w8RICxPHA9vBw+Pfw8PHwAPFv+fAsAvCc8vEr8ivwD/EQ8Bol8OEBa/A78hrwAPCU8vESNvvwWfHwNfAVoDHr+ZAAED34YaAdJPAK7PLwSEgDLHAGo1Pz8Pvx9fUwMrpb8O/58VTzAPIBoXIyQJNF8hpwIVAT8YGAUADDNBaX3RAMomJCg9EhUeA29MABsZBTMNJipjOhc19gcIDR8bBwQHEggCWi6DIgLuAQYA+BAFCha3A5XiAEsqM7UFFgFLhAMjFTMYE1Klnw74nRVBG/ASCm0BYRN/BrsU3VoWy+S0vV8LQx+vN8gF2AC2AK5EAWwApgYDKmAAroQ0NDQ0AT+OCg7wAAIHRAbpNgVcBV0APTA5BfbPFgMLzcYL/QqqA82eBALKCjQCjqYCht0/k2+OAsXQAoP3ASTKDgDw6ACKAUYCMpIKJpRaAE4A5womABzZvs0REEKiACIQAd5QdAECAj4Ywg/wGqY2AVgAYADYvAoCGAEubA0gvAY2ALAAbpbvqpyEAGAEpgQAJgAG7gAgAEACmghUFwCqAMpAINQIwC4DthRAAPcycKgApoIdABwBfCisABoATwBqASIAvhnSBP8aH/ECeAKXAq40NjgDBTwFYQU6AXs3oABgAD4XNgmcCY1eCl5tIFZeUqGgyoNHABgAEQAaABNwWQAmABMATPMa3T34ADldyprmM1M2XociUQgLzvwAXT3xABgAEQAaABNwIGFAnADD8AAgAD4BBJWzaCcIAIEBFMAWwKoAAdq9BWAF5wLQpALEtQAKUSGkahR4GnJM+gsAwCgeFAiUAECQ0BQuL8AAIAAAADKeIheclvFqQAAETr4iAMxIARMgAMIoHhQIAn0E0pDQFC4HhznoAAAAIAI2C0/4lvFqQAAETgBJJwYCAy4ABgYAFAA8MBKYEH4eRhTkAjYeFcgACAYAeABsOqyQ5gRwDayqugEgaIIAtgoACgDmEABmBAWGme5OBJJA2m4cDeoAmITWAXwrMgOgAGwBCh6CBXYF1Tzg1wKAAFdiuABRAFwAXQBsAG8AdgBrAHYAbwCEAHEwfxQBVE5TEQADVFhTBwBDANILAqcCzgLTApQCrQL6vAAMAL8APLhNBKkE6glGKTAU4Dr4N2EYEwBCkABKk8rHAbYBmwIoAiU4Ajf/Aq4CowCAANIChzgaNBsCsTgeODcFXrgClQKdAqQBiQGYAqsCsjTsNHsfNPA0ixsAWTWiOAMFPDQSNCk2BDZHNow2TTZUNhk28Jk9VzI3QkEoAoICoQKwAqcAQAAxBV4FXbS9BW47YkIXP1ciUqs05DS/FwABUwJW11e6nHuYZmSh/RAYA8oMKvZ8KASoUAJYWAJ6ILAsAZSoqjpgA0ocBIhmDgDWAAawRDQoAAcuAj5iAHABZiR2AIgiHgCaAU68ACxuHAG0ygM8MiZIAlgBdF4GagJqAPZOHAMuBgoATkYAsABiAHgAMLoGDPj0HpKEBAAOJgAuALggTAHWAeAMEDbd20Uege0ADwAWADkAQgA9OHd+2MUQZBBhBgNNDkxxPxUQArEPqwvqERoM1irQ090ANK4H8ANYB/ADWANYB/AH8ANYB/ADWANYA1gDWBwP8B/YxRBkD00EcgWTBZAE2wiIJk4RhgctCNdUEnQjHEwDSgEBIypJITuYMxAlR0wRTQgIATZHbKx9PQNMMbBU+pCnA9AyVDlxBgMedhKlAC8PeCE1uk6DekxxpQpQT7NX9wBFBgASqwAS5gBJDSgAUCwGPQBI4zTYABNGAE2bAE3KAExdGABKaAbgAFBXAFCOAFBJABI2SWdObALDOq0//QomCZhvwHdTBkIQHCemEPgMNAG2ATwN7kvZBPIGPATKH34ZGg/OlZ0Ipi3eDO4m5C6igFsj9iqEBe5L9TzeC05RaQ9aC2YJ5DpkgU8DIgEOIowK3g06CG4Q9ArKbA3mEUYHOgPWSZsApgcCCxIdNhW2JhFirQsKOXgG/Br3C5AmsBMqev0F1BoiBk4BKhsAANAu6IWxWjJcHU9gBgQLJiPIFKlQIQ0mQLh4SRocBxYlqgKSQ3FKiFE3HpQh9zw+DWcuFFF9B/Y8BhlQC4I8n0asRQ8R0z6OPUkiSkwtBDaALDAnjAnQD4YMunxzAVoJIgmyDHITMhEYN8YIOgcaLpclJxYIIkaWYJsE+KAD9BPSAwwFQAlCBxQDthwuEy8VKgUOgSXYAvQ21i60ApBWgQEYBcwPJh/gEFFH4Q7qCJwCZgOEJewALhUiABginAhEZABgj9lTBi7MCMhqbSN1A2gU6GIRdAeSDlgHqBw0FcAc4nDJXgyGCSiksAlcAXYJmgFgBOQICjVcjKEgQmdUi1kYnCBiQUBd/QIyDGYVoES+h3kCjA9sEhwBNgF0BzoNAgJ4Ee4RbBCWCOyGBTW2M/k6JgRQIYQgEgooA1BszwsoJvoM+WoBpBJjAw00PnfvZ6xgtyUX/gcaMsZBYSHyC5NPzgydGsIYQ1QvGeUHwAP0GvQn60FYBgADpAQUOk4z7wS+C2oIjAlAAEoOpBgH2BhrCnKM0QEyjAG4mgNYkoQCcJAGOAcMAGgMiAV65gAeAqgIpAAGANADWAA6Aq4HngAaAIZCAT4DKDABIuYCkAOUCDLMAZYwAfQqBBzEDBYA+DhuSwLDsgKAa2ajBd5ZAo8CSjYBTiYEBk9IUgOwcuIA3ABMBhTgSAEWrEvMG+REAeBwLADIAPwABjYHBkIBzgH0bgC4AWALMgmjtLYBTuoqAIQAFmwB2AKKAN4ANgCA8gFUAE4FWvoF1AJQSgESMhksWGIBvAMgATQBDgB6BsyOpsoIIARuB9QCEBwV4gLvLwe2AgMi4BPOQsYCvd9WADIXUu5eZwqoCqdeaAC0YTQHMnM9UQAPH6k+yAdy/BZIiQImSwBQ5gBQQzSaNTFWSTYBpwGqKQK38AFtqwBI/wK37gK3rQK3sAK6280C0gK33AK3zxAAUEIAUD9SklKDArekArw5AEQAzAHCO147WTteO1k7XjtZO147WTteO1kDmChYI03AVU0oJqkKbV9GYewMpw3VRMk6ShPcYFJgMxPJLbgUwhXPJVcZPhq9JwYl5VUKDwUt1GYxCC00dhe9AEApaYNCY4ceMQpMHOhTklT5LRwAskujM7ANrRsWREEFSHXuYisWDwojAmSCAmJDXE6wXDchAqH4AmiZAmYKAp+FOBwMAmY8AmYnBG8EgAN/FAN+kzkHOXgYOYM6JCQCbB4CMjc4CwJtyAJtr/CLADRoRiwBaADfAOIASwYHmQyOAP8MwwAOtgJ3MAJ2o0ACeUxEAni7Hl3cRa9G9AJ8QAJ6yQJ9CgJ88UgBSH5kJQAsFklZSlwWGErNAtECAtDNSygDiFADh+dExpEzAvKiXQQDA69Lz0wuJgTQTU1NsAKLQAKK2cIcCB5EaAa4Ao44Ao5dQZiCAo7aAo5deVG1UzYLUtVUhgKT/AKTDQDqAB1VH1WwVdEHLBwplocy4nhnRTw6ApegAu+zWCKpAFomApaQApZ9nQCqWa1aCoJOADwClrYClk9cRVzSApnMApllXMtdCBoCnJw5wzqeApwXAp+cAp65iwAeEDIrEAKd8gKekwC2PmE1YfACntQCoG8BqgKeoCACnk+mY8lkKCYsAiewAiZ/AqD8AqBN2AKmMAKlzwKoAAB+AqfzaH1osgAESmodatICrOQCrK8CrWgCrQMCVx4CVd0CseLYAx9PbJgCsr4OArLpGGzhbWRtSWADJc4Ctl08QG6RAylGArhfArlIFgK5K3hwN3DiAr0aAy2zAzISAr6JcgMDM3ICvhtzI3NQAsPMAsMFc4N0TDZGdOEDPKgDPJsDPcACxX0CxkgCxhGKAshqUgLIRQLJUALJLwJkngLd03h6YniveSZL0QMYpGcDAmH1GfSVJXsMXpNevBICz2wCz20wTFTT9BSgAMeuAs90ASrrA04TfkwGAtwoAtuLAtJQA1JdA1NgAQIDVY2AikABzBfuYUZ2AILPg44C2sgC2d+EEYRKpz0DhqYAMANkD4ZyWvoAVgLfZgLeuXR4AuIw7RUB8zEoAfScAfLTiALr9ALpcXoAAur6AurlAPpIAboC7ooC652Wq5cEAu5AA4XhmHpw4XGiAvMEAGoDjheZlAL3FAORbwOSiAL3mQL52gL4Z5odmqy8OJsfA52EAv77ARwAOp8dn7QDBY4DpmsDptoA0sYDBmuhiaIGCgMMSgFgASACtgNGAJwEgLpoBgC8BGzAEowcggCEDC6kdjoAJAM0C5IKRoABZCgiAIzw3AYBLACkfng9ogigkgNmWAN6AEQCvrkEVqTGAwCsBRbAA+4iQkMCHR072jI2PTbUNsk2RjY5NvA23TZKNiU3EDcZN5I+RTxDRTBCJkK5VBYKFhZfwQCWygU3AJBRHpu+OytgNxa61A40GMsYjsn7BVwFXQVcBV0FaAVdBVwFXQVcBV0FXAVdBVwFXUsaCNyKAK4AAQUHBwKU7oICoW1e7jAEzgPxA+YDwgCkBFDAwADABKzAAOxFLhitA1UFTDeyPkM+bj51QkRCuwTQWWQ8X+0AWBYzsACNA8xwzAGm7EZ/QisoCTAbLDs6fnLfb8H2GccsbgFw13M1HAVkBW/Jxsm9CNRO8E8FDD0FBQw9FkcClOYCoMFegpDfADgcMiA2AJQACB8AsigKAIzIEAJKeBIApY5yPZQIAKQiHb4fvj5BKSRPQrZCOz0oXyxgOywfKAnGbgMClQaCAkILXgdeCD9IIGUgQj5fPoY+dT52Ao5CM0dAX9BTVG9SDzFwWTQAbxBzJF/lOEIQQglCCkKJIAls5AcClQICoKPMODEFxhi6KSAbiyfIRrMjtCgdWCAkPlFBIitCsEJRzAbMAV/OEyQzDg0OAQQEJ36i328/Mk9AybDJsQlq3tDRApUKAkFzXf1d/j9uALYP6hCoFgCTGD8kPsFKQiobrm0+zj0KSD8kPnVCRBwMDyJRTHFgMTJa5rwXQiQ2YfI/JD7BMEJEHGINTw4TOFlIRzwJO0icMQpyPyQ+wzJCRBv6DVgnKB01NgUKj2bwYzMqCoBkznBgEF+zYDIocwRIX+NgHj4HICNfh2C4CwdwFWpTG/lgUhYGAwRfv2Ts8mAaXzVgml/XYIJfuWC4HI1gUF9pYJZgMR6ilQHMAOwLAlDRefC0in4AXAEJA6PjCwc0IamOANMMCAECRQDFNRTZBgd+CwQlRA+r6+gLBDEFBnwUBXgKATIArwAGRAAHA3cDdAN2A3kDdwN9A3oDdQN7A30DfAN4A3oDfQAYEAAlAtYASwMAUAFsAHcKAHcAmgB3AHUAdQB2AHVu8UgAygDAAHcAdQB1AHYAdQALCgB3AAsAmgB3AAsCOwB3AAtu8UgAygDAAHgKAJoAdwB3AHUAdQB2AHUAeAB1AHUAdgB1bvFIAMoAwAALCgCaAHcACwB3AAsCOwB3AAtu8UgAygDAAH4ACwGgALcBpwC6AahdAu0COwLtbvFIAMoAwAALCgCaAu0ACwLtAAsCOwLtAAtu8UgAygDAA24ACwNvAAu0VsQAAzsAABCkjUIpAAsAUIusOggWcgMeBxVsGwL67U/2HlzmWOEeOgALASvuAAseAfpKUpnpGgYJDCIZM6YyARUE9ThqAD5iXQgnAJYJPnOzw0ZAEZxEKsIAkA4DhAHnTAIDxxUDK0lxCQlPYgIvIQVYJQBVqE1GakUAKGYiDToSBA1EtAYAXQJYAIF8GgMHRyAAIAjOe9YncekRAA0KACUrjwE7Ayc6AAYWAqaiKG4McEcqANoN3+Mg9TwCBhIkuCny+JwUQ29L008JluRxu3K+oAdqiHOqFH0AG5SUIfUJ5SxCGfxdipRzqTmT4V5Zb+r1Uo4Vm+NqSSEl2mNvR2JhIa8SpYO6ntdwFXHCWTCK8f2+Hxo7uiG3drDycAuKIMP5bhi06ACnqArH1rz4Rqg//lm6SgJGEVbF9xJHISaR6HxqxSnkw6shDnelHKNEfGUXSJRJ1GcsmtJw25xrZMDK9gXSm1/YMkdX4/6NKYOdtk/NQ3/NnDASjTc3fPjIjW/5sVfVObX2oTDWkr1dF9f3kxBsD3/3aQO8hPfRz+e0uEiJqt1161griu7gz8hDDwtpy+F+BWtefnKHZPAxcZoWbnznhJpy0e842j36bcNzGnIEusgGX0a8ZxsnjcSsPDZ09yZ36fCQbriHeQ72JRMILNl6ePPf2HWoVwgWAm1fb3V2sAY0+B6rAXqSwPBgseVmoqsBTSrm91+XasMYYySI8eeRxH3ZvHkMz3BQ5aJ3iUVbYPNM3/7emRtjlsMgv/9VyTsyt/mK+8fgWeT6SoFaclXqn42dAIsvAarF5vNNWHzKSkKQ/8Hfk5ZWK7r9yliOsooyBjRhfkHP4Q2DkWXQi6FG/9r/IwbmkV5T7JSopHKn1pJwm9tb5Ot0oyN1Z2mPpKXHTxx2nlK08fKk1hEYA8WgVVWL5lgx0iTv+KdojJeU23ZDjmiubXOxVXJKKi2Wjuh2HLZOFLiSC7Tls5SMh4f+Pj6xUSrNjFqLGehRNB8lC0QSLNmkJJx/wSG3MnjE9T1CkPwJI0wH2lfzwETIiVqUxg0dfu5q39Gt+hwdcxkhhNvQ4TyrBceof3Mhs/IxFci1HmHr4FMZgXEEczPiGCx0HRwzAqDq2j9AVm1kwN0mRVLWLylgtoPNapF5cY4Y1wJh/e0BBwZj44YgZrDNqvD/9Hv7GFYdUQeDJuQ3EWI4HaKqavU1XjC/n41kT4L79kqGq0kLhdTZvgP3TA3fS0ozVz+5piZsoOtIvBUFoMKbNcmBL6YxxaUAusHB38XrS8dQMnQwJfUUkpRoGr5AUeWicvBTzyK9g77+yCkf5PAysL7r/JjcZgrbvRpMW9iyaxZvKO6ceZN2EwIxKwVFPuvFuiEPGCoagbMo+SpydLrXqBzNCDGFCrO/rkcwa2xhokQZ5CdZ0AsU3JfSqJ6n5I14YA+P/uAgfhPU84Tlw7cEFfp7AEE8ey4sP12PTt4Cods1GRgDOB5xvyiR5m+Bx8O5nBCNctU8BevfV5A08x6RHd5jcwPTMDSZJOedIZ1cGQ704lxbAzqZOP05ZxaOghzSdvFBHYqomATARyAADK4elP8Ly3IrUZKfWh23Xy20uBUmLS4Pfagu9+oyVa2iPgqRP3F2CTUsvJ7+RYnN8fFZbU/HVvxvcFFDKkiTqV5UBZ3Gz54JAKByi9hkKMZJvuGgcSYXFmw08UyoQyVdfTD1/dMkCHXcTGAKeROgArsvmRrQTLUOXioOHGK2QkjHuoYFgXciZoTJd6Fs5q1QX1G+p/e26hYsEf7QZD1nnIyl/SFkNtYYmmBhpBrxl9WbY0YpHWRuw2Ll/tj9mD8P4snVzJl4F9J+1arVeTb9E5r2ILH04qStjxQNwn3m4YNqxmaNbLAqW2TN6LidwuJRqS+NXbtqxoeDXpxeGWmxzSkWxjkyCkX4NQRme6q5SAcC+M7+9ETfA/EwrzQajKakCwYyeunP6ZFlxU2oMEn1Pz31zeStW74G406ZJFCl1wAXIoUKkWotYEpOuXB1uVNxJ63dpJEqfxBeptwIHNrPz8BllZoIcBoXwgfJ+8VAUnVPvRvexnw0Ma/WiGYuJO5y8QTvEYBigFmhUxY5RqzE8OcywN/8m4UYrlaniJO75XQ6KSo9+tWHlu+hMi0UVdiKQp7NelnoZUzNaIyBPVeOwK6GNp+FfHuPOoyhaWuNvTYFkvxscMQWDh+zeFCFkgwbXftiV23ywJ4+uwRqmg9k3KzwIQpzppt8DBBOMbrqwQM5Gb05sEwdKzMiAqOloaA/lr0KA+1pr0/+HiWoiIjHA/wir2nIuS3PeU/ji3O6ZwoxcR1SZ9FhtLC5S0FIzFhbBWcGVP/KpxOPSiUoAdWUpqKH++6Scz507iCcxYI6rdMBICPJZea7OcmeFw5mObJSiqpjg2UoWNIs+cFhyDSt6geV5qgi3FunmwwDoGSMgerFOZGX1m0dMCYo5XOruxO063dwENK9DbnVM9wYFREzh4vyU1WYYJ/LRRp6oxgjqP/X5a8/4Af6p6NWkQferzBmXme0zY/4nwMJm/wd1tIqSwGz+E3xPEAOoZlJit3XddD7/BT1pllzOx+8bmQtANQ/S6fZexc6qi3W+Q2xcmXTUhuS5mpHQRvcxZUN0S5+PL9lXWUAaRZhEH8hTdAcuNMMCuVNKTEGtSUKNi3O6KhSaTzck8csZ2vWRZ+d7mW8c4IKwXIYd25S/zIftPkwPzufjEvOHWVD1m+FjpDVUTV0DGDuHj6QnaEwLu/dEgdLQOg9E1Sro9XHJ8ykLAwtPu+pxqKDuFexqON1sKQm7rwbE1E68UCfA/erovrTCG+DBSNg0l4goDQvZN6uNlbyLpcZAwj2UclycvLpIZMgv4yRlpb3YuMftozorbcGVHt/VeDV3+Fdf1TP0iuaCsPi2G4XeGhsyF1ubVDxkoJhmniQ0/jSg/eYML9KLfnCFgISWkp91eauR3IQvED0nAPXK+6hPCYs+n3+hCZbiskmVMG2da+0EsZPonUeIY8EbfusQXjsK/eFDaosbPjEfQS0RKG7yj5GG69M7MeO1HmiUYocgygJHL6M1qzUDDwUSmr99V7Sdr2F3JjQAJY+F0yH33Iv3+C9M38eML7gTgmNu/r2bUMiPvpYbZ6v1/IaESirBHNa7mPKn4dEmYg7v/+HQgPN1G79jBQ1+soydfDC2r+h2Bl/KIc5KjMK7OH6nb1jLsNf0EHVe2KBiE51ox636uyG6Lho0t3J34L5QY/ilE3mikaF4HKXG1mG1rCevT1Vv6GavltxoQe/bMrpZvRggnBxSEPEeEzkEdOxTnPXHVjUYdw8JYvjB/o7Eegc3Ma+NUxLLnsK0kJlinPmUHzHGtrk5+CAbVzFOBqpyy3QVUnzTDfC/0XD94/okH+OB+i7g9lolhWIjSnfIb+Eq43ZXOWmwvjyV/qqD+t0e+7mTEM74qP/Ozt8nmC7mRpyu63OB4KnUzFc074SqoyPUAgM+/TJGFo6T44EHnQU4X4z6qannVqgw/U7zCpwcmXV1AubIrvOmkKHazJAR55ePjp5tLBsN8vAqs3NAHdcEHOR2xQ0lsNAFzSUuxFQCFYvXLZJdOj9p4fNq6p0HBGUik2YzaI4xySy91KzhQ0+q1hjxvImRwPRf76tChlRkhRCi74NXZ9qUNeIwP+s5p+3m5nwPdNOHgSLD79n7O9m1n1uDHiMntq4nkYwV5OZ1ENbXxFd4PgrlvavZsyUO4MqYlqqn1O8W/I1dEZq5dXhrbETLaZIbC2Kj/Aa/QM+fqUOHdf0tXAQ1huZ3cmWECWSXy/43j35+Mvq9xws7JKseriZ1pEWKc8qlzNrGPUGcVgOa9cPJYIJsGnJTAUsEcDOEVULO5x0rXBijc1lgXEzQQKhROf8zIV82w8eswc78YX11KYLWQRcgHNJElBxfXr72lS2RBSl07qTKorO2uUDZr3sFhYsvnhLZn0A94KRzJ/7DEGIAhW5ZWFpL8gEwu1aLA9MuWZzNwl8Oze9Y+bX+v9gywRVnoB5I/8kXTXU3141yRLYrIOOz6SOnyHNy4SieqzkBXharjfjqq1q6tklaEbA8Qfm2DaIPs7OTq/nvJBjKfO2H9bH2cCMh1+5gspfycu8f/cuuRmtDjyqZ7uCIMyjdV3a+p3fqmXsRx4C8lujezIFHnQiVTXLXuI1XrwN3+siYYj2HHTvESUx8DlOTXpak9qFRK+L3mgJ1WsD7F4cu1aJoFoYQnu+wGDMOjJM3kiBQWHCcvhJ/HRdxodOQp45YZaOTA22Nb4XKCVxqkbwMYFhzYQYIAnCW8FW14uf98jhUG2zrKhQQ0q0CEq0t5nXyvUyvR8DvD69LU+g3i+HFWQMQ8PqZuHD+sNKAV0+M6EJC0szq7rEr7B5bQ8BcNHzvDMc9eqB5ZCQdTf80Obn4uzjwpYU7SISdtV0QGa9D3Wrh2BDQtpBKxaNFV+/Cy2P/Sv+8s7Ud0Fd74X4+o/TNztWgETUapy+majNQ68Lq3ee0ZO48VEbTZYiH1Co4OlfWef82RWeyUXo7woM03PyapGfikTnQinoNq5z5veLpeMV3HCAMTaZmA1oGLAn7XS3XYsz+XK7VMQsc4XKrmDXOLU/pSXVNUq8dIqTba///3x6LiLS6xs1xuCAYSfcQ3+rQgmu7uvf3THKt5Ooo97TqcbRqxx7EASizaQCBQllG/rYxVapMLgtLbZS64w1MDBMXX+PQpBKNwqUKOf2DDRDUXQf9EhOS0Qj4nTmlA8dzSLz/G1d+Ud8MTy/6ghhdiLpeerGY/UlDOfiuqFsMUU5/UYlP+BAmgRLuNpvrUaLlVkrqDievNVEAwF+4CoM1MZTmjxjJMsKJq+u8Zd7tNCUFy6LiyYXRJQ4VyvEQFFaCGKsxIwQkk7EzZ6LTJq2hUuPhvAW+gQnSG6J+MszC+7QCRHcnqDdyNRJ6T9xyS87A6MDutbzKGvGktpbXqtzWtXb9HsfK2cBMomjN9a4y+TaJLnXxAeX/HWzmf4cR4vALt/P4w4qgKY04ml4ZdLOinFYS6cup3G/1ie4+t1eOnpBNlqGqs75ilzkT4+DsZQxNvaSKJ//6zIbbk/M7LOhFmRc/1R+kBtz7JFGdZm/COotIdvQoXpTqP/1uqEUmCb/QWoGLMwO5ANcHzxdY48IGP5+J+zKOTBFZ4Pid+GTM+Wq12MV/H86xEJptBa6T+p3kgpwLedManBHC2GgNrFpoN2xnrMz9WFWX/8/ygSBkavq2Uv7FdCsLEYLu9LLIvAU0bNRDtzYl+/vXmjpIvuJFYjmI0im6QEYqnIeMsNjXG4vIutIGHijeAG/9EDBozKV5cldkHbLxHh25vT+ZEzbhXlqvpzKJwcEgfNwLAKFeo0/pvEE10XDB+EXRTXtSzJozQKFFAJhMxYkVaCW+E9AL7tMeU8acxidHqzb6lX4691UsDpy/LLRmT+epgW56+5Cw8tB4kMUv6s9lh3eRKbyGs+H/4mQMaYzPTf2OOdokEn+zzgvoD3FqNKk8QqGAXVsqcGdXrT62fSPkR2vROFi68A6se86UxRUk4cajfPyCC4G5wDhD+zNq4jodQ4u4n/m37Lr36n4LIAAsVr02dFi9AiwA81MYs2rm4eDlDNmdMRvEKRHfBwW5DdMNp0jPFZMeARqF/wL4XBfd+EMLBfMzpH5GH6NaW+1vrvMdg+VxDzatk3MXgO3ro3P/DpcC6+Mo4MySJhKJhSR01SGGGp5hPWmrrUgrv3lDnP+HhcI3nt3YqBoVAVTBAQT5iuhTg8nvPtd8ZeYj6w1x6RqGUBrSku7+N1+BaasZvjTk64RoIDlL8brpEcJx3OmY7jLoZsswdtmhfC/G21llXhITOwmvRDDeTTPbyASOa16cF5/A1fZAidJpqju3wYAy9avPR1ya6eNp9K8XYrrtuxlqi+bDKwlfrYdR0RRiKRVTLOH85+ZY7XSmzRpfZBJjaTa81VDcJHpZnZnSQLASGYW9l51ZV/h7eVzTi3Hv6hUsgc/51AqJRTkpbFVLXXszoBL8nBX0u/0jBLT8nH+fJePbrwURT58OY+UieRjd1vs04w0VG5VN2U6MoGZkQzKN/ptz0Q366dxoTGmj7i1NQGHi9GgnquXFYdrCfZBmeb7s0T6yrdlZH5cZuwHFyIJ/kAtGsTg0xH5taAAq44BAk1CPk9KVVbqQzrCUiFdF/6gtlPQ8bHHc1G1W92MXGZ5HEHftyLYs8mbD/9xYRUWkHmlM0zC2ilJlnNgV4bfALpQghxOUoZL7VTqtCHIaQSXm+YUMnpkXybnV+A6xlm2CVy8fn0Xlm2XRa0+zzOa21JWWmixfiPMSCZ7qA4rS93VN3pkpF1s5TonQjisHf7iU9ZGvUPOAKZcR1pbeVf/Ul7OhepGCaId9wOtqo7pJ7yLcBZ0pFkOF28y4zEI/kcUNmutBHaQpBdNM8vjCS6HZRokkeo88TBAjGyG7SR+6vUgTcyK9Imalj0kuxz0wmK+byQU11AiJFk/ya5dNduRClcnU64yGu/ieWSeOos1t3ep+RPIWQ2pyTYVbZltTbsb7NiwSi3AV+8KLWk7LxCnfZUetEM8ThnsSoGH38/nyAwFguJp8FjvlHtcWZuU4hPva0rHfr0UhOOJ/F6vS62FW7KzkmRll2HEc7oUq4fyi5T70Vl7YVIfsPHUCdHesf9Lk7WNVWO75JDkYbMI8TOW8JKVtLY9d6UJRITO8oKo0xS+o99Yy04iniGHAaGj88kEWgwv0OrHdY/nr76DOGNS59hXCGXzTKUvDl9iKpLSWYN1lxIeyywdNpTkhay74w2jFT6NS8qkjo5CxA1yfSYwp6AJIZNKIeEK5PJAW7ORgWgwp0VgzYpqovMrWxbu+DGZ6Lhie1RAqpzm8VUzKJOH3mCzWuTOLsN3VT/dv2eeYe9UjbR8YTBsLz7q60VN1sU51k+um1f8JxD5pPhbhSC8rRaB454tmh6YUWrJI3+GWY0qeWioj/tbkYITOkJaeuGt4JrJvHA+l0Gu7kY7XOaa05alMnRWVCXqFgLIwSY4uF59Ue5SU4QKuc/HamDxbr0x6csCetXGoP7Qn1Bk/J9DsynO/UD6iZ1Hyrz+jit0hDCwi/E9OjgKTbB3ZQKQ/0ZOvevfNHG0NK4Aj3Cp7NpRk07RT1i/S0EL93Ag8GRgKI9CfpajKyK6+Jj/PI1KO5/85VAwz2AwzP8FTBb075IxCXv6T9RVvWT2tUaqxDS92zrGUbWzUYk9mSs82pECH+fkqsDt93VW++4YsR/dHCYcQSYTO/KaBMDj9LSD/J/+z20Kq8XvZUAIHtm9hRPP3ItbuAu2Hm5lkPs92pd7kCxgRs0xOVBnZ13ccdA0aunrwv9SdqElJRC3g+oCu+nXyCgmXUs9yMjTMAIHfxZV+aPKcZeUBWt057Xo85Ks1Ir5gzEHCWqZEhrLZMuF11ziGtFQUds/EESajhagzcKsxamcSZxGth4UII+adPhQkUnx2WyN+4YWR+r3f8MnkyGFuR4zjzxJS8WsQYR5PTyRaD9ixa6Mh741nBHbzfjXHskGDq179xaRNrCIB1z1xRfWfjqw2pHc1zk9xlPpL8sQWAIuETZZhbnmL54rceXVNRvUiKrrqIkeogsl0XXb17ylNb0f4GA9Wd44vffEG8FSZGHEL2fbaTGRcSiCeA8PmA/f6Hz8HCS76fXUHwgwkzSwlI71ekZ7Fapmlk/KC+Hs8hUcw3N2LN5LhkVYyizYFl/uPeVP5lsoJHhhfWvvSWruCUW1ZcJOeuTbrDgywJ/qG07gZJplnTvLcYdNaH0KMYOYMGX+rB4NGPFmQsNaIwlWrfCezxre8zXBrsMT+edVLbLqN1BqB76JH4BvZTqUIMfGwPGEn+EnmTV86fPBaYbFL3DFEhjB45CewkXEAtJxk4/Ms2pPXnaRqdky0HOYdcUcE2zcXq4vaIvW2/v0nHFJH2XXe22ueDmq/18XGtELSq85j9X8q0tcNSSKJIX8FTuJF/Pf8j5PhqG2u+osvsLxYrvvfeVJL+4tkcXcr9JV7v0ERmj/X6fM3NC4j6dS1+9Umr2oPavqiAydTZPLMNRGY23LO9zAVDly7jD+70G5TPPLdhRIl4WxcYjLnM+SNcJ26FOrkrISUtPObIz5Zb3AG612krnpy15RMW+1cQjlnWFI6538qky9axd2oJmHIHP08KyP0ubGO+TQNOYuv2uh17yCIvR8VcStw7o1g0NM60sk+8Tq7YfIBJrtp53GkvzXH7OA0p8/n/u1satf/VJhtR1l8Wa6Gmaug7haSpaCaYQax6ta0mkutlb+eAOSG1aobM81D9A4iS1RRlzBBoVX6tU1S6WE2N9ORY6DfeLRC4l9Rvr5h95XDWB2mR1d4WFudpsgVYwiTwT31ljskD8ZyDOlm5DkGh9N/UB/0AI5Xvb8ZBmai2hQ4BWMqFwYnzxwB26YHSOv9WgY3JXnvoN+2R4rqGVh/LLDMtpFP+SpMGJNWvbIl5SOodbCczW2RKleksPoUeGEzrjtKHVdtZA+kfqO+rVx/iclCqwoopepvJpSTDjT+b9GWylGRF8EDbGlw6eUzmJM95Ovoz+kwLX3c2fTjFeYEsE7vUZm3mqdGJuKh2w9/QGSaqRHs99aScGOdDqkFcACoqdbBoQqqjamhH6Q9ng39JCg3lrGJwd50Qk9ovnqBTr8MME7Ps2wiVfygUmPoUBJJfJWX5Nda0nuncbFkA=="))
}
const Xa = E_();
new Set(Ac(Xa)), new Set(Ac(Xa)), y_(Xa), A_(Xa);
const I_ = new Uint8Array(32);
I_.fill(0);
const S_ = `Ethereum Signed Message:
`;

function j0(r) {
    return typeof r == "string" && (r = Zh(r)), Hu(X3([Zh(S_), Zh(String(r.length)), r]))
}
const x_ = "address/5.7.0",
    xo = new dr(x_);

function Jd(r) {
    Yr(r, 20) || xo.throwArgumentError("invalid address", "address", r), r = r.toLowerCase();
    const t = r.substring(2).split(""),
        e = new Uint8Array(40);
    for (let o = 0; o < 40; o++) e[o] = t[o].charCodeAt(0);
    const n = Ve(Hu(e));
    for (let o = 0; o < 40; o += 2) n[o >> 1] >> 4 >= 8 && (t[o] = t[o].toUpperCase()), (n[o >> 1] & 15) >= 8 && (t[o + 1] = t[o + 1].toUpperCase());
    return "0x" + t.join("")
}
const P_ = 9007199254740991;

function M_(r) {
    return Math.log10 ? Math.log10(r) : Math.log(r) / Math.LN10
}
const Vu = {};
for (let r = 0; r < 10; r++) Vu[String(r)] = String(r);
for (let r = 0; r < 26; r++) Vu[String.fromCharCode(65 + r)] = String(10 + r);
const Yd = Math.floor(M_(P_));

function C_(r) {
    r = r.toUpperCase(), r = r.substring(4) + r.substring(0, 2) + "00";
    let t = r.split("").map(n => Vu[n]).join("");
    for (; t.length >= Yd;) {
        let n = t.substring(0, Yd);
        t = parseInt(n, 10) % 97 + t.substring(n.length)
    }
    let e = String(98 - parseInt(t, 10) % 97);
    for (; e.length < 2;) e = "0" + e;
    return e
}

function N_(r) {
    let t = null;
    if (typeof r != "string" && xo.throwArgumentError("invalid address", "address", r), r.match(/^(0x)?[0-9a-fA-F]{40}$/)) r.substring(0, 2) !== "0x" && (r = "0x" + r), t = Jd(r), r.match(/([A-F].*[a-f])|([a-f].*[A-F])/) && t !== r && xo.throwArgumentError("bad address checksum", "address", r);
    else if (r.match(/^XE[0-9]{2}[0-9A-Za-z]{30,31}$/)) {
        for (r.substring(2, 4) !== C_(r) && xo.throwArgumentError("bad icap checksum", "address", r), t = s_(r.substring(4)); t.length < 40;) t = "0" + t;
        t = Jd("0x" + t)
    } else xo.throwArgumentError("invalid address", "address", r);
    return t
}

function wo(r, t, e) {
    Object.defineProperty(r, t, {
        enumerable: !0,
        value: e,
        writable: !1
    })
}
const R_ = new Uint8Array(32);
R_.fill(0), Mr.from(-1);
const O_ = Mr.from(0),
    T_ = Mr.from(1);
Mr.from("0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"), Ji(T_.toHexString(), 32), Ji(O_.toHexString(), 32);
var Ki = {},
    de = {},
    Ho = z0;

function z0(r, t) {
    if (!r) throw new Error(t || "Assertion failed")
}
z0.equal = function(r, t, e) {
    if (r != t) throw new Error(e || "Assertion failed: " + r + " != " + t)
};
var Su = {
    exports: {}
};
typeof Object.create == "function" ? Su.exports = function(r, t) {
    t && (r.super_ = t, r.prototype = Object.create(t.prototype, {
        constructor: {
            value: r,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }))
} : Su.exports = function(r, t) {
    if (t) {
        r.super_ = t;
        var e = function() {};
        e.prototype = t.prototype, r.prototype = new e, r.prototype.constructor = r
    }
};
var D_ = Ho,
    q_ = Su.exports;
de.inherits = q_;

function B_(r, t) {
    return (r.charCodeAt(t) & 64512) !== 55296 || t < 0 || t + 1 >= r.length ? !1 : (r.charCodeAt(t + 1) & 64512) === 56320
}

function U_(r, t) {
    if (Array.isArray(r)) return r.slice();
    if (!r) return [];
    var e = [];
    if (typeof r == "string")
        if (t) {
            if (t === "hex")
                for (r = r.replace(/[^a-z0-9]+/ig, ""), r.length % 2 !== 0 && (r = "0" + r), o = 0; o < r.length; o += 2) e.push(parseInt(r[o] + r[o + 1], 16))
        } else
            for (var n = 0, o = 0; o < r.length; o++) {
                var a = r.charCodeAt(o);
                a < 128 ? e[n++] = a : a < 2048 ? (e[n++] = a >> 6 | 192, e[n++] = a & 63 | 128) : B_(r, o) ? (a = 65536 + ((a & 1023) << 10) + (r.charCodeAt(++o) & 1023), e[n++] = a >> 18 | 240, e[n++] = a >> 12 & 63 | 128, e[n++] = a >> 6 & 63 | 128, e[n++] = a & 63 | 128) : (e[n++] = a >> 12 | 224, e[n++] = a >> 6 & 63 | 128, e[n++] = a & 63 | 128)
            } else
                for (o = 0; o < r.length; o++) e[o] = r[o] | 0;
    return e
}
de.toArray = U_;

function k_(r) {
    for (var t = "", e = 0; e < r.length; e++) t += H0(r[e].toString(16));
    return t
}
de.toHex = k_;

function F0(r) {
    var t = r >>> 24 | r >>> 8 & 65280 | r << 8 & 16711680 | (r & 255) << 24;
    return t >>> 0
}
de.htonl = F0;

function L_(r, t) {
    for (var e = "", n = 0; n < r.length; n++) {
        var o = r[n];
        t === "little" && (o = F0(o)), e += K0(o.toString(16))
    }
    return e
}
de.toHex32 = L_;

function H0(r) {
    return r.length === 1 ? "0" + r : r
}
de.zero2 = H0;

function K0(r) {
    return r.length === 7 ? "0" + r : r.length === 6 ? "00" + r : r.length === 5 ? "000" + r : r.length === 4 ? "0000" + r : r.length === 3 ? "00000" + r : r.length === 2 ? "000000" + r : r.length === 1 ? "0000000" + r : r
}
de.zero8 = K0;

function $_(r, t, e, n) {
    var o = e - t;
    D_(o % 4 === 0);
    for (var a = new Array(o / 4), h = 0, g = t; h < a.length; h++, g += 4) {
        var b;
        n === "big" ? b = r[g] << 24 | r[g + 1] << 16 | r[g + 2] << 8 | r[g + 3] : b = r[g + 3] << 24 | r[g + 2] << 16 | r[g + 1] << 8 | r[g], a[h] = b >>> 0
    }
    return a
}
de.join32 = $_;

function j_(r, t) {
    for (var e = new Array(r.length * 4), n = 0, o = 0; n < r.length; n++, o += 4) {
        var a = r[n];
        t === "big" ? (e[o] = a >>> 24, e[o + 1] = a >>> 16 & 255, e[o + 2] = a >>> 8 & 255, e[o + 3] = a & 255) : (e[o + 3] = a >>> 24, e[o + 2] = a >>> 16 & 255, e[o + 1] = a >>> 8 & 255, e[o] = a & 255)
    }
    return e
}
de.split32 = j_;

function z_(r, t) {
    return r >>> t | r << 32 - t
}
de.rotr32 = z_;

function F_(r, t) {
    return r << t | r >>> 32 - t
}
de.rotl32 = F_;

function H_(r, t) {
    return r + t >>> 0
}
de.sum32 = H_;

function K_(r, t, e) {
    return r + t + e >>> 0
}
de.sum32_3 = K_;

function V_(r, t, e, n) {
    return r + t + e + n >>> 0
}
de.sum32_4 = V_;

function G_(r, t, e, n, o) {
    return r + t + e + n + o >>> 0
}
de.sum32_5 = G_;

function Q_(r, t, e, n) {
    var o = r[t],
        a = r[t + 1],
        h = n + a >>> 0,
        g = (h < n ? 1 : 0) + e + o;
    r[t] = g >>> 0, r[t + 1] = h
}
de.sum64 = Q_;

function W_(r, t, e, n) {
    var o = t + n >>> 0,
        a = (o < t ? 1 : 0) + r + e;
    return a >>> 0
}
de.sum64_hi = W_;

function J_(r, t, e, n) {
    var o = t + n;
    return o >>> 0
}
de.sum64_lo = J_;

function Y_(r, t, e, n, o, a, h, g) {
    var b = 0,
        m = t;
    m = m + n >>> 0, b += m < t ? 1 : 0, m = m + a >>> 0, b += m < a ? 1 : 0, m = m + g >>> 0, b += m < g ? 1 : 0;
    var _ = r + e + o + h + b;
    return _ >>> 0
}
de.sum64_4_hi = Y_;

function X_(r, t, e, n, o, a, h, g) {
    var b = t + n + a + g;
    return b >>> 0
}
de.sum64_4_lo = X_;

function Z_(r, t, e, n, o, a, h, g, b, m) {
    var _ = 0,
        S = t;
    S = S + n >>> 0, _ += S < t ? 1 : 0, S = S + a >>> 0, _ += S < a ? 1 : 0, S = S + g >>> 0, _ += S < g ? 1 : 0, S = S + m >>> 0, _ += S < m ? 1 : 0;
    var B = r + e + o + h + b + _;
    return B >>> 0
}
de.sum64_5_hi = Z_;

function tA(r, t, e, n, o, a, h, g, b, m) {
    var _ = t + n + a + g + m;
    return _ >>> 0
}
de.sum64_5_lo = tA;

function eA(r, t, e) {
    var n = t << 32 - e | r >>> e;
    return n >>> 0
}
de.rotr64_hi = eA;

function rA(r, t, e) {
    var n = r << 32 - e | t >>> e;
    return n >>> 0
}
de.rotr64_lo = rA;

function iA(r, t, e) {
    return r >>> e
}
de.shr64_hi = iA;

function nA(r, t, e) {
    var n = r << 32 - e | t >>> e;
    return n >>> 0
}
de.shr64_lo = nA;
var Qs = {},
    Xd = de,
    sA = Ho;

function Za() {
    this.pending = null, this.pendingTotal = 0, this.blockSize = this.constructor.blockSize, this.outSize = this.constructor.outSize, this.hmacStrength = this.constructor.hmacStrength, this.padLength = this.constructor.padLength / 8, this.endian = "big", this._delta8 = this.blockSize / 8, this._delta32 = this.blockSize / 32
}
Qs.BlockHash = Za, Za.prototype.update = function(r, t) {
    if (r = Xd.toArray(r, t), this.pending ? this.pending = this.pending.concat(r) : this.pending = r, this.pendingTotal += r.length, this.pending.length >= this._delta8) {
        r = this.pending;
        var e = r.length % this._delta8;
        this.pending = r.slice(r.length - e, r.length), this.pending.length === 0 && (this.pending = null), r = Xd.join32(r, 0, r.length - e, this.endian);
        for (var n = 0; n < r.length; n += this._delta32) this._update(r, n, n + this._delta32)
    }
    return this
}, Za.prototype.digest = function(r) {
    return this.update(this._pad()), sA(this.pending === null), this._digest(r)
}, Za.prototype._pad = function() {
    var r = this.pendingTotal,
        t = this._delta8,
        e = t - (r + this.padLength) % t,
        n = new Array(e + this.padLength);
    n[0] = 128;
    for (var o = 1; o < e; o++) n[o] = 0;
    if (r <<= 3, this.endian === "big") {
        for (var a = 8; a < this.padLength; a++) n[o++] = 0;
        n[o++] = 0, n[o++] = 0, n[o++] = 0, n[o++] = 0, n[o++] = r >>> 24 & 255, n[o++] = r >>> 16 & 255, n[o++] = r >>> 8 & 255, n[o++] = r & 255
    } else
        for (n[o++] = r & 255, n[o++] = r >>> 8 & 255, n[o++] = r >>> 16 & 255, n[o++] = r >>> 24 & 255, n[o++] = 0, n[o++] = 0, n[o++] = 0, n[o++] = 0, a = 8; a < this.padLength; a++) n[o++] = 0;
    return n
};
var qs = {},
    rn = {},
    oA = de,
    Yi = oA.rotr32;

function aA(r, t, e, n) {
    if (r === 0) return V0(t, e, n);
    if (r === 1 || r === 3) return Q0(t, e, n);
    if (r === 2) return G0(t, e, n)
}
rn.ft_1 = aA;

function V0(r, t, e) {
    return r & t ^ ~r & e
}
rn.ch32 = V0;

function G0(r, t, e) {
    return r & t ^ r & e ^ t & e
}
rn.maj32 = G0;

function Q0(r, t, e) {
    return r ^ t ^ e
}
rn.p32 = Q0;

function cA(r) {
    return Yi(r, 2) ^ Yi(r, 13) ^ Yi(r, 22)
}
rn.s0_256 = cA;

function hA(r) {
    return Yi(r, 6) ^ Yi(r, 11) ^ Yi(r, 25)
}
rn.s1_256 = hA;

function uA(r) {
    return Yi(r, 7) ^ Yi(r, 18) ^ r >>> 3
}
rn.g0_256 = uA;

function lA(r) {
    return Yi(r, 17) ^ Yi(r, 19) ^ r >>> 10
}
rn.g1_256 = lA;
var Fs = de,
    fA = Qs,
    dA = rn,
    eu = Fs.rotl32,
    bo = Fs.sum32,
    pA = Fs.sum32_5,
    gA = dA.ft_1,
    W0 = fA.BlockHash,
    mA = [1518500249, 1859775393, 2400959708, 3395469782];

function Qi() {
    if (!(this instanceof Qi)) return new Qi;
    W0.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.W = new Array(80)
}
Fs.inherits(Qi, W0);
var vA = Qi;
Qi.blockSize = 512, Qi.outSize = 160, Qi.hmacStrength = 80, Qi.padLength = 64, Qi.prototype._update = function(r, t) {
    for (var e = this.W, n = 0; n < 16; n++) e[n] = r[t + n];
    for (; n < e.length; n++) e[n] = eu(e[n - 3] ^ e[n - 8] ^ e[n - 14] ^ e[n - 16], 1);
    var o = this.h[0],
        a = this.h[1],
        h = this.h[2],
        g = this.h[3],
        b = this.h[4];
    for (n = 0; n < e.length; n++) {
        var m = ~~(n / 20),
            _ = pA(eu(o, 5), gA(m, a, h, g), b, e[n], mA[m]);
        b = g, g = h, h = eu(a, 30), a = o, o = _
    }
    this.h[0] = bo(this.h[0], o), this.h[1] = bo(this.h[1], a), this.h[2] = bo(this.h[2], h), this.h[3] = bo(this.h[3], g), this.h[4] = bo(this.h[4], b)
}, Qi.prototype._digest = function(r) {
    return r === "hex" ? Fs.toHex32(this.h, "big") : Fs.split32(this.h, "big")
};
var Hs = de,
    yA = Qs,
    Ws = rn,
    wA = Ho,
    xi = Hs.sum32,
    bA = Hs.sum32_4,
    _A = Hs.sum32_5,
    AA = Ws.ch32,
    EA = Ws.maj32,
    IA = Ws.s0_256,
    SA = Ws.s1_256,
    xA = Ws.g0_256,
    PA = Ws.g1_256,
    J0 = yA.BlockHash,
    MA = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];

function Wi() {
    if (!(this instanceof Wi)) return new Wi;
    J0.call(this), this.h = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225], this.k = MA, this.W = new Array(64)
}
Hs.inherits(Wi, J0);
var Y0 = Wi;
Wi.blockSize = 512, Wi.outSize = 256, Wi.hmacStrength = 192, Wi.padLength = 64, Wi.prototype._update = function(r, t) {
    for (var e = this.W, n = 0; n < 16; n++) e[n] = r[t + n];
    for (; n < e.length; n++) e[n] = bA(PA(e[n - 2]), e[n - 7], xA(e[n - 15]), e[n - 16]);
    var o = this.h[0],
        a = this.h[1],
        h = this.h[2],
        g = this.h[3],
        b = this.h[4],
        m = this.h[5],
        _ = this.h[6],
        S = this.h[7];
    for (wA(this.k.length === e.length), n = 0; n < e.length; n++) {
        var B = _A(S, SA(b), AA(b, m, _), this.k[n], e[n]),
            k = xi(IA(o), EA(o, a, h));
        S = _, _ = m, m = b, b = xi(g, B), g = h, h = a, a = o, o = xi(B, k)
    }
    this.h[0] = xi(this.h[0], o), this.h[1] = xi(this.h[1], a), this.h[2] = xi(this.h[2], h), this.h[3] = xi(this.h[3], g), this.h[4] = xi(this.h[4], b), this.h[5] = xi(this.h[5], m), this.h[6] = xi(this.h[6], _), this.h[7] = xi(this.h[7], S)
}, Wi.prototype._digest = function(r) {
    return r === "hex" ? Hs.toHex32(this.h, "big") : Hs.split32(this.h, "big")
};
var xu = de,
    X0 = Y0;

function mn() {
    if (!(this instanceof mn)) return new mn;
    X0.call(this), this.h = [3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428]
}
xu.inherits(mn, X0);
var CA = mn;
mn.blockSize = 512, mn.outSize = 224, mn.hmacStrength = 192, mn.padLength = 64, mn.prototype._digest = function(r) {
    return r === "hex" ? xu.toHex32(this.h.slice(0, 7), "big") : xu.split32(this.h.slice(0, 7), "big")
};
var jr = de,
    NA = Qs,
    RA = Ho,
    Xi = jr.rotr64_hi,
    Zi = jr.rotr64_lo,
    Z0 = jr.shr64_hi,
    tg = jr.shr64_lo,
    On = jr.sum64,
    ru = jr.sum64_hi,
    iu = jr.sum64_lo,
    OA = jr.sum64_4_hi,
    TA = jr.sum64_4_lo,
    DA = jr.sum64_5_hi,
    qA = jr.sum64_5_lo,
    eg = NA.BlockHash,
    BA = [1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591];

function Ni() {
    if (!(this instanceof Ni)) return new Ni;
    eg.call(this), this.h = [1779033703, 4089235720, 3144134277, 2227873595, 1013904242, 4271175723, 2773480762, 1595750129, 1359893119, 2917565137, 2600822924, 725511199, 528734635, 4215389547, 1541459225, 327033209], this.k = BA, this.W = new Array(160)
}
jr.inherits(Ni, eg);
var rg = Ni;
Ni.blockSize = 1024, Ni.outSize = 512, Ni.hmacStrength = 192, Ni.padLength = 128, Ni.prototype._prepareBlock = function(r, t) {
    for (var e = this.W, n = 0; n < 32; n++) e[n] = r[t + n];
    for (; n < e.length; n += 2) {
        var o = GA(e[n - 4], e[n - 3]),
            a = QA(e[n - 4], e[n - 3]),
            h = e[n - 14],
            g = e[n - 13],
            b = KA(e[n - 30], e[n - 29]),
            m = VA(e[n - 30], e[n - 29]),
            _ = e[n - 32],
            S = e[n - 31];
        e[n] = OA(o, a, h, g, b, m, _, S), e[n + 1] = TA(o, a, h, g, b, m, _, S)
    }
}, Ni.prototype._update = function(r, t) {
    this._prepareBlock(r, t);
    var e = this.W,
        n = this.h[0],
        o = this.h[1],
        a = this.h[2],
        h = this.h[3],
        g = this.h[4],
        b = this.h[5],
        m = this.h[6],
        _ = this.h[7],
        S = this.h[8],
        B = this.h[9],
        k = this.h[10],
        L = this.h[11],
        K = this.h[12],
        Q = this.h[13],
        et = this.h[14],
        at = this.h[15];
    RA(this.k.length === e.length);
    for (var ut = 0; ut < e.length; ut += 2) {
        var ft = et,
            st = at,
            ot = FA(S, B),
            it = HA(S, B),
            mt = UA(S, B, k, L, K),
            Zt = kA(S, B, k, L, K, Q),
            oe = this.k[ut],
            Tt = this.k[ut + 1],
            ve = e[ut],
            u = e[ut + 1],
            p = DA(ft, st, ot, it, mt, Zt, oe, Tt, ve, u),
            v = qA(ft, st, ot, it, mt, Zt, oe, Tt, ve, u);
        ft = jA(n, o), st = zA(n, o), ot = LA(n, o, a, h, g), it = $A(n, o, a, h, g, b);
        var P = ru(ft, st, ot, it),
            C = iu(ft, st, ot, it);
        et = K, at = Q, K = k, Q = L, k = S, L = B, S = ru(m, _, p, v), B = iu(_, _, p, v), m = g, _ = b, g = a, b = h, a = n, h = o, n = ru(p, v, P, C), o = iu(p, v, P, C)
    }
    On(this.h, 0, n, o), On(this.h, 2, a, h), On(this.h, 4, g, b), On(this.h, 6, m, _), On(this.h, 8, S, B), On(this.h, 10, k, L), On(this.h, 12, K, Q), On(this.h, 14, et, at)
}, Ni.prototype._digest = function(r) {
    return r === "hex" ? jr.toHex32(this.h, "big") : jr.split32(this.h, "big")
};

function UA(r, t, e, n, o) {
    var a = r & e ^ ~r & o;
    return a < 0 && (a += 4294967296), a
}

function kA(r, t, e, n, o, a) {
    var h = t & n ^ ~t & a;
    return h < 0 && (h += 4294967296), h
}

function LA(r, t, e, n, o) {
    var a = r & e ^ r & o ^ e & o;
    return a < 0 && (a += 4294967296), a
}

function $A(r, t, e, n, o, a) {
    var h = t & n ^ t & a ^ n & a;
    return h < 0 && (h += 4294967296), h
}

function jA(r, t) {
    var e = Xi(r, t, 28),
        n = Xi(t, r, 2),
        o = Xi(t, r, 7),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function zA(r, t) {
    var e = Zi(r, t, 28),
        n = Zi(t, r, 2),
        o = Zi(t, r, 7),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function FA(r, t) {
    var e = Xi(r, t, 14),
        n = Xi(r, t, 18),
        o = Xi(t, r, 9),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function HA(r, t) {
    var e = Zi(r, t, 14),
        n = Zi(r, t, 18),
        o = Zi(t, r, 9),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function KA(r, t) {
    var e = Xi(r, t, 1),
        n = Xi(r, t, 8),
        o = Z0(r, t, 7),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function VA(r, t) {
    var e = Zi(r, t, 1),
        n = Zi(r, t, 8),
        o = tg(r, t, 7),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function GA(r, t) {
    var e = Xi(r, t, 19),
        n = Xi(t, r, 29),
        o = Z0(r, t, 6),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}

function QA(r, t) {
    var e = Zi(r, t, 19),
        n = Zi(t, r, 29),
        o = tg(r, t, 6),
        a = e ^ n ^ o;
    return a < 0 && (a += 4294967296), a
}
var Pu = de,
    ig = rg;

function vn() {
    if (!(this instanceof vn)) return new vn;
    ig.call(this), this.h = [3418070365, 3238371032, 1654270250, 914150663, 2438529370, 812702999, 355462360, 4144912697, 1731405415, 4290775857, 2394180231, 1750603025, 3675008525, 1694076839, 1203062813, 3204075428]
}
Pu.inherits(vn, ig);
var WA = vn;
vn.blockSize = 1024, vn.outSize = 384, vn.hmacStrength = 192, vn.padLength = 128, vn.prototype._digest = function(r) {
    return r === "hex" ? Pu.toHex32(this.h.slice(0, 12), "big") : Pu.split32(this.h.slice(0, 12), "big")
}, qs.sha1 = vA, qs.sha224 = CA, qs.sha256 = Y0, qs.sha384 = WA, qs.sha512 = rg;
var ng = {},
    us = de,
    JA = Qs,
    tc = us.rotl32,
    Zd = us.sum32,
    _o = us.sum32_3,
    tp = us.sum32_4,
    sg = JA.BlockHash;

function Vi() {
    if (!(this instanceof Vi)) return new Vi;
    sg.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.endian = "little"
}
us.inherits(Vi, sg), ng.ripemd160 = Vi, Vi.blockSize = 512, Vi.outSize = 160, Vi.hmacStrength = 192, Vi.padLength = 64, Vi.prototype._update = function(r, t) {
    for (var e = this.h[0], n = this.h[1], o = this.h[2], a = this.h[3], h = this.h[4], g = e, b = n, m = o, _ = a, S = h, B = 0; B < 80; B++) {
        var k = Zd(tc(tp(e, ep(B, n, o, a), r[ZA[B] + t], YA(B)), eE[B]), h);
        e = h, h = a, a = tc(o, 10), o = n, n = k, k = Zd(tc(tp(g, ep(79 - B, b, m, _), r[tE[B] + t], XA(B)), rE[B]), S), g = S, S = _, _ = tc(m, 10), m = b, b = k
    }
    k = _o(this.h[1], o, _), this.h[1] = _o(this.h[2], a, S), this.h[2] = _o(this.h[3], h, g), this.h[3] = _o(this.h[4], e, b), this.h[4] = _o(this.h[0], n, m), this.h[0] = k
}, Vi.prototype._digest = function(r) {
    return r === "hex" ? us.toHex32(this.h, "little") : us.split32(this.h, "little")
};

function ep(r, t, e, n) {
    return r <= 15 ? t ^ e ^ n : r <= 31 ? t & e | ~t & n : r <= 47 ? (t | ~e) ^ n : r <= 63 ? t & n | e & ~n : t ^ (e | ~n)
}

function YA(r) {
    return r <= 15 ? 0 : r <= 31 ? 1518500249 : r <= 47 ? 1859775393 : r <= 63 ? 2400959708 : 2840853838
}

function XA(r) {
    return r <= 15 ? 1352829926 : r <= 31 ? 1548603684 : r <= 47 ? 1836072691 : r <= 63 ? 2053994217 : 0
}
var ZA = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13],
    tE = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11],
    eE = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6],
    rE = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11],
    iE = de,
    nE = Ho;

function zs(r, t, e) {
    if (!(this instanceof zs)) return new zs(r, t, e);
    this.Hash = r, this.blockSize = r.blockSize / 8, this.outSize = r.outSize / 8, this.inner = null, this.outer = null, this._init(iE.toArray(t, e))
}
var sE = zs;
zs.prototype._init = function(r) {
        r.length > this.blockSize && (r = new this.Hash().update(r).digest()), nE(r.length <= this.blockSize);
        for (var t = r.length; t < this.blockSize; t++) r.push(0);
        for (t = 0; t < r.length; t++) r[t] ^= 54;
        for (this.inner = new this.Hash().update(r), t = 0; t < r.length; t++) r[t] ^= 106;
        this.outer = new this.Hash().update(r)
    }, zs.prototype.update = function(r, t) {
        return this.inner.update(r, t), this
    }, zs.prototype.digest = function(r) {
        return this.outer.update(this.inner.digest()), this.outer.digest(r)
    },
    function(r) {
        var t = r;
        t.utils = de, t.common = Qs, t.sha = qs, t.ripemd = ng, t.hmac = sE, t.sha1 = t.sha.sha1, t.sha256 = t.sha.sha256, t.sha224 = t.sha.sha224, t.sha384 = t.sha.sha384, t.sha512 = t.sha.sha512, t.ripemd160 = t.ripemd.ripemd160
    }(Ki);

function Js(r, t, e) {
    return e = {
        path: t,
        exports: {},
        require: function(n, o) {
            return oE(n, o ? ? e.path)
        }
    }, r(e, e.exports), e.exports
}

function oE() {
    throw new Error("Dynamic requires are not currently supported by @rollup/plugin-commonjs")
}
var Gu = og;

function og(r, t) {
    if (!r) throw new Error(t || "Assertion failed")
}
og.equal = function(r, t, e) {
    if (r != t) throw new Error(e || "Assertion failed: " + r + " != " + t)
};
var Ri = Js(function(r, t) {
        var e = t;

        function n(h, g) {
            if (Array.isArray(h)) return h.slice();
            if (!h) return [];
            var b = [];
            if (typeof h != "string") {
                for (var m = 0; m < h.length; m++) b[m] = h[m] | 0;
                return b
            }
            if (g === "hex") {
                h = h.replace(/[^a-z0-9]+/ig, ""), h.length % 2 !== 0 && (h = "0" + h);
                for (var m = 0; m < h.length; m += 2) b.push(parseInt(h[m] + h[m + 1], 16))
            } else
                for (var m = 0; m < h.length; m++) {
                    var _ = h.charCodeAt(m),
                        S = _ >> 8,
                        B = _ & 255;
                    S ? b.push(S, B) : b.push(B)
                }
            return b
        }
        e.toArray = n;

        function o(h) {
            return h.length === 1 ? "0" + h : h
        }
        e.zero2 = o;

        function a(h) {
            for (var g = "", b = 0; b < h.length; b++) g += o(h[b].toString(16));
            return g
        }
        e.toHex = a, e.encode = function(h, g) {
            return g === "hex" ? a(h) : h
        }
    }),
    Xr = Js(function(r, t) {
        var e = t;
        e.assert = Gu, e.toArray = Ri.toArray, e.zero2 = Ri.zero2, e.toHex = Ri.toHex, e.encode = Ri.encode;

        function n(b, m, _) {
            var S = new Array(Math.max(b.bitLength(), _) + 1);
            S.fill(0);
            for (var B = 1 << m + 1, k = b.clone(), L = 0; L < S.length; L++) {
                var K, Q = k.andln(B - 1);
                k.isOdd() ? (Q > (B >> 1) - 1 ? K = (B >> 1) - Q : K = Q, k.isubn(K)) : K = 0, S[L] = K, k.iushrn(1)
            }
            return S
        }
        e.getNAF = n;

        function o(b, m) {
            var _ = [
                [],
                []
            ];
            b = b.clone(), m = m.clone();
            for (var S = 0, B = 0, k; b.cmpn(-S) > 0 || m.cmpn(-B) > 0;) {
                var L = b.andln(3) + S & 3,
                    K = m.andln(3) + B & 3;
                L === 3 && (L = -1), K === 3 && (K = -1);
                var Q;
                L & 1 ? (k = b.andln(7) + S & 7, (k === 3 || k === 5) && K === 2 ? Q = -L : Q = L) : Q = 0, _[0].push(Q);
                var et;
                K & 1 ? (k = m.andln(7) + B & 7, (k === 3 || k === 5) && L === 2 ? et = -K : et = K) : et = 0, _[1].push(et), 2 * S === Q + 1 && (S = 1 - S), 2 * B === et + 1 && (B = 1 - B), b.iushrn(1), m.iushrn(1)
            }
            return _
        }
        e.getJSF = o;

        function a(b, m, _) {
            var S = "_" + m;
            b.prototype[m] = function() {
                return this[S] !== void 0 ? this[S] : this[S] = _.call(this)
            }
        }
        e.cachedProperty = a;

        function h(b) {
            return typeof b == "string" ? e.toArray(b, "hex") : b
        }
        e.parseBytes = h;

        function g(b) {
            return new Yt(b, "hex", "le")
        }
        e.intFromLE = g
    }),
    ec = Xr.getNAF,
    aE = Xr.getJSF,
    Ec = Xr.assert;

function Bn(r, t) {
    this.type = r, this.p = new Yt(t.p, 16), this.red = t.prime ? Yt.red(t.prime) : Yt.mont(this.p), this.zero = new Yt(0).toRed(this.red), this.one = new Yt(1).toRed(this.red), this.two = new Yt(2).toRed(this.red), this.n = t.n && new Yt(t.n, 16), this.g = t.g && this.pointFromJSON(t.g, t.gRed), this._wnafT1 = new Array(4), this._wnafT2 = new Array(4), this._wnafT3 = new Array(4), this._wnafT4 = new Array(4), this._bitLength = this.n ? this.n.bitLength() : 0;
    var e = this.n && this.p.div(this.n);
    !e || e.cmpn(100) > 0 ? this.redN = null : (this._maxwellTrick = !0, this.redN = this.n.toRed(this.red))
}
var ps = Bn;
Bn.prototype.point = function() {
    throw new Error("Not implemented")
}, Bn.prototype.validate = function() {
    throw new Error("Not implemented")
}, Bn.prototype._fixedNafMul = function(r, t) {
    Ec(r.precomputed);
    var e = r._getDoubles(),
        n = ec(t, 1, this._bitLength),
        o = (1 << e.step + 1) - (e.step % 2 === 0 ? 2 : 1);
    o /= 3;
    var a = [],
        h, g;
    for (h = 0; h < n.length; h += e.step) {
        g = 0;
        for (var b = h + e.step - 1; b >= h; b--) g = (g << 1) + n[b];
        a.push(g)
    }
    for (var m = this.jpoint(null, null, null), _ = this.jpoint(null, null, null), S = o; S > 0; S--) {
        for (h = 0; h < a.length; h++) g = a[h], g === S ? _ = _.mixedAdd(e.points[h]) : g === -S && (_ = _.mixedAdd(e.points[h].neg()));
        m = m.add(_)
    }
    return m.toP()
}, Bn.prototype._wnafMul = function(r, t) {
    var e = 4,
        n = r._getNAFPoints(e);
    e = n.wnd;
    for (var o = n.points, a = ec(t, e, this._bitLength), h = this.jpoint(null, null, null), g = a.length - 1; g >= 0; g--) {
        for (var b = 0; g >= 0 && a[g] === 0; g--) b++;
        if (g >= 0 && b++, h = h.dblp(b), g < 0) break;
        var m = a[g];
        Ec(m !== 0), r.type === "affine" ? m > 0 ? h = h.mixedAdd(o[m - 1 >> 1]) : h = h.mixedAdd(o[-m - 1 >> 1].neg()) : m > 0 ? h = h.add(o[m - 1 >> 1]) : h = h.add(o[-m - 1 >> 1].neg())
    }
    return r.type === "affine" ? h.toP() : h
}, Bn.prototype._wnafMulAdd = function(r, t, e, n, o) {
    var a = this._wnafT1,
        h = this._wnafT2,
        g = this._wnafT3,
        b = 0,
        m, _, S;
    for (m = 0; m < n; m++) {
        S = t[m];
        var B = S._getNAFPoints(r);
        a[m] = B.wnd, h[m] = B.points
    }
    for (m = n - 1; m >= 1; m -= 2) {
        var k = m - 1,
            L = m;
        if (a[k] !== 1 || a[L] !== 1) {
            g[k] = ec(e[k], a[k], this._bitLength), g[L] = ec(e[L], a[L], this._bitLength), b = Math.max(g[k].length, b), b = Math.max(g[L].length, b);
            continue
        }
        var K = [t[k], null, null, t[L]];
        t[k].y.cmp(t[L].y) === 0 ? (K[1] = t[k].add(t[L]), K[2] = t[k].toJ().mixedAdd(t[L].neg())) : t[k].y.cmp(t[L].y.redNeg()) === 0 ? (K[1] = t[k].toJ().mixedAdd(t[L]), K[2] = t[k].add(t[L].neg())) : (K[1] = t[k].toJ().mixedAdd(t[L]), K[2] = t[k].toJ().mixedAdd(t[L].neg()));
        var Q = [-3, -1, -5, -7, 0, 7, 5, 1, 3],
            et = aE(e[k], e[L]);
        for (b = Math.max(et[0].length, b), g[k] = new Array(b), g[L] = new Array(b), _ = 0; _ < b; _++) {
            var at = et[0][_] | 0,
                ut = et[1][_] | 0;
            g[k][_] = Q[(at + 1) * 3 + (ut + 1)], g[L][_] = 0, h[k] = K
        }
    }
    var ft = this.jpoint(null, null, null),
        st = this._wnafT4;
    for (m = b; m >= 0; m--) {
        for (var ot = 0; m >= 0;) {
            var it = !0;
            for (_ = 0; _ < n; _++) st[_] = g[_][m] | 0, st[_] !== 0 && (it = !1);
            if (!it) break;
            ot++, m--
        }
        if (m >= 0 && ot++, ft = ft.dblp(ot), m < 0) break;
        for (_ = 0; _ < n; _++) {
            var mt = st[_];
            mt !== 0 && (mt > 0 ? S = h[_][mt - 1 >> 1] : mt < 0 && (S = h[_][-mt - 1 >> 1].neg()), S.type === "affine" ? ft = ft.mixedAdd(S) : ft = ft.add(S))
        }
    }
    for (m = 0; m < n; m++) h[m] = null;
    return o ? ft : ft.toP()
};

function di(r, t) {
    this.curve = r, this.type = t, this.precomputed = null
}
Bn.BasePoint = di, di.prototype.eq = function() {
    throw new Error("Not implemented")
}, di.prototype.validate = function() {
    return this.curve.validate(this)
}, Bn.prototype.decodePoint = function(r, t) {
    r = Xr.toArray(r, t);
    var e = this.p.byteLength();
    if ((r[0] === 4 || r[0] === 6 || r[0] === 7) && r.length - 1 === 2 * e) {
        r[0] === 6 ? Ec(r[r.length - 1] % 2 === 0) : r[0] === 7 && Ec(r[r.length - 1] % 2 === 1);
        var n = this.point(r.slice(1, 1 + e), r.slice(1 + e, 1 + 2 * e));
        return n
    } else if ((r[0] === 2 || r[0] === 3) && r.length - 1 === e) return this.pointFromX(r.slice(1, 1 + e), r[0] === 3);
    throw new Error("Unknown point format")
}, di.prototype.encodeCompressed = function(r) {
    return this.encode(r, !0)
}, di.prototype._encode = function(r) {
    var t = this.curve.p.byteLength(),
        e = this.getX().toArray("be", t);
    return r ? [this.getY().isEven() ? 2 : 3].concat(e) : [4].concat(e, this.getY().toArray("be", t))
}, di.prototype.encode = function(r, t) {
    return Xr.encode(this._encode(t), r)
}, di.prototype.precompute = function(r) {
    if (this.precomputed) return this;
    var t = {
        doubles: null,
        naf: null,
        beta: null
    };
    return t.naf = this._getNAFPoints(8), t.doubles = this._getDoubles(4, r), t.beta = this._getBeta(), this.precomputed = t, this
}, di.prototype._hasDoubles = function(r) {
    if (!this.precomputed) return !1;
    var t = this.precomputed.doubles;
    return t ? t.points.length >= Math.ceil((r.bitLength() + 1) / t.step) : !1
}, di.prototype._getDoubles = function(r, t) {
    if (this.precomputed && this.precomputed.doubles) return this.precomputed.doubles;
    for (var e = [this], n = this, o = 0; o < t; o += r) {
        for (var a = 0; a < r; a++) n = n.dbl();
        e.push(n)
    }
    return {
        step: r,
        points: e
    }
}, di.prototype._getNAFPoints = function(r) {
    if (this.precomputed && this.precomputed.naf) return this.precomputed.naf;
    for (var t = [this], e = (1 << r) - 1, n = e === 1 ? null : this.dbl(), o = 1; o < e; o++) t[o] = t[o - 1].add(n);
    return {
        wnd: r,
        points: t
    }
}, di.prototype._getBeta = function() {
    return null
}, di.prototype.dblp = function(r) {
    for (var t = this, e = 0; e < r; e++) t = t.dbl();
    return t
};
var Qu = Js(function(r) {
        typeof Object.create == "function" ? r.exports = function(t, e) {
            e && (t.super_ = e, t.prototype = Object.create(e.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }))
        } : r.exports = function(t, e) {
            if (e) {
                t.super_ = e;
                var n = function() {};
                n.prototype = e.prototype, t.prototype = new n, t.prototype.constructor = t
            }
        }
    }),
    cE = Xr.assert;

function yi(r) {
    ps.call(this, "short", r), this.a = new Yt(r.a, 16).toRed(this.red), this.b = new Yt(r.b, 16).toRed(this.red), this.tinv = this.two.redInvm(), this.zeroA = this.a.fromRed().cmpn(0) === 0, this.threeA = this.a.fromRed().sub(this.p).cmpn(-3) === 0, this.endo = this._getEndomorphism(r), this._endoWnafT1 = new Array(4), this._endoWnafT2 = new Array(4)
}
Qu(yi, ps);
var hE = yi;
yi.prototype._getEndomorphism = function(r) {
    if (!(!this.zeroA || !this.g || !this.n || this.p.modn(3) !== 1)) {
        var t, e;
        if (r.beta) t = new Yt(r.beta, 16).toRed(this.red);
        else {
            var n = this._getEndoRoots(this.p);
            t = n[0].cmp(n[1]) < 0 ? n[0] : n[1], t = t.toRed(this.red)
        }
        if (r.lambda) e = new Yt(r.lambda, 16);
        else {
            var o = this._getEndoRoots(this.n);
            this.g.mul(o[0]).x.cmp(this.g.x.redMul(t)) === 0 ? e = o[0] : (e = o[1], cE(this.g.mul(e).x.cmp(this.g.x.redMul(t)) === 0))
        }
        var a;
        return r.basis ? a = r.basis.map(function(h) {
            return {
                a: new Yt(h.a, 16),
                b: new Yt(h.b, 16)
            }
        }) : a = this._getEndoBasis(e), {
            beta: t,
            lambda: e,
            basis: a
        }
    }
}, yi.prototype._getEndoRoots = function(r) {
    var t = r === this.p ? this.red : Yt.mont(r),
        e = new Yt(2).toRed(t).redInvm(),
        n = e.redNeg(),
        o = new Yt(3).toRed(t).redNeg().redSqrt().redMul(e),
        a = n.redAdd(o).fromRed(),
        h = n.redSub(o).fromRed();
    return [a, h]
}, yi.prototype._getEndoBasis = function(r) {
    for (var t = this.n.ushrn(Math.floor(this.n.bitLength() / 2)), e = r, n = this.n.clone(), o = new Yt(1), a = new Yt(0), h = new Yt(0), g = new Yt(1), b, m, _, S, B, k, L, K = 0, Q, et; e.cmpn(0) !== 0;) {
        var at = n.div(e);
        Q = n.sub(at.mul(e)), et = h.sub(at.mul(o));
        var ut = g.sub(at.mul(a));
        if (!_ && Q.cmp(t) < 0) b = L.neg(), m = o, _ = Q.neg(), S = et;
        else if (_ && ++K === 2) break;
        L = Q, n = e, e = Q, h = o, o = et, g = a, a = ut
    }
    B = Q.neg(), k = et;
    var ft = _.sqr().add(S.sqr()),
        st = B.sqr().add(k.sqr());
    return st.cmp(ft) >= 0 && (B = b, k = m), _.negative && (_ = _.neg(), S = S.neg()), B.negative && (B = B.neg(), k = k.neg()), [{
        a: _,
        b: S
    }, {
        a: B,
        b: k
    }]
}, yi.prototype._endoSplit = function(r) {
    var t = this.endo.basis,
        e = t[0],
        n = t[1],
        o = n.b.mul(r).divRound(this.n),
        a = e.b.neg().mul(r).divRound(this.n),
        h = o.mul(e.a),
        g = a.mul(n.a),
        b = o.mul(e.b),
        m = a.mul(n.b),
        _ = r.sub(h).sub(g),
        S = b.add(m).neg();
    return {
        k1: _,
        k2: S
    }
}, yi.prototype.pointFromX = function(r, t) {
    r = new Yt(r, 16), r.red || (r = r.toRed(this.red));
    var e = r.redSqr().redMul(r).redIAdd(r.redMul(this.a)).redIAdd(this.b),
        n = e.redSqrt();
    if (n.redSqr().redSub(e).cmp(this.zero) !== 0) throw new Error("invalid point");
    var o = n.fromRed().isOdd();
    return (t && !o || !t && o) && (n = n.redNeg()), this.point(r, n)
}, yi.prototype.validate = function(r) {
    if (r.inf) return !0;
    var t = r.x,
        e = r.y,
        n = this.a.redMul(t),
        o = t.redSqr().redMul(t).redIAdd(n).redIAdd(this.b);
    return e.redSqr().redISub(o).cmpn(0) === 0
}, yi.prototype._endoWnafMulAdd = function(r, t, e) {
    for (var n = this._endoWnafT1, o = this._endoWnafT2, a = 0; a < r.length; a++) {
        var h = this._endoSplit(t[a]),
            g = r[a],
            b = g._getBeta();
        h.k1.negative && (h.k1.ineg(), g = g.neg(!0)), h.k2.negative && (h.k2.ineg(), b = b.neg(!0)), n[a * 2] = g, n[a * 2 + 1] = b, o[a * 2] = h.k1, o[a * 2 + 1] = h.k2
    }
    for (var m = this._wnafMulAdd(1, n, o, a * 2, e), _ = 0; _ < a * 2; _++) n[_] = null, o[_] = null;
    return m
};

function ar(r, t, e, n) {
    ps.BasePoint.call(this, r, "affine"), t === null && e === null ? (this.x = null, this.y = null, this.inf = !0) : (this.x = new Yt(t, 16), this.y = new Yt(e, 16), n && (this.x.forceRed(this.curve.red), this.y.forceRed(this.curve.red)), this.x.red || (this.x = this.x.toRed(this.curve.red)), this.y.red || (this.y = this.y.toRed(this.curve.red)), this.inf = !1)
}
Qu(ar, ps.BasePoint), yi.prototype.point = function(r, t, e) {
    return new ar(this, r, t, e)
}, yi.prototype.pointFromJSON = function(r, t) {
    return ar.fromJSON(this, r, t)
}, ar.prototype._getBeta = function() {
    if (this.curve.endo) {
        var r = this.precomputed;
        if (r && r.beta) return r.beta;
        var t = this.curve.point(this.x.redMul(this.curve.endo.beta), this.y);
        if (r) {
            var e = this.curve,
                n = function(o) {
                    return e.point(o.x.redMul(e.endo.beta), o.y)
                };
            r.beta = t, t.precomputed = {
                beta: null,
                naf: r.naf && {
                    wnd: r.naf.wnd,
                    points: r.naf.points.map(n)
                },
                doubles: r.doubles && {
                    step: r.doubles.step,
                    points: r.doubles.points.map(n)
                }
            }
        }
        return t
    }
}, ar.prototype.toJSON = function() {
    return this.precomputed ? [this.x, this.y, this.precomputed && {
        doubles: this.precomputed.doubles && {
            step: this.precomputed.doubles.step,
            points: this.precomputed.doubles.points.slice(1)
        },
        naf: this.precomputed.naf && {
            wnd: this.precomputed.naf.wnd,
            points: this.precomputed.naf.points.slice(1)
        }
    }] : [this.x, this.y]
}, ar.fromJSON = function(r, t, e) {
    typeof t == "string" && (t = JSON.parse(t));
    var n = r.point(t[0], t[1], e);
    if (!t[2]) return n;

    function o(h) {
        return r.point(h[0], h[1], e)
    }
    var a = t[2];
    return n.precomputed = {
        beta: null,
        doubles: a.doubles && {
            step: a.doubles.step,
            points: [n].concat(a.doubles.points.map(o))
        },
        naf: a.naf && {
            wnd: a.naf.wnd,
            points: [n].concat(a.naf.points.map(o))
        }
    }, n
}, ar.prototype.inspect = function() {
    return this.isInfinity() ? "<EC Point Infinity>" : "<EC Point x: " + this.x.fromRed().toString(16, 2) + " y: " + this.y.fromRed().toString(16, 2) + ">"
}, ar.prototype.isInfinity = function() {
    return this.inf
}, ar.prototype.add = function(r) {
    if (this.inf) return r;
    if (r.inf) return this;
    if (this.eq(r)) return this.dbl();
    if (this.neg().eq(r)) return this.curve.point(null, null);
    if (this.x.cmp(r.x) === 0) return this.curve.point(null, null);
    var t = this.y.redSub(r.y);
    t.cmpn(0) !== 0 && (t = t.redMul(this.x.redSub(r.x).redInvm()));
    var e = t.redSqr().redISub(this.x).redISub(r.x),
        n = t.redMul(this.x.redSub(e)).redISub(this.y);
    return this.curve.point(e, n)
}, ar.prototype.dbl = function() {
    if (this.inf) return this;
    var r = this.y.redAdd(this.y);
    if (r.cmpn(0) === 0) return this.curve.point(null, null);
    var t = this.curve.a,
        e = this.x.redSqr(),
        n = r.redInvm(),
        o = e.redAdd(e).redIAdd(e).redIAdd(t).redMul(n),
        a = o.redSqr().redISub(this.x.redAdd(this.x)),
        h = o.redMul(this.x.redSub(a)).redISub(this.y);
    return this.curve.point(a, h)
}, ar.prototype.getX = function() {
    return this.x.fromRed()
}, ar.prototype.getY = function() {
    return this.y.fromRed()
}, ar.prototype.mul = function(r) {
    return r = new Yt(r, 16), this.isInfinity() ? this : this._hasDoubles(r) ? this.curve._fixedNafMul(this, r) : this.curve.endo ? this.curve._endoWnafMulAdd([this], [r]) : this.curve._wnafMul(this, r)
}, ar.prototype.mulAdd = function(r, t, e) {
    var n = [this, t],
        o = [r, e];
    return this.curve.endo ? this.curve._endoWnafMulAdd(n, o) : this.curve._wnafMulAdd(1, n, o, 2)
}, ar.prototype.jmulAdd = function(r, t, e) {
    var n = [this, t],
        o = [r, e];
    return this.curve.endo ? this.curve._endoWnafMulAdd(n, o, !0) : this.curve._wnafMulAdd(1, n, o, 2, !0)
}, ar.prototype.eq = function(r) {
    return this === r || this.inf === r.inf && (this.inf || this.x.cmp(r.x) === 0 && this.y.cmp(r.y) === 0)
}, ar.prototype.neg = function(r) {
    if (this.inf) return this;
    var t = this.curve.point(this.x, this.y.redNeg());
    if (r && this.precomputed) {
        var e = this.precomputed,
            n = function(o) {
                return o.neg()
            };
        t.precomputed = {
            naf: e.naf && {
                wnd: e.naf.wnd,
                points: e.naf.points.map(n)
            },
            doubles: e.doubles && {
                step: e.doubles.step,
                points: e.doubles.points.map(n)
            }
        }
    }
    return t
}, ar.prototype.toJ = function() {
    if (this.inf) return this.curve.jpoint(null, null, null);
    var r = this.curve.jpoint(this.x, this.y, this.curve.one);
    return r
};

function ur(r, t, e, n) {
    ps.BasePoint.call(this, r, "jacobian"), t === null && e === null && n === null ? (this.x = this.curve.one, this.y = this.curve.one, this.z = new Yt(0)) : (this.x = new Yt(t, 16), this.y = new Yt(e, 16), this.z = new Yt(n, 16)), this.x.red || (this.x = this.x.toRed(this.curve.red)), this.y.red || (this.y = this.y.toRed(this.curve.red)), this.z.red || (this.z = this.z.toRed(this.curve.red)), this.zOne = this.z === this.curve.one
}
Qu(ur, ps.BasePoint), yi.prototype.jpoint = function(r, t, e) {
    return new ur(this, r, t, e)
}, ur.prototype.toP = function() {
    if (this.isInfinity()) return this.curve.point(null, null);
    var r = this.z.redInvm(),
        t = r.redSqr(),
        e = this.x.redMul(t),
        n = this.y.redMul(t).redMul(r);
    return this.curve.point(e, n)
}, ur.prototype.neg = function() {
    return this.curve.jpoint(this.x, this.y.redNeg(), this.z)
}, ur.prototype.add = function(r) {
    if (this.isInfinity()) return r;
    if (r.isInfinity()) return this;
    var t = r.z.redSqr(),
        e = this.z.redSqr(),
        n = this.x.redMul(t),
        o = r.x.redMul(e),
        a = this.y.redMul(t.redMul(r.z)),
        h = r.y.redMul(e.redMul(this.z)),
        g = n.redSub(o),
        b = a.redSub(h);
    if (g.cmpn(0) === 0) return b.cmpn(0) !== 0 ? this.curve.jpoint(null, null, null) : this.dbl();
    var m = g.redSqr(),
        _ = m.redMul(g),
        S = n.redMul(m),
        B = b.redSqr().redIAdd(_).redISub(S).redISub(S),
        k = b.redMul(S.redISub(B)).redISub(a.redMul(_)),
        L = this.z.redMul(r.z).redMul(g);
    return this.curve.jpoint(B, k, L)
}, ur.prototype.mixedAdd = function(r) {
    if (this.isInfinity()) return r.toJ();
    if (r.isInfinity()) return this;
    var t = this.z.redSqr(),
        e = this.x,
        n = r.x.redMul(t),
        o = this.y,
        a = r.y.redMul(t).redMul(this.z),
        h = e.redSub(n),
        g = o.redSub(a);
    if (h.cmpn(0) === 0) return g.cmpn(0) !== 0 ? this.curve.jpoint(null, null, null) : this.dbl();
    var b = h.redSqr(),
        m = b.redMul(h),
        _ = e.redMul(b),
        S = g.redSqr().redIAdd(m).redISub(_).redISub(_),
        B = g.redMul(_.redISub(S)).redISub(o.redMul(m)),
        k = this.z.redMul(h);
    return this.curve.jpoint(S, B, k)
}, ur.prototype.dblp = function(r) {
    if (r === 0) return this;
    if (this.isInfinity()) return this;
    if (!r) return this.dbl();
    var t;
    if (this.curve.zeroA || this.curve.threeA) {
        var e = this;
        for (t = 0; t < r; t++) e = e.dbl();
        return e
    }
    var n = this.curve.a,
        o = this.curve.tinv,
        a = this.x,
        h = this.y,
        g = this.z,
        b = g.redSqr().redSqr(),
        m = h.redAdd(h);
    for (t = 0; t < r; t++) {
        var _ = a.redSqr(),
            S = m.redSqr(),
            B = S.redSqr(),
            k = _.redAdd(_).redIAdd(_).redIAdd(n.redMul(b)),
            L = a.redMul(S),
            K = k.redSqr().redISub(L.redAdd(L)),
            Q = L.redISub(K),
            et = k.redMul(Q);
        et = et.redIAdd(et).redISub(B);
        var at = m.redMul(g);
        t + 1 < r && (b = b.redMul(B)), a = K, g = at, m = et
    }
    return this.curve.jpoint(a, m.redMul(o), g)
}, ur.prototype.dbl = function() {
    return this.isInfinity() ? this : this.curve.zeroA ? this._zeroDbl() : this.curve.threeA ? this._threeDbl() : this._dbl()
}, ur.prototype._zeroDbl = function() {
    var r, t, e;
    if (this.zOne) {
        var n = this.x.redSqr(),
            o = this.y.redSqr(),
            a = o.redSqr(),
            h = this.x.redAdd(o).redSqr().redISub(n).redISub(a);
        h = h.redIAdd(h);
        var g = n.redAdd(n).redIAdd(n),
            b = g.redSqr().redISub(h).redISub(h),
            m = a.redIAdd(a);
        m = m.redIAdd(m), m = m.redIAdd(m), r = b, t = g.redMul(h.redISub(b)).redISub(m), e = this.y.redAdd(this.y)
    } else {
        var _ = this.x.redSqr(),
            S = this.y.redSqr(),
            B = S.redSqr(),
            k = this.x.redAdd(S).redSqr().redISub(_).redISub(B);
        k = k.redIAdd(k);
        var L = _.redAdd(_).redIAdd(_),
            K = L.redSqr(),
            Q = B.redIAdd(B);
        Q = Q.redIAdd(Q), Q = Q.redIAdd(Q), r = K.redISub(k).redISub(k), t = L.redMul(k.redISub(r)).redISub(Q), e = this.y.redMul(this.z), e = e.redIAdd(e)
    }
    return this.curve.jpoint(r, t, e)
}, ur.prototype._threeDbl = function() {
    var r, t, e;
    if (this.zOne) {
        var n = this.x.redSqr(),
            o = this.y.redSqr(),
            a = o.redSqr(),
            h = this.x.redAdd(o).redSqr().redISub(n).redISub(a);
        h = h.redIAdd(h);
        var g = n.redAdd(n).redIAdd(n).redIAdd(this.curve.a),
            b = g.redSqr().redISub(h).redISub(h);
        r = b;
        var m = a.redIAdd(a);
        m = m.redIAdd(m), m = m.redIAdd(m), t = g.redMul(h.redISub(b)).redISub(m), e = this.y.redAdd(this.y)
    } else {
        var _ = this.z.redSqr(),
            S = this.y.redSqr(),
            B = this.x.redMul(S),
            k = this.x.redSub(_).redMul(this.x.redAdd(_));
        k = k.redAdd(k).redIAdd(k);
        var L = B.redIAdd(B);
        L = L.redIAdd(L);
        var K = L.redAdd(L);
        r = k.redSqr().redISub(K), e = this.y.redAdd(this.z).redSqr().redISub(S).redISub(_);
        var Q = S.redSqr();
        Q = Q.redIAdd(Q), Q = Q.redIAdd(Q), Q = Q.redIAdd(Q), t = k.redMul(L.redISub(r)).redISub(Q)
    }
    return this.curve.jpoint(r, t, e)
}, ur.prototype._dbl = function() {
    var r = this.curve.a,
        t = this.x,
        e = this.y,
        n = this.z,
        o = n.redSqr().redSqr(),
        a = t.redSqr(),
        h = e.redSqr(),
        g = a.redAdd(a).redIAdd(a).redIAdd(r.redMul(o)),
        b = t.redAdd(t);
    b = b.redIAdd(b);
    var m = b.redMul(h),
        _ = g.redSqr().redISub(m.redAdd(m)),
        S = m.redISub(_),
        B = h.redSqr();
    B = B.redIAdd(B), B = B.redIAdd(B), B = B.redIAdd(B);
    var k = g.redMul(S).redISub(B),
        L = e.redAdd(e).redMul(n);
    return this.curve.jpoint(_, k, L)
}, ur.prototype.trpl = function() {
    if (!this.curve.zeroA) return this.dbl().add(this);
    var r = this.x.redSqr(),
        t = this.y.redSqr(),
        e = this.z.redSqr(),
        n = t.redSqr(),
        o = r.redAdd(r).redIAdd(r),
        a = o.redSqr(),
        h = this.x.redAdd(t).redSqr().redISub(r).redISub(n);
    h = h.redIAdd(h), h = h.redAdd(h).redIAdd(h), h = h.redISub(a);
    var g = h.redSqr(),
        b = n.redIAdd(n);
    b = b.redIAdd(b), b = b.redIAdd(b), b = b.redIAdd(b);
    var m = o.redIAdd(h).redSqr().redISub(a).redISub(g).redISub(b),
        _ = t.redMul(m);
    _ = _.redIAdd(_), _ = _.redIAdd(_);
    var S = this.x.redMul(g).redISub(_);
    S = S.redIAdd(S), S = S.redIAdd(S);
    var B = this.y.redMul(m.redMul(b.redISub(m)).redISub(h.redMul(g)));
    B = B.redIAdd(B), B = B.redIAdd(B), B = B.redIAdd(B);
    var k = this.z.redAdd(h).redSqr().redISub(e).redISub(g);
    return this.curve.jpoint(S, B, k)
}, ur.prototype.mul = function(r, t) {
    return r = new Yt(r, t), this.curve._wnafMul(this, r)
}, ur.prototype.eq = function(r) {
    if (r.type === "affine") return this.eq(r.toJ());
    if (this === r) return !0;
    var t = this.z.redSqr(),
        e = r.z.redSqr();
    if (this.x.redMul(e).redISub(r.x.redMul(t)).cmpn(0) !== 0) return !1;
    var n = t.redMul(this.z),
        o = e.redMul(r.z);
    return this.y.redMul(o).redISub(r.y.redMul(n)).cmpn(0) === 0
}, ur.prototype.eqXToP = function(r) {
    var t = this.z.redSqr(),
        e = r.toRed(this.curve.red).redMul(t);
    if (this.x.cmp(e) === 0) return !0;
    for (var n = r.clone(), o = this.curve.redN.redMul(t);;) {
        if (n.iadd(this.curve.n), n.cmp(this.curve.p) >= 0) return !1;
        if (e.redIAdd(o), this.x.cmp(e) === 0) return !0
    }
}, ur.prototype.inspect = function() {
    return this.isInfinity() ? "<EC JPoint Infinity>" : "<EC JPoint x: " + this.x.toString(16, 2) + " y: " + this.y.toString(16, 2) + " z: " + this.z.toString(16, 2) + ">"
}, ur.prototype.isInfinity = function() {
    return this.z.cmpn(0) === 0
};
var uc = Js(function(r, t) {
        var e = t;
        e.base = ps, e.short = hE, e.mont = null, e.edwards = null
    }),
    lc = Js(function(r, t) {
        var e = t,
            n = Xr.assert;

        function o(g) {
            g.type === "short" ? this.curve = new uc.short(g) : g.type === "edwards" ? this.curve = new uc.edwards(g) : this.curve = new uc.mont(g), this.g = this.curve.g, this.n = this.curve.n, this.hash = g.hash, n(this.g.validate(), "Invalid curve"), n(this.g.mul(this.n).isInfinity(), "Invalid curve, G*N != O")
        }
        e.PresetCurve = o;

        function a(g, b) {
            Object.defineProperty(e, g, {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    var m = new o(b);
                    return Object.defineProperty(e, g, {
                        configurable: !0,
                        enumerable: !0,
                        value: m
                    }), m
                }
            })
        }
        a("p192", {
            type: "short",
            prime: "p192",
            p: "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff",
            a: "ffffffff ffffffff ffffffff fffffffe ffffffff fffffffc",
            b: "64210519 e59c80e7 0fa7e9ab 72243049 feb8deec c146b9b1",
            n: "ffffffff ffffffff ffffffff 99def836 146bc9b1 b4d22831",
            hash: Ki.sha256,
            gRed: !1,
            g: ["188da80e b03090f6 7cbf20eb 43a18800 f4ff0afd 82ff1012", "07192b95 ffc8da78 631011ed 6b24cdd5 73f977a1 1e794811"]
        }), a("p224", {
            type: "short",
            prime: "p224",
            p: "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001",
            a: "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff fffffffe",
            b: "b4050a85 0c04b3ab f5413256 5044b0b7 d7bfd8ba 270b3943 2355ffb4",
            n: "ffffffff ffffffff ffffffff ffff16a2 e0b8f03e 13dd2945 5c5c2a3d",
            hash: Ki.sha256,
            gRed: !1,
            g: ["b70e0cbd 6bb4bf7f 321390b9 4a03c1d3 56c21122 343280d6 115c1d21", "bd376388 b5f723fb 4c22dfe6 cd4375a0 5a074764 44d58199 85007e34"]
        }), a("p256", {
            type: "short",
            prime: null,
            p: "ffffffff 00000001 00000000 00000000 00000000 ffffffff ffffffff ffffffff",
            a: "ffffffff 00000001 00000000 00000000 00000000 ffffffff ffffffff fffffffc",
            b: "5ac635d8 aa3a93e7 b3ebbd55 769886bc 651d06b0 cc53b0f6 3bce3c3e 27d2604b",
            n: "ffffffff 00000000 ffffffff ffffffff bce6faad a7179e84 f3b9cac2 fc632551",
            hash: Ki.sha256,
            gRed: !1,
            g: ["6b17d1f2 e12c4247 f8bce6e5 63a440f2 77037d81 2deb33a0 f4a13945 d898c296", "4fe342e2 fe1a7f9b 8ee7eb4a 7c0f9e16 2bce3357 6b315ece cbb64068 37bf51f5"]
        }), a("p384", {
            type: "short",
            prime: null,
            p: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe ffffffff 00000000 00000000 ffffffff",
            a: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe ffffffff 00000000 00000000 fffffffc",
            b: "b3312fa7 e23ee7e4 988e056b e3f82d19 181d9c6e fe814112 0314088f 5013875a c656398d 8a2ed19d 2a85c8ed d3ec2aef",
            n: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff c7634d81 f4372ddf 581a0db2 48b0a77a ecec196a ccc52973",
            hash: Ki.sha384,
            gRed: !1,
            g: ["aa87ca22 be8b0537 8eb1c71e f320ad74 6e1d3b62 8ba79b98 59f741e0 82542a38 5502f25d bf55296c 3a545e38 72760ab7", "3617de4a 96262c6f 5d9e98bf 9292dc29 f8f41dbd 289a147c e9da3113 b5f0b8c0 0a60b1ce 1d7e819d 7a431d7c 90ea0e5f"]
        }), a("p521", {
            type: "short",
            prime: null,
            p: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff",
            a: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffc",
            b: "00000051 953eb961 8e1c9a1f 929a21a0 b68540ee a2da725b 99b315f3 b8b48991 8ef109e1 56193951 ec7e937b 1652c0bd 3bb1bf07 3573df88 3d2c34f1 ef451fd4 6b503f00",
            n: "000001ff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffa 51868783 bf2f966b 7fcc0148 f709a5d0 3bb5c9b8 899c47ae bb6fb71e 91386409",
            hash: Ki.sha512,
            gRed: !1,
            g: ["000000c6 858e06b7 0404e9cd 9e3ecb66 2395b442 9c648139 053fb521 f828af60 6b4d3dba a14b5e77 efe75928 fe1dc127 a2ffa8de 3348b3c1 856a429b f97e7e31 c2e5bd66", "00000118 39296a78 9a3bc004 5c8a5fb4 2c7d1bd9 98f54449 579b4468 17afbd17 273e662c 97ee7299 5ef42640 c550b901 3fad0761 353c7086 a272c240 88be9476 9fd16650"]
        }), a("curve25519", {
            type: "mont",
            prime: "p25519",
            p: "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed",
            a: "76d06",
            b: "1",
            n: "1000000000000000 0000000000000000 14def9dea2f79cd6 5812631a5cf5d3ed",
            hash: Ki.sha256,
            gRed: !1,
            g: ["9"]
        }), a("ed25519", {
            type: "edwards",
            prime: "p25519",
            p: "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed",
            a: "-1",
            c: "1",
            d: "52036cee2b6ffe73 8cc740797779e898 00700a4d4141d8ab 75eb4dca135978a3",
            n: "1000000000000000 0000000000000000 14def9dea2f79cd6 5812631a5cf5d3ed",
            hash: Ki.sha256,
            gRed: !1,
            g: ["216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a", "6666666666666666666666666666666666666666666666666666666666666658"]
        });
        var h;
        try {
            h = null.crash()
        } catch {
            h = void 0
        }
        a("secp256k1", {
            type: "short",
            prime: "k256",
            p: "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f",
            a: "0",
            b: "7",
            n: "ffffffff ffffffff ffffffff fffffffe baaedce6 af48a03b bfd25e8c d0364141",
            h: "1",
            hash: Ki.sha256,
            beta: "7ae96a2b657c07106e64479eac3434e99cf0497512f58995c1396c28719501ee",
            lambda: "5363ad4cc05c30e0a5261c028812645a122e22ea20816678df02967c1b23bd72",
            basis: [{
                a: "3086d221a7d46bcde86c90e49284eb15",
                b: "-e4437ed6010e88286f547fa90abfe4c3"
            }, {
                a: "114ca50f7a8e2f3f657c1108d9d44cfd8",
                b: "3086d221a7d46bcde86c90e49284eb15"
            }],
            gRed: !1,
            g: ["79be667ef9dcbbac55a06295ce870b07029bfcdb2dce28d959f2815b16f81798", "483ada7726a3c4655da4fbfc0e1108a8fd17b448a68554199c47d08ffb10d4b8", h]
        })
    });

function Un(r) {
    if (!(this instanceof Un)) return new Un(r);
    this.hash = r.hash, this.predResist = !!r.predResist, this.outLen = this.hash.outSize, this.minEntropy = r.minEntropy || this.hash.hmacStrength, this._reseed = null, this.reseedInterval = null, this.K = null, this.V = null;
    var t = Ri.toArray(r.entropy, r.entropyEnc || "hex"),
        e = Ri.toArray(r.nonce, r.nonceEnc || "hex"),
        n = Ri.toArray(r.pers, r.persEnc || "hex");
    Gu(t.length >= this.minEntropy / 8, "Not enough entropy. Minimum is: " + this.minEntropy + " bits"), this._init(t, e, n)
}
var rp = Un;
Un.prototype._init = function(r, t, e) {
    var n = r.concat(t).concat(e);
    this.K = new Array(this.outLen / 8), this.V = new Array(this.outLen / 8);
    for (var o = 0; o < this.V.length; o++) this.K[o] = 0, this.V[o] = 1;
    this._update(n), this._reseed = 1, this.reseedInterval = 281474976710656
}, Un.prototype._hmac = function() {
    return new Ki.hmac(this.hash, this.K)
}, Un.prototype._update = function(r) {
    var t = this._hmac().update(this.V).update([0]);
    r && (t = t.update(r)), this.K = t.digest(), this.V = this._hmac().update(this.V).digest(), r && (this.K = this._hmac().update(this.V).update([1]).update(r).digest(), this.V = this._hmac().update(this.V).digest())
}, Un.prototype.reseed = function(r, t, e, n) {
    typeof t != "string" && (n = e, e = t, t = null), r = Ri.toArray(r, t), e = Ri.toArray(e, n), Gu(r.length >= this.minEntropy / 8, "Not enough entropy. Minimum is: " + this.minEntropy + " bits"), this._update(r.concat(e || [])), this._reseed = 1
}, Un.prototype.generate = function(r, t, e, n) {
    if (this._reseed > this.reseedInterval) throw new Error("Reseed is required");
    typeof t != "string" && (n = e, e = t, t = null), e && (e = Ri.toArray(e, n || "hex"), this._update(e));
    for (var o = []; o.length < r;) this.V = this._hmac().update(this.V).digest(), o = o.concat(this.V);
    var a = o.slice(0, r);
    return this._update(e), this._reseed++, Ri.encode(a, t)
};
var nu = Xr.assert;

function vr(r, t) {
    this.ec = r, this.priv = null, this.pub = null, t.priv && this._importPrivate(t.priv, t.privEnc), t.pub && this._importPublic(t.pub, t.pubEnc)
}
var su = vr;
vr.fromPublic = function(r, t, e) {
    return t instanceof vr ? t : new vr(r, {
        pub: t,
        pubEnc: e
    })
}, vr.fromPrivate = function(r, t, e) {
    return t instanceof vr ? t : new vr(r, {
        priv: t,
        privEnc: e
    })
}, vr.prototype.validate = function() {
    var r = this.getPublic();
    return r.isInfinity() ? {
        result: !1,
        reason: "Invalid public key"
    } : r.validate() ? r.mul(this.ec.curve.n).isInfinity() ? {
        result: !0,
        reason: null
    } : {
        result: !1,
        reason: "Public key * N != O"
    } : {
        result: !1,
        reason: "Public key is not a point"
    }
}, vr.prototype.getPublic = function(r, t) {
    return typeof r == "string" && (t = r, r = null), this.pub || (this.pub = this.ec.g.mul(this.priv)), t ? this.pub.encode(t, r) : this.pub
}, vr.prototype.getPrivate = function(r) {
    return r === "hex" ? this.priv.toString(16, 2) : this.priv
}, vr.prototype._importPrivate = function(r, t) {
    this.priv = new Yt(r, t || 16), this.priv = this.priv.umod(this.ec.curve.n)
}, vr.prototype._importPublic = function(r, t) {
    if (r.x || r.y) {
        this.ec.curve.type === "mont" ? nu(r.x, "Need x coordinate") : (this.ec.curve.type === "short" || this.ec.curve.type === "edwards") && nu(r.x && r.y, "Need both x and y coordinate"), this.pub = this.ec.curve.point(r.x, r.y);
        return
    }
    this.pub = this.ec.curve.decodePoint(r, t)
}, vr.prototype.derive = function(r) {
    return r.validate() || nu(r.validate(), "public point not validated"), r.mul(this.priv).getX()
}, vr.prototype.sign = function(r, t, e) {
    return this.ec.sign(r, this, t, e)
}, vr.prototype.verify = function(r, t) {
    return this.ec.verify(r, t, this)
}, vr.prototype.inspect = function() {
    return "<Key priv: " + (this.priv && this.priv.toString(16, 2)) + " pub: " + (this.pub && this.pub.inspect()) + " >"
};
var uE = Xr.assert;

function Tc(r, t) {
    if (r instanceof Tc) return r;
    this._importDER(r, t) || (uE(r.r && r.s, "Signature without r or s"), this.r = new Yt(r.r, 16), this.s = new Yt(r.s, 16), r.recoveryParam === void 0 ? this.recoveryParam = null : this.recoveryParam = r.recoveryParam)
}
var rc = Tc;

function lE() {
    this.place = 0
}

function ou(r, t) {
    var e = r[t.place++];
    if (!(e & 128)) return e;
    var n = e & 15;
    if (n === 0 || n > 4) return !1;
    for (var o = 0, a = 0, h = t.place; a < n; a++, h++) o <<= 8, o |= r[h], o >>>= 0;
    return o <= 127 ? !1 : (t.place = h, o)
}

function ip(r) {
    for (var t = 0, e = r.length - 1; !r[t] && !(r[t + 1] & 128) && t < e;) t++;
    return t === 0 ? r : r.slice(t)
}
Tc.prototype._importDER = function(r, t) {
    r = Xr.toArray(r, t);
    var e = new lE;
    if (r[e.place++] !== 48) return !1;
    var n = ou(r, e);
    if (n === !1 || n + e.place !== r.length || r[e.place++] !== 2) return !1;
    var o = ou(r, e);
    if (o === !1) return !1;
    var a = r.slice(e.place, o + e.place);
    if (e.place += o, r[e.place++] !== 2) return !1;
    var h = ou(r, e);
    if (h === !1 || r.length !== h + e.place) return !1;
    var g = r.slice(e.place, h + e.place);
    if (a[0] === 0)
        if (a[1] & 128) a = a.slice(1);
        else return !1;
    if (g[0] === 0)
        if (g[1] & 128) g = g.slice(1);
        else return !1;
    return this.r = new Yt(a), this.s = new Yt(g), this.recoveryParam = null, !0
};

function au(r, t) {
    if (t < 128) {
        r.push(t);
        return
    }
    var e = 1 + (Math.log(t) / Math.LN2 >>> 3);
    for (r.push(e | 128); --e;) r.push(t >>> (e << 3) & 255);
    r.push(t)
}
Tc.prototype.toDER = function(r) {
    var t = this.r.toArray(),
        e = this.s.toArray();
    for (t[0] & 128 && (t = [0].concat(t)), e[0] & 128 && (e = [0].concat(e)), t = ip(t), e = ip(e); !e[0] && !(e[1] & 128);) e = e.slice(1);
    var n = [2];
    au(n, t.length), n = n.concat(t), n.push(2), au(n, e.length);
    var o = n.concat(e),
        a = [48];
    return au(a, o.length), a = a.concat(o), Xr.encode(a, r)
};
var fE = function() {
        throw new Error("unsupported")
    },
    ag = Xr.assert;

function mi(r) {
    if (!(this instanceof mi)) return new mi(r);
    typeof r == "string" && (ag(Object.prototype.hasOwnProperty.call(lc, r), "Unknown curve " + r), r = lc[r]), r instanceof lc.PresetCurve && (r = {
        curve: r
    }), this.curve = r.curve.curve, this.n = this.curve.n, this.nh = this.n.ushrn(1), this.g = this.curve.g, this.g = r.curve.g, this.g.precompute(r.curve.n.bitLength() + 1), this.hash = r.hash || r.curve.hash
}
var dE = mi;
mi.prototype.keyPair = function(r) {
    return new su(this, r)
}, mi.prototype.keyFromPrivate = function(r, t) {
    return su.fromPrivate(this, r, t)
}, mi.prototype.keyFromPublic = function(r, t) {
    return su.fromPublic(this, r, t)
}, mi.prototype.genKeyPair = function(r) {
    r || (r = {});
    for (var t = new rp({
            hash: this.hash,
            pers: r.pers,
            persEnc: r.persEnc || "utf8",
            entropy: r.entropy || fE(this.hash.hmacStrength),
            entropyEnc: r.entropy && r.entropyEnc || "utf8",
            nonce: this.n.toArray()
        }), e = this.n.byteLength(), n = this.n.sub(new Yt(2));;) {
        var o = new Yt(t.generate(e));
        if (!(o.cmp(n) > 0)) return o.iaddn(1), this.keyFromPrivate(o)
    }
}, mi.prototype._truncateToN = function(r, t) {
    var e = r.byteLength() * 8 - this.n.bitLength();
    return e > 0 && (r = r.ushrn(e)), !t && r.cmp(this.n) >= 0 ? r.sub(this.n) : r
}, mi.prototype.sign = function(r, t, e, n) {
    typeof e == "object" && (n = e, e = null), n || (n = {}), t = this.keyFromPrivate(t, e), r = this._truncateToN(new Yt(r, 16));
    for (var o = this.n.byteLength(), a = t.getPrivate().toArray("be", o), h = r.toArray("be", o), g = new rp({
            hash: this.hash,
            entropy: a,
            nonce: h,
            pers: n.pers,
            persEnc: n.persEnc || "utf8"
        }), b = this.n.sub(new Yt(1)), m = 0;; m++) {
        var _ = n.k ? n.k(m) : new Yt(g.generate(this.n.byteLength()));
        if (_ = this._truncateToN(_, !0), !(_.cmpn(1) <= 0 || _.cmp(b) >= 0)) {
            var S = this.g.mul(_);
            if (!S.isInfinity()) {
                var B = S.getX(),
                    k = B.umod(this.n);
                if (k.cmpn(0) !== 0) {
                    var L = _.invm(this.n).mul(k.mul(t.getPrivate()).iadd(r));
                    if (L = L.umod(this.n), L.cmpn(0) !== 0) {
                        var K = (S.getY().isOdd() ? 1 : 0) | (B.cmp(k) !== 0 ? 2 : 0);
                        return n.canonical && L.cmp(this.nh) > 0 && (L = this.n.sub(L), K ^= 1), new rc({
                            r: k,
                            s: L,
                            recoveryParam: K
                        })
                    }
                }
            }
        }
    }
}, mi.prototype.verify = function(r, t, e, n) {
    r = this._truncateToN(new Yt(r, 16)), e = this.keyFromPublic(e, n), t = new rc(t, "hex");
    var o = t.r,
        a = t.s;
    if (o.cmpn(1) < 0 || o.cmp(this.n) >= 0 || a.cmpn(1) < 0 || a.cmp(this.n) >= 0) return !1;
    var h = a.invm(this.n),
        g = h.mul(r).umod(this.n),
        b = h.mul(o).umod(this.n),
        m;
    return this.curve._maxwellTrick ? (m = this.g.jmulAdd(g, e.getPublic(), b), m.isInfinity() ? !1 : m.eqXToP(o)) : (m = this.g.mulAdd(g, e.getPublic(), b), m.isInfinity() ? !1 : m.getX().umod(this.n).cmp(o) === 0)
}, mi.prototype.recoverPubKey = function(r, t, e, n) {
    ag((3 & e) === e, "The recovery param is more than two bits"), t = new rc(t, n);
    var o = this.n,
        a = new Yt(r),
        h = t.r,
        g = t.s,
        b = e & 1,
        m = e >> 1;
    if (h.cmp(this.curve.p.umod(this.curve.n)) >= 0 && m) throw new Error("Unable to find sencond key candinate");
    m ? h = this.curve.pointFromX(h.add(this.curve.n), b) : h = this.curve.pointFromX(h, b);
    var _ = t.r.invm(o),
        S = o.sub(a).mul(_).umod(o),
        B = g.mul(_).umod(o);
    return this.g.mulAdd(S, h, B)
}, mi.prototype.getKeyRecoveryParam = function(r, t, e, n) {
    if (t = new rc(t, n), t.recoveryParam !== null) return t.recoveryParam;
    for (var o = 0; o < 4; o++) {
        var a;
        try {
            a = this.recoverPubKey(r, t, o)
        } catch {
            continue
        }
        if (a.eq(e)) return o
    }
    throw new Error("Unable to find valid recovery factor")
};
var pE = Js(function(r, t) {
        var e = t;
        e.version = "6.5.4", e.utils = Xr, e.rand = function() {
            throw new Error("unsupported")
        }, e.curve = uc, e.curves = lc, e.ec = dE, e.eddsa = null
    }),
    gE = pE.ec;
const mE = "signing-key/5.7.0",
    Mu = new dr(mE);
let cu = null;

function qn() {
    return cu || (cu = new gE("secp256k1")), cu
}
class vE {
    constructor(t) {
        wo(this, "curve", "secp256k1"), wo(this, "privateKey", Ur(t)), t_(this.privateKey) !== 32 && Mu.throwArgumentError("invalid private key", "privateKey", "[[ REDACTED ]]");
        const e = qn().keyFromPrivate(Ve(this.privateKey));
        wo(this, "publicKey", "0x" + e.getPublic(!1, "hex")), wo(this, "compressedPublicKey", "0x" + e.getPublic(!0, "hex")), wo(this, "_isSigningKey", !0)
    }
    _addPoint(t) {
        const e = qn().keyFromPublic(Ve(this.publicKey)),
            n = qn().keyFromPublic(Ve(t));
        return "0x" + e.pub.add(n.pub).encodeCompressed("hex")
    }
    signDigest(t) {
        const e = qn().keyFromPrivate(Ve(this.privateKey)),
            n = Ve(t);
        n.length !== 32 && Mu.throwArgumentError("bad digest length", "digest", t);
        const o = e.sign(n, {
            canonical: !0
        });
        return O0({
            recoveryParam: o.recoveryParam,
            r: Ji("0x" + o.r.toString(16), 32),
            s: Ji("0x" + o.s.toString(16), 32)
        })
    }
    computeSharedSecret(t) {
        const e = qn().keyFromPrivate(Ve(this.privateKey)),
            n = qn().keyFromPublic(Ve(cg(t)));
        return Ji("0x" + e.derive(n.getPublic()).toString(16), 32)
    }
    static isSigningKey(t) {
        return !!(t && t._isSigningKey)
    }
}

function yE(r, t) {
    const e = O0(t),
        n = {
            r: Ve(e.r),
            s: Ve(e.s)
        };
    return "0x" + qn().recoverPubKey(Ve(r), n, e.recoveryParam).encode("hex", !1)
}

function cg(r, t) {
    const e = Ve(r);
    return e.length === 32 ? new vE(e).publicKey : e.length === 33 ? "0x" + qn().keyFromPublic(e).getPublic(!1, "hex") : e.length === 65 ? Ur(e) : Mu.throwArgumentError("invalid public or private key", "key", "[REDACTED]")
}
var np;
(function(r) {
    r[r.legacy = 0] = "legacy", r[r.eip2930 = 1] = "eip2930", r[r.eip1559 = 2] = "eip1559"
})(np || (np = {}));

function wE(r) {
    const t = cg(r);
    return N_(Fd(Hu(Fd(t, 1)), 12))
}

function bE(r, t) {
    return wE(yE(Ve(r), t))
}
const _E = "https://rpc.walletconnect.com/v1";
async function AE(r, t, e, n, o, a) {
    switch (e.t) {
        case "eip191":
            return EE(r, t, e.s);
        case "eip1271":
            return await IE(r, t, e.s, n, o, a);
        default:
            throw new Error(`verifySignature failed: Attempted to verify CacaoSignature with unknown type: ${e.t}`)
    }
}

function EE(r, t, e) {
    return bE(j0(t), e).toLowerCase() === r.toLowerCase()
}
async function IE(r, t, e, n, o, a) {
    try {
        const h = "0x1626ba7e",
            g = "0000000000000000000000000000000000000000000000000000000000000040",
            b = "0000000000000000000000000000000000000000000000000000000000000041",
            m = e.substring(2),
            _ = j0(t).substring(2),
            S = h + _ + g + b + m,
            B = await fetch(`${a||_E}/?chainId=${n}&projectId=${o}`, {
                method: "POST",
                body: JSON.stringify({
                    id: SE(),
                    jsonrpc: "2.0",
                    method: "eth_call",
                    params: [{
                        to: r,
                        data: S
                    }, "latest"]
                })
            }),
            {
                result: k
            } = await B.json();
        return k ? k.slice(0, h.length).toLowerCase() === h.toLowerCase() : !1
    } catch (h) {
        return console.error("isValidEip1271Signature: ", h), !1
    }
}

function SE() {
    return Date.now() + Math.floor(Math.random() * 1e3)
}
var xE = Object.defineProperty,
    PE = Object.defineProperties,
    ME = Object.getOwnPropertyDescriptors,
    sp = Object.getOwnPropertySymbols,
    CE = Object.prototype.hasOwnProperty,
    NE = Object.prototype.propertyIsEnumerable,
    op = (r, t, e) => t in r ? xE(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    RE = (r, t) => {
        for (var e in t || (t = {})) CE.call(t, e) && op(r, e, t[e]);
        if (sp)
            for (var e of sp(t)) NE.call(t, e) && op(r, e, t[e]);
        return r
    },
    OE = (r, t) => PE(r, ME(t));
const TE = "did:pkh:",
    Wu = r => r == null ? void 0 : r.split(":"),
    hg = r => {
        const t = r && Wu(r);
        if (t) return r.includes(TE) ? t[3] : t[1]
    },
    ap = r => {
        const t = r && Wu(r);
        if (t) return t[2] + ":" + t[3]
    },
    Ic = r => {
        const t = r && Wu(r);
        if (t) return t.pop()
    };
async function cp(r) {
    const {
        cacao: t,
        projectId: e
    } = r, {
        s: n,
        p: o
    } = t, a = ug(o, o.iss), h = Ic(o.iss);
    return await AE(h, a, n, hg(o.iss), e)
}
const ug = (r, t) => {
    const e = `${r.domain} wants you to sign in with your Ethereum account:`,
        n = Ic(t);
    if (!r.aud && !r.uri) throw new Error("Either `aud` or `uri` is required to construct the message");
    let o = r.statement || void 0;
    const a = `URI: ${r.aud||r.uri}`,
        h = `Version: ${r.version}`,
        g = `Chain ID: ${hg(t)}`,
        b = `Nonce: ${r.nonce}`,
        m = `Issued At: ${r.iat}`,
        _ = r.exp ? `Expiration Time: ${r.exp}` : void 0,
        S = r.nbf ? `Not Before: ${r.nbf}` : void 0,
        B = r.requestId ? `Request ID: ${r.requestId}` : void 0,
        k = r.resources ? `Resources:${r.resources.map(K=>`
- ${K}`).join("")}` : void 0,
        L = fc(r.resources);
    if (L) {
        const K = Bo(L);
        o = zE(o, K)
    }
    return [e, n, "", o, "", a, h, g, b, m, _, S, B, k].filter(K => K != null).join(`
`)
};

function DE(r) {
    return Buffer.from(JSON.stringify(r)).toString("base64")
}

function qE(r) {
    return JSON.parse(Buffer.from(r, "base64").toString("utf-8"))
}

function ls(r) {
    if (!r) throw new Error("No recap provided, value is undefined");
    if (!r.att) throw new Error("No `att` property found");
    const t = Object.keys(r.att);
    if (!(t != null && t.length)) throw new Error("No resources found in `att` property");
    t.forEach(e => {
        const n = r.att[e];
        if (Array.isArray(n)) throw new Error(`Resource must be an object: ${e}`);
        if (typeof n != "object") throw new Error(`Resource must be an object: ${e}`);
        if (!Object.keys(n).length) throw new Error(`Resource object is empty: ${e}`);
        Object.keys(n).forEach(o => {
            const a = n[o];
            if (!Array.isArray(a)) throw new Error(`Ability limits ${o} must be an array of objects, found: ${a}`);
            if (!a.length) throw new Error(`Value of ${o} is empty array, must be an array with objects`);
            a.forEach(h => {
                if (typeof h != "object") throw new Error(`Ability limits (${o}) must be an array of objects, found: ${h}`)
            })
        })
    })
}

function BE(r, t, e, n = {}) {
    return e == null || e.sort((o, a) => o.localeCompare(a)), {
        att: {
            [r]: UE(t, e, n)
        }
    }
}

function UE(r, t, e = {}) {
    t = t == null ? void 0 : t.sort((o, a) => o.localeCompare(a));
    const n = t.map(o => ({
        [`${r}/${o}`]: [e]
    }));
    return Object.assign({}, ...n)
}

function lg(r) {
    return ls(r), `urn:recap:${DE(r).replace(/=/g,"")}`
}

function Bo(r) {
    const t = qE(r.replace("urn:recap:", ""));
    return ls(t), t
}

function kE(r, t, e) {
    const n = BE(r, t, e);
    return lg(n)
}

function LE(r) {
    return r && r.includes("urn:recap:")
}

function $E(r, t) {
    const e = Bo(r),
        n = Bo(t),
        o = jE(e, n);
    return lg(o)
}

function jE(r, t) {
    ls(r), ls(t);
    const e = Object.keys(r.att).concat(Object.keys(t.att)).sort((o, a) => o.localeCompare(a)),
        n = {
            att: {}
        };
    return e.forEach(o => {
        var a, h;
        Object.keys(((a = r.att) == null ? void 0 : a[o]) || {}).concat(Object.keys(((h = t.att) == null ? void 0 : h[o]) || {})).sort((g, b) => g.localeCompare(b)).forEach(g => {
            var b, m;
            n.att[o] = OE(RE({}, n.att[o]), {
                [g]: ((b = r.att[o]) == null ? void 0 : b[g]) || ((m = t.att[o]) == null ? void 0 : m[g])
            })
        })
    }), n
}

function zE(r = "", t) {
    ls(t);
    const e = "I further authorize the stated URI to perform the following actions on my behalf: ";
    if (r.includes(e)) return r;
    const n = [];
    let o = 0;
    Object.keys(t.att).forEach(g => {
        const b = Object.keys(t.att[g]).map(S => ({
            ability: S.split("/")[0],
            action: S.split("/")[1]
        }));
        b.sort((S, B) => S.action.localeCompare(B.action));
        const m = {};
        b.forEach(S => {
            m[S.ability] || (m[S.ability] = []), m[S.ability].push(S.action)
        });
        const _ = Object.keys(m).map(S => (o++, `(${o}) '${S}': '${m[S].join("', '")}' for '${g}'.`));
        n.push(_.join(", ").replace(".,", "."))
    });
    const a = n.join(" "),
        h = `${e}${a}`;
    return `${r?r+" ":""}${h}`
}

function hp(r) {
    var t;
    const e = Bo(r);
    ls(e);
    const n = (t = e.att) == null ? void 0 : t.eip155;
    return n ? Object.keys(n).map(o => o.split("/")[1]) : []
}

function up(r) {
    const t = Bo(r);
    ls(t);
    const e = [];
    return Object.values(t.att).forEach(n => {
        Object.values(n).forEach(o => {
            var a;
            (a = o == null ? void 0 : o[0]) != null && a.chains && e.push(o[0].chains)
        })
    }), [...new Set(e.flat())]
}

function fc(r) {
    if (!r) return;
    const t = r == null ? void 0 : r[r.length - 1];
    return LE(t) ? t : void 0
}
const fg = "base10",
    xr = "base16",
    Cu = "base64pad",
    Ju = "utf8",
    dg = 0,
    yn = 1,
    FE = 0,
    lp = 1,
    Nu = 12,
    Yu = 32;

function HE() {
    const r = o0.generateKeyPair();
    return {
        privateKey: Pr(r.secretKey, xr),
        publicKey: Pr(r.publicKey, xr)
    }
}

function Ru() {
    const r = Mc.randomBytes(Yu);
    return Pr(r, xr)
}

function KE(r, t) {
    const e = o0.sharedKey($r(r, xr), $r(t, xr), !0),
        n = new C2(Lu.SHA256, e).expand(Yu);
    return Pr(n, xr)
}

function dc(r) {
    const t = Lu.hash($r(r, xr));
    return Pr(t, xr)
}

function hs(r) {
    const t = Lu.hash($r(r, Ju));
    return Pr(t, xr)
}

function VE(r) {
    return $r(`${r}`, fg)
}

function Ko(r) {
    return Number(Pr(r, fg))
}

function GE(r) {
    const t = VE(typeof r.type < "u" ? r.type : dg);
    if (Ko(t) === yn && typeof r.senderPublicKey > "u") throw new Error("Missing sender public key for type 1 envelope");
    const e = typeof r.senderPublicKey < "u" ? $r(r.senderPublicKey, xr) : void 0,
        n = typeof r.iv < "u" ? $r(r.iv, xr) : Mc.randomBytes(Nu),
        o = new a0.ChaCha20Poly1305($r(r.symKey, xr)).seal(n, $r(r.message, Ju));
    return WE({
        type: t,
        sealed: o,
        iv: n,
        senderPublicKey: e
    })
}

function QE(r) {
    const t = new a0.ChaCha20Poly1305($r(r.symKey, xr)),
        {
            sealed: e,
            iv: n
        } = Sc(r.encoded),
        o = t.open(n, e);
    if (o === null) throw new Error("Failed to decrypt");
    return Pr(o, Ju)
}

function WE(r) {
    if (Ko(r.type) === yn) {
        if (typeof r.senderPublicKey > "u") throw new Error("Missing sender public key for type 1 envelope");
        return Pr(_u([r.type, r.senderPublicKey, r.iv, r.sealed]), Cu)
    }
    return Pr(_u([r.type, r.iv, r.sealed]), Cu)
}

function Sc(r) {
    const t = $r(r, Cu),
        e = t.slice(FE, lp),
        n = lp;
    if (Ko(e) === yn) {
        const g = n + Yu,
            b = g + Nu,
            m = t.slice(n, g),
            _ = t.slice(g, b),
            S = t.slice(b);
        return {
            type: e,
            sealed: S,
            iv: _,
            senderPublicKey: m
        }
    }
    const o = n + Nu,
        a = t.slice(n, o),
        h = t.slice(o);
    return {
        type: e,
        sealed: h,
        iv: a
    }
}

function JE(r, t) {
    const e = Sc(r);
    return pg({
        type: Ko(e.type),
        senderPublicKey: typeof e.senderPublicKey < "u" ? Pr(e.senderPublicKey, xr) : void 0,
        receiverPublicKey: t == null ? void 0 : t.receiverPublicKey
    })
}

function pg(r) {
    const t = (r == null ? void 0 : r.type) || dg;
    if (t === yn) {
        if (typeof(r == null ? void 0 : r.senderPublicKey) > "u") throw new Error("missing sender public key");
        if (typeof(r == null ? void 0 : r.receiverPublicKey) > "u") throw new Error("missing receiver public key")
    }
    return {
        type: t,
        senderPublicKey: r == null ? void 0 : r.senderPublicKey,
        receiverPublicKey: r == null ? void 0 : r.receiverPublicKey
    }
}

function fp(r) {
    return r.type === yn && typeof r.senderPublicKey == "string" && typeof r.receiverPublicKey == "string"
}
const YE = "irn";

function Ou(r) {
    return (r == null ? void 0 : r.relay) || {
        protocol: YE
    }
}

function Po(r) {
    const t = M3[r];
    if (typeof t > "u") throw new Error(`Relay Protocol not supported: ${r}`);
    return t
}
var XE = Object.defineProperty,
    ZE = Object.defineProperties,
    t5 = Object.getOwnPropertyDescriptors,
    dp = Object.getOwnPropertySymbols,
    e5 = Object.prototype.hasOwnProperty,
    r5 = Object.prototype.propertyIsEnumerable,
    pp = (r, t, e) => t in r ? XE(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    gp = (r, t) => {
        for (var e in t || (t = {})) e5.call(t, e) && pp(r, e, t[e]);
        if (dp)
            for (var e of dp(t)) r5.call(t, e) && pp(r, e, t[e]);
        return r
    },
    i5 = (r, t) => ZE(r, t5(t));

function n5(r, t = "-") {
    const e = {},
        n = "relay" + t;
    return Object.keys(r).forEach(o => {
        if (o.startsWith(n)) {
            const a = o.replace(n, ""),
                h = r[o];
            e[a] = h
        }
    }), e
}

function mp(r) {
    r = r.includes("wc://") ? r.replace("wc://", "") : r, r = r.includes("wc:") ? r.replace("wc:", "") : r;
    const t = r.indexOf(":"),
        e = r.indexOf("?") !== -1 ? r.indexOf("?") : void 0,
        n = r.substring(0, t),
        o = r.substring(t + 1, e).split("@"),
        a = typeof e < "u" ? r.substring(e) : "",
        h = gc.parse(a),
        g = typeof h.methods == "string" ? h.methods.split(",") : void 0;
    return {
        protocol: n,
        topic: s5(o[0]),
        version: parseInt(o[1], 10),
        symKey: h.symKey,
        relay: n5(h),
        methods: g,
        expiryTimestamp: h.expiryTimestamp ? parseInt(h.expiryTimestamp, 10) : void 0
    }
}

function s5(r) {
    return r.startsWith("//") ? r.substring(2) : r
}

function o5(r, t = "-") {
    const e = "relay",
        n = {};
    return Object.keys(r).forEach(o => {
        const a = e + t + o;
        r[o] && (n[a] = r[o])
    }), n
}

function a5(r) {
    return `${r.protocol}:${r.topic}@${r.version}?` + gc.stringify(gp(i5(gp({
        symKey: r.symKey
    }, o5(r.relay)), {
        expiryTimestamp: r.expiryTimestamp
    }), r.methods ? {
        methods: r.methods.join(",")
    } : {}))
}

function Ys(r) {
    const t = [];
    return r.forEach(e => {
        const [n, o] = e.split(":");
        t.push(`${n}:${o}`)
    }), t
}

function c5(r) {
    const t = [];
    return Object.values(r).forEach(e => {
        t.push(...Ys(e.accounts))
    }), t
}

function h5(r, t) {
    const e = [];
    return Object.values(r).forEach(n => {
        Ys(n.accounts).includes(t) && e.push(...n.methods)
    }), e
}

function u5(r, t) {
    const e = [];
    return Object.values(r).forEach(n => {
        Ys(n.accounts).includes(t) && e.push(...n.events)
    }), e
}

function Xu(r) {
    return r.includes(":")
}

function Mo(r) {
    return Xu(r) ? r.split(":")[0] : r
}

function l5(r) {
    const t = {};
    return r == null || r.forEach(e => {
        const [n, o] = e.split(":");
        t[n] || (t[n] = {
            accounts: [],
            chains: [],
            events: []
        }), t[n].accounts.push(e), t[n].chains.push(`${n}:${o}`)
    }), t
}

function vp(r, t) {
    t = t.map(n => n.replace("did:pkh:", ""));
    const e = l5(t);
    for (const [n, o] of Object.entries(e)) o.methods ? o.methods = cc(o.methods, r) : o.methods = r, o.events = ["chainChanged", "accountsChanged"];
    return e
}
const f5 = {
        INVALID_METHOD: {
            message: "Invalid method.",
            code: 1001
        },
        INVALID_EVENT: {
            message: "Invalid event.",
            code: 1002
        },
        INVALID_UPDATE_REQUEST: {
            message: "Invalid update request.",
            code: 1003
        },
        INVALID_EXTEND_REQUEST: {
            message: "Invalid extend request.",
            code: 1004
        },
        INVALID_SESSION_SETTLE_REQUEST: {
            message: "Invalid session settle request.",
            code: 1005
        },
        UNAUTHORIZED_METHOD: {
            message: "Unauthorized method.",
            code: 3001
        },
        UNAUTHORIZED_EVENT: {
            message: "Unauthorized event.",
            code: 3002
        },
        UNAUTHORIZED_UPDATE_REQUEST: {
            message: "Unauthorized update request.",
            code: 3003
        },
        UNAUTHORIZED_EXTEND_REQUEST: {
            message: "Unauthorized extend request.",
            code: 3004
        },
        USER_REJECTED: {
            message: "User rejected.",
            code: 5e3
        },
        USER_REJECTED_CHAINS: {
            message: "User rejected chains.",
            code: 5001
        },
        USER_REJECTED_METHODS: {
            message: "User rejected methods.",
            code: 5002
        },
        USER_REJECTED_EVENTS: {
            message: "User rejected events.",
            code: 5003
        },
        UNSUPPORTED_CHAINS: {
            message: "Unsupported chains.",
            code: 5100
        },
        UNSUPPORTED_METHODS: {
            message: "Unsupported methods.",
            code: 5101
        },
        UNSUPPORTED_EVENTS: {
            message: "Unsupported events.",
            code: 5102
        },
        UNSUPPORTED_ACCOUNTS: {
            message: "Unsupported accounts.",
            code: 5103
        },
        UNSUPPORTED_NAMESPACE_KEY: {
            message: "Unsupported namespace key.",
            code: 5104
        },
        USER_DISCONNECTED: {
            message: "User disconnected.",
            code: 6e3
        },
        SESSION_SETTLEMENT_FAILED: {
            message: "Session settlement failed.",
            code: 7e3
        },
        WC_METHOD_UNSUPPORTED: {
            message: "Unsupported wc_ method.",
            code: 10001
        }
    },
    d5 = {
        NOT_INITIALIZED: {
            message: "Not initialized.",
            code: 1
        },
        NO_MATCHING_KEY: {
            message: "No matching key.",
            code: 2
        },
        RESTORE_WILL_OVERRIDE: {
            message: "Restore will override.",
            code: 3
        },
        RESUBSCRIBED: {
            message: "Resubscribed.",
            code: 4
        },
        MISSING_OR_INVALID: {
            message: "Missing or invalid.",
            code: 5
        },
        EXPIRED: {
            message: "Expired.",
            code: 6
        },
        UNKNOWN_TYPE: {
            message: "Unknown type.",
            code: 7
        },
        MISMATCHED_TOPIC: {
            message: "Mismatched topic.",
            code: 8
        },
        NON_CONFORMING_NAMESPACES: {
            message: "Non conforming namespaces.",
            code: 9
        }
    };

function nt(r, t) {
    const {
        message: e,
        code: n
    } = d5[r];
    return {
        message: t ? `${e} ${t}` : e,
        code: n
    }
}

function Ne(r, t) {
    const {
        message: e,
        code: n
    } = f5[r];
    return {
        message: t ? `${e} ${t}` : e,
        code: n
    }
}

function tn(r, t) {
    return !!Array.isArray(r)
}

function Uo(r) {
    return Object.getPrototypeOf(r) === Object.prototype && Object.keys(r).length
}

function kr(r) {
    return typeof r > "u"
}

function Ye(r, t) {
    return t && kr(r) ? !0 : typeof r == "string" && !!r.trim().length
}

function Zu(r, t) {
    return typeof r == "number" && !isNaN(r)
}

function p5(r, t) {
    const {
        requiredNamespaces: e
    } = t, n = Object.keys(r.namespaces), o = Object.keys(e);
    let a = !0;
    return cs(o, n) ? (n.forEach(h => {
        const {
            accounts: g,
            methods: b,
            events: m
        } = r.namespaces[h], _ = Ys(g), S = e[h];
        (!cs(I0(h, S), _) || !cs(S.methods, b) || !cs(S.events, m)) && (a = !1)
    }), a) : !1
}

function xc(r) {
    return Ye(r, !1) && r.includes(":") ? r.split(":").length === 2 : !1
}

function g5(r) {
    if (Ye(r, !1) && r.includes(":")) {
        const t = r.split(":");
        if (t.length === 3) {
            const e = t[0] + ":" + t[1];
            return !!t[2] && xc(e)
        }
    }
    return !1
}

function m5(r) {
    if (Ye(r, !1)) try {
        return typeof new URL(r) < "u"
    } catch {
        return !1
    }
    return !1
}

function v5(r) {
    var t;
    return (t = r == null ? void 0 : r.proposer) == null ? void 0 : t.publicKey
}

function y5(r) {
    return r == null ? void 0 : r.topic
}

function w5(r, t) {
    let e = null;
    return Ye(r == null ? void 0 : r.publicKey, !1) || (e = nt("MISSING_OR_INVALID", `${t} controller public key should be a string`)), e
}

function yp(r) {
    let t = !0;
    return tn(r) ? r.length && (t = r.every(e => Ye(e, !1))) : t = !1, t
}

function b5(r, t, e) {
    let n = null;
    return tn(t) && t.length ? t.forEach(o => {
        n || xc(o) || (n = Ne("UNSUPPORTED_CHAINS", `${e}, chain ${o} should be a string and conform to "namespace:chainId" format`))
    }) : xc(r) || (n = Ne("UNSUPPORTED_CHAINS", `${e}, chains must be defined as "namespace:chainId" e.g. "eip155:1": {...} in the namespace key OR as an array of CAIP-2 chainIds e.g. eip155: { chains: ["eip155:1", "eip155:5"] }`)), n
}

function _5(r, t, e) {
    let n = null;
    return Object.entries(r).forEach(([o, a]) => {
        if (n) return;
        const h = b5(o, I0(o, a), `${t} ${e}`);
        h && (n = h)
    }), n
}

function A5(r, t) {
    let e = null;
    return tn(r) ? r.forEach(n => {
        e || g5(n) || (e = Ne("UNSUPPORTED_ACCOUNTS", `${t}, account ${n} should be a string and conform to "namespace:chainId:address" format`))
    }) : e = Ne("UNSUPPORTED_ACCOUNTS", `${t}, accounts should be an array of strings conforming to "namespace:chainId:address" format`), e
}

function E5(r, t) {
    let e = null;
    return Object.values(r).forEach(n => {
        if (e) return;
        const o = A5(n == null ? void 0 : n.accounts, `${t} namespace`);
        o && (e = o)
    }), e
}

function I5(r, t) {
    let e = null;
    return yp(r == null ? void 0 : r.methods) ? yp(r == null ? void 0 : r.events) || (e = Ne("UNSUPPORTED_EVENTS", `${t}, events should be an array of strings or empty array for no events`)) : e = Ne("UNSUPPORTED_METHODS", `${t}, methods should be an array of strings or empty array for no methods`), e
}

function gg(r, t) {
    let e = null;
    return Object.values(r).forEach(n => {
        if (e) return;
        const o = I5(n, `${t}, namespace`);
        o && (e = o)
    }), e
}

function S5(r, t, e) {
    let n = null;
    if (r && Uo(r)) {
        const o = gg(r, t);
        o && (n = o);
        const a = _5(r, t, e);
        a && (n = a)
    } else n = nt("MISSING_OR_INVALID", `${t}, ${e} should be an object with data`);
    return n
}

function hu(r, t) {
    let e = null;
    if (r && Uo(r)) {
        const n = gg(r, t);
        n && (e = n);
        const o = E5(r, t);
        o && (e = o)
    } else e = nt("MISSING_OR_INVALID", `${t}, namespaces should be an object with data`);
    return e
}

function mg(r) {
    return Ye(r.protocol, !0)
}

function x5(r, t) {
    let e = !1;
    return r ? r && tn(r) && r.length && r.forEach(n => {
        e = mg(n)
    }) : e = !0, e
}

function P5(r) {
    return typeof r == "number"
}

function Br(r) {
    return typeof r < "u" && typeof r !== null
}

function M5(r) {
    return !(!r || typeof r != "object" || !r.code || !Zu(r.code) || !r.message || !Ye(r.message, !1))
}

function C5(r) {
    return !(kr(r) || !Ye(r.method, !1))
}

function N5(r) {
    return !(kr(r) || kr(r.result) && kr(r.error) || !Zu(r.id) || !Ye(r.jsonrpc, !1))
}

function R5(r) {
    return !(kr(r) || !Ye(r.name, !1))
}

function wp(r, t) {
    return !(!xc(t) || !c5(r).includes(t))
}

function O5(r, t, e) {
    return Ye(e, !1) ? h5(r, t).includes(e) : !1
}

function T5(r, t, e) {
    return Ye(e, !1) ? u5(r, t).includes(e) : !1
}

function bp(r, t, e) {
    let n = null;
    const o = D5(r),
        a = q5(t),
        h = Object.keys(o),
        g = Object.keys(a),
        b = _p(Object.keys(r)),
        m = _p(Object.keys(t)),
        _ = b.filter(S => !m.includes(S));
    return _.length && (n = nt("NON_CONFORMING_NAMESPACES", `${e} namespaces keys don't satisfy requiredNamespaces.
      Required: ${_.toString()}
      Received: ${Object.keys(t).toString()}`)), cs(h, g) || (n = nt("NON_CONFORMING_NAMESPACES", `${e} namespaces chains don't satisfy required namespaces.
      Required: ${h.toString()}
      Approved: ${g.toString()}`)), Object.keys(t).forEach(S => {
        if (!S.includes(":") || n) return;
        const B = Ys(t[S].accounts);
        B.includes(S) || (n = nt("NON_CONFORMING_NAMESPACES", `${e} namespaces accounts don't satisfy namespace accounts for ${S}
        Required: ${S}
        Approved: ${B.toString()}`))
    }), h.forEach(S => {
        n || (cs(o[S].methods, a[S].methods) ? cs(o[S].events, a[S].events) || (n = nt("NON_CONFORMING_NAMESPACES", `${e} namespaces events don't satisfy namespace events for ${S}`)) : n = nt("NON_CONFORMING_NAMESPACES", `${e} namespaces methods don't satisfy namespace methods for ${S}`))
    }), n
}

function D5(r) {
    const t = {};
    return Object.keys(r).forEach(e => {
        var n;
        e.includes(":") ? t[e] = r[e] : (n = r[e].chains) == null || n.forEach(o => {
            t[o] = {
                methods: r[e].methods,
                events: r[e].events
            }
        })
    }), t
}

function _p(r) {
    return [...new Set(r.map(t => t.includes(":") ? t.split(":")[0] : t))]
}

function q5(r) {
    const t = {};
    return Object.keys(r).forEach(e => {
        if (e.includes(":")) t[e] = r[e];
        else {
            const n = Ys(r[e].accounts);
            n == null || n.forEach(o => {
                t[o] = {
                    accounts: r[e].accounts.filter(a => a.includes(`${o}:`)),
                    methods: r[e].methods,
                    events: r[e].events
                }
            })
        }
    }), t
}

function B5(r, t) {
    return Zu(r) && r <= t.max && r >= t.min
}

function Ap() {
    const r = Fo();
    return new Promise(t => {
        switch (r) {
            case Jr.browser:
                t(U5());
                break;
            case Jr.reactNative:
                t(k5());
                break;
            case Jr.node:
                t(L5());
                break;
            default:
                t(!0)
        }
    })
}

function U5() {
    return Vs() && (navigator == null ? void 0 : navigator.onLine)
}
async function k5() {
    if (Ks() && typeof global < "u" && global != null && global.NetInfo) {
        const r = await (global == null ? void 0 : global.NetInfo.fetch());
        return r == null ? void 0 : r.isConnected
    }
    return !0
}

function L5() {
    return !0
}

function $5(r) {
    switch (Fo()) {
        case Jr.browser:
            j5(r);
            break;
        case Jr.reactNative:
            z5(r);
            break
    }
}

function j5(r) {
    !Ks() && Vs() && (window.addEventListener("online", () => r(!0)), window.addEventListener("offline", () => r(!1)))
}

function z5(r) {
    Ks() && typeof global < "u" && global != null && global.NetInfo && (global == null || global.NetInfo.addEventListener(t => r(t == null ? void 0 : t.isConnected)))
}
const uu = {};
class Ao {
    static get(t) {
        return uu[t]
    }
    static set(t, e) {
        uu[t] = e
    }
    static delete(t) {
        delete uu[t]
    }
}
class F5 extends ds {
    constructor(t) {
        super(), this.opts = t, this.protocol = "wc", this.version = 2
    }
}
class H5 extends ds {
    constructor(t, e) {
        super(), this.core = t, this.logger = e, this.records = new Map
    }
}
class K5 {
    constructor(t, e) {
        this.logger = t, this.core = e
    }
}
let V5 = class extends ds {
        constructor(t, e) {
            super(), this.relayer = t, this.logger = e
        }
    },
    G5 = class extends ds {
        constructor(t) {
            super()
        }
    },
    Q5 = class {
        constructor(t, e, n, o) {
            this.core = t, this.logger = e, this.name = n
        }
    };
class W5 extends ds {
    constructor(t, e) {
        super(), this.relayer = t, this.logger = e
    }
}
let J5 = class extends ds {
        constructor(t, e) {
            super(), this.core = t, this.logger = e
        }
    },
    Y5 = class {
        constructor(t, e) {
            this.projectId = t, this.logger = e
        }
    },
    X5 = class {
        constructor(t, e) {
            this.projectId = t, this.logger = e
        }
    },
    Z5 = class {
        constructor(t) {
            this.opts = t, this.protocol = "wc", this.version = 2
        }
    };
class tI {
    constructor(t) {
        this.client = t
    }
}
var eI = {
    SUDO_GID: "0",
    USER: "buildbot",
    npm_config_user_agent: "npm/9.6.7 node/v18.17.1 linux x64 workspaces/false",
    CI: "true",
    CF_PAGES_COMMIT_SHA: "ddb0dfb53b40d36209c1baa9a42d57b3f077b953",
    ROOT_DIR: "/",
    npm_node_execpath: "/opt/buildhome/.asdf/installs/nodejs/18.17.1/bin/node",
    SHLVL: "1",
    npm_config_noproxy: "",
    HOME: "/opt/buildhome",
    VITE_DEPOSIT_ADDRESS: "0x94d9afC98EB98b02eBF7685da649b3e62d1CEf0d",
    npm_package_json: "/opt/buildhome/repo/package.json",
    VITE_UNLOCK_CODE: "BUYCASINO",
    NODE_OPTIONS: "--max_old_space_size=4096",
    npm_config_userconfig: "/opt/buildhome/.npmrc",
    npm_config_local_prefix: "/opt/buildhome/repo",
    PKG_EXECPATH: "/opt/build/bin/build",
    CFP_TURNSTILE_SECRET_KEY: "0x4AAAAAAAi1y9FMu1ckBczxnwN07_X5Sxk",
    COLOR: "0",
    CF_PAGES_BRANCH: "main",
    npm_config_metrics_registry: "https://registry.npmjs.org/",
    SUDO_UID: "0",
    LOGNAME: "buildbot",
    VITE_X_API_KEY: "7c5e3430-8617-495d-be5d-6b056ae2a073",
    npm_config_prefix: "/opt/buildhome/.asdf/installs/nodejs/18.17.1",
    TERM: "unknown",
    npm_config_cache: "/opt/buildhome/.npm",
    npm_config_node_gyp: "/opt/buildhome/.asdf/installs/nodejs/18.17.1/lib/node_modules/npm/node_modules/node-gyp/bin/node-gyp.js",
    PATH: "/opt/buildhome/repo/node_modules/.bin:/opt/buildhome/node_modules/.bin:/opt/node_modules/.bin:/node_modules/.bin:/opt/buildhome/.asdf/installs/nodejs/18.17.1/lib/node_modules/npm/node_modules/@npmcli/run-script/lib/node-gyp-bin:/opt/buildhome/.asdf/plugins/nodejs/shims:/opt/buildhome/.asdf/installs/nodejs/18.17.1/bin:/opt/buildhome/.asdf/shims:/opt/buildhome/.asdf/bin:/opt/buildhome/.swiftenv/bin:/opt/buildhome/.swiftenv/shims:/opt/buildhome/.php:/opt/buildhome/.binrc/bin:/usr/local/rvm/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/buildhome/.cask/bin:/opt/buildhome/.gimme/bin:/opt/buildhome/.dotnet/tools:/opt/buildhome/.dotnet:/opt/buildhome/.local/bin",
    CF_PAGES_URL: "https://910c54cd.cc-pages-presale.pages.dev",
    NODE: "/opt/buildhome/.asdf/installs/nodejs/18.17.1/bin/node",
    npm_package_name: "paladin",
    npm_lifecycle_script: "tsc && vite build",
    SUDO_COMMAND: "/opt/build/bin/build npm run build",
    VITE_API_BASE_URL: "https://tokenapi.cryptocasino.com/",
    SHELL: "/bin/bash",
    npm_package_version: "0.0.0",
    npm_lifecycle_event: "build",
    REPO_DIR: "/opt/buildhome/repo",
    SUDO_USER: "root",
    VITE_TURNSTILE_SITE_KEY: "0x4AAAAAAAi1ywfCZyROoRwy",
    npm_config_globalconfig: "/opt/buildhome/.asdf/installs/nodejs/18.17.1/etc/npmrc",
    npm_config_init_module: "/opt/buildhome/.npm-init.js",
    PWD: "/opt/buildhome/repo",
    npm_execpath: "/opt/buildhome/.asdf/installs/nodejs/18.17.1/lib/node_modules/npm/bin/npm-cli.js",
    CF_PAGES: "1",
    npm_config_global_prefix: "/opt/buildhome/.asdf/installs/nodejs/18.17.1",
    npm_command: "run-script",
    CFP_UNLOCK_CODE: "BUYCASINO",
    INIT_CWD: "/opt/buildhome/repo",
    EDITOR: "vi",
    NODE_ENV: "production"
};

function rI(r, t) {
    if (r.length >= 255) throw new TypeError("Alphabet too long");
    for (var e = new Uint8Array(256), n = 0; n < e.length; n++) e[n] = 255;
    for (var o = 0; o < r.length; o++) {
        var a = r.charAt(o),
            h = a.charCodeAt(0);
        if (e[h] !== 255) throw new TypeError(a + " is ambiguous");
        e[h] = o
    }
    var g = r.length,
        b = r.charAt(0),
        m = Math.log(g) / Math.log(256),
        _ = Math.log(256) / Math.log(g);

    function S(L) {
        if (L instanceof Uint8Array || (ArrayBuffer.isView(L) ? L = new Uint8Array(L.buffer, L.byteOffset, L.byteLength) : Array.isArray(L) && (L = Uint8Array.from(L))), !(L instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
        if (L.length === 0) return "";
        for (var K = 0, Q = 0, et = 0, at = L.length; et !== at && L[et] === 0;) et++, K++;
        for (var ut = (at - et) * _ + 1 >>> 0, ft = new Uint8Array(ut); et !== at;) {
            for (var st = L[et], ot = 0, it = ut - 1;
                (st !== 0 || ot < Q) && it !== -1; it--, ot++) st += 256 * ft[it] >>> 0, ft[it] = st % g >>> 0, st = st / g >>> 0;
            if (st !== 0) throw new Error("Non-zero carry");
            Q = ot, et++
        }
        for (var mt = ut - Q; mt !== ut && ft[mt] === 0;) mt++;
        for (var Zt = b.repeat(K); mt < ut; ++mt) Zt += r.charAt(ft[mt]);
        return Zt
    }

    function B(L) {
        if (typeof L != "string") throw new TypeError("Expected String");
        if (L.length === 0) return new Uint8Array;
        var K = 0;
        if (L[K] !== " ") {
            for (var Q = 0, et = 0; L[K] === b;) Q++, K++;
            for (var at = (L.length - K) * m + 1 >>> 0, ut = new Uint8Array(at); L[K];) {
                var ft = e[L.charCodeAt(K)];
                if (ft === 255) return;
                for (var st = 0, ot = at - 1;
                    (ft !== 0 || st < et) && ot !== -1; ot--, st++) ft += g * ut[ot] >>> 0, ut[ot] = ft % 256 >>> 0, ft = ft / 256 >>> 0;
                if (ft !== 0) throw new Error("Non-zero carry");
                et = st, K++
            }
            if (L[K] !== " ") {
                for (var it = at - et; it !== at && ut[it] === 0;) it++;
                for (var mt = new Uint8Array(Q + (at - it)), Zt = Q; it !== at;) mt[Zt++] = ut[it++];
                return mt
            }
        }
    }

    function k(L) {
        var K = B(L);
        if (K) return K;
        throw new Error(`Non-${t} character`)
    }
    return {
        encode: S,
        decodeUnsafe: B,
        decode: k
    }
}
var iI = rI,
    nI = iI;
const vg = r => {
        if (r instanceof Uint8Array && r.constructor.name === "Uint8Array") return r;
        if (r instanceof ArrayBuffer) return new Uint8Array(r);
        if (ArrayBuffer.isView(r)) return new Uint8Array(r.buffer, r.byteOffset, r.byteLength);
        throw new Error("Unknown type, must be binary type")
    },
    sI = r => new TextEncoder().encode(r),
    oI = r => new TextDecoder().decode(r);
let aI = class {
    constructor(t, e, n) {
        this.name = t, this.prefix = e, this.baseEncode = n
    }
    encode(t) {
        if (t instanceof Uint8Array) return `${this.prefix}${this.baseEncode(t)}`;
        throw Error("Unknown type, must be binary type")
    }
};
class cI {
    constructor(t, e, n) {
        if (this.name = t, this.prefix = e, e.codePointAt(0) === void 0) throw new Error("Invalid prefix character");
        this.prefixCodePoint = e.codePointAt(0), this.baseDecode = n
    }
    decode(t) {
        if (typeof t == "string") {
            if (t.codePointAt(0) !== this.prefixCodePoint) throw Error(`Unable to decode multibase string ${JSON.stringify(t)}, ${this.name} decoder only supports inputs prefixed with ${this.prefix}`);
            return this.baseDecode(t.slice(this.prefix.length))
        } else throw Error("Can only multibase decode strings")
    }
    or(t) {
        return yg(this, t)
    }
}
class hI {
    constructor(t) {
        this.decoders = t
    }
    or(t) {
        return yg(this, t)
    }
    decode(t) {
        const e = t[0],
            n = this.decoders[e];
        if (n) return n.decode(t);
        throw RangeError(`Unable to decode multibase string ${JSON.stringify(t)}, only inputs prefixed with ${Object.keys(this.decoders)} are supported`)
    }
}
const yg = (r, t) => new hI({ ...r.decoders || {
        [r.prefix]: r
    },
    ...t.decoders || {
        [t.prefix]: t
    }
});
let uI = class {
    constructor(t, e, n, o) {
        this.name = t, this.prefix = e, this.baseEncode = n, this.baseDecode = o, this.encoder = new aI(t, e, n), this.decoder = new cI(t, e, o)
    }
    encode(t) {
        return this.encoder.encode(t)
    }
    decode(t) {
        return this.decoder.decode(t)
    }
};
const Dc = ({
        name: r,
        prefix: t,
        encode: e,
        decode: n
    }) => new uI(r, t, e, n),
    Vo = ({
        prefix: r,
        name: t,
        alphabet: e
    }) => {
        const {
            encode: n,
            decode: o
        } = nI(e, t);
        return Dc({
            prefix: r,
            name: t,
            encode: n,
            decode: a => vg(o(a))
        })
    },
    lI = (r, t, e, n) => {
        const o = {};
        for (let _ = 0; _ < t.length; ++_) o[t[_]] = _;
        let a = r.length;
        for (; r[a - 1] === "=";) --a;
        const h = new Uint8Array(a * e / 8 | 0);
        let g = 0,
            b = 0,
            m = 0;
        for (let _ = 0; _ < a; ++_) {
            const S = o[r[_]];
            if (S === void 0) throw new SyntaxError(`Non-${n} character`);
            b = b << e | S, g += e, g >= 8 && (g -= 8, h[m++] = 255 & b >> g)
        }
        if (g >= e || 255 & b << 8 - g) throw new SyntaxError("Unexpected end of data");
        return h
    },
    fI = (r, t, e) => {
        const n = t[t.length - 1] === "=",
            o = (1 << e) - 1;
        let a = "",
            h = 0,
            g = 0;
        for (let b = 0; b < r.length; ++b)
            for (g = g << 8 | r[b], h += 8; h > e;) h -= e, a += t[o & g >> h];
        if (h && (a += t[o & g << e - h]), n)
            for (; a.length * e & 7;) a += "=";
        return a
    },
    pr = ({
        name: r,
        prefix: t,
        bitsPerChar: e,
        alphabet: n
    }) => Dc({
        prefix: t,
        name: r,
        encode(o) {
            return fI(o, n, e)
        },
        decode(o) {
            return lI(o, n, e, r)
        }
    }),
    dI = Dc({
        prefix: "\0",
        name: "identity",
        encode: r => oI(r),
        decode: r => sI(r)
    });
var pI = Object.freeze({
    __proto__: null,
    identity: dI
});
const gI = pr({
    prefix: "0",
    name: "base2",
    alphabet: "01",
    bitsPerChar: 1
});
var mI = Object.freeze({
    __proto__: null,
    base2: gI
});
const vI = pr({
    prefix: "7",
    name: "base8",
    alphabet: "01234567",
    bitsPerChar: 3
});
var yI = Object.freeze({
    __proto__: null,
    base8: vI
});
const wI = Vo({
    prefix: "9",
    name: "base10",
    alphabet: "0123456789"
});
var bI = Object.freeze({
    __proto__: null,
    base10: wI
});
const _I = pr({
        prefix: "f",
        name: "base16",
        alphabet: "0123456789abcdef",
        bitsPerChar: 4
    }),
    AI = pr({
        prefix: "F",
        name: "base16upper",
        alphabet: "0123456789ABCDEF",
        bitsPerChar: 4
    });
var EI = Object.freeze({
    __proto__: null,
    base16: _I,
    base16upper: AI
});
const II = pr({
        prefix: "b",
        name: "base32",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567",
        bitsPerChar: 5
    }),
    SI = pr({
        prefix: "B",
        name: "base32upper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
        bitsPerChar: 5
    }),
    xI = pr({
        prefix: "c",
        name: "base32pad",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567=",
        bitsPerChar: 5
    }),
    PI = pr({
        prefix: "C",
        name: "base32padupper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567=",
        bitsPerChar: 5
    }),
    MI = pr({
        prefix: "v",
        name: "base32hex",
        alphabet: "0123456789abcdefghijklmnopqrstuv",
        bitsPerChar: 5
    }),
    CI = pr({
        prefix: "V",
        name: "base32hexupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV",
        bitsPerChar: 5
    }),
    NI = pr({
        prefix: "t",
        name: "base32hexpad",
        alphabet: "0123456789abcdefghijklmnopqrstuv=",
        bitsPerChar: 5
    }),
    RI = pr({
        prefix: "T",
        name: "base32hexpadupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV=",
        bitsPerChar: 5
    }),
    OI = pr({
        prefix: "h",
        name: "base32z",
        alphabet: "ybndrfg8ejkmcpqxot1uwisza345h769",
        bitsPerChar: 5
    });
var TI = Object.freeze({
    __proto__: null,
    base32: II,
    base32upper: SI,
    base32pad: xI,
    base32padupper: PI,
    base32hex: MI,
    base32hexupper: CI,
    base32hexpad: NI,
    base32hexpadupper: RI,
    base32z: OI
});
const DI = Vo({
        prefix: "k",
        name: "base36",
        alphabet: "0123456789abcdefghijklmnopqrstuvwxyz"
    }),
    qI = Vo({
        prefix: "K",
        name: "base36upper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    });
var BI = Object.freeze({
    __proto__: null,
    base36: DI,
    base36upper: qI
});
const UI = Vo({
        name: "base58btc",
        prefix: "z",
        alphabet: "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    }),
    kI = Vo({
        name: "base58flickr",
        prefix: "Z",
        alphabet: "123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ"
    });
var LI = Object.freeze({
    __proto__: null,
    base58btc: UI,
    base58flickr: kI
});
const $I = pr({
        prefix: "m",
        name: "base64",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        bitsPerChar: 6
    }),
    jI = pr({
        prefix: "M",
        name: "base64pad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        bitsPerChar: 6
    }),
    zI = pr({
        prefix: "u",
        name: "base64url",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
        bitsPerChar: 6
    }),
    FI = pr({
        prefix: "U",
        name: "base64urlpad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=",
        bitsPerChar: 6
    });
var HI = Object.freeze({
    __proto__: null,
    base64: $I,
    base64pad: jI,
    base64url: zI,
    base64urlpad: FI
});
const wg = Array.from("🚀🪐☄🛰🌌🌑🌒🌓🌔🌕🌖🌗🌘🌍🌏🌎🐉☀💻🖥💾💿😂❤😍🤣😊🙏💕😭😘👍😅👏😁🔥🥰💔💖💙😢🤔😆🙄💪😉☺👌🤗💜😔😎😇🌹🤦🎉💞✌✨🤷😱😌🌸🙌😋💗💚😏💛🙂💓🤩😄😀🖤😃💯🙈👇🎶😒🤭❣😜💋👀😪😑💥🙋😞😩😡🤪👊🥳😥🤤👉💃😳✋😚😝😴🌟😬🙃🍀🌷😻😓⭐✅🥺🌈😈🤘💦✔😣🏃💐☹🎊💘😠☝😕🌺🎂🌻😐🖕💝🙊😹🗣💫💀👑🎵🤞😛🔴😤🌼😫⚽🤙☕🏆🤫👈😮🙆🍻🍃🐶💁😲🌿🧡🎁⚡🌞🎈❌✊👋😰🤨😶🤝🚶💰🍓💢🤟🙁🚨💨🤬✈🎀🍺🤓😙💟🌱😖👶🥴▶➡❓💎💸⬇😨🌚🦋😷🕺⚠🙅😟😵👎🤲🤠🤧📌🔵💅🧐🐾🍒😗🤑🌊🤯🐷☎💧😯💆👆🎤🙇🍑❄🌴💣🐸💌📍🥀🤢👅💡💩👐📸👻🤐🤮🎼🥵🚩🍎🍊👼💍📣🥂"),
    KI = wg.reduce((r, t, e) => (r[e] = t, r), []),
    VI = wg.reduce((r, t, e) => (r[t.codePointAt(0)] = e, r), []);

function GI(r) {
    return r.reduce((t, e) => (t += KI[e], t), "")
}

function QI(r) {
    const t = [];
    for (const e of r) {
        const n = VI[e.codePointAt(0)];
        if (n === void 0) throw new Error(`Non-base256emoji character: ${e}`);
        t.push(n)
    }
    return new Uint8Array(t)
}
const WI = Dc({
    prefix: "🚀",
    name: "base256emoji",
    encode: GI,
    decode: QI
});
var JI = Object.freeze({
        __proto__: null,
        base256emoji: WI
    }),
    YI = bg,
    Ep = 128,
    XI = 127,
    ZI = ~XI,
    t8 = Math.pow(2, 31);

function bg(r, t, e) {
    t = t || [], e = e || 0;
    for (var n = e; r >= t8;) t[e++] = r & 255 | Ep, r /= 128;
    for (; r & ZI;) t[e++] = r & 255 | Ep, r >>>= 7;
    return t[e] = r | 0, bg.bytes = e - n + 1, t
}
var e8 = Tu,
    r8 = 128,
    Ip = 127;

function Tu(r, n) {
    var e = 0,
        n = n || 0,
        o = 0,
        a = n,
        h, g = r.length;
    do {
        if (a >= g) throw Tu.bytes = 0, new RangeError("Could not decode varint");
        h = r[a++], e += o < 28 ? (h & Ip) << o : (h & Ip) * Math.pow(2, o), o += 7
    } while (h >= r8);
    return Tu.bytes = a - n, e
}
var i8 = Math.pow(2, 7),
    n8 = Math.pow(2, 14),
    s8 = Math.pow(2, 21),
    o8 = Math.pow(2, 28),
    a8 = Math.pow(2, 35),
    c8 = Math.pow(2, 42),
    h8 = Math.pow(2, 49),
    u8 = Math.pow(2, 56),
    l8 = Math.pow(2, 63),
    f8 = function(r) {
        return r < i8 ? 1 : r < n8 ? 2 : r < s8 ? 3 : r < o8 ? 4 : r < a8 ? 5 : r < c8 ? 6 : r < h8 ? 7 : r < u8 ? 8 : r < l8 ? 9 : 10
    },
    d8 = {
        encode: YI,
        decode: e8,
        encodingLength: f8
    },
    _g = d8;
const Sp = (r, t, e = 0) => (_g.encode(r, t, e), t),
    xp = r => _g.encodingLength(r),
    Du = (r, t) => {
        const e = t.byteLength,
            n = xp(r),
            o = n + xp(e),
            a = new Uint8Array(o + e);
        return Sp(r, a, 0), Sp(e, a, n), a.set(t, o), new p8(r, e, t, a)
    };
class p8 {
    constructor(t, e, n, o) {
        this.code = t, this.size = e, this.digest = n, this.bytes = o
    }
}
const Ag = ({
    name: r,
    code: t,
    encode: e
}) => new g8(r, t, e);
class g8 {
    constructor(t, e, n) {
        this.name = t, this.code = e, this.encode = n
    }
    digest(t) {
        if (t instanceof Uint8Array) {
            const e = this.encode(t);
            return e instanceof Uint8Array ? Du(this.code, e) : e.then(n => Du(this.code, n))
        } else throw Error("Unknown type, must be binary type")
    }
}
const Eg = r => async t => new Uint8Array(await crypto.subtle.digest(r, t)),
    m8 = Ag({
        name: "sha2-256",
        code: 18,
        encode: Eg("SHA-256")
    }),
    v8 = Ag({
        name: "sha2-512",
        code: 19,
        encode: Eg("SHA-512")
    });
var y8 = Object.freeze({
    __proto__: null,
    sha256: m8,
    sha512: v8
});
const Ig = 0,
    w8 = "identity",
    Sg = vg,
    b8 = r => Du(Ig, Sg(r)),
    _8 = {
        code: Ig,
        name: w8,
        encode: Sg,
        digest: b8
    };
var A8 = Object.freeze({
    __proto__: null,
    identity: _8
});
new TextEncoder, new TextDecoder;
const Pp = { ...pI,
    ...mI,
    ...yI,
    ...bI,
    ...EI,
    ...TI,
    ...BI,
    ...LI,
    ...HI,
    ...JI
};
({ ...y8,
    ...A8
});

function E8(r = 0) {
    return globalThis.Buffer != null && globalThis.Buffer.allocUnsafe != null ? globalThis.Buffer.allocUnsafe(r) : new Uint8Array(r)
}

function xg(r, t, e, n) {
    return {
        name: r,
        prefix: t,
        encoder: {
            name: r,
            prefix: t,
            encode: e
        },
        decoder: {
            decode: n
        }
    }
}
const Mp = xg("utf8", "u", r => "u" + new TextDecoder("utf8").decode(r), r => new TextEncoder().encode(r.substring(1))),
    lu = xg("ascii", "a", r => {
        let t = "a";
        for (let e = 0; e < r.length; e++) t += String.fromCharCode(r[e]);
        return t
    }, r => {
        r = r.substring(1);
        const t = E8(r.length);
        for (let e = 0; e < r.length; e++) t[e] = r.charCodeAt(e);
        return t
    }),
    I8 = {
        utf8: Mp,
        "utf-8": Mp,
        hex: Pp.base16,
        latin1: lu,
        ascii: lu,
        binary: lu,
        ...Pp
    };

function S8(r, t = "utf8") {
    const e = I8[t];
    if (!e) throw new Error(`Unsupported encoding "${t}"`);
    return (t === "utf8" || t === "utf-8") && globalThis.Buffer != null && globalThis.Buffer.from != null ? globalThis.Buffer.from(r, "utf8") : e.decoder.decode(`${e.prefix}${r}`)
}
const Pg = "wc",
    x8 = 2,
    tl = "core",
    kn = `${Pg}@2:${tl}:`,
    P8 = {
        name: tl,
        logger: "error"
    },
    M8 = {
        database: ":memory:"
    },
    C8 = "crypto",
    Cp = "client_ed25519_seed",
    N8 = lt.ONE_DAY,
    R8 = "keychain",
    O8 = "0.3",
    T8 = "messages",
    D8 = "0.3",
    q8 = lt.SIX_HOURS,
    B8 = "publisher",
    Mg = "irn",
    U8 = "error",
    Cg = "wss://relay.walletconnect.org",
    k8 = "relayer",
    Lr = {
        message: "relayer_message",
        message_ack: "relayer_message_ack",
        connect: "relayer_connect",
        disconnect: "relayer_disconnect",
        error: "relayer_error",
        connection_stalled: "relayer_connection_stalled",
        transport_closed: "relayer_transport_closed",
        publish: "relayer_publish"
    },
    L8 = "_subscription",
    pi = {
        payload: "payload",
        connect: "connect",
        disconnect: "disconnect",
        error: "error"
    },
    $8 = .1,
    j8 = "2.15.1",
    z8 = 1e4,
    F8 = "0.3",
    H8 = "WALLETCONNECT_CLIENT_ID",
    Gi = {
        created: "subscription_created",
        deleted: "subscription_deleted",
        expired: "subscription_expired",
        disabled: "subscription_disabled",
        sync: "subscription_sync",
        resubscribed: "subscription_resubscribed"
    },
    K8 = "subscription",
    V8 = "0.3",
    G8 = lt.FIVE_SECONDS * 1e3,
    Q8 = "pairing",
    W8 = "0.3",
    Eo = {
        wc_pairingDelete: {
            req: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1e3
            },
            res: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1001
            }
        },
        wc_pairingPing: {
            req: {
                ttl: lt.THIRTY_SECONDS,
                prompt: !1,
                tag: 1002
            },
            res: {
                ttl: lt.THIRTY_SECONDS,
                prompt: !1,
                tag: 1003
            }
        },
        unregistered_method: {
            req: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 0
            },
            res: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 0
            }
        }
    },
    ks = {
        create: "pairing_create",
        expire: "pairing_expire",
        delete: "pairing_delete",
        ping: "pairing_ping"
    },
    Pi = {
        created: "history_created",
        updated: "history_updated",
        deleted: "history_deleted",
        sync: "history_sync"
    },
    J8 = "history",
    Y8 = "0.3",
    X8 = "expirer",
    gi = {
        created: "expirer_created",
        deleted: "expirer_deleted",
        expired: "expirer_expired",
        sync: "expirer_sync"
    },
    Z8 = "0.3",
    fu = "verify-api",
    tS = "https://verify.walletconnect.com",
    Ng = "https://verify.walletconnect.org",
    Co = Ng,
    eS = [tS, Ng],
    rS = "echo",
    iS = "https://echo.walletconnect.com";
class nS {
    constructor(t, e) {
        this.core = t, this.logger = e, this.keychain = new Map, this.name = R8, this.version = O8, this.initialized = !1, this.storagePrefix = kn, this.init = async () => {
            if (!this.initialized) {
                const n = await this.getKeyChain();
                typeof n < "u" && (this.keychain = n), this.initialized = !0
            }
        }, this.has = n => (this.isInitialized(), this.keychain.has(n)), this.set = async (n, o) => {
            this.isInitialized(), this.keychain.set(n, o), await this.persist()
        }, this.get = n => {
            this.isInitialized();
            const o = this.keychain.get(n);
            if (typeof o > "u") {
                const {
                    message: a
                } = nt("NO_MATCHING_KEY", `${this.name}: ${n}`);
                throw new Error(a)
            }
            return o
        }, this.del = async n => {
            this.isInitialized(), this.keychain.delete(n), await this.persist()
        }, this.core = t, this.logger = Fr(e, this.name)
    }
    get context() {
        return zr(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + this.core.customStoragePrefix + "//" + this.name
    }
    async setKeyChain(t) {
        await this.core.storage.setItem(this.storageKey, S0(t))
    }
    async getKeyChain() {
        const t = await this.core.storage.getItem(this.storageKey);
        return typeof t < "u" ? x0(t) : void 0
    }
    async persist() {
        await this.setKeyChain(this.keychain)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class sS {
    constructor(t, e, n) {
        this.core = t, this.logger = e, this.name = C8, this.randomSessionIdentifier = Ru(), this.initialized = !1, this.init = async () => {
            this.initialized || (await this.keychain.init(), this.initialized = !0)
        }, this.hasKeys = o => (this.isInitialized(), this.keychain.has(o)), this.getClientId = async () => {
            this.isInitialized();
            const o = await this.getClientSeed(),
                a = _d(o);
            return y0(a.publicKey)
        }, this.generateKeyPair = () => {
            this.isInitialized();
            const o = HE();
            return this.setPrivateKey(o.publicKey, o.privateKey)
        }, this.signJWT = async o => {
            this.isInitialized();
            const a = await this.getClientSeed(),
                h = _d(a),
                g = this.randomSessionIdentifier;
            return await Z6(g, o, N8, h)
        }, this.generateSharedKey = (o, a, h) => {
            this.isInitialized();
            const g = this.getPrivateKey(o),
                b = KE(g, a);
            return this.setSymKey(b, h)
        }, this.setSymKey = async (o, a) => {
            this.isInitialized();
            const h = a || dc(o);
            return await this.keychain.set(h, o), h
        }, this.deleteKeyPair = async o => {
            this.isInitialized(), await this.keychain.del(o)
        }, this.deleteSymKey = async o => {
            this.isInitialized(), await this.keychain.del(o)
        }, this.encode = async (o, a, h) => {
            this.isInitialized();
            const g = pg(h),
                b = wn(a);
            if (fp(g)) {
                const B = g.senderPublicKey,
                    k = g.receiverPublicKey;
                o = await this.generateSharedKey(B, k)
            }
            const m = this.getSymKey(o),
                {
                    type: _,
                    senderPublicKey: S
                } = g;
            return GE({
                type: _,
                symKey: m,
                message: b,
                senderPublicKey: S
            })
        }, this.decode = async (o, a, h) => {
            this.isInitialized();
            const g = JE(a, h);
            if (fp(g)) {
                const b = g.receiverPublicKey,
                    m = g.senderPublicKey;
                o = await this.generateSharedKey(b, m)
            }
            try {
                const b = this.getSymKey(o),
                    m = QE({
                        symKey: b,
                        encoded: a
                    });
                return $o(m)
            } catch (b) {
                this.logger.error(`Failed to decode message from topic: '${o}', clientId: '${await this.getClientId()}'`), this.logger.error(b)
            }
        }, this.getPayloadType = o => {
            const a = Sc(o);
            return Ko(a.type)
        }, this.getPayloadSenderPublicKey = o => {
            const a = Sc(o);
            return a.senderPublicKey ? Pr(a.senderPublicKey, xr) : void 0
        }, this.core = t, this.logger = Fr(e, this.name), this.keychain = n || new nS(this.core, this.logger)
    }
    get context() {
        return zr(this.logger)
    }
    async setPrivateKey(t, e) {
        return await this.keychain.set(t, e), t
    }
    getPrivateKey(t) {
        return this.keychain.get(t)
    }
    async getClientSeed() {
        let t = "";
        try {
            t = this.keychain.get(Cp)
        } catch {
            t = Ru(), await this.keychain.set(Cp, t)
        }
        return S8(t, "base16")
    }
    getSymKey(t) {
        return this.keychain.get(t)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class oS extends K5 {
    constructor(t, e) {
        super(t, e), this.logger = t, this.core = e, this.messages = new Map, this.name = T8, this.version = D8, this.initialized = !1, this.storagePrefix = kn, this.init = async () => {
            if (!this.initialized) {
                this.logger.trace("Initialized");
                try {
                    const n = await this.getRelayerMessages();
                    typeof n < "u" && (this.messages = n), this.logger.debug(`Successfully Restored records for ${this.name}`), this.logger.trace({
                        type: "method",
                        method: "restore",
                        size: this.messages.size
                    })
                } catch (n) {
                    this.logger.debug(`Failed to Restore records for ${this.name}`), this.logger.error(n)
                } finally {
                    this.initialized = !0
                }
            }
        }, this.set = async (n, o) => {
            this.isInitialized();
            const a = hs(o);
            let h = this.messages.get(n);
            return typeof h > "u" && (h = {}), typeof h[a] < "u" || (h[a] = o, this.messages.set(n, h), await this.persist()), a
        }, this.get = n => {
            this.isInitialized();
            let o = this.messages.get(n);
            return typeof o > "u" && (o = {}), o
        }, this.has = (n, o) => {
            this.isInitialized();
            const a = this.get(n),
                h = hs(o);
            return typeof a[h] < "u"
        }, this.del = async n => {
            this.isInitialized(), this.messages.delete(n), await this.persist()
        }, this.logger = Fr(t, this.name), this.core = e
    }
    get context() {
        return zr(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + this.core.customStoragePrefix + "//" + this.name
    }
    async setRelayerMessages(t) {
        await this.core.storage.setItem(this.storageKey, S0(t))
    }
    async getRelayerMessages() {
        const t = await this.core.storage.getItem(this.storageKey);
        return typeof t < "u" ? x0(t) : void 0
    }
    async persist() {
        await this.setRelayerMessages(this.messages)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class aS extends V5 {
    constructor(t, e) {
        super(t, e), this.relayer = t, this.logger = e, this.events = new wi.EventEmitter, this.name = B8, this.queue = new Map, this.publishTimeout = lt.toMiliseconds(lt.ONE_MINUTE), this.failedPublishTimeout = lt.toMiliseconds(lt.ONE_SECOND), this.needsTransportRestart = !1, this.publish = async (n, o, a) => {
            var h;
            this.logger.debug("Publishing Payload"), this.logger.trace({
                type: "method",
                method: "publish",
                params: {
                    topic: n,
                    message: o,
                    opts: a
                }
            });
            const g = (a == null ? void 0 : a.ttl) || q8,
                b = Ou(a),
                m = (a == null ? void 0 : a.prompt) || !1,
                _ = (a == null ? void 0 : a.tag) || 0,
                S = (a == null ? void 0 : a.id) || as().toString(),
                B = {
                    topic: n,
                    message: o,
                    opts: {
                        ttl: g,
                        relay: b,
                        prompt: m,
                        tag: _,
                        id: S,
                        attestation: a == null ? void 0 : a.attestation
                    }
                },
                k = `Failed to publish payload, please try again. id:${S} tag:${_}`,
                L = Date.now();
            let K, Q = 1;
            try {
                for (; K === void 0;) {
                    if (Date.now() - L > this.publishTimeout) throw new Error(k);
                    this.logger.trace({
                        id: S,
                        attempts: Q
                    }, `publisher.publish - attempt ${Q}`), K = await await $s(this.rpcPublish(n, o, g, b, m, _, S, a == null ? void 0 : a.attestation).catch(et => this.logger.warn(et)), this.publishTimeout, k), Q++, K || await new Promise(et => setTimeout(et, this.failedPublishTimeout))
                }
                this.relayer.events.emit(Lr.publish, B), this.logger.debug("Successfully Published Payload"), this.logger.trace({
                    type: "method",
                    method: "publish",
                    params: {
                        id: S,
                        topic: n,
                        message: o,
                        opts: a
                    }
                })
            } catch (et) {
                if (this.logger.debug("Failed to Publish Payload"), this.logger.error(et), (h = a == null ? void 0 : a.internal) != null && h.throwOnFailedPublish) throw et;
                this.queue.set(S, B)
            }
        }, this.on = (n, o) => {
            this.events.on(n, o)
        }, this.once = (n, o) => {
            this.events.once(n, o)
        }, this.off = (n, o) => {
            this.events.off(n, o)
        }, this.removeListener = (n, o) => {
            this.events.removeListener(n, o)
        }, this.relayer = t, this.logger = Fr(e, this.name), this.registerEventListeners()
    }
    get context() {
        return zr(this.logger)
    }
    rpcPublish(t, e, n, o, a, h, g, b) {
        var m, _, S, B;
        const k = {
            method: Po(o.protocol).publish,
            params: {
                topic: t,
                message: e,
                ttl: n,
                prompt: a,
                tag: h,
                attestation: b
            },
            id: g
        };
        return kr((m = k.params) == null ? void 0 : m.prompt) && ((_ = k.params) == null || delete _.prompt), kr((S = k.params) == null ? void 0 : S.tag) && ((B = k.params) == null || delete B.tag), this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "message",
            direction: "outgoing",
            request: k
        }), this.relayer.request(k)
    }
    removeRequestFromQueue(t) {
        this.queue.delete(t)
    }
    checkQueue() {
        this.queue.forEach(async t => {
            const {
                topic: e,
                message: n,
                opts: o
            } = t;
            await this.publish(e, n, o)
        })
    }
    registerEventListeners() {
        this.relayer.core.heartbeat.on(jo.pulse, () => {
            if (this.needsTransportRestart) {
                this.needsTransportRestart = !1, this.relayer.events.emit(Lr.connection_stalled);
                return
            }
            this.checkQueue()
        }), this.relayer.on(Lr.message_ack, t => {
            this.removeRequestFromQueue(t.id.toString())
        })
    }
}
class cS {
    constructor() {
        this.map = new Map, this.set = (t, e) => {
            const n = this.get(t);
            this.exists(t, e) || this.map.set(t, [...n, e])
        }, this.get = t => this.map.get(t) || [], this.exists = (t, e) => this.get(t).includes(e), this.delete = (t, e) => {
            if (typeof e > "u") {
                this.map.delete(t);
                return
            }
            if (!this.map.has(t)) return;
            const n = this.get(t);
            if (!this.exists(t, e)) return;
            const o = n.filter(a => a !== e);
            if (!o.length) {
                this.map.delete(t);
                return
            }
            this.map.set(t, o)
        }, this.clear = () => {
            this.map.clear()
        }
    }
    get topics() {
        return Array.from(this.map.keys())
    }
}
var hS = Object.defineProperty,
    uS = Object.defineProperties,
    lS = Object.getOwnPropertyDescriptors,
    Np = Object.getOwnPropertySymbols,
    fS = Object.prototype.hasOwnProperty,
    dS = Object.prototype.propertyIsEnumerable,
    Rp = (r, t, e) => t in r ? hS(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Io = (r, t) => {
        for (var e in t || (t = {})) fS.call(t, e) && Rp(r, e, t[e]);
        if (Np)
            for (var e of Np(t)) dS.call(t, e) && Rp(r, e, t[e]);
        return r
    },
    du = (r, t) => uS(r, lS(t));
class pS extends W5 {
    constructor(t, e) {
        super(t, e), this.relayer = t, this.logger = e, this.subscriptions = new Map, this.topicMap = new cS, this.events = new wi.EventEmitter, this.name = K8, this.version = V8, this.pending = new Map, this.cached = [], this.initialized = !1, this.pendingSubscriptionWatchLabel = "pending_sub_watch_label", this.pollingInterval = 20, this.storagePrefix = kn, this.subscribeTimeout = lt.toMiliseconds(lt.ONE_MINUTE), this.restartInProgress = !1, this.batchSubscribeTopicsLimit = 500, this.pendingBatchMessages = [], this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), this.registerEventListeners(), this.clientId = await this.relayer.core.crypto.getClientId())
        }, this.subscribe = async (n, o) => {
            await this.restartToComplete(), this.isInitialized(), this.logger.debug("Subscribing Topic"), this.logger.trace({
                type: "method",
                method: "subscribe",
                params: {
                    topic: n,
                    opts: o
                }
            });
            try {
                const a = Ou(o),
                    h = {
                        topic: n,
                        relay: a
                    };
                this.pending.set(n, h);
                const g = await this.rpcSubscribe(n, a);
                return typeof g == "string" && (this.onSubscribe(g, h), this.logger.debug("Successfully Subscribed Topic"), this.logger.trace({
                    type: "method",
                    method: "subscribe",
                    params: {
                        topic: n,
                        opts: o
                    }
                })), g
            } catch (a) {
                throw this.logger.debug("Failed to Subscribe Topic"), this.logger.error(a), a
            }
        }, this.unsubscribe = async (n, o) => {
            await this.restartToComplete(), this.isInitialized(), typeof(o == null ? void 0 : o.id) < "u" ? await this.unsubscribeById(n, o.id, o) : await this.unsubscribeByTopic(n, o)
        }, this.isSubscribed = async n => {
            if (this.topics.includes(n)) return !0;
            const o = `${this.pendingSubscriptionWatchLabel}_${n}`;
            return await new Promise((a, h) => {
                const g = new lt.Watch;
                g.start(o);
                const b = setInterval(() => {
                    !this.pending.has(n) && this.topics.includes(n) && (clearInterval(b), g.stop(o), a(!0)), g.elapsed(o) >= G8 && (clearInterval(b), g.stop(o), h(new Error("Subscription resolution timeout")))
                }, this.pollingInterval)
            }).catch(() => !1)
        }, this.on = (n, o) => {
            this.events.on(n, o)
        }, this.once = (n, o) => {
            this.events.once(n, o)
        }, this.off = (n, o) => {
            this.events.off(n, o)
        }, this.removeListener = (n, o) => {
            this.events.removeListener(n, o)
        }, this.start = async () => {
            await this.onConnect()
        }, this.stop = async () => {
            await this.onDisconnect()
        }, this.restart = async () => {
            this.restartInProgress = !0, await this.restore(), await this.reset(), this.restartInProgress = !1
        }, this.relayer = t, this.logger = Fr(e, this.name), this.clientId = ""
    }
    get context() {
        return zr(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + this.relayer.core.customStoragePrefix + "//" + this.name
    }
    get length() {
        return this.subscriptions.size
    }
    get ids() {
        return Array.from(this.subscriptions.keys())
    }
    get values() {
        return Array.from(this.subscriptions.values())
    }
    get topics() {
        return this.topicMap.topics
    }
    hasSubscription(t, e) {
        let n = !1;
        try {
            n = this.getSubscription(t).topic === e
        } catch {}
        return n
    }
    onEnable() {
        this.cached = [], this.initialized = !0
    }
    onDisable() {
        this.cached = this.values, this.subscriptions.clear(), this.topicMap.clear()
    }
    async unsubscribeByTopic(t, e) {
        const n = this.topicMap.get(t);
        await Promise.all(n.map(async o => await this.unsubscribeById(t, o, e)))
    }
    async unsubscribeById(t, e, n) {
        this.logger.debug("Unsubscribing Topic"), this.logger.trace({
            type: "method",
            method: "unsubscribe",
            params: {
                topic: t,
                id: e,
                opts: n
            }
        });
        try {
            const o = Ou(n);
            await this.rpcUnsubscribe(t, e, o);
            const a = Ne("USER_DISCONNECTED", `${this.name}, ${t}`);
            await this.onUnsubscribe(t, e, a), this.logger.debug("Successfully Unsubscribed Topic"), this.logger.trace({
                type: "method",
                method: "unsubscribe",
                params: {
                    topic: t,
                    id: e,
                    opts: n
                }
            })
        } catch (o) {
            throw this.logger.debug("Failed to Unsubscribe Topic"), this.logger.error(o), o
        }
    }
    async rpcSubscribe(t, e) {
        const n = {
            method: Po(e.protocol).subscribe,
            params: {
                topic: t
            }
        };
        this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: n
        });
        try {
            return await await $s(this.relayer.request(n).catch(o => this.logger.warn(o)), this.subscribeTimeout) ? hs(t + this.clientId) : null
        } catch {
            this.logger.debug("Outgoing Relay Subscribe Payload stalled"), this.relayer.events.emit(Lr.connection_stalled)
        }
        return null
    }
    async rpcBatchSubscribe(t) {
        if (!t.length) return;
        const e = t[0].relay,
            n = {
                method: Po(e.protocol).batchSubscribe,
                params: {
                    topics: t.map(o => o.topic)
                }
            };
        this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: n
        });
        try {
            return await await $s(this.relayer.request(n).catch(o => this.logger.warn(o)), this.subscribeTimeout)
        } catch {
            this.relayer.events.emit(Lr.connection_stalled)
        }
    }
    async rpcBatchFetchMessages(t) {
        if (!t.length) return;
        const e = t[0].relay,
            n = {
                method: Po(e.protocol).batchFetchMessages,
                params: {
                    topics: t.map(a => a.topic)
                }
            };
        this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: n
        });
        let o;
        try {
            o = await await $s(this.relayer.request(n).catch(a => this.logger.warn(a)), this.subscribeTimeout)
        } catch {
            this.relayer.events.emit(Lr.connection_stalled)
        }
        return o
    }
    rpcUnsubscribe(t, e, n) {
        const o = {
            method: Po(n.protocol).unsubscribe,
            params: {
                topic: t,
                id: e
            }
        };
        return this.logger.debug("Outgoing Relay Payload"), this.logger.trace({
            type: "payload",
            direction: "outgoing",
            request: o
        }), this.relayer.request(o)
    }
    onSubscribe(t, e) {
        this.setSubscription(t, du(Io({}, e), {
            id: t
        })), this.pending.delete(e.topic)
    }
    onBatchSubscribe(t) {
        t.length && t.forEach(e => {
            this.setSubscription(e.id, Io({}, e)), this.pending.delete(e.topic)
        })
    }
    async onUnsubscribe(t, e, n) {
        this.events.removeAllListeners(e), this.hasSubscription(e, t) && this.deleteSubscription(e, n), await this.relayer.messages.del(t)
    }
    async setRelayerSubscriptions(t) {
        await this.relayer.core.storage.setItem(this.storageKey, t)
    }
    async getRelayerSubscriptions() {
        return await this.relayer.core.storage.getItem(this.storageKey)
    }
    setSubscription(t, e) {
        this.logger.debug("Setting subscription"), this.logger.trace({
            type: "method",
            method: "setSubscription",
            id: t,
            subscription: e
        }), this.addSubscription(t, e)
    }
    addSubscription(t, e) {
        this.subscriptions.set(t, Io({}, e)), this.topicMap.set(e.topic, t), this.events.emit(Gi.created, e)
    }
    getSubscription(t) {
        this.logger.debug("Getting subscription"), this.logger.trace({
            type: "method",
            method: "getSubscription",
            id: t
        });
        const e = this.subscriptions.get(t);
        if (!e) {
            const {
                message: n
            } = nt("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw new Error(n)
        }
        return e
    }
    deleteSubscription(t, e) {
        this.logger.debug("Deleting subscription"), this.logger.trace({
            type: "method",
            method: "deleteSubscription",
            id: t,
            reason: e
        });
        const n = this.getSubscription(t);
        this.subscriptions.delete(t), this.topicMap.delete(n.topic, t), this.events.emit(Gi.deleted, du(Io({}, n), {
            reason: e
        }))
    }
    async persist() {
        await this.setRelayerSubscriptions(this.values), this.events.emit(Gi.sync)
    }
    async reset() {
        if (this.cached.length) {
            const t = Math.ceil(this.cached.length / this.batchSubscribeTopicsLimit);
            for (let e = 0; e < t; e++) {
                const n = this.cached.splice(0, this.batchSubscribeTopicsLimit);
                await this.batchFetchMessages(n), await this.batchSubscribe(n)
            }
        }
        this.events.emit(Gi.resubscribed)
    }
    async restore() {
        try {
            const t = await this.getRelayerSubscriptions();
            if (typeof t > "u" || !t.length) return;
            if (this.subscriptions.size) {
                const {
                    message: e
                } = nt("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(e), this.logger.error(`${this.name}: ${JSON.stringify(this.values)}`), new Error(e)
            }
            this.cached = t, this.logger.debug(`Successfully Restored subscriptions for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                subscriptions: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore subscriptions for ${this.name}`), this.logger.error(t)
        }
    }
    async batchSubscribe(t) {
        if (!t.length) return;
        const e = await this.rpcBatchSubscribe(t);
        tn(e) && this.onBatchSubscribe(e.map((n, o) => du(Io({}, t[o]), {
            id: n
        })))
    }
    async batchFetchMessages(t) {
        if (!t.length) return;
        this.logger.trace(`Fetching batch messages for ${t.length} subscriptions`);
        const e = await this.rpcBatchFetchMessages(t);
        e && e.messages && (this.pendingBatchMessages = this.pendingBatchMessages.concat(e.messages))
    }
    async onConnect() {
        await this.restart(), this.onEnable()
    }
    onDisconnect() {
        this.onDisable()
    }
    async checkPending() {
        if (!this.initialized || !this.relayer.connected) return;
        const t = [];
        this.pending.forEach(e => {
            t.push(e)
        }), await this.batchSubscribe(t), this.pendingBatchMessages.length && (await this.relayer.handleBatchMessageEvents(this.pendingBatchMessages), this.pendingBatchMessages = [])
    }
    registerEventListeners() {
        this.relayer.core.heartbeat.on(jo.pulse, async () => {
            await this.checkPending()
        }), this.events.on(Gi.created, async t => {
            const e = Gi.created;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                data: t
            }), await this.persist()
        }), this.events.on(Gi.deleted, async t => {
            const e = Gi.deleted;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                data: t
            }), await this.persist()
        })
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    async restartToComplete() {
        this.restartInProgress && await new Promise(t => {
            const e = setInterval(() => {
                this.restartInProgress || (clearInterval(e), t())
            }, this.pollingInterval)
        })
    }
}
var gS = Object.defineProperty,
    Op = Object.getOwnPropertySymbols,
    mS = Object.prototype.hasOwnProperty,
    vS = Object.prototype.propertyIsEnumerable,
    Tp = (r, t, e) => t in r ? gS(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    yS = (r, t) => {
        for (var e in t || (t = {})) mS.call(t, e) && Tp(r, e, t[e]);
        if (Op)
            for (var e of Op(t)) vS.call(t, e) && Tp(r, e, t[e]);
        return r
    };
class wS extends G5 {
    constructor(t) {
        super(t), this.protocol = "wc", this.version = 2, this.events = new wi.EventEmitter, this.name = k8, this.transportExplicitlyClosed = !1, this.initialized = !1, this.connectionAttemptInProgress = !1, this.connectionStatusPollingInterval = 20, this.staleConnectionErrors = ["socket hang up", "stalled", "interrupted"], this.hasExperiencedNetworkDisruption = !1, this.requestsInFlight = new Map, this.heartBeatTimeout = lt.toMiliseconds(lt.THIRTY_SECONDS + lt.ONE_SECOND), this.request = async e => {
            var n, o;
            this.logger.debug("Publishing Request Payload");
            const a = e.id || as().toString();
            await this.toEstablishConnection();
            try {
                const h = this.provider.request(e);
                this.requestsInFlight.set(a, {
                    promise: h,
                    request: e
                }), this.logger.trace({
                    id: a,
                    method: e.method,
                    topic: (n = e.params) == null ? void 0 : n.topic
                }, "relayer.request - attempt to publish...");
                const g = await new Promise(async (b, m) => {
                    const _ = () => {
                        m(new Error(`relayer.request - publish interrupted, id: ${a}`))
                    };
                    this.provider.on(pi.disconnect, _);
                    const S = await h;
                    this.provider.off(pi.disconnect, _), b(S)
                });
                return this.logger.trace({
                    id: a,
                    method: e.method,
                    topic: (o = e.params) == null ? void 0 : o.topic
                }, "relayer.request - published"), g
            } catch (h) {
                throw this.logger.debug(`Failed to Publish Request: ${a}`), h
            } finally {
                this.requestsInFlight.delete(a)
            }
        }, this.resetPingTimeout = () => {
            if (Do()) try {
                clearTimeout(this.pingTimeout), this.pingTimeout = setTimeout(() => {
                    var e, n, o;
                    (o = (n = (e = this.provider) == null ? void 0 : e.connection) == null ? void 0 : n.socket) == null || o.terminate()
                }, this.heartBeatTimeout)
            } catch (e) {
                this.logger.warn(e)
            }
        }, this.onPayloadHandler = e => {
            this.onProviderPayload(e), this.resetPingTimeout()
        }, this.onConnectHandler = () => {
            this.logger.trace("relayer connected"), this.startPingTimeout(), this.events.emit(Lr.connect)
        }, this.onDisconnectHandler = () => {
            this.logger.trace("relayer disconnected"), this.onProviderDisconnect()
        }, this.onProviderErrorHandler = e => {
            this.logger.error(e), this.events.emit(Lr.error, e), this.logger.info("Fatal socket error received, closing transport"), this.transportClose()
        }, this.registerProviderListeners = () => {
            this.provider.on(pi.payload, this.onPayloadHandler), this.provider.on(pi.connect, this.onConnectHandler), this.provider.on(pi.disconnect, this.onDisconnectHandler), this.provider.on(pi.error, this.onProviderErrorHandler)
        }, this.core = t.core, this.logger = typeof t.logger < "u" && typeof t.logger != "string" ? Fr(t.logger, this.name) : ko(Cc({
            level: t.logger || U8
        })), this.messages = new oS(this.logger, t.core), this.subscriber = new pS(this, this.logger), this.publisher = new aS(this, this.logger), this.relayUrl = (t == null ? void 0 : t.relayUrl) || Cg, this.projectId = t.projectId, this.bundleId = q3(), this.provider = {}
    }
    async init() {
        this.logger.trace("Initialized"), this.registerEventListeners(), await Promise.all([this.messages.init(), this.subscriber.init()]), await this.transportOpen(), this.initialized = !0, setTimeout(async () => {
            this.subscriber.topics.length === 0 && this.subscriber.pending.size === 0 && (this.logger.info("No topics subscribed to after init, closing transport"), await this.transportClose(), this.transportExplicitlyClosed = !1)
        }, z8)
    }
    get context() {
        return zr(this.logger)
    }
    get connected() {
        var t, e, n;
        return ((n = (e = (t = this.provider) == null ? void 0 : t.connection) == null ? void 0 : e.socket) == null ? void 0 : n.readyState) === 1
    }
    get connecting() {
        var t, e, n;
        return ((n = (e = (t = this.provider) == null ? void 0 : t.connection) == null ? void 0 : e.socket) == null ? void 0 : n.readyState) === 0
    }
    async publish(t, e, n) {
        this.isInitialized(), await this.publisher.publish(t, e, n), await this.recordMessageEvent({
            topic: t,
            message: e,
            publishedAt: Date.now()
        })
    }
    async subscribe(t, e) {
        var n;
        this.isInitialized();
        let o = ((n = this.subscriber.topicMap.get(t)) == null ? void 0 : n[0]) || "",
            a;
        const h = g => {
            g.topic === t && (this.subscriber.off(Gi.created, h), a())
        };
        return await Promise.all([new Promise(g => {
            a = g, this.subscriber.on(Gi.created, h)
        }), new Promise(async g => {
            o = await this.subscriber.subscribe(t, e) || o, g()
        })]), o
    }
    async unsubscribe(t, e) {
        this.isInitialized(), await this.subscriber.unsubscribe(t, e)
    }
    on(t, e) {
        this.events.on(t, e)
    }
    once(t, e) {
        this.events.once(t, e)
    }
    off(t, e) {
        this.events.off(t, e)
    }
    removeListener(t, e) {
        this.events.removeListener(t, e)
    }
    async transportDisconnect() {
        if (!this.hasExperiencedNetworkDisruption && this.connected && this.requestsInFlight.size > 0) try {
            await Promise.all(Array.from(this.requestsInFlight.values()).map(t => t.promise))
        } catch (t) {
            this.logger.warn(t)
        }
        this.hasExperiencedNetworkDisruption || this.connected ? await $s(this.provider.disconnect(), 2e3, "provider.disconnect()").catch(() => this.onProviderDisconnect()) : this.onProviderDisconnect()
    }
    async transportClose() {
        this.transportExplicitlyClosed = !0, await this.transportDisconnect()
    }
    async transportOpen(t) {
        await this.confirmOnlineStateOrThrow(), t && t !== this.relayUrl && (this.relayUrl = t, await this.transportDisconnect()), await this.createProvider(), this.connectionAttemptInProgress = !0, this.transportExplicitlyClosed = !1;
        try {
            await new Promise(async (e, n) => {
                const o = () => {
                    this.provider.off(pi.disconnect, o), n(new Error("Connection interrupted while trying to subscribe"))
                };
                this.provider.on(pi.disconnect, o), await $s(this.provider.connect(), lt.toMiliseconds(lt.ONE_MINUTE), `Socket stalled when trying to connect to ${this.relayUrl}`).catch(a => {
                    n(a)
                }), this.subscriber.start().catch(a => {
                    this.logger.error(a), this.onDisconnectHandler()
                }), this.hasExperiencedNetworkDisruption = !1, e()
            })
        } catch (e) {
            this.logger.error(e);
            const n = e;
            if (this.hasExperiencedNetworkDisruption = !0, !this.isConnectionStalled(n.message)) throw e
        } finally {
            this.connectionAttemptInProgress = !1
        }
    }
    async restartTransport(t) {
        this.connectionAttemptInProgress || (this.relayUrl = t || this.relayUrl, await this.confirmOnlineStateOrThrow(), await this.transportClose(), await this.transportOpen())
    }
    async confirmOnlineStateOrThrow() {
        if (!await Ap()) throw new Error("No internet connection detected. Please restart your network and try again.")
    }
    async handleBatchMessageEvents(t) {
        if ((t == null ? void 0 : t.length) === 0) {
            this.logger.trace("Batch message events is empty. Ignoring...");
            return
        }
        const e = t.sort((n, o) => n.publishedAt - o.publishedAt);
        this.logger.trace(`Batch of ${e.length} message events sorted`);
        for (const n of e) try {
            await this.onMessageEvent(n)
        } catch (o) {
            this.logger.warn(o)
        }
        this.logger.trace(`Batch of ${e.length} message events processed`)
    }
    startPingTimeout() {
        var t, e, n, o, a;
        if (Do()) try {
            (e = (t = this.provider) == null ? void 0 : t.connection) != null && e.socket && ((a = (o = (n = this.provider) == null ? void 0 : n.connection) == null ? void 0 : o.socket) == null || a.once("ping", () => {
                this.resetPingTimeout()
            })), this.resetPingTimeout()
        } catch (h) {
            this.logger.warn(h)
        }
    }
    isConnectionStalled(t) {
        return this.staleConnectionErrors.some(e => t.includes(e))
    }
    async createProvider() {
        this.provider.connection && this.unregisterProviderListeners();
        const t = await this.core.crypto.signJWT(this.relayUrl);
        this.provider = new Ti(new y3(j3({
            sdkVersion: j8,
            protocol: this.protocol,
            version: this.version,
            relayUrl: this.relayUrl,
            projectId: this.projectId,
            auth: t,
            useOnCloseEvent: !0,
            bundleId: this.bundleId
        }))), this.registerProviderListeners()
    }
    async recordMessageEvent(t) {
        const {
            topic: e,
            message: n
        } = t;
        await this.messages.set(e, n)
    }
    async shouldIgnoreMessageEvent(t) {
        const {
            topic: e,
            message: n
        } = t;
        if (!n || n.length === 0) return this.logger.debug(`Ignoring invalid/empty message: ${n}`), !0;
        if (!await this.subscriber.isSubscribed(e)) return this.logger.debug(`Ignoring message for non-subscribed topic ${e}`), !0;
        const o = this.messages.has(e, n);
        return o && this.logger.debug(`Ignoring duplicate message: ${n}`), o
    }
    async onProviderPayload(t) {
        if (this.logger.debug("Incoming Relay Payload"), this.logger.trace({
                type: "payload",
                direction: "incoming",
                payload: t
            }), Fu(t)) {
            if (!t.method.endsWith(L8)) return;
            const e = t.params,
                {
                    topic: n,
                    message: o,
                    publishedAt: a,
                    attestation: h
                } = e.data,
                g = {
                    topic: n,
                    message: o,
                    publishedAt: a,
                    attestation: h
                };
            this.logger.debug("Emitting Relayer Payload"), this.logger.trace(yS({
                type: "event",
                event: e.id
            }, g)), this.events.emit(e.id, g), await this.acknowledgePayload(t), await this.onMessageEvent(g)
        } else Oc(t) && this.events.emit(Lr.message_ack, t)
    }
    async onMessageEvent(t) {
        await this.shouldIgnoreMessageEvent(t) || (this.events.emit(Lr.message, t), await this.recordMessageEvent(t))
    }
    async acknowledgePayload(t) {
        const e = Nc(t.id, !0);
        await this.provider.connection.send(e)
    }
    unregisterProviderListeners() {
        this.provider.off(pi.payload, this.onPayloadHandler), this.provider.off(pi.connect, this.onConnectHandler), this.provider.off(pi.disconnect, this.onDisconnectHandler), this.provider.off(pi.error, this.onProviderErrorHandler), clearTimeout(this.pingTimeout)
    }
    async registerEventListeners() {
        let t = await Ap();
        $5(async e => {
            t !== e && (t = e, e ? await this.restartTransport().catch(n => this.logger.error(n)) : (this.hasExperiencedNetworkDisruption = !0, await this.transportDisconnect(), this.transportExplicitlyClosed = !1))
        })
    }
    async onProviderDisconnect() {
        await this.subscriber.stop(), this.requestsInFlight.clear(), clearTimeout(this.pingTimeout), this.events.emit(Lr.disconnect), this.connectionAttemptInProgress = !1, !this.transportExplicitlyClosed && setTimeout(async () => {
            await this.transportOpen().catch(t => this.logger.error(t))
        }, lt.toMiliseconds($8))
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    async toEstablishConnection() {
        await this.confirmOnlineStateOrThrow(), !this.connected && (this.connectionAttemptInProgress && await new Promise(t => {
            const e = setInterval(() => {
                this.connected && (clearInterval(e), t())
            }, this.connectionStatusPollingInterval)
        }), await this.transportOpen())
    }
}
var bS = Object.defineProperty,
    Dp = Object.getOwnPropertySymbols,
    _S = Object.prototype.hasOwnProperty,
    AS = Object.prototype.propertyIsEnumerable,
    qp = (r, t, e) => t in r ? bS(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Bp = (r, t) => {
        for (var e in t || (t = {})) _S.call(t, e) && qp(r, e, t[e]);
        if (Dp)
            for (var e of Dp(t)) AS.call(t, e) && qp(r, e, t[e]);
        return r
    };
class gs extends Q5 {
    constructor(t, e, n, o = kn, a = void 0) {
        super(t, e, n, o), this.core = t, this.logger = e, this.name = n, this.map = new Map, this.version = F8, this.cached = [], this.initialized = !1, this.storagePrefix = kn, this.recentlyDeleted = [], this.recentlyDeletedLimit = 200, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restore(), this.cached.forEach(h => {
                this.getKey && h !== null && !kr(h) ? this.map.set(this.getKey(h), h) : v5(h) ? this.map.set(h.id, h) : y5(h) && this.map.set(h.topic, h)
            }), this.cached = [], this.initialized = !0)
        }, this.set = async (h, g) => {
            this.isInitialized(), this.map.has(h) ? await this.update(h, g) : (this.logger.debug("Setting value"), this.logger.trace({
                type: "method",
                method: "set",
                key: h,
                value: g
            }), this.map.set(h, g), await this.persist())
        }, this.get = h => (this.isInitialized(), this.logger.debug("Getting value"), this.logger.trace({
            type: "method",
            method: "get",
            key: h
        }), this.getData(h)), this.getAll = h => (this.isInitialized(), h ? this.values.filter(g => Object.keys(h).every(b => b3(g[b], h[b]))) : this.values), this.update = async (h, g) => {
            this.isInitialized(), this.logger.debug("Updating value"), this.logger.trace({
                type: "method",
                method: "update",
                key: h,
                update: g
            });
            const b = Bp(Bp({}, this.getData(h)), g);
            this.map.set(h, b), await this.persist()
        }, this.delete = async (h, g) => {
            this.isInitialized(), this.map.has(h) && (this.logger.debug("Deleting value"), this.logger.trace({
                type: "method",
                method: "delete",
                key: h,
                reason: g
            }), this.map.delete(h), this.addToRecentlyDeleted(h), await this.persist())
        }, this.logger = Fr(e, this.name), this.storagePrefix = o, this.getKey = a
    }
    get context() {
        return zr(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + this.core.customStoragePrefix + "//" + this.name
    }
    get length() {
        return this.map.size
    }
    get keys() {
        return Array.from(this.map.keys())
    }
    get values() {
        return Array.from(this.map.values())
    }
    addToRecentlyDeleted(t) {
        this.recentlyDeleted.push(t), this.recentlyDeleted.length >= this.recentlyDeletedLimit && this.recentlyDeleted.splice(0, this.recentlyDeletedLimit / 2)
    }
    async setDataStore(t) {
        await this.core.storage.setItem(this.storageKey, t)
    }
    async getDataStore() {
        return await this.core.storage.getItem(this.storageKey)
    }
    getData(t) {
        const e = this.map.get(t);
        if (!e) {
            if (this.recentlyDeleted.includes(t)) {
                const {
                    message: o
                } = nt("MISSING_OR_INVALID", `Record was recently deleted - ${this.name}: ${t}`);
                throw this.logger.error(o), new Error(o)
            }
            const {
                message: n
            } = nt("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw this.logger.error(n), new Error(n)
        }
        return e
    }
    async persist() {
        await this.setDataStore(this.values)
    }
    async restore() {
        try {
            const t = await this.getDataStore();
            if (typeof t > "u" || !t.length) return;
            if (this.map.size) {
                const {
                    message: e
                } = nt("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(e), new Error(e)
            }
            this.cached = t, this.logger.debug(`Successfully Restored value for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                value: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore value for ${this.name}`), this.logger.error(t)
        }
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class ES {
    constructor(t, e) {
        this.core = t, this.logger = e, this.name = Q8, this.version = W8, this.events = new ku, this.initialized = !1, this.storagePrefix = kn, this.ignoredPayloadTypes = [yn], this.registeredMethods = [], this.init = async () => {
            this.initialized || (await this.pairings.init(), await this.cleanup(), this.registerRelayerEvents(), this.registerExpirerEvents(), this.initialized = !0, this.logger.trace("Initialized"))
        }, this.register = ({
            methods: n
        }) => {
            this.isInitialized(), this.registeredMethods = [...new Set([...this.registeredMethods, ...n])]
        }, this.create = async n => {
            this.isInitialized();
            const o = Ru(),
                a = await this.core.crypto.setSymKey(o),
                h = fr(lt.FIVE_MINUTES),
                g = {
                    protocol: Mg
                },
                b = {
                    topic: a,
                    expiry: h,
                    relay: g,
                    active: !1
                },
                m = a5({
                    protocol: this.core.protocol,
                    version: this.core.version,
                    topic: a,
                    symKey: o,
                    relay: g,
                    expiryTimestamp: h,
                    methods: n == null ? void 0 : n.methods
                });
            return this.core.expirer.set(a, h), await this.pairings.set(a, b), await this.core.relayer.subscribe(a), {
                topic: a,
                uri: m
            }
        }, this.pair = async n => {
            this.isInitialized(), this.isValidPair(n);
            const {
                topic: o,
                symKey: a,
                relay: h,
                expiryTimestamp: g,
                methods: b
            } = mp(n.uri);
            let m;
            if (this.pairings.keys.includes(o) && (m = this.pairings.get(o), m.active)) throw new Error(`Pairing already exists: ${o}. Please try again with a new connection URI.`);
            const _ = g || fr(lt.FIVE_MINUTES),
                S = {
                    topic: o,
                    relay: h,
                    expiry: _,
                    active: !1,
                    methods: b
                };
            return this.core.expirer.set(o, _), await this.pairings.set(o, S), n.activatePairing && await this.activate({
                topic: o
            }), this.events.emit(ks.create, S), this.core.crypto.keychain.has(o) || await this.core.crypto.setSymKey(a, o), await this.core.relayer.subscribe(o, {
                relay: h
            }), S
        }, this.activate = async ({
            topic: n
        }) => {
            this.isInitialized();
            const o = fr(lt.THIRTY_DAYS);
            this.core.expirer.set(n, o), await this.pairings.update(n, {
                active: !0,
                expiry: o
            })
        }, this.ping = async n => {
            this.isInitialized(), await this.isValidPing(n);
            const {
                topic: o
            } = n;
            if (this.pairings.keys.includes(o)) {
                const a = await this.sendRequest(o, "wc_pairingPing", {}),
                    {
                        done: h,
                        resolve: g,
                        reject: b
                    } = os();
                this.events.once(he("pairing_ping", a), ({
                    error: m
                }) => {
                    m ? b(m) : g()
                }), await h()
            }
        }, this.updateExpiry = async ({
            topic: n,
            expiry: o
        }) => {
            this.isInitialized(), await this.pairings.update(n, {
                expiry: o
            })
        }, this.updateMetadata = async ({
            topic: n,
            metadata: o
        }) => {
            this.isInitialized(), await this.pairings.update(n, {
                peerMetadata: o
            })
        }, this.getPairings = () => (this.isInitialized(), this.pairings.values), this.disconnect = async n => {
            this.isInitialized(), await this.isValidDisconnect(n);
            const {
                topic: o
            } = n;
            this.pairings.keys.includes(o) && (await this.sendRequest(o, "wc_pairingDelete", Ne("USER_DISCONNECTED")), await this.deletePairing(o))
        }, this.sendRequest = async (n, o, a) => {
            const h = Ls(o, a),
                g = await this.core.crypto.encode(n, h),
                b = Eo[o].req;
            return this.core.history.set(n, h), this.core.relayer.publish(n, g, b), h.id
        }, this.sendResult = async (n, o, a) => {
            const h = Nc(n, a),
                g = await this.core.crypto.encode(o, h),
                b = await this.core.history.get(o, n),
                m = Eo[b.request.method].res;
            await this.core.relayer.publish(o, g, m), await this.core.history.resolve(h)
        }, this.sendError = async (n, o, a) => {
            const h = Rc(n, a),
                g = await this.core.crypto.encode(o, h),
                b = await this.core.history.get(o, n),
                m = Eo[b.request.method] ? Eo[b.request.method].res : Eo.unregistered_method.res;
            await this.core.relayer.publish(o, g, m), await this.core.history.resolve(h)
        }, this.deletePairing = async (n, o) => {
            await this.core.relayer.unsubscribe(n), await Promise.all([this.pairings.delete(n, Ne("USER_DISCONNECTED")), this.core.crypto.deleteSymKey(n), o ? Promise.resolve() : this.core.expirer.del(n)])
        }, this.cleanup = async () => {
            const n = this.pairings.getAll().filter(o => Dn(o.expiry));
            await Promise.all(n.map(o => this.deletePairing(o.topic)))
        }, this.onRelayEventRequest = n => {
            const {
                topic: o,
                payload: a
            } = n;
            switch (a.method) {
                case "wc_pairingPing":
                    return this.onPairingPingRequest(o, a);
                case "wc_pairingDelete":
                    return this.onPairingDeleteRequest(o, a);
                default:
                    return this.onUnknownRpcMethodRequest(o, a)
            }
        }, this.onRelayEventResponse = async n => {
            const {
                topic: o,
                payload: a
            } = n, h = (await this.core.history.get(o, a.id)).request.method;
            switch (h) {
                case "wc_pairingPing":
                    return this.onPairingPingResponse(o, a);
                default:
                    return this.onUnknownRpcMethodResponse(h)
            }
        }, this.onPairingPingRequest = async (n, o) => {
            const {
                id: a
            } = o;
            try {
                this.isValidPing({
                    topic: n
                }), await this.sendResult(a, n, !0), this.events.emit(ks.ping, {
                    id: a,
                    topic: n
                })
            } catch (h) {
                await this.sendError(a, n, h), this.logger.error(h)
            }
        }, this.onPairingPingResponse = (n, o) => {
            const {
                id: a
            } = o;
            setTimeout(() => {
                Hi(o) ? this.events.emit(he("pairing_ping", a), {}) : vi(o) && this.events.emit(he("pairing_ping", a), {
                    error: o.error
                })
            }, 500)
        }, this.onPairingDeleteRequest = async (n, o) => {
            const {
                id: a
            } = o;
            try {
                this.isValidDisconnect({
                    topic: n
                }), await this.deletePairing(n), this.events.emit(ks.delete, {
                    id: a,
                    topic: n
                })
            } catch (h) {
                await this.sendError(a, n, h), this.logger.error(h)
            }
        }, this.onUnknownRpcMethodRequest = async (n, o) => {
            const {
                id: a,
                method: h
            } = o;
            try {
                if (this.registeredMethods.includes(h)) return;
                const g = Ne("WC_METHOD_UNSUPPORTED", h);
                await this.sendError(a, n, g), this.logger.error(g)
            } catch (g) {
                await this.sendError(a, n, g), this.logger.error(g)
            }
        }, this.onUnknownRpcMethodResponse = n => {
            this.registeredMethods.includes(n) || this.logger.error(Ne("WC_METHOD_UNSUPPORTED", n))
        }, this.isValidPair = n => {
            var o;
            if (!Br(n)) {
                const {
                    message: h
                } = nt("MISSING_OR_INVALID", `pair() params: ${n}`);
                throw new Error(h)
            }
            if (!m5(n.uri)) {
                const {
                    message: h
                } = nt("MISSING_OR_INVALID", `pair() uri: ${n.uri}`);
                throw new Error(h)
            }
            const a = mp(n.uri);
            if (!((o = a == null ? void 0 : a.relay) != null && o.protocol)) {
                const {
                    message: h
                } = nt("MISSING_OR_INVALID", "pair() uri#relay-protocol");
                throw new Error(h)
            }
            if (!(a != null && a.symKey)) {
                const {
                    message: h
                } = nt("MISSING_OR_INVALID", "pair() uri#symKey");
                throw new Error(h)
            }
            if (a != null && a.expiryTimestamp && lt.toMiliseconds(a == null ? void 0 : a.expiryTimestamp) < Date.now()) {
                const {
                    message: h
                } = nt("EXPIRED", "pair() URI has expired. Please try again with a new connection URI.");
                throw new Error(h)
            }
        }, this.isValidPing = async n => {
            if (!Br(n)) {
                const {
                    message: a
                } = nt("MISSING_OR_INVALID", `ping() params: ${n}`);
                throw new Error(a)
            }
            const {
                topic: o
            } = n;
            await this.isValidPairingTopic(o)
        }, this.isValidDisconnect = async n => {
            if (!Br(n)) {
                const {
                    message: a
                } = nt("MISSING_OR_INVALID", `disconnect() params: ${n}`);
                throw new Error(a)
            }
            const {
                topic: o
            } = n;
            await this.isValidPairingTopic(o)
        }, this.isValidPairingTopic = async n => {
            if (!Ye(n, !1)) {
                const {
                    message: o
                } = nt("MISSING_OR_INVALID", `pairing topic should be a string: ${n}`);
                throw new Error(o)
            }
            if (!this.pairings.keys.includes(n)) {
                const {
                    message: o
                } = nt("NO_MATCHING_KEY", `pairing topic doesn't exist: ${n}`);
                throw new Error(o)
            }
            if (Dn(this.pairings.get(n).expiry)) {
                await this.deletePairing(n);
                const {
                    message: o
                } = nt("EXPIRED", `pairing topic: ${n}`);
                throw new Error(o)
            }
        }, this.core = t, this.logger = Fr(e, this.name), this.pairings = new gs(this.core, this.logger, this.name, this.storagePrefix)
    }
    get context() {
        return zr(this.logger)
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
    registerRelayerEvents() {
        this.core.relayer.on(Lr.message, async t => {
            const {
                topic: e,
                message: n
            } = t;
            if (!this.pairings.keys.includes(e) || this.ignoredPayloadTypes.includes(this.core.crypto.getPayloadType(n))) return;
            const o = await this.core.crypto.decode(e, n);
            try {
                Fu(o) ? (this.core.history.set(e, o), this.onRelayEventRequest({
                    topic: e,
                    payload: o
                })) : Oc(o) && (await this.core.history.resolve(o), await this.onRelayEventResponse({
                    topic: e,
                    payload: o
                }), this.core.history.delete(e, o.id))
            } catch (a) {
                this.logger.error(a)
            }
        })
    }
    registerExpirerEvents() {
        this.core.expirer.on(gi.expired, async t => {
            const {
                topic: e
            } = M0(t.target);
            e && this.pairings.keys.includes(e) && (await this.deletePairing(e, !0), this.events.emit(ks.expire, {
                topic: e
            }))
        })
    }
}
class IS extends H5 {
    constructor(t, e) {
        super(t, e), this.core = t, this.logger = e, this.records = new Map, this.events = new wi.EventEmitter, this.name = J8, this.version = Y8, this.cached = [], this.initialized = !1, this.storagePrefix = kn, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restore(), this.cached.forEach(n => this.records.set(n.id, n)), this.cached = [], this.registerEventListeners(), this.initialized = !0)
        }, this.set = (n, o, a) => {
            if (this.isInitialized(), this.logger.debug("Setting JSON-RPC request history record"), this.logger.trace({
                    type: "method",
                    method: "set",
                    topic: n,
                    request: o,
                    chainId: a
                }), this.records.has(o.id)) return;
            const h = {
                id: o.id,
                topic: n,
                request: {
                    method: o.method,
                    params: o.params || null
                },
                chainId: a,
                expiry: fr(lt.THIRTY_DAYS)
            };
            this.records.set(h.id, h), this.persist(), this.events.emit(Pi.created, h)
        }, this.resolve = async n => {
            if (this.isInitialized(), this.logger.debug("Updating JSON-RPC response history record"), this.logger.trace({
                    type: "method",
                    method: "update",
                    response: n
                }), !this.records.has(n.id)) return;
            const o = await this.getRecord(n.id);
            typeof o.response > "u" && (o.response = vi(n) ? {
                error: n.error
            } : {
                result: n.result
            }, this.records.set(o.id, o), this.persist(), this.events.emit(Pi.updated, o))
        }, this.get = async (n, o) => (this.isInitialized(), this.logger.debug("Getting record"), this.logger.trace({
            type: "method",
            method: "get",
            topic: n,
            id: o
        }), await this.getRecord(o)), this.delete = (n, o) => {
            this.isInitialized(), this.logger.debug("Deleting record"), this.logger.trace({
                type: "method",
                method: "delete",
                id: o
            }), this.values.forEach(a => {
                if (a.topic === n) {
                    if (typeof o < "u" && a.id !== o) return;
                    this.records.delete(a.id), this.events.emit(Pi.deleted, a)
                }
            }), this.persist()
        }, this.exists = async (n, o) => (this.isInitialized(), this.records.has(o) ? (await this.getRecord(o)).topic === n : !1), this.on = (n, o) => {
            this.events.on(n, o)
        }, this.once = (n, o) => {
            this.events.once(n, o)
        }, this.off = (n, o) => {
            this.events.off(n, o)
        }, this.removeListener = (n, o) => {
            this.events.removeListener(n, o)
        }, this.logger = Fr(e, this.name)
    }
    get context() {
        return zr(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + this.core.customStoragePrefix + "//" + this.name
    }
    get size() {
        return this.records.size
    }
    get keys() {
        return Array.from(this.records.keys())
    }
    get values() {
        return Array.from(this.records.values())
    }
    get pending() {
        const t = [];
        return this.values.forEach(e => {
            if (typeof e.response < "u") return;
            const n = {
                topic: e.topic,
                request: Ls(e.request.method, e.request.params, e.id),
                chainId: e.chainId
            };
            return t.push(n)
        }), t
    }
    async setJsonRpcRecords(t) {
        await this.core.storage.setItem(this.storageKey, t)
    }
    async getJsonRpcRecords() {
        return await this.core.storage.getItem(this.storageKey)
    }
    getRecord(t) {
        this.isInitialized();
        const e = this.records.get(t);
        if (!e) {
            const {
                message: n
            } = nt("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw new Error(n)
        }
        return e
    }
    async persist() {
        await this.setJsonRpcRecords(this.values), this.events.emit(Pi.sync)
    }
    async restore() {
        try {
            const t = await this.getJsonRpcRecords();
            if (typeof t > "u" || !t.length) return;
            if (this.records.size) {
                const {
                    message: e
                } = nt("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(e), new Error(e)
            }
            this.cached = t, this.logger.debug(`Successfully Restored records for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                records: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore records for ${this.name}`), this.logger.error(t)
        }
    }
    registerEventListeners() {
        this.events.on(Pi.created, t => {
            const e = Pi.created;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                record: t
            })
        }), this.events.on(Pi.updated, t => {
            const e = Pi.updated;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                record: t
            })
        }), this.events.on(Pi.deleted, t => {
            const e = Pi.deleted;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                record: t
            })
        }), this.core.heartbeat.on(jo.pulse, () => {
            this.cleanup()
        })
    }
    cleanup() {
        try {
            this.isInitialized();
            let t = !1;
            this.records.forEach(e => {
                lt.toMiliseconds(e.expiry || 0) - Date.now() <= 0 && (this.logger.info(`Deleting expired history log: ${e.id}`), this.records.delete(e.id), this.events.emit(Pi.deleted, e, !1), t = !0)
            }), t && this.persist()
        } catch (t) {
            this.logger.warn(t)
        }
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class SS extends J5 {
    constructor(t, e) {
        super(t, e), this.core = t, this.logger = e, this.expirations = new Map, this.events = new wi.EventEmitter, this.name = X8, this.version = Z8, this.cached = [], this.initialized = !1, this.storagePrefix = kn, this.init = async () => {
            this.initialized || (this.logger.trace("Initialized"), await this.restore(), this.cached.forEach(n => this.expirations.set(n.target, n)), this.cached = [], this.registerEventListeners(), this.initialized = !0)
        }, this.has = n => {
            try {
                const o = this.formatTarget(n);
                return typeof this.getExpiration(o) < "u"
            } catch {
                return !1
            }
        }, this.set = (n, o) => {
            this.isInitialized();
            const a = this.formatTarget(n),
                h = {
                    target: a,
                    expiry: o
                };
            this.expirations.set(a, h), this.checkExpiry(a, h), this.events.emit(gi.created, {
                target: a,
                expiration: h
            })
        }, this.get = n => {
            this.isInitialized();
            const o = this.formatTarget(n);
            return this.getExpiration(o)
        }, this.del = n => {
            if (this.isInitialized(), this.has(n)) {
                const o = this.formatTarget(n),
                    a = this.getExpiration(o);
                this.expirations.delete(o), this.events.emit(gi.deleted, {
                    target: o,
                    expiration: a
                })
            }
        }, this.on = (n, o) => {
            this.events.on(n, o)
        }, this.once = (n, o) => {
            this.events.once(n, o)
        }, this.off = (n, o) => {
            this.events.off(n, o)
        }, this.removeListener = (n, o) => {
            this.events.removeListener(n, o)
        }, this.logger = Fr(e, this.name)
    }
    get context() {
        return zr(this.logger)
    }
    get storageKey() {
        return this.storagePrefix + this.version + this.core.customStoragePrefix + "//" + this.name
    }
    get length() {
        return this.expirations.size
    }
    get keys() {
        return Array.from(this.expirations.keys())
    }
    get values() {
        return Array.from(this.expirations.values())
    }
    formatTarget(t) {
        if (typeof t == "string") return z3(t);
        if (typeof t == "number") return F3(t);
        const {
            message: e
        } = nt("UNKNOWN_TYPE", `Target type: ${typeof t}`);
        throw new Error(e)
    }
    async setExpirations(t) {
        await this.core.storage.setItem(this.storageKey, t)
    }
    async getExpirations() {
        return await this.core.storage.getItem(this.storageKey)
    }
    async persist() {
        await this.setExpirations(this.values), this.events.emit(gi.sync)
    }
    async restore() {
        try {
            const t = await this.getExpirations();
            if (typeof t > "u" || !t.length) return;
            if (this.expirations.size) {
                const {
                    message: e
                } = nt("RESTORE_WILL_OVERRIDE", this.name);
                throw this.logger.error(e), new Error(e)
            }
            this.cached = t, this.logger.debug(`Successfully Restored expirations for ${this.name}`), this.logger.trace({
                type: "method",
                method: "restore",
                expirations: this.values
            })
        } catch (t) {
            this.logger.debug(`Failed to Restore expirations for ${this.name}`), this.logger.error(t)
        }
    }
    getExpiration(t) {
        const e = this.expirations.get(t);
        if (!e) {
            const {
                message: n
            } = nt("NO_MATCHING_KEY", `${this.name}: ${t}`);
            throw this.logger.warn(n), new Error(n)
        }
        return e
    }
    checkExpiry(t, e) {
        const {
            expiry: n
        } = e;
        lt.toMiliseconds(n) - Date.now() <= 0 && this.expire(t, e)
    }
    expire(t, e) {
        this.expirations.delete(t), this.events.emit(gi.expired, {
            target: t,
            expiration: e
        })
    }
    checkExpirations() {
        this.core.relayer.connected && this.expirations.forEach((t, e) => this.checkExpiry(e, t))
    }
    registerEventListeners() {
        this.core.heartbeat.on(jo.pulse, () => this.checkExpirations()), this.events.on(gi.created, t => {
            const e = gi.created;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                data: t
            }), this.persist()
        }), this.events.on(gi.expired, t => {
            const e = gi.expired;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                data: t
            }), this.persist()
        }), this.events.on(gi.deleted, t => {
            const e = gi.deleted;
            this.logger.info(`Emitting ${e}`), this.logger.debug({
                type: "event",
                event: e,
                data: t
            }), this.persist()
        })
    }
    isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
    }
}
class xS extends Y5 {
    constructor(t, e) {
        super(t, e), this.projectId = t, this.logger = e, this.name = fu, this.initialized = !1, this.queue = [], this.verifyDisabled = !1, this.init = async n => {
            if (this.verifyDisabled || Ks() || !Vs()) return;
            const o = this.getVerifyUrl(n == null ? void 0 : n.verifyUrl);
            this.verifyUrl !== o && this.removeIframe(), this.verifyUrl = o;
            try {
                await this.createIframe()
            } catch (a) {
                this.logger.info(`Verify iframe failed to load: ${this.verifyUrl}`), this.logger.info(a), this.verifyDisabled = !0
            }
        }, this.register = async n => {
            this.initialized ? this.sendPost(n.attestationId) : (this.addToQueue(n.attestationId), await this.init())
        }, this.resolve = async n => {
            if (this.isDevEnv) return "";
            const o = this.getVerifyUrl(n == null ? void 0 : n.verifyUrl);
            return this.fetchAttestation(n.attestationId, o)
        }, this.fetchAttestation = async (n, o) => {
            this.logger.info(`resolving attestation: ${n} from url: ${o}`);
            const a = this.startAbortTimer(lt.ONE_SECOND * 5),
                h = await fetch(`${o}/attestation/${n}`, {
                    signal: this.abortController.signal
                });
            return clearTimeout(a), h.status === 200 ? await h.json() : void 0
        }, this.addToQueue = n => {
            this.queue.push(n)
        }, this.processQueue = () => {
            this.queue.length !== 0 && (this.queue.forEach(n => this.sendPost(n)), this.queue = [])
        }, this.sendPost = n => {
            var o;
            try {
                if (!this.iframe) return;
                (o = this.iframe.contentWindow) == null || o.postMessage(n, "*"), this.logger.info(`postMessage sent: ${n} ${this.verifyUrl}`)
            } catch {}
        }, this.createIframe = async () => {
            let n;
            const o = a => {
                a.data === "verify_ready" && (this.onInit(), window.removeEventListener("message", o), n())
            };
            await Promise.race([new Promise(a => {
                const h = document.getElementById(fu);
                if (h) return this.iframe = h, this.onInit(), a();
                window.addEventListener("message", o);
                const g = document.createElement("iframe");
                g.id = fu, g.src = `${this.verifyUrl}/${this.projectId}`, g.style.display = "none", document.body.append(g), this.iframe = g, n = a
            }), new Promise((a, h) => setTimeout(() => {
                window.removeEventListener("message", o), h("verify iframe load timeout")
            }, lt.toMiliseconds(lt.FIVE_SECONDS)))])
        }, this.onInit = () => {
            this.initialized = !0, this.processQueue()
        }, this.removeIframe = () => {
            this.iframe && (this.iframe.remove(), this.iframe = void 0, this.initialized = !1)
        }, this.getVerifyUrl = n => {
            let o = n || Co;
            return eS.includes(o) || (this.logger.info(`verify url: ${o}, not included in trusted list, assigning default: ${Co}`), o = Co), o
        }, this.logger = Fr(e, this.name), this.verifyUrl = Co, this.abortController = new AbortController, this.isDevEnv = Do() && eI.IS_VITEST
    }
    get context() {
        return zr(this.logger)
    }
    startAbortTimer(t) {
        return this.abortController = new AbortController, setTimeout(() => this.abortController.abort(), lt.toMiliseconds(t))
    }
}
class PS extends X5 {
    constructor(t, e) {
        super(t, e), this.projectId = t, this.logger = e, this.context = rS, this.registerDeviceToken = async n => {
            const {
                clientId: o,
                token: a,
                notificationType: h,
                enableEncrypted: g = !1
            } = n, b = `${iS}/${this.projectId}/clients`;
            await fetch(b, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    client_id: o,
                    type: h,
                    token: a,
                    always_raw: g
                })
            })
        }, this.logger = Fr(e, this.context)
    }
}
var MS = Object.defineProperty,
    Up = Object.getOwnPropertySymbols,
    CS = Object.prototype.hasOwnProperty,
    NS = Object.prototype.propertyIsEnumerable,
    kp = (r, t, e) => t in r ? MS(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Lp = (r, t) => {
        for (var e in t || (t = {})) CS.call(t, e) && kp(r, e, t[e]);
        if (Up)
            for (var e of Up(t)) NS.call(t, e) && kp(r, e, t[e]);
        return r
    };
class el extends F5 {
    constructor(t) {
        var e;
        super(t), this.protocol = Pg, this.version = x8, this.name = tl, this.events = new wi.EventEmitter, this.initialized = !1, this.on = (h, g) => this.events.on(h, g), this.once = (h, g) => this.events.once(h, g), this.off = (h, g) => this.events.off(h, g), this.removeListener = (h, g) => this.events.removeListener(h, g), this.projectId = t == null ? void 0 : t.projectId, this.relayUrl = (t == null ? void 0 : t.relayUrl) || Cg, this.customStoragePrefix = t != null && t.customStoragePrefix ? `:${t.customStoragePrefix}` : "";
        const n = Cc({
                level: typeof(t == null ? void 0 : t.logger) == "string" && t.logger ? t.logger : P8.logger
            }),
            {
                logger: o,
                chunkLoggerController: a
            } = L6({
                opts: n,
                maxSizeInBytes: t == null ? void 0 : t.maxLogBlobSizeInBytes,
                loggerOverride: t == null ? void 0 : t.logger
            });
        this.logChunkController = a, (e = this.logChunkController) != null && e.downloadLogsBlobInBrowser && (window.downloadLogsBlobInBrowser = async () => {
            var h, g;
            (h = this.logChunkController) != null && h.downloadLogsBlobInBrowser && ((g = this.logChunkController) == null || g.downloadLogsBlobInBrowser({
                clientId: await this.crypto.getClientId()
            }))
        }), this.logger = Fr(o, this.name), this.heartbeat = new I6, this.crypto = new sS(this, this.logger, t == null ? void 0 : t.keychain), this.history = new IS(this, this.logger), this.expirer = new SS(this, this.logger), this.storage = t != null && t.storage ? t.storage : new A6(Lp(Lp({}, M8), t == null ? void 0 : t.storageOptions)), this.relayer = new wS({
            core: this,
            logger: this.logger,
            relayUrl: this.relayUrl,
            projectId: this.projectId
        }), this.pairing = new ES(this, this.logger), this.verify = new xS(this.projectId || "", this.logger), this.echoClient = new PS(this.projectId || "", this.logger)
    }
    static async init(t) {
        const e = new el(t);
        await e.initialize();
        const n = await e.crypto.getClientId();
        return await e.storage.setItem(H8, n), e
    }
    get context() {
        return zr(this.logger)
    }
    async start() {
        this.initialized || await this.initialize()
    }
    async getLogsBlob() {
        var t;
        return (t = this.logChunkController) == null ? void 0 : t.logsToBlob({
            clientId: await this.crypto.getClientId()
        })
    }
    async initialize() {
        this.logger.trace("Initialized");
        try {
            await this.crypto.init(), await this.history.init(), await this.expirer.init(), await this.relayer.init(), await this.heartbeat.init(), await this.pairing.init(), this.initialized = !0, this.logger.info("Core Initialization Success")
        } catch (t) {
            throw this.logger.warn(`Core Initialization Failure at epoch ${Date.now()}`, t), this.logger.error(t.message), t
        }
    }
}
const RS = el,
    Rg = "wc",
    Og = 2,
    Tg = "client",
    rl = `${Rg}@${Og}:${Tg}:`,
    pu = {
        name: Tg,
        logger: "error",
        controller: !1,
        relayUrl: "wss://relay.walletconnect.com"
    },
    $p = "WALLETCONNECT_DEEPLINK_CHOICE",
    OS = "proposal",
    Dg = "Proposal expired",
    TS = "session",
    Ds = lt.SEVEN_DAYS,
    DS = "engine",
    lr = {
        wc_sessionPropose: {
            req: {
                ttl: lt.FIVE_MINUTES,
                prompt: !0,
                tag: 1100
            },
            res: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1101
            },
            reject: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1120
            },
            autoReject: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1121
            }
        },
        wc_sessionSettle: {
            req: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1102
            },
            res: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1103
            }
        },
        wc_sessionUpdate: {
            req: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1104
            },
            res: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1105
            }
        },
        wc_sessionExtend: {
            req: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1106
            },
            res: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1107
            }
        },
        wc_sessionRequest: {
            req: {
                ttl: lt.FIVE_MINUTES,
                prompt: !0,
                tag: 1108
            },
            res: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1109
            }
        },
        wc_sessionEvent: {
            req: {
                ttl: lt.FIVE_MINUTES,
                prompt: !0,
                tag: 1110
            },
            res: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1111
            }
        },
        wc_sessionDelete: {
            req: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1112
            },
            res: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1113
            }
        },
        wc_sessionPing: {
            req: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1114
            },
            res: {
                ttl: lt.ONE_DAY,
                prompt: !1,
                tag: 1115
            }
        },
        wc_sessionAuthenticate: {
            req: {
                ttl: lt.ONE_HOUR,
                prompt: !0,
                tag: 1116
            },
            res: {
                ttl: lt.ONE_HOUR,
                prompt: !1,
                tag: 1117
            },
            reject: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1118
            },
            autoReject: {
                ttl: lt.FIVE_MINUTES,
                prompt: !1,
                tag: 1119
            }
        }
    },
    gu = {
        min: lt.FIVE_MINUTES,
        max: lt.SEVEN_DAYS
    },
    Fi = {
        idle: "IDLE",
        active: "ACTIVE"
    },
    qS = "request",
    BS = ["wc_sessionPropose", "wc_sessionRequest", "wc_authRequest", "wc_sessionAuthenticate"],
    US = "wc",
    kS = "auth",
    LS = "authKeys",
    $S = "pairingTopics",
    jS = "requests",
    qc = `${US}@${1.5}:${kS}:`,
    pc = `${qc}:PUB_KEY`;
var zS = Object.defineProperty,
    FS = Object.defineProperties,
    HS = Object.getOwnPropertyDescriptors,
    jp = Object.getOwnPropertySymbols,
    KS = Object.prototype.hasOwnProperty,
    VS = Object.prototype.propertyIsEnumerable,
    zp = (r, t, e) => t in r ? zS(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    rr = (r, t) => {
        for (var e in t || (t = {})) KS.call(t, e) && zp(r, e, t[e]);
        if (jp)
            for (var e of jp(t)) VS.call(t, e) && zp(r, e, t[e]);
        return r
    },
    ss = (r, t) => FS(r, HS(t));
class GS extends tI {
    constructor(t) {
        super(t), this.name = DS, this.events = new ku, this.initialized = !1, this.requestQueue = {
            state: Fi.idle,
            queue: []
        }, this.sessionRequestQueue = {
            state: Fi.idle,
            queue: []
        }, this.requestQueueDelay = lt.ONE_SECOND, this.expectedPairingMethodMap = new Map, this.recentlyDeletedMap = new Map, this.recentlyDeletedLimit = 200, this.relayMessageCache = [], this.init = async () => {
            this.initialized || (await this.cleanup(), this.registerRelayerEvents(), this.registerExpirerEvents(), this.registerPairingEvents(), this.client.core.pairing.register({
                methods: Object.keys(lr)
            }), this.initialized = !0, setTimeout(() => {
                this.sessionRequestQueue.queue = this.getPendingSessionRequests(), this.processSessionRequestQueue()
            }, lt.toMiliseconds(this.requestQueueDelay)))
        }, this.connect = async e => {
            await this.isInitialized();
            const n = ss(rr({}, e), {
                requiredNamespaces: e.requiredNamespaces || {},
                optionalNamespaces: e.optionalNamespaces || {}
            });
            await this.isValidConnect(n);
            const {
                pairingTopic: o,
                requiredNamespaces: a,
                optionalNamespaces: h,
                sessionProperties: g,
                relays: b
            } = n;
            let m = o,
                _, S = !1;
            try {
                m && (S = this.client.core.pairing.pairings.get(m).active)
            } catch (ft) {
                throw this.client.logger.error(`connect() -> pairing.get(${m}) failed`), ft
            }
            if (!m || !S) {
                const {
                    topic: ft,
                    uri: st
                } = await this.client.core.pairing.create();
                m = ft, _ = st
            }
            if (!m) {
                const {
                    message: ft
                } = nt("NO_MATCHING_KEY", `connect() pairing topic: ${m}`);
                throw new Error(ft)
            }
            const B = await this.client.core.crypto.generateKeyPair(),
                k = lr.wc_sessionPropose.req.ttl || lt.FIVE_MINUTES,
                L = fr(k),
                K = rr({
                    requiredNamespaces: a,
                    optionalNamespaces: h,
                    relays: b ? ? [{
                        protocol: Mg
                    }],
                    proposer: {
                        publicKey: B,
                        metadata: this.client.metadata
                    },
                    expiryTimestamp: L,
                    pairingTopic: m
                }, g && {
                    sessionProperties: g
                }),
                {
                    reject: Q,
                    resolve: et,
                    done: at
                } = os(k, Dg);
            this.events.once(he("session_connect"), async ({
                error: ft,
                session: st
            }) => {
                if (ft) Q(ft);
                else if (st) {
                    st.self.publicKey = B;
                    const ot = ss(rr({}, st), {
                        pairingTopic: K.pairingTopic,
                        requiredNamespaces: K.requiredNamespaces,
                        optionalNamespaces: K.optionalNamespaces
                    });
                    await this.client.session.set(st.topic, ot), await this.setExpiry(st.topic, st.expiry), m && await this.client.core.pairing.updateMetadata({
                        topic: m,
                        metadata: st.peer.metadata
                    }), this.cleanupDuplicatePairings(ot), et(ot)
                }
            });
            const ut = await this.sendRequest({
                topic: m,
                method: "wc_sessionPropose",
                params: K,
                throwOnFailedPublish: !0
            });
            return await this.setProposal(ut, rr({
                id: ut
            }, K)), {
                uri: _,
                approval: at
            }
        }, this.pair = async e => {
            await this.isInitialized();
            try {
                return await this.client.core.pairing.pair(e)
            } catch (n) {
                throw this.client.logger.error("pair() failed"), n
            }
        }, this.approve = async e => {
            await this.isInitialized();
            try {
                await this.isValidApprove(e)
            } catch (at) {
                throw this.client.logger.error("approve() -> isValidApprove() failed"), at
            }
            const {
                id: n,
                relayProtocol: o,
                namespaces: a,
                sessionProperties: h,
                sessionConfig: g
            } = e;
            let b;
            try {
                b = this.client.proposal.get(n)
            } catch (at) {
                throw this.client.logger.error(`approve() -> proposal.get(${n}) failed`), at
            }
            const {
                pairingTopic: m,
                proposer: _,
                requiredNamespaces: S,
                optionalNamespaces: B
            } = b, k = await this.client.core.crypto.generateKeyPair(), L = _.publicKey, K = await this.client.core.crypto.generateSharedKey(k, L), Q = rr(rr({
                relay: {
                    protocol: o ? ? "irn"
                },
                namespaces: a,
                controller: {
                    publicKey: k,
                    metadata: this.client.metadata
                },
                expiry: fr(Ds)
            }, h && {
                sessionProperties: h
            }), g && {
                sessionConfig: g
            });
            await this.client.core.relayer.subscribe(K);
            const et = ss(rr({}, Q), {
                topic: K,
                requiredNamespaces: S,
                optionalNamespaces: B,
                pairingTopic: m,
                acknowledged: !1,
                self: Q.controller,
                peer: {
                    publicKey: _.publicKey,
                    metadata: _.metadata
                },
                controller: k
            });
            await this.client.session.set(K, et);
            try {
                await this.sendRequest({
                    topic: K,
                    method: "wc_sessionSettle",
                    params: Q,
                    throwOnFailedPublish: !0
                }), await this.sendResult({
                    id: n,
                    topic: m,
                    result: {
                        relay: {
                            protocol: o ? ? "irn"
                        },
                        responderPublicKey: k
                    },
                    throwOnFailedPublish: !0
                })
            } catch (at) {
                throw this.client.logger.error(at), this.client.session.delete(K, Ne("USER_DISCONNECTED")), await this.client.core.relayer.unsubscribe(K), at
            }
            return await this.client.core.pairing.updateMetadata({
                topic: m,
                metadata: _.metadata
            }), await this.client.proposal.delete(n, Ne("USER_DISCONNECTED")), await this.client.core.pairing.activate({
                topic: m
            }), await this.setExpiry(K, fr(Ds)), {
                topic: K,
                acknowledged: () => Promise.resolve(this.client.session.get(K))
            }
        }, this.reject = async e => {
            await this.isInitialized();
            try {
                await this.isValidReject(e)
            } catch (h) {
                throw this.client.logger.error("reject() -> isValidReject() failed"), h
            }
            const {
                id: n,
                reason: o
            } = e;
            let a;
            try {
                a = this.client.proposal.get(n).pairingTopic
            } catch (h) {
                throw this.client.logger.error(`reject() -> proposal.get(${n}) failed`), h
            }
            a && (await this.sendError({
                id: n,
                topic: a,
                error: o,
                rpcOpts: lr.wc_sessionPropose.reject
            }), await this.client.proposal.delete(n, Ne("USER_DISCONNECTED")))
        }, this.update = async e => {
            await this.isInitialized();
            try {
                await this.isValidUpdate(e)
            } catch (S) {
                throw this.client.logger.error("update() -> isValidUpdate() failed"), S
            }
            const {
                topic: n,
                namespaces: o
            } = e, {
                done: a,
                resolve: h,
                reject: g
            } = os(), b = Tn(), m = as().toString(), _ = this.client.session.get(n).namespaces;
            return this.events.once(he("session_update", b), ({
                error: S
            }) => {
                S ? g(S) : h()
            }), await this.client.session.update(n, {
                namespaces: o
            }), await this.sendRequest({
                topic: n,
                method: "wc_sessionUpdate",
                params: {
                    namespaces: o
                },
                throwOnFailedPublish: !0,
                clientRpcId: b,
                relayRpcId: m
            }).catch(S => {
                this.client.logger.error(S), this.client.session.update(n, {
                    namespaces: _
                }), g(S)
            }), {
                acknowledged: a
            }
        }, this.extend = async e => {
            await this.isInitialized();
            try {
                await this.isValidExtend(e)
            } catch (b) {
                throw this.client.logger.error("extend() -> isValidExtend() failed"), b
            }
            const {
                topic: n
            } = e, o = Tn(), {
                done: a,
                resolve: h,
                reject: g
            } = os();
            return this.events.once(he("session_extend", o), ({
                error: b
            }) => {
                b ? g(b) : h()
            }), await this.setExpiry(n, fr(Ds)), this.sendRequest({
                topic: n,
                method: "wc_sessionExtend",
                params: {},
                clientRpcId: o,
                throwOnFailedPublish: !0
            }).catch(b => {
                g(b)
            }), {
                acknowledged: a
            }
        }, this.request = async e => {
            await this.isInitialized();
            try {
                await this.isValidRequest(e)
            } catch (k) {
                throw this.client.logger.error("request() -> isValidRequest() failed"), k
            }
            const {
                chainId: n,
                request: o,
                topic: a,
                expiry: h = lr.wc_sessionRequest.req.ttl
            } = e, g = this.client.session.get(a), b = Tn(), m = as().toString(), {
                done: _,
                resolve: S,
                reject: B
            } = os(h, "Request expired. Please try again.");
            return this.events.once(he("session_request", b), ({
                error: k,
                result: L
            }) => {
                k ? B(k) : S(L)
            }), await Promise.all([new Promise(async k => {
                await this.sendRequest({
                    clientRpcId: b,
                    relayRpcId: m,
                    topic: a,
                    method: "wc_sessionRequest",
                    params: {
                        request: ss(rr({}, o), {
                            expiryTimestamp: fr(h)
                        }),
                        chainId: n
                    },
                    expiry: h,
                    throwOnFailedPublish: !0
                }).catch(L => B(L)), this.client.events.emit("session_request_sent", {
                    topic: a,
                    request: o,
                    chainId: n,
                    id: b
                }), k()
            }), new Promise(async k => {
                var L;
                if (!((L = g.sessionConfig) != null && L.disableDeepLink)) {
                    const K = await K3(this.client.core.storage, $p);
                    H3({
                        id: b,
                        topic: a,
                        wcDeepLink: K
                    })
                }
                k()
            }), _()]).then(k => k[2])
        }, this.respond = async e => {
            await this.isInitialized(), await this.isValidRespond(e);
            const {
                topic: n,
                response: o
            } = e, {
                id: a
            } = o;
            Hi(o) ? await this.sendResult({
                id: a,
                topic: n,
                result: o.result,
                throwOnFailedPublish: !0
            }) : vi(o) && await this.sendError({
                id: a,
                topic: n,
                error: o.error
            }), this.cleanupAfterResponse(e)
        }, this.ping = async e => {
            await this.isInitialized();
            try {
                await this.isValidPing(e)
            } catch (o) {
                throw this.client.logger.error("ping() -> isValidPing() failed"), o
            }
            const {
                topic: n
            } = e;
            if (this.client.session.keys.includes(n)) {
                const o = Tn(),
                    a = as().toString(),
                    {
                        done: h,
                        resolve: g,
                        reject: b
                    } = os();
                this.events.once(he("session_ping", o), ({
                    error: m
                }) => {
                    m ? b(m) : g()
                }), await Promise.all([this.sendRequest({
                    topic: n,
                    method: "wc_sessionPing",
                    params: {},
                    throwOnFailedPublish: !0,
                    clientRpcId: o,
                    relayRpcId: a
                }), h()])
            } else this.client.core.pairing.pairings.keys.includes(n) && await this.client.core.pairing.ping({
                topic: n
            })
        }, this.emit = async e => {
            await this.isInitialized(), await this.isValidEmit(e);
            const {
                topic: n,
                event: o,
                chainId: a
            } = e, h = as().toString();
            await this.sendRequest({
                topic: n,
                method: "wc_sessionEvent",
                params: {
                    event: o,
                    chainId: a
                },
                throwOnFailedPublish: !0,
                relayRpcId: h
            })
        }, this.disconnect = async e => {
            await this.isInitialized(), await this.isValidDisconnect(e);
            const {
                topic: n
            } = e;
            if (this.client.session.keys.includes(n)) await this.sendRequest({
                topic: n,
                method: "wc_sessionDelete",
                params: Ne("USER_DISCONNECTED"),
                throwOnFailedPublish: !0
            }), await this.deleteSession({
                topic: n,
                emitEvent: !1
            });
            else if (this.client.core.pairing.pairings.keys.includes(n)) await this.client.core.pairing.disconnect({
                topic: n
            });
            else {
                const {
                    message: o
                } = nt("MISMATCHED_TOPIC", `Session or pairing topic not found: ${n}`);
                throw new Error(o)
            }
        }, this.find = e => (this.isInitialized(), this.client.session.getAll().filter(n => p5(n, e))), this.getPendingSessionRequests = () => this.client.pendingRequest.getAll(), this.authenticate = async e => {
            this.isInitialized(), this.isValidAuthenticate(e);
            const {
                chains: n,
                statement: o = "",
                uri: a,
                domain: h,
                nonce: g,
                type: b,
                exp: m,
                nbf: _,
                methods: S = [],
                expiry: B
            } = e, k = [...e.resources || []], {
                topic: L,
                uri: K
            } = await this.client.core.pairing.create({
                methods: ["wc_sessionAuthenticate"]
            });
            this.client.logger.info({
                message: "Generated new pairing",
                pairing: {
                    topic: L,
                    uri: K
                }
            });
            const Q = await this.client.core.crypto.generateKeyPair(),
                et = dc(Q);
            if (await Promise.all([this.client.auth.authKeys.set(pc, {
                    responseTopic: et,
                    publicKey: Q
                }), this.client.auth.pairingTopics.set(et, {
                    topic: et,
                    pairingTopic: L
                })]), await this.client.core.relayer.subscribe(et), this.client.logger.info(`sending request to new pairing topic: ${L}`), S.length > 0) {
                const {
                    namespace: u
                } = Ro(n[0]);
                let p = kE(u, "request", S);
                fc(k) && (p = $E(p, k.pop())), k.push(p)
            }
            const at = B && B > lr.wc_sessionAuthenticate.req.ttl ? B : lr.wc_sessionAuthenticate.req.ttl,
                ut = {
                    authPayload: {
                        type: b ? ? "caip122",
                        chains: n,
                        statement: o,
                        aud: a,
                        domain: h,
                        version: "1",
                        nonce: g,
                        iat: new Date().toISOString(),
                        exp: m,
                        nbf: _,
                        resources: k
                    },
                    requester: {
                        publicKey: Q,
                        metadata: this.client.metadata
                    },
                    expiryTimestamp: fr(at)
                },
                ft = {
                    eip155: {
                        chains: n,
                        methods: [...new Set(["personal_sign", ...S])],
                        events: ["chainChanged", "accountsChanged"]
                    }
                },
                st = {
                    requiredNamespaces: {},
                    optionalNamespaces: ft,
                    relays: [{
                        protocol: "irn"
                    }],
                    pairingTopic: L,
                    proposer: {
                        publicKey: Q,
                        metadata: this.client.metadata
                    },
                    expiryTimestamp: fr(lr.wc_sessionPropose.req.ttl)
                },
                {
                    done: ot,
                    resolve: it,
                    reject: mt
                } = os(at, "Request expired"),
                Zt = async ({
                    error: u,
                    session: p
                }) => {
                    if (this.events.off(he("session_request", Tt), oe), u) mt(u);
                    else if (p) {
                        p.self.publicKey = Q, await this.client.session.set(p.topic, p), await this.setExpiry(p.topic, p.expiry), L && await this.client.core.pairing.updateMetadata({
                            topic: L,
                            metadata: p.peer.metadata
                        });
                        const v = this.client.session.get(p.topic);
                        await this.deleteProposal(ve), it({
                            session: v
                        })
                    }
                },
                oe = async u => {
                    if (await this.deletePendingAuthRequest(Tt, {
                            message: "fulfilled",
                            code: 0
                        }), u.error) {
                        const E = Ne("WC_METHOD_UNSUPPORTED", "wc_sessionAuthenticate");
                        return u.error.code === E.code ? void 0 : (this.events.off(he("session_connect"), Zt), mt(u.error.message))
                    }
                    await this.deleteProposal(ve), this.events.off(he("session_connect"), Zt);
                    const {
                        cacaos: p,
                        responder: v
                    } = u.result, P = [], C = [];
                    for (const E of p) {
                        await cp({
                            cacao: E,
                            projectId: this.client.core.projectId
                        }) || (this.client.logger.error(E, "Signature verification failed"), mt(Ne("SESSION_SETTLEMENT_FAILED", "Signature verification failed")));
                        const {
                            p: f
                        } = E, x = fc(f.resources), ht = [ap(f.iss)], gt = Ic(f.iss);
                        if (x) {
                            const y = hp(x),
                                V = up(x);
                            P.push(...y), ht.push(...V)
                        }
                        for (const y of ht) C.push(`${y}:${gt}`)
                    }
                    const R = await this.client.core.crypto.generateSharedKey(Q, v.publicKey);
                    let T;
                    P.length > 0 && (T = {
                        topic: R,
                        acknowledged: !0,
                        self: {
                            publicKey: Q,
                            metadata: this.client.metadata
                        },
                        peer: v,
                        controller: v.publicKey,
                        expiry: fr(Ds),
                        requiredNamespaces: {},
                        optionalNamespaces: {},
                        relay: {
                            protocol: "irn"
                        },
                        pairingTopic: L,
                        namespaces: vp([...new Set(P)], [...new Set(C)])
                    }, await this.client.core.relayer.subscribe(R), await this.client.session.set(R, T), L && await this.client.core.pairing.updateMetadata({
                        topic: L,
                        metadata: v.metadata
                    }), T = this.client.session.get(R)), it({
                        auths: p,
                        session: T
                    })
                },
                Tt = Tn(),
                ve = Tn();
            this.events.once(he("session_connect"), Zt), this.events.once(he("session_request", Tt), oe);
            try {
                await Promise.all([this.sendRequest({
                    topic: L,
                    method: "wc_sessionAuthenticate",
                    params: ut,
                    expiry: e.expiry,
                    throwOnFailedPublish: !0,
                    clientRpcId: Tt
                }), this.sendRequest({
                    topic: L,
                    method: "wc_sessionPropose",
                    params: st,
                    expiry: lr.wc_sessionPropose.req.ttl,
                    throwOnFailedPublish: !0,
                    clientRpcId: ve
                })])
            } catch (u) {
                throw this.events.off(he("session_connect"), Zt), this.events.off(he("session_request", Tt), oe), u
            }
            return await this.setProposal(ve, rr({
                id: ve
            }, st)), await this.setAuthRequest(Tt, {
                request: ss(rr({}, ut), {
                    verifyContext: {}
                }),
                pairingTopic: L
            }), {
                uri: K,
                response: ot
            }
        }, this.approveSessionAuthenticate = async e => {
            this.isInitialized();
            const {
                id: n,
                auths: o
            } = e, a = this.getPendingAuthRequest(n);
            if (!a) throw new Error(`Could not find pending auth request with id ${n}`);
            const h = a.requester.publicKey,
                g = await this.client.core.crypto.generateKeyPair(),
                b = dc(h),
                m = {
                    type: yn,
                    receiverPublicKey: h,
                    senderPublicKey: g
                },
                _ = [],
                S = [];
            for (const L of o) {
                if (!await cp({
                        cacao: L,
                        projectId: this.client.core.projectId
                    })) {
                    const ut = Ne("SESSION_SETTLEMENT_FAILED", "Signature verification failed");
                    throw await this.sendError({
                        id: n,
                        topic: b,
                        error: ut,
                        encodeOpts: m
                    }), new Error(ut.message)
                }
                const {
                    p: K
                } = L, Q = fc(K.resources), et = [ap(K.iss)], at = Ic(K.iss);
                if (Q) {
                    const ut = hp(Q),
                        ft = up(Q);
                    _.push(...ut), et.push(...ft)
                }
                for (const ut of et) S.push(`${ut}:${at}`)
            }
            const B = await this.client.core.crypto.generateSharedKey(g, h);
            let k;
            return (_ == null ? void 0 : _.length) > 0 && (k = {
                topic: B,
                acknowledged: !0,
                self: {
                    publicKey: g,
                    metadata: this.client.metadata
                },
                peer: {
                    publicKey: h,
                    metadata: a.requester.metadata
                },
                controller: h,
                expiry: fr(Ds),
                authentication: o,
                requiredNamespaces: {},
                optionalNamespaces: {},
                relay: {
                    protocol: "irn"
                },
                pairingTopic: a.pairingTopic,
                namespaces: vp([...new Set(_)], [...new Set(S)])
            }, await this.client.core.relayer.subscribe(B), await this.client.session.set(B, k), await this.client.core.pairing.updateMetadata({
                topic: a.pairingTopic,
                metadata: a.requester.metadata
            })), await this.sendResult({
                topic: b,
                id: n,
                result: {
                    cacaos: o,
                    responder: {
                        publicKey: g,
                        metadata: this.client.metadata
                    }
                },
                encodeOpts: m,
                throwOnFailedPublish: !0
            }), await this.client.auth.requests.delete(n, {
                message: "fulfilled",
                code: 0
            }), await this.client.core.pairing.activate({
                topic: a.pairingTopic
            }), {
                session: k
            }
        }, this.rejectSessionAuthenticate = async e => {
            await this.isInitialized();
            const {
                id: n,
                reason: o
            } = e, a = this.getPendingAuthRequest(n);
            if (!a) throw new Error(`Could not find pending auth request with id ${n}`);
            const h = a.requester.publicKey,
                g = await this.client.core.crypto.generateKeyPair(),
                b = dc(h),
                m = {
                    type: yn,
                    receiverPublicKey: h,
                    senderPublicKey: g
                };
            await this.sendError({
                id: n,
                topic: b,
                error: o,
                encodeOpts: m,
                rpcOpts: lr.wc_sessionAuthenticate.reject
            }), await this.client.auth.requests.delete(n, {
                message: "rejected",
                code: 0
            }), await this.client.proposal.delete(n, Ne("USER_DISCONNECTED"))
        }, this.formatAuthMessage = e => {
            this.isInitialized();
            const {
                request: n,
                iss: o
            } = e;
            return ug(n, o)
        }, this.processRelayMessageCache = () => {
            setTimeout(async () => {
                if (this.relayMessageCache.length !== 0)
                    for (; this.relayMessageCache.length > 0;) try {
                        const e = this.relayMessageCache.shift();
                        e && await this.onRelayMessage(e)
                    } catch (e) {
                        this.client.logger.error(e)
                    }
            }, 50)
        }, this.cleanupDuplicatePairings = async e => {
            if (e.pairingTopic) try {
                const n = this.client.core.pairing.pairings.get(e.pairingTopic),
                    o = this.client.core.pairing.pairings.getAll().filter(a => {
                        var h, g;
                        return ((h = a.peerMetadata) == null ? void 0 : h.url) && ((g = a.peerMetadata) == null ? void 0 : g.url) === e.peer.metadata.url && a.topic && a.topic !== n.topic
                    });
                if (o.length === 0) return;
                this.client.logger.info(`Cleaning up ${o.length} duplicate pairing(s)`), await Promise.all(o.map(a => this.client.core.pairing.disconnect({
                    topic: a.topic
                }))), this.client.logger.info("Duplicate pairings clean up finished")
            } catch (n) {
                this.client.logger.error(n)
            }
        }, this.deleteSession = async e => {
            var n;
            const {
                topic: o,
                expirerHasDeleted: a = !1,
                emitEvent: h = !0,
                id: g = 0
            } = e, {
                self: b
            } = this.client.session.get(o);
            await this.client.core.relayer.unsubscribe(o), await this.client.session.delete(o, Ne("USER_DISCONNECTED")), this.addToRecentlyDeleted(o, "session"), this.client.core.crypto.keychain.has(b.publicKey) && await this.client.core.crypto.deleteKeyPair(b.publicKey), this.client.core.crypto.keychain.has(o) && await this.client.core.crypto.deleteSymKey(o), a || this.client.core.expirer.del(o), this.client.core.storage.removeItem($p).catch(m => this.client.logger.warn(m)), this.getPendingSessionRequests().forEach(m => {
                m.topic === o && this.deletePendingSessionRequest(m.id, Ne("USER_DISCONNECTED"))
            }), o === ((n = this.sessionRequestQueue.queue[0]) == null ? void 0 : n.topic) && (this.sessionRequestQueue.state = Fi.idle), h && this.client.events.emit("session_delete", {
                id: g,
                topic: o
            })
        }, this.deleteProposal = async (e, n) => {
            await Promise.all([this.client.proposal.delete(e, Ne("USER_DISCONNECTED")), n ? Promise.resolve() : this.client.core.expirer.del(e)]), this.addToRecentlyDeleted(e, "proposal")
        }, this.deletePendingSessionRequest = async (e, n, o = !1) => {
            await Promise.all([this.client.pendingRequest.delete(e, n), o ? Promise.resolve() : this.client.core.expirer.del(e)]), this.addToRecentlyDeleted(e, "request"), this.sessionRequestQueue.queue = this.sessionRequestQueue.queue.filter(a => a.id !== e), o && (this.sessionRequestQueue.state = Fi.idle, this.client.events.emit("session_request_expire", {
                id: e
            }))
        }, this.deletePendingAuthRequest = async (e, n, o = !1) => {
            await Promise.all([this.client.auth.requests.delete(e, n), o ? Promise.resolve() : this.client.core.expirer.del(e)])
        }, this.setExpiry = async (e, n) => {
            this.client.session.keys.includes(e) && (this.client.core.expirer.set(e, n), await this.client.session.update(e, {
                expiry: n
            }))
        }, this.setProposal = async (e, n) => {
            this.client.core.expirer.set(e, fr(lr.wc_sessionPropose.req.ttl)), await this.client.proposal.set(e, n)
        }, this.setAuthRequest = async (e, n) => {
            const {
                request: o,
                pairingTopic: a
            } = n;
            this.client.core.expirer.set(e, o.expiryTimestamp), await this.client.auth.requests.set(e, {
                authPayload: o.authPayload,
                requester: o.requester,
                expiryTimestamp: o.expiryTimestamp,
                id: e,
                pairingTopic: a,
                verifyContext: o.verifyContext
            })
        }, this.setPendingSessionRequest = async e => {
            const {
                id: n,
                topic: o,
                params: a,
                verifyContext: h
            } = e, g = a.request.expiryTimestamp || fr(lr.wc_sessionRequest.req.ttl);
            this.client.core.expirer.set(n, g), await this.client.pendingRequest.set(n, {
                id: n,
                topic: o,
                params: a,
                verifyContext: h
            })
        }, this.sendRequest = async e => {
            const {
                topic: n,
                method: o,
                params: a,
                expiry: h,
                relayRpcId: g,
                clientRpcId: b,
                throwOnFailedPublish: m
            } = e, _ = Ls(o, a, b);
            if (Vs() && BS.includes(o)) {
                const k = hs(JSON.stringify(_));
                this.client.core.verify.register({
                    attestationId: k
                })
            }
            let S;
            try {
                S = await this.client.core.crypto.encode(n, _)
            } catch (k) {
                throw await this.cleanup(), this.client.logger.error(`sendRequest() -> core.crypto.encode() for topic ${n} failed`), k
            }
            const B = lr[o].req;
            return h && (B.ttl = h), g && (B.id = g), this.client.core.history.set(n, _), m ? (B.internal = ss(rr({}, B.internal), {
                throwOnFailedPublish: !0
            }), await this.client.core.relayer.publish(n, S, B)) : this.client.core.relayer.publish(n, S, B).catch(k => this.client.logger.error(k)), _.id
        }, this.sendResult = async e => {
            const {
                id: n,
                topic: o,
                result: a,
                throwOnFailedPublish: h,
                encodeOpts: g
            } = e, b = Nc(n, a);
            let m;
            try {
                m = await this.client.core.crypto.encode(o, b, g)
            } catch (B) {
                throw await this.cleanup(), this.client.logger.error(`sendResult() -> core.crypto.encode() for topic ${o} failed`), B
            }
            let _;
            try {
                _ = await this.client.core.history.get(o, n)
            } catch (B) {
                throw this.client.logger.error(`sendResult() -> history.get(${o}, ${n}) failed`), B
            }
            const S = lr[_.request.method].res;
            h ? (S.internal = ss(rr({}, S.internal), {
                throwOnFailedPublish: !0
            }), await this.client.core.relayer.publish(o, m, S)) : this.client.core.relayer.publish(o, m, S).catch(B => this.client.logger.error(B)), await this.client.core.history.resolve(b)
        }, this.sendError = async e => {
            const {
                id: n,
                topic: o,
                error: a,
                encodeOpts: h,
                rpcOpts: g
            } = e, b = Rc(n, a);
            let m;
            try {
                m = await this.client.core.crypto.encode(o, b, h)
            } catch (B) {
                throw await this.cleanup(), this.client.logger.error(`sendError() -> core.crypto.encode() for topic ${o} failed`), B
            }
            let _;
            try {
                _ = await this.client.core.history.get(o, n)
            } catch (B) {
                throw this.client.logger.error(`sendError() -> history.get(${o}, ${n}) failed`), B
            }
            const S = g || lr[_.request.method].res;
            this.client.core.relayer.publish(o, m, S), await this.client.core.history.resolve(b)
        }, this.cleanup = async () => {
            const e = [],
                n = [];
            this.client.session.getAll().forEach(o => {
                let a = !1;
                Dn(o.expiry) && (a = !0), this.client.core.crypto.keychain.has(o.topic) || (a = !0), a && e.push(o.topic)
            }), this.client.proposal.getAll().forEach(o => {
                Dn(o.expiryTimestamp) && n.push(o.id)
            }), await Promise.all([...e.map(o => this.deleteSession({
                topic: o
            })), ...n.map(o => this.deleteProposal(o))])
        }, this.onRelayEventRequest = async e => {
            this.requestQueue.queue.push(e), await this.processRequestsQueue()
        }, this.processRequestsQueue = async () => {
            if (this.requestQueue.state === Fi.active) {
                this.client.logger.info("Request queue already active, skipping...");
                return
            }
            for (this.client.logger.info(`Request queue starting with ${this.requestQueue.queue.length} requests`); this.requestQueue.queue.length > 0;) {
                this.requestQueue.state = Fi.active;
                const e = this.requestQueue.queue.shift();
                if (e) try {
                    await this.processRequest(e)
                } catch (n) {
                    this.client.logger.warn(n)
                }
            }
            this.requestQueue.state = Fi.idle
        }, this.processRequest = async e => {
            const {
                topic: n,
                payload: o
            } = e, a = o.method;
            if (!this.shouldIgnorePairingRequest({
                    topic: n,
                    requestMethod: a
                })) switch (a) {
                case "wc_sessionPropose":
                    return await this.onSessionProposeRequest(n, o);
                case "wc_sessionSettle":
                    return await this.onSessionSettleRequest(n, o);
                case "wc_sessionUpdate":
                    return await this.onSessionUpdateRequest(n, o);
                case "wc_sessionExtend":
                    return await this.onSessionExtendRequest(n, o);
                case "wc_sessionPing":
                    return await this.onSessionPingRequest(n, o);
                case "wc_sessionDelete":
                    return await this.onSessionDeleteRequest(n, o);
                case "wc_sessionRequest":
                    return await this.onSessionRequest(n, o);
                case "wc_sessionEvent":
                    return await this.onSessionEventRequest(n, o);
                case "wc_sessionAuthenticate":
                    return await this.onSessionAuthenticateRequest(n, o);
                default:
                    return this.client.logger.info(`Unsupported request method ${a}`)
            }
        }, this.onRelayEventResponse = async e => {
            const {
                topic: n,
                payload: o
            } = e, a = (await this.client.core.history.get(n, o.id)).request.method;
            switch (a) {
                case "wc_sessionPropose":
                    return this.onSessionProposeResponse(n, o);
                case "wc_sessionSettle":
                    return this.onSessionSettleResponse(n, o);
                case "wc_sessionUpdate":
                    return this.onSessionUpdateResponse(n, o);
                case "wc_sessionExtend":
                    return this.onSessionExtendResponse(n, o);
                case "wc_sessionPing":
                    return this.onSessionPingResponse(n, o);
                case "wc_sessionRequest":
                    return this.onSessionRequestResponse(n, o);
                case "wc_sessionAuthenticate":
                    return this.onSessionAuthenticateResponse(n, o);
                default:
                    return this.client.logger.info(`Unsupported response method ${a}`)
            }
        }, this.onRelayEventUnknownPayload = e => {
            const {
                topic: n
            } = e, {
                message: o
            } = nt("MISSING_OR_INVALID", `Decoded payload on topic ${n} is not identifiable as a JSON-RPC request or a response.`);
            throw new Error(o)
        }, this.shouldIgnorePairingRequest = e => {
            const {
                topic: n,
                requestMethod: o
            } = e, a = this.expectedPairingMethodMap.get(n);
            return !a || a.includes(o) ? !1 : !!(a.includes("wc_sessionAuthenticate") && this.client.events.listenerCount("session_authenticate") > 0)
        }, this.onSessionProposeRequest = async (e, n) => {
            const {
                params: o,
                id: a
            } = n;
            try {
                this.isValidConnect(rr({}, n.params));
                const h = o.expiryTimestamp || fr(lr.wc_sessionPropose.req.ttl),
                    g = rr({
                        id: a,
                        pairingTopic: e,
                        expiryTimestamp: h
                    }, o);
                await this.setProposal(a, g);
                const b = hs(JSON.stringify(n)),
                    m = await this.getVerifyContext(b, g.proposer.metadata);
                this.client.events.emit("session_proposal", {
                    id: a,
                    params: g,
                    verifyContext: m
                })
            } catch (h) {
                await this.sendError({
                    id: a,
                    topic: e,
                    error: h,
                    rpcOpts: lr.wc_sessionPropose.autoReject
                }), this.client.logger.error(h)
            }
        }, this.onSessionProposeResponse = async (e, n) => {
            const {
                id: o
            } = n;
            if (Hi(n)) {
                const {
                    result: a
                } = n;
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    result: a
                });
                const h = this.client.proposal.get(o);
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    proposal: h
                });
                const g = h.proposer.publicKey;
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    selfPublicKey: g
                });
                const b = a.responderPublicKey;
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    peerPublicKey: b
                });
                const m = await this.client.core.crypto.generateSharedKey(g, b);
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    sessionTopic: m
                });
                const _ = await this.client.core.relayer.subscribe(m);
                this.client.logger.trace({
                    type: "method",
                    method: "onSessionProposeResponse",
                    subscriptionId: _
                }), await this.client.core.pairing.activate({
                    topic: e
                })
            } else if (vi(n)) {
                await this.client.proposal.delete(o, Ne("USER_DISCONNECTED"));
                const a = he("session_connect");
                if (this.events.listenerCount(a) === 0) throw new Error(`emitting ${a} without any listeners, 954`);
                this.events.emit(he("session_connect"), {
                    error: n.error
                })
            }
        }, this.onSessionSettleRequest = async (e, n) => {
            const {
                id: o,
                params: a
            } = n;
            try {
                this.isValidSessionSettleRequest(a);
                const {
                    relay: h,
                    controller: g,
                    expiry: b,
                    namespaces: m,
                    sessionProperties: _,
                    sessionConfig: S
                } = n.params, B = rr(rr({
                    topic: e,
                    relay: h,
                    expiry: b,
                    namespaces: m,
                    acknowledged: !0,
                    pairingTopic: "",
                    requiredNamespaces: {},
                    optionalNamespaces: {},
                    controller: g.publicKey,
                    self: {
                        publicKey: "",
                        metadata: this.client.metadata
                    },
                    peer: {
                        publicKey: g.publicKey,
                        metadata: g.metadata
                    }
                }, _ && {
                    sessionProperties: _
                }), S && {
                    sessionConfig: S
                }), k = he("session_connect");
                if (this.events.listenerCount(k) === 0) throw new Error(`emitting ${k} without any listeners 997`);
                this.events.emit(he("session_connect"), {
                    session: B
                }), await this.sendResult({
                    id: n.id,
                    topic: e,
                    result: !0,
                    throwOnFailedPublish: !0
                })
            } catch (h) {
                await this.sendError({
                    id: o,
                    topic: e,
                    error: h
                }), this.client.logger.error(h)
            }
        }, this.onSessionSettleResponse = async (e, n) => {
            const {
                id: o
            } = n;
            Hi(n) ? (await this.client.session.update(e, {
                acknowledged: !0
            }), this.events.emit(he("session_approve", o), {})) : vi(n) && (await this.client.session.delete(e, Ne("USER_DISCONNECTED")), this.events.emit(he("session_approve", o), {
                error: n.error
            }))
        }, this.onSessionUpdateRequest = async (e, n) => {
            const {
                params: o,
                id: a
            } = n;
            try {
                const h = `${e}_session_update`,
                    g = Ao.get(h);
                if (g && this.isRequestOutOfSync(g, a)) {
                    this.client.logger.info(`Discarding out of sync request - ${a}`), this.sendError({
                        id: a,
                        topic: e,
                        error: Ne("INVALID_UPDATE_REQUEST")
                    });
                    return
                }
                this.isValidUpdate(rr({
                    topic: e
                }, o));
                try {
                    Ao.set(h, a), await this.client.session.update(e, {
                        namespaces: o.namespaces
                    }), await this.sendResult({
                        id: a,
                        topic: e,
                        result: !0,
                        throwOnFailedPublish: !0
                    })
                } catch (b) {
                    throw Ao.delete(h), b
                }
                this.client.events.emit("session_update", {
                    id: a,
                    topic: e,
                    params: o
                })
            } catch (h) {
                await this.sendError({
                    id: a,
                    topic: e,
                    error: h
                }), this.client.logger.error(h)
            }
        }, this.isRequestOutOfSync = (e, n) => parseInt(n.toString().slice(0, -3)) <= parseInt(e.toString().slice(0, -3)), this.onSessionUpdateResponse = (e, n) => {
            const {
                id: o
            } = n, a = he("session_update", o);
            if (this.events.listenerCount(a) === 0) throw new Error(`emitting ${a} without any listeners`);
            Hi(n) ? this.events.emit(he("session_update", o), {}) : vi(n) && this.events.emit(he("session_update", o), {
                error: n.error
            })
        }, this.onSessionExtendRequest = async (e, n) => {
            const {
                id: o
            } = n;
            try {
                this.isValidExtend({
                    topic: e
                }), await this.setExpiry(e, fr(Ds)), await this.sendResult({
                    id: o,
                    topic: e,
                    result: !0,
                    throwOnFailedPublish: !0
                }), this.client.events.emit("session_extend", {
                    id: o,
                    topic: e
                })
            } catch (a) {
                await this.sendError({
                    id: o,
                    topic: e,
                    error: a
                }), this.client.logger.error(a)
            }
        }, this.onSessionExtendResponse = (e, n) => {
            const {
                id: o
            } = n, a = he("session_extend", o);
            if (this.events.listenerCount(a) === 0) throw new Error(`emitting ${a} without any listeners`);
            Hi(n) ? this.events.emit(he("session_extend", o), {}) : vi(n) && this.events.emit(he("session_extend", o), {
                error: n.error
            })
        }, this.onSessionPingRequest = async (e, n) => {
            const {
                id: o
            } = n;
            try {
                this.isValidPing({
                    topic: e
                }), await this.sendResult({
                    id: o,
                    topic: e,
                    result: !0,
                    throwOnFailedPublish: !0
                }), this.client.events.emit("session_ping", {
                    id: o,
                    topic: e
                })
            } catch (a) {
                await this.sendError({
                    id: o,
                    topic: e,
                    error: a
                }), this.client.logger.error(a)
            }
        }, this.onSessionPingResponse = (e, n) => {
            const {
                id: o
            } = n, a = he("session_ping", o);
            if (this.events.listenerCount(a) === 0) throw new Error(`emitting ${a} without any listeners`);
            setTimeout(() => {
                Hi(n) ? this.events.emit(he("session_ping", o), {}) : vi(n) && this.events.emit(he("session_ping", o), {
                    error: n.error
                })
            }, 500)
        }, this.onSessionDeleteRequest = async (e, n) => {
            const {
                id: o
            } = n;
            try {
                this.isValidDisconnect({
                    topic: e,
                    reason: n.params
                }), await Promise.all([new Promise(a => {
                    this.client.core.relayer.once(Lr.publish, async () => {
                        a(await this.deleteSession({
                            topic: e,
                            id: o
                        }))
                    })
                }), this.sendResult({
                    id: o,
                    topic: e,
                    result: !0,
                    throwOnFailedPublish: !0
                }), this.cleanupPendingSentRequestsForTopic({
                    topic: e,
                    error: Ne("USER_DISCONNECTED")
                })])
            } catch (a) {
                this.client.logger.error(a)
            }
        }, this.onSessionRequest = async (e, n) => {
            var o;
            const {
                id: a,
                params: h
            } = n;
            try {
                await this.isValidRequest(rr({
                    topic: e
                }, h));
                const g = hs(JSON.stringify(Ls("wc_sessionRequest", h, a))),
                    b = this.client.session.get(e),
                    m = await this.getVerifyContext(g, b.peer.metadata),
                    _ = {
                        id: a,
                        topic: e,
                        params: h,
                        verifyContext: m
                    };
                await this.setPendingSessionRequest(_), (o = this.client.signConfig) != null && o.disableRequestQueue ? this.emitSessionRequest(_) : (this.addSessionRequestToSessionRequestQueue(_), this.processSessionRequestQueue())
            } catch (g) {
                await this.sendError({
                    id: a,
                    topic: e,
                    error: g
                }), this.client.logger.error(g)
            }
        }, this.onSessionRequestResponse = (e, n) => {
            const {
                id: o
            } = n, a = he("session_request", o);
            if (this.events.listenerCount(a) === 0) throw new Error(`emitting ${a} without any listeners`);
            Hi(n) ? this.events.emit(he("session_request", o), {
                result: n.result
            }) : vi(n) && this.events.emit(he("session_request", o), {
                error: n.error
            })
        }, this.onSessionEventRequest = async (e, n) => {
            const {
                id: o,
                params: a
            } = n;
            try {
                const h = `${e}_session_event_${a.event.name}`,
                    g = Ao.get(h);
                if (g && this.isRequestOutOfSync(g, o)) {
                    this.client.logger.info(`Discarding out of sync request - ${o}`);
                    return
                }
                this.isValidEmit(rr({
                    topic: e
                }, a)), this.client.events.emit("session_event", {
                    id: o,
                    topic: e,
                    params: a
                }), Ao.set(h, o)
            } catch (h) {
                await this.sendError({
                    id: o,
                    topic: e,
                    error: h
                }), this.client.logger.error(h)
            }
        }, this.onSessionAuthenticateResponse = (e, n) => {
            const {
                id: o
            } = n;
            this.client.logger.trace({
                type: "method",
                method: "onSessionAuthenticateResponse",
                topic: e,
                payload: n
            }), Hi(n) ? this.events.emit(he("session_request", o), {
                result: n.result
            }) : vi(n) && this.events.emit(he("session_request", o), {
                error: n.error
            })
        }, this.onSessionAuthenticateRequest = async (e, n) => {
            try {
                const {
                    requester: o,
                    authPayload: a,
                    expiryTimestamp: h
                } = n.params, g = hs(JSON.stringify(n)), b = await this.getVerifyContext(g, this.client.metadata), m = {
                    requester: o,
                    pairingTopic: e,
                    id: n.id,
                    authPayload: a,
                    verifyContext: b,
                    expiryTimestamp: h
                };
                await this.setAuthRequest(n.id, {
                    request: m,
                    pairingTopic: e
                }), this.client.events.emit("session_authenticate", {
                    topic: e,
                    params: n.params,
                    id: n.id,
                    verifyContext: b
                })
            } catch (o) {
                this.client.logger.error(o);
                const a = n.params.requester.publicKey,
                    h = await this.client.core.crypto.generateKeyPair(),
                    g = {
                        type: yn,
                        receiverPublicKey: a,
                        senderPublicKey: h
                    };
                await this.sendError({
                    id: n.id,
                    topic: e,
                    error: o,
                    encodeOpts: g,
                    rpcOpts: lr.wc_sessionAuthenticate.autoReject
                })
            }
        }, this.addSessionRequestToSessionRequestQueue = e => {
            this.sessionRequestQueue.queue.push(e)
        }, this.cleanupAfterResponse = e => {
            this.deletePendingSessionRequest(e.response.id, {
                message: "fulfilled",
                code: 0
            }), setTimeout(() => {
                this.sessionRequestQueue.state = Fi.idle, this.processSessionRequestQueue()
            }, lt.toMiliseconds(this.requestQueueDelay))
        }, this.cleanupPendingSentRequestsForTopic = ({
            topic: e,
            error: n
        }) => {
            const o = this.client.core.history.pending;
            o.length > 0 && o.filter(a => a.topic === e && a.request.method === "wc_sessionRequest").forEach(a => {
                const h = a.request.id,
                    g = he("session_request", h);
                if (this.events.listenerCount(g) === 0) throw new Error(`emitting ${g} without any listeners`);
                this.events.emit(he("session_request", a.request.id), {
                    error: n
                })
            })
        }, this.processSessionRequestQueue = () => {
            if (this.sessionRequestQueue.state === Fi.active) {
                this.client.logger.info("session request queue is already active.");
                return
            }
            const e = this.sessionRequestQueue.queue[0];
            if (!e) {
                this.client.logger.info("session request queue is empty.");
                return
            }
            try {
                this.sessionRequestQueue.state = Fi.active, this.emitSessionRequest(e)
            } catch (n) {
                this.client.logger.error(n)
            }
        }, this.emitSessionRequest = e => {
            this.client.events.emit("session_request", e)
        }, this.onPairingCreated = e => {
            if (e.methods && this.expectedPairingMethodMap.set(e.topic, e.methods), e.active) return;
            const n = this.client.proposal.getAll().find(o => o.pairingTopic === e.topic);
            n && this.onSessionProposeRequest(e.topic, Ls("wc_sessionPropose", {
                requiredNamespaces: n.requiredNamespaces,
                optionalNamespaces: n.optionalNamespaces,
                relays: n.relays,
                proposer: n.proposer,
                sessionProperties: n.sessionProperties
            }, n.id))
        }, this.isValidConnect = async e => {
            if (!Br(e)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `connect() params: ${JSON.stringify(e)}`);
                throw new Error(b)
            }
            const {
                pairingTopic: n,
                requiredNamespaces: o,
                optionalNamespaces: a,
                sessionProperties: h,
                relays: g
            } = e;
            if (kr(n) || await this.isValidPairingTopic(n), !x5(g)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `connect() relays: ${g}`);
                throw new Error(b)
            }!kr(o) && Uo(o) !== 0 && this.validateNamespaces(o, "requiredNamespaces"), !kr(a) && Uo(a) !== 0 && this.validateNamespaces(a, "optionalNamespaces"), kr(h) || this.validateSessionProps(h, "sessionProperties")
        }, this.validateNamespaces = (e, n) => {
            const o = S5(e, "connect()", n);
            if (o) throw new Error(o.message)
        }, this.isValidApprove = async e => {
            if (!Br(e)) throw new Error(nt("MISSING_OR_INVALID", `approve() params: ${e}`).message);
            const {
                id: n,
                namespaces: o,
                relayProtocol: a,
                sessionProperties: h
            } = e;
            this.checkRecentlyDeleted(n), await this.isValidProposalId(n);
            const g = this.client.proposal.get(n),
                b = hu(o, "approve()");
            if (b) throw new Error(b.message);
            const m = bp(g.requiredNamespaces, o, "approve()");
            if (m) throw new Error(m.message);
            if (!Ye(a, !0)) {
                const {
                    message: _
                } = nt("MISSING_OR_INVALID", `approve() relayProtocol: ${a}`);
                throw new Error(_)
            }
            kr(h) || this.validateSessionProps(h, "sessionProperties")
        }, this.isValidReject = async e => {
            if (!Br(e)) {
                const {
                    message: a
                } = nt("MISSING_OR_INVALID", `reject() params: ${e}`);
                throw new Error(a)
            }
            const {
                id: n,
                reason: o
            } = e;
            if (this.checkRecentlyDeleted(n), await this.isValidProposalId(n), !M5(o)) {
                const {
                    message: a
                } = nt("MISSING_OR_INVALID", `reject() reason: ${JSON.stringify(o)}`);
                throw new Error(a)
            }
        }, this.isValidSessionSettleRequest = e => {
            if (!Br(e)) {
                const {
                    message: m
                } = nt("MISSING_OR_INVALID", `onSessionSettleRequest() params: ${e}`);
                throw new Error(m)
            }
            const {
                relay: n,
                controller: o,
                namespaces: a,
                expiry: h
            } = e;
            if (!mg(n)) {
                const {
                    message: m
                } = nt("MISSING_OR_INVALID", "onSessionSettleRequest() relay protocol should be a string");
                throw new Error(m)
            }
            const g = w5(o, "onSessionSettleRequest()");
            if (g) throw new Error(g.message);
            const b = hu(a, "onSessionSettleRequest()");
            if (b) throw new Error(b.message);
            if (Dn(h)) {
                const {
                    message: m
                } = nt("EXPIRED", "onSessionSettleRequest()");
                throw new Error(m)
            }
        }, this.isValidUpdate = async e => {
            if (!Br(e)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `update() params: ${e}`);
                throw new Error(b)
            }
            const {
                topic: n,
                namespaces: o
            } = e;
            this.checkRecentlyDeleted(n), await this.isValidSessionTopic(n);
            const a = this.client.session.get(n),
                h = hu(o, "update()");
            if (h) throw new Error(h.message);
            const g = bp(a.requiredNamespaces, o, "update()");
            if (g) throw new Error(g.message)
        }, this.isValidExtend = async e => {
            if (!Br(e)) {
                const {
                    message: o
                } = nt("MISSING_OR_INVALID", `extend() params: ${e}`);
                throw new Error(o)
            }
            const {
                topic: n
            } = e;
            this.checkRecentlyDeleted(n), await this.isValidSessionTopic(n)
        }, this.isValidRequest = async e => {
            if (!Br(e)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `request() params: ${e}`);
                throw new Error(b)
            }
            const {
                topic: n,
                request: o,
                chainId: a,
                expiry: h
            } = e;
            this.checkRecentlyDeleted(n), await this.isValidSessionTopic(n);
            const {
                namespaces: g
            } = this.client.session.get(n);
            if (!wp(g, a)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `request() chainId: ${a}`);
                throw new Error(b)
            }
            if (!C5(o)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `request() ${JSON.stringify(o)}`);
                throw new Error(b)
            }
            if (!O5(g, a, o.method)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `request() method: ${o.method}`);
                throw new Error(b)
            }
            if (h && !B5(h, gu)) {
                const {
                    message: b
                } = nt("MISSING_OR_INVALID", `request() expiry: ${h}. Expiry must be a number (in seconds) between ${gu.min} and ${gu.max}`);
                throw new Error(b)
            }
        }, this.isValidRespond = async e => {
            var n;
            if (!Br(e)) {
                const {
                    message: h
                } = nt("MISSING_OR_INVALID", `respond() params: ${e}`);
                throw new Error(h)
            }
            const {
                topic: o,
                response: a
            } = e;
            try {
                await this.isValidSessionTopic(o)
            } catch (h) {
                throw (n = e == null ? void 0 : e.response) != null && n.id && this.cleanupAfterResponse(e), h
            }
            if (!N5(a)) {
                const {
                    message: h
                } = nt("MISSING_OR_INVALID", `respond() response: ${JSON.stringify(a)}`);
                throw new Error(h)
            }
        }, this.isValidPing = async e => {
            if (!Br(e)) {
                const {
                    message: o
                } = nt("MISSING_OR_INVALID", `ping() params: ${e}`);
                throw new Error(o)
            }
            const {
                topic: n
            } = e;
            await this.isValidSessionOrPairingTopic(n)
        }, this.isValidEmit = async e => {
            if (!Br(e)) {
                const {
                    message: g
                } = nt("MISSING_OR_INVALID", `emit() params: ${e}`);
                throw new Error(g)
            }
            const {
                topic: n,
                event: o,
                chainId: a
            } = e;
            await this.isValidSessionTopic(n);
            const {
                namespaces: h
            } = this.client.session.get(n);
            if (!wp(h, a)) {
                const {
                    message: g
                } = nt("MISSING_OR_INVALID", `emit() chainId: ${a}`);
                throw new Error(g)
            }
            if (!R5(o)) {
                const {
                    message: g
                } = nt("MISSING_OR_INVALID", `emit() event: ${JSON.stringify(o)}`);
                throw new Error(g)
            }
            if (!T5(h, a, o.name)) {
                const {
                    message: g
                } = nt("MISSING_OR_INVALID", `emit() event: ${JSON.stringify(o)}`);
                throw new Error(g)
            }
        }, this.isValidDisconnect = async e => {
            if (!Br(e)) {
                const {
                    message: o
                } = nt("MISSING_OR_INVALID", `disconnect() params: ${e}`);
                throw new Error(o)
            }
            const {
                topic: n
            } = e;
            await this.isValidSessionOrPairingTopic(n)
        }, this.isValidAuthenticate = e => {
            const {
                chains: n,
                uri: o,
                domain: a,
                nonce: h
            } = e;
            if (!Array.isArray(n) || n.length === 0) throw new Error("chains is required and must be a non-empty array");
            if (!Ye(o, !1)) throw new Error("uri is required parameter");
            if (!Ye(a, !1)) throw new Error("domain is required parameter");
            if (!Ye(h, !1)) throw new Error("nonce is required parameter");
            if ([...new Set(n.map(b => Ro(b).namespace))].length > 1) throw new Error("Multi-namespace requests are not supported. Please request single namespace only.");
            const {
                namespace: g
            } = Ro(n[0]);
            if (g !== "eip155") throw new Error("Only eip155 namespace is supported for authenticated sessions. Please use .connect() for non-eip155 chains.")
        }, this.getVerifyContext = async (e, n) => {
            const o = {
                verified: {
                    verifyUrl: n.verifyUrl || Co,
                    validation: "UNKNOWN",
                    origin: n.url || ""
                }
            };
            try {
                const a = await this.client.core.verify.resolve({
                    attestationId: e,
                    verifyUrl: n.verifyUrl
                });
                a && (o.verified.origin = a.origin, o.verified.isScam = a.isScam, o.verified.validation = a.origin === new URL(n.url).origin ? "VALID" : "INVALID")
            } catch (a) {
                this.client.logger.info(a)
            }
            return this.client.logger.info(`Verify context: ${JSON.stringify(o)}`), o
        }, this.validateSessionProps = (e, n) => {
            Object.values(e).forEach(o => {
                if (!Ye(o, !1)) {
                    const {
                        message: a
                    } = nt("MISSING_OR_INVALID", `${n} must be in Record<string, string> format. Received: ${JSON.stringify(o)}`);
                    throw new Error(a)
                }
            })
        }, this.getPendingAuthRequest = e => {
            const n = this.client.auth.requests.get(e);
            return typeof n == "object" ? n : void 0
        }, this.addToRecentlyDeleted = (e, n) => {
            if (this.recentlyDeletedMap.set(e, n), this.recentlyDeletedMap.size >= this.recentlyDeletedLimit) {
                let o = 0;
                const a = this.recentlyDeletedLimit / 2;
                for (const h of this.recentlyDeletedMap.keys()) {
                    if (o++ >= a) break;
                    this.recentlyDeletedMap.delete(h)
                }
            }
        }, this.checkRecentlyDeleted = e => {
            const n = this.recentlyDeletedMap.get(e);
            if (n) {
                const {
                    message: o
                } = nt("MISSING_OR_INVALID", `Record was recently deleted - ${n}: ${e}`);
                throw new Error(o)
            }
        }
    }
    async isInitialized() {
        if (!this.initialized) {
            const {
                message: t
            } = nt("NOT_INITIALIZED", this.name);
            throw new Error(t)
        }
        await this.client.core.relayer.confirmOnlineStateOrThrow()
    }
    registerRelayerEvents() {
        this.client.core.relayer.on(Lr.message, t => {
            !this.initialized || this.relayMessageCache.length > 0 ? this.relayMessageCache.push(t) : this.onRelayMessage(t)
        })
    }
    async onRelayMessage(t) {
        const {
            topic: e,
            message: n,
            attestation: o
        } = t, {
            publicKey: a
        } = this.client.auth.authKeys.keys.includes(pc) ? this.client.auth.authKeys.get(pc) : {
            responseTopic: void 0,
            publicKey: void 0
        }, h = await this.client.core.crypto.decode(e, n, {
            receiverPublicKey: a
        });
        try {
            Fu(h) ? (this.client.core.history.set(e, h), this.onRelayEventRequest({
                topic: e,
                payload: h,
                attestation: o
            })) : Oc(h) ? (await this.client.core.history.resolve(h), await this.onRelayEventResponse({
                topic: e,
                payload: h
            }), this.client.core.history.delete(e, h.id)) : this.onRelayEventUnknownPayload({
                topic: e,
                payload: h
            })
        } catch (g) {
            this.client.logger.error(g)
        }
    }
    registerExpirerEvents() {
        this.client.core.expirer.on(gi.expired, async t => {
            const {
                topic: e,
                id: n
            } = M0(t.target);
            if (n && this.client.pendingRequest.keys.includes(n)) return await this.deletePendingSessionRequest(n, nt("EXPIRED"), !0);
            if (n && this.client.auth.requests.keys.includes(n)) return await this.deletePendingAuthRequest(n, nt("EXPIRED"), !0);
            e ? this.client.session.keys.includes(e) && (await this.deleteSession({
                topic: e,
                expirerHasDeleted: !0
            }), this.client.events.emit("session_expire", {
                topic: e
            })) : n && (await this.deleteProposal(n, !0), this.client.events.emit("proposal_expire", {
                id: n
            }))
        })
    }
    registerPairingEvents() {
        this.client.core.pairing.events.on(ks.create, t => this.onPairingCreated(t)), this.client.core.pairing.events.on(ks.delete, t => {
            this.addToRecentlyDeleted(t.topic, "pairing")
        })
    }
    isValidPairingTopic(t) {
        if (!Ye(t, !1)) {
            const {
                message: e
            } = nt("MISSING_OR_INVALID", `pairing topic should be a string: ${t}`);
            throw new Error(e)
        }
        if (!this.client.core.pairing.pairings.keys.includes(t)) {
            const {
                message: e
            } = nt("NO_MATCHING_KEY", `pairing topic doesn't exist: ${t}`);
            throw new Error(e)
        }
        if (Dn(this.client.core.pairing.pairings.get(t).expiry)) {
            const {
                message: e
            } = nt("EXPIRED", `pairing topic: ${t}`);
            throw new Error(e)
        }
    }
    async isValidSessionTopic(t) {
        if (!Ye(t, !1)) {
            const {
                message: e
            } = nt("MISSING_OR_INVALID", `session topic should be a string: ${t}`);
            throw new Error(e)
        }
        if (this.checkRecentlyDeleted(t), !this.client.session.keys.includes(t)) {
            const {
                message: e
            } = nt("NO_MATCHING_KEY", `session topic doesn't exist: ${t}`);
            throw new Error(e)
        }
        if (Dn(this.client.session.get(t).expiry)) {
            await this.deleteSession({
                topic: t
            });
            const {
                message: e
            } = nt("EXPIRED", `session topic: ${t}`);
            throw new Error(e)
        }
        if (!this.client.core.crypto.keychain.has(t)) {
            const {
                message: e
            } = nt("MISSING_OR_INVALID", `session topic does not exist in keychain: ${t}`);
            throw await this.deleteSession({
                topic: t
            }), new Error(e)
        }
    }
    async isValidSessionOrPairingTopic(t) {
        if (this.checkRecentlyDeleted(t), this.client.session.keys.includes(t)) await this.isValidSessionTopic(t);
        else if (this.client.core.pairing.pairings.keys.includes(t)) this.isValidPairingTopic(t);
        else if (Ye(t, !1)) {
            const {
                message: e
            } = nt("NO_MATCHING_KEY", `session or pairing topic doesn't exist: ${t}`);
            throw new Error(e)
        } else {
            const {
                message: e
            } = nt("MISSING_OR_INVALID", `session or pairing topic should be a string: ${t}`);
            throw new Error(e)
        }
    }
    async isValidProposalId(t) {
        if (!P5(t)) {
            const {
                message: e
            } = nt("MISSING_OR_INVALID", `proposal id should be a number: ${t}`);
            throw new Error(e)
        }
        if (!this.client.proposal.keys.includes(t)) {
            const {
                message: e
            } = nt("NO_MATCHING_KEY", `proposal id doesn't exist: ${t}`);
            throw new Error(e)
        }
        if (Dn(this.client.proposal.get(t).expiryTimestamp)) {
            await this.deleteProposal(t);
            const {
                message: e
            } = nt("EXPIRED", `proposal id: ${t}`);
            throw new Error(e)
        }
    }
}
class QS extends gs {
    constructor(t, e) {
        super(t, e, OS, rl), this.core = t, this.logger = e
    }
}
class WS extends gs {
    constructor(t, e) {
        super(t, e, TS, rl), this.core = t, this.logger = e
    }
}
class JS extends gs {
    constructor(t, e) {
        super(t, e, qS, rl, n => n.id), this.core = t, this.logger = e
    }
}
class YS extends gs {
    constructor(t, e) {
        super(t, e, LS, qc, () => pc), this.core = t, this.logger = e
    }
}
class XS extends gs {
    constructor(t, e) {
        super(t, e, $S, qc), this.core = t, this.logger = e
    }
}
class ZS extends gs {
    constructor(t, e) {
        super(t, e, jS, qc, n => n.id), this.core = t, this.logger = e
    }
}
class t4 {
    constructor(t, e) {
        this.core = t, this.logger = e, this.authKeys = new YS(this.core, this.logger), this.pairingTopics = new XS(this.core, this.logger), this.requests = new ZS(this.core, this.logger)
    }
    async init() {
        await this.authKeys.init(), await this.pairingTopics.init(), await this.requests.init()
    }
}
class il extends Z5 {
    constructor(t) {
        super(t), this.protocol = Rg, this.version = Og, this.name = pu.name, this.events = new wi.EventEmitter, this.on = (n, o) => this.events.on(n, o), this.once = (n, o) => this.events.once(n, o), this.off = (n, o) => this.events.off(n, o), this.removeListener = (n, o) => this.events.removeListener(n, o), this.removeAllListeners = n => this.events.removeAllListeners(n), this.connect = async n => {
            try {
                return await this.engine.connect(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.pair = async n => {
            try {
                return await this.engine.pair(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.approve = async n => {
            try {
                return await this.engine.approve(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.reject = async n => {
            try {
                return await this.engine.reject(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.update = async n => {
            try {
                return await this.engine.update(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.extend = async n => {
            try {
                return await this.engine.extend(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.request = async n => {
            try {
                return await this.engine.request(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.respond = async n => {
            try {
                return await this.engine.respond(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.ping = async n => {
            try {
                return await this.engine.ping(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.emit = async n => {
            try {
                return await this.engine.emit(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.disconnect = async n => {
            try {
                return await this.engine.disconnect(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.find = n => {
            try {
                return this.engine.find(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.getPendingSessionRequests = () => {
            try {
                return this.engine.getPendingSessionRequests()
            } catch (n) {
                throw this.logger.error(n.message), n
            }
        }, this.authenticate = async n => {
            try {
                return await this.engine.authenticate(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.formatAuthMessage = n => {
            try {
                return this.engine.formatAuthMessage(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.approveSessionAuthenticate = async n => {
            try {
                return await this.engine.approveSessionAuthenticate(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.rejectSessionAuthenticate = async n => {
            try {
                return await this.engine.rejectSessionAuthenticate(n)
            } catch (o) {
                throw this.logger.error(o.message), o
            }
        }, this.name = (t == null ? void 0 : t.name) || pu.name, this.metadata = (t == null ? void 0 : t.metadata) || U3(), this.signConfig = t == null ? void 0 : t.signConfig;
        const e = typeof(t == null ? void 0 : t.logger) < "u" && typeof(t == null ? void 0 : t.logger) != "string" ? t.logger : ko(Cc({
            level: (t == null ? void 0 : t.logger) || pu.logger
        }));
        this.core = (t == null ? void 0 : t.core) || new RS(t), this.logger = Fr(e, this.name), this.session = new WS(this.core, this.logger), this.proposal = new QS(this.core, this.logger), this.pendingRequest = new JS(this.core, this.logger), this.engine = new GS(this), this.auth = new t4(this.core, this.logger)
    }
    static async init(t) {
        const e = new il(t);
        return await e.initialize(), e
    }
    get context() {
        return zr(this.logger)
    }
    get pairing() {
        return this.core.pairing.pairings
    }
    async initialize() {
        this.logger.trace("Initialized");
        try {
            await this.core.start(), await this.session.init(), await this.proposal.init(), await this.pendingRequest.init(), await this.engine.init(), await this.auth.init(), this.core.verify.init({
                verifyUrl: this.metadata.verifyUrl
            }), this.logger.info("SignClient Initialization Success"), this.engine.processRelayMessageCache()
        } catch (t) {
            throw this.logger.info("SignClient Initialization Failure"), this.logger.error(t.message), t
        }
    }
}
const Fp = "error",
    e4 = "wss://relay.walletconnect.com",
    r4 = "wc",
    i4 = "universal_provider",
    Hp = `${r4}@2:${i4}:`,
    n4 = "https://rpc.walletconnect.com/v1/",
    Bs = "generic",
    Di = {
        DEFAULT_CHAIN_CHANGED: "default_chain_changed"
    };
var So = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {},
    qu = {
        exports: {}
    };
/**
 * @license
 * Lodash <https://lodash.com/>
 * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */
(function(r, t) {
    (function() {
        var e, n = "4.17.21",
            o = 200,
            a = "Unsupported core-js use. Try https://npms.io/search?q=ponyfill.",
            h = "Expected a function",
            g = "Invalid `variable` option passed into `_.template`",
            b = "__lodash_hash_undefined__",
            m = 500,
            _ = "__lodash_placeholder__",
            S = 1,
            B = 2,
            k = 4,
            L = 1,
            K = 2,
            Q = 1,
            et = 2,
            at = 4,
            ut = 8,
            ft = 16,
            st = 32,
            ot = 64,
            it = 128,
            mt = 256,
            Zt = 512,
            oe = 30,
            Tt = "...",
            ve = 800,
            u = 16,
            p = 1,
            v = 2,
            P = 3,
            C = 1 / 0,
            R = 9007199254740991,
            T = 17976931348623157e292,
            E = NaN,
            f = 4294967295,
            x = f - 1,
            ht = f >>> 1,
            gt = [
                ["ary", it],
                ["bind", Q],
                ["bindKey", et],
                ["curry", ut],
                ["curryRight", ft],
                ["flip", Zt],
                ["partial", st],
                ["partialRight", ot],
                ["rearg", mt]
            ],
            y = "[object Arguments]",
            V = "[object Array]",
            O = "[object AsyncFunction]",
            D = "[object Boolean]",
            U = "[object Date]",
            d = "[object DOMException]",
            N = "[object Error]",
            W = "[object Function]",
            rt = "[object GeneratorFunction]",
            Z = "[object Map]",
            wt = "[object Number]",
            bt = "[object Null]",
            vt = "[object Object]",
            Re = "[object Promise]",
            Lt = "[object Proxy]",
            Rt = "[object RegExp]",
            ne = "[object Set]",
            It = "[object String]",
            St = "[object Symbol]",
            be = "[object Undefined]",
            _t = "[object WeakMap]",
            xt = "[object WeakSet]",
            te = "[object ArrayBuffer]",
            At = "[object DataView]",
            Dt = "[object Float32Array]",
            ae = "[object Float64Array]",
            $t = "[object Int8Array]",
            Kt = "[object Int16Array]",
            ke = "[object Int32Array]",
            Qt = "[object Uint8Array]",
            Vt = "[object Uint8ClampedArray]",
            ze = "[object Uint16Array]",
            ee = "[object Uint32Array]",
            ue = /\b__p \+= '';/g,
            Fe = /\b(__p \+=) '' \+/g,
            pe = /(__e\(.*?\)|\b__t\)) \+\n'';/g,
            ye = /&(?:amp|lt|gt|quot|#39);/g,
            yr = /[&<>"']/g,
            qt = RegExp(ye.source),
            Mt = RegExp(yr.source),
            Ae = /<%-([\s\S]+?)%>/g,
            Bt = /<%([\s\S]+?)%>/g,
            Ot = /<%=([\s\S]+?)%>/g,
            we = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            jt = /^\w*$/,
            zt = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            Ee = /[\\^$.*+?()[\]{}|]/g,
            Ft = RegExp(Ee.source),
            Ut = /^\s+/,
            xe = /\s/,
            kt = /\{(?:\n\/\* \[wrapped with .+\] \*\/)?\n?/,
            Et = /\{\n\/\* \[wrapped with (.+)\] \*/,
            Oe = /,? & /,
            Ht = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,
            Pe = /[()=,{}\[\]\/\s]/,
            bi = /\\(\\)?/g,
            Me = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g,
            se = /\w*$/,
            Zr = /^[-+]0x[0-9a-f]+$/i,
            ti = /^0b[01]+$/i,
            ei = /^\[object .+?Constructor\]$/,
            ri = /^0o[0-7]+$/i,
            ii = /^(?:0|[1-9]\d*)$/,
            nr = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,
            qi = /($^)/,
            Ln = /['\n\r\u2028\u2029\\]/g,
            Bi = "\\ud800-\\udfff",
            $n = "\\u0300-\\u036f",
            jn = "\\ufe20-\\ufe2f",
            Ui = "\\u20d0-\\u20ff",
            bn = $n + jn + Ui,
            _n = "\\u2700-\\u27bf",
            wr = "a-z\\xdf-\\xf6\\xf8-\\xff",
            zn = "\\xac\\xb1\\xd7\\xf7",
            Fn = "\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf",
            Hn = "\\u2000-\\u206f",
            Kn = " \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",
            Go = "A-Z\\xc0-\\xd6\\xd8-\\xde",
            Qo = "\\ufe0e\\ufe0f",
            Vn = zn + Fn + Hn + Kn,
            Xs = "['’]",
            Gn = "[" + Bi + "]",
            Zs = "[" + Vn + "]",
            Qn = "[" + bn + "]",
            Wo = "\\d+",
            Bc = "[" + _n + "]",
            Jo = "[" + wr + "]",
            Yo = "[^" + Bi + Vn + Wo + _n + wr + Go + "]",
            vs = "\\ud83c[\\udffb-\\udfff]",
            Uc = "(?:" + Qn + "|" + vs + ")",
            Xo = "[^" + Bi + "]",
            ys = "(?:\\ud83c[\\udde6-\\uddff]){2}",
            An = "[\\ud800-\\udbff][\\udc00-\\udfff]",
            Hr = "[" + Go + "]",
            Zo = "\\u200d",
            ta = "(?:" + Jo + "|" + Yo + ")",
            ki = "(?:" + Hr + "|" + Yo + ")",
            ea = "(?:" + Xs + "(?:d|ll|m|re|s|t|ve))?",
            ra = "(?:" + Xs + "(?:D|LL|M|RE|S|T|VE))?",
            ia = Uc + "?",
            na = "[" + Qo + "]?",
            kc = "(?:" + Zo + "(?:" + [Xo, ys, An].join("|") + ")" + na + ia + ")*",
            nn = "\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",
            sa = "\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])",
            oa = na + ia + kc,
            ws = "(?:" + [Bc, ys, An].join("|") + ")" + oa,
            Lc = "(?:" + [Xo + Qn + "?", Qn, ys, An, Gn].join("|") + ")",
            to = RegExp(Xs, "g"),
            $c = RegExp(Qn, "g"),
            bs = RegExp(vs + "(?=" + vs + ")|" + Lc + oa, "g"),
            aa = RegExp([Hr + "?" + Jo + "+" + ea + "(?=" + [Zs, Hr, "$"].join("|") + ")", ki + "+" + ra + "(?=" + [Zs, Hr + ta, "$"].join("|") + ")", Hr + "?" + ta + "+" + ea, Hr + "+" + ra, sa, nn, Wo, ws].join("|"), "g"),
            ca = RegExp("[" + Zo + Bi + bn + Qo + "]"),
            Wn = /[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,
            ha = ["Array", "Buffer", "DataView", "Date", "Error", "Float32Array", "Float64Array", "Function", "Int8Array", "Int16Array", "Int32Array", "Map", "Math", "Object", "Promise", "RegExp", "Set", "String", "Symbol", "TypeError", "Uint8Array", "Uint8ClampedArray", "Uint16Array", "Uint32Array", "WeakMap", "_", "clearTimeout", "isFinite", "parseInt", "setTimeout"],
            jc = -1,
            De = {};
        De[Dt] = De[ae] = De[$t] = De[Kt] = De[ke] = De[Qt] = De[Vt] = De[ze] = De[ee] = !0, De[y] = De[V] = De[te] = De[D] = De[At] = De[U] = De[N] = De[W] = De[Z] = De[wt] = De[vt] = De[Rt] = De[ne] = De[It] = De[_t] = !1;
        var Te = {};
        Te[y] = Te[V] = Te[te] = Te[At] = Te[D] = Te[U] = Te[Dt] = Te[ae] = Te[$t] = Te[Kt] = Te[ke] = Te[Z] = Te[wt] = Te[vt] = Te[Rt] = Te[ne] = Te[It] = Te[St] = Te[Qt] = Te[Vt] = Te[ze] = Te[ee] = !0, Te[N] = Te[W] = Te[_t] = !1;
        var M = {
                À: "A",
                Á: "A",
                Â: "A",
                Ã: "A",
                Ä: "A",
                Å: "A",
                à: "a",
                á: "a",
                â: "a",
                ã: "a",
                ä: "a",
                å: "a",
                Ç: "C",
                ç: "c",
                Ð: "D",
                ð: "d",
                È: "E",
                É: "E",
                Ê: "E",
                Ë: "E",
                è: "e",
                é: "e",
                ê: "e",
                ë: "e",
                Ì: "I",
                Í: "I",
                Î: "I",
                Ï: "I",
                ì: "i",
                í: "i",
                î: "i",
                ï: "i",
                Ñ: "N",
                ñ: "n",
                Ò: "O",
                Ó: "O",
                Ô: "O",
                Õ: "O",
                Ö: "O",
                Ø: "O",
                ò: "o",
                ó: "o",
                ô: "o",
                õ: "o",
                ö: "o",
                ø: "o",
                Ù: "U",
                Ú: "U",
                Û: "U",
                Ü: "U",
                ù: "u",
                ú: "u",
                û: "u",
                ü: "u",
                Ý: "Y",
                ý: "y",
                ÿ: "y",
                Æ: "Ae",
                æ: "ae",
                Þ: "Th",
                þ: "th",
                ß: "ss",
                Ā: "A",
                Ă: "A",
                Ą: "A",
                ā: "a",
                ă: "a",
                ą: "a",
                Ć: "C",
                Ĉ: "C",
                Ċ: "C",
                Č: "C",
                ć: "c",
                ĉ: "c",
                ċ: "c",
                č: "c",
                Ď: "D",
                Đ: "D",
                ď: "d",
                đ: "d",
                Ē: "E",
                Ĕ: "E",
                Ė: "E",
                Ę: "E",
                Ě: "E",
                ē: "e",
                ĕ: "e",
                ė: "e",
                ę: "e",
                ě: "e",
                Ĝ: "G",
                Ğ: "G",
                Ġ: "G",
                Ģ: "G",
                ĝ: "g",
                ğ: "g",
                ġ: "g",
                ģ: "g",
                Ĥ: "H",
                Ħ: "H",
                ĥ: "h",
                ħ: "h",
                Ĩ: "I",
                Ī: "I",
                Ĭ: "I",
                Į: "I",
                İ: "I",
                ĩ: "i",
                ī: "i",
                ĭ: "i",
                į: "i",
                ı: "i",
                Ĵ: "J",
                ĵ: "j",
                Ķ: "K",
                ķ: "k",
                ĸ: "k",
                Ĺ: "L",
                Ļ: "L",
                Ľ: "L",
                Ŀ: "L",
                Ł: "L",
                ĺ: "l",
                ļ: "l",
                ľ: "l",
                ŀ: "l",
                ł: "l",
                Ń: "N",
                Ņ: "N",
                Ň: "N",
                Ŋ: "N",
                ń: "n",
                ņ: "n",
                ň: "n",
                ŋ: "n",
                Ō: "O",
                Ŏ: "O",
                Ő: "O",
                ō: "o",
                ŏ: "o",
                ő: "o",
                Ŕ: "R",
                Ŗ: "R",
                Ř: "R",
                ŕ: "r",
                ŗ: "r",
                ř: "r",
                Ś: "S",
                Ŝ: "S",
                Ş: "S",
                Š: "S",
                ś: "s",
                ŝ: "s",
                ş: "s",
                š: "s",
                Ţ: "T",
                Ť: "T",
                Ŧ: "T",
                ţ: "t",
                ť: "t",
                ŧ: "t",
                Ũ: "U",
                Ū: "U",
                Ŭ: "U",
                Ů: "U",
                Ű: "U",
                Ų: "U",
                ũ: "u",
                ū: "u",
                ŭ: "u",
                ů: "u",
                ű: "u",
                ų: "u",
                Ŵ: "W",
                ŵ: "w",
                Ŷ: "Y",
                ŷ: "y",
                Ÿ: "Y",
                Ź: "Z",
                Ż: "Z",
                Ž: "Z",
                ź: "z",
                ż: "z",
                ž: "z",
                Ĳ: "IJ",
                ĳ: "ij",
                Œ: "Oe",
                œ: "oe",
                ŉ: "'n",
                ſ: "s"
            },
            j = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            },
            X = {
                "&amp;": "&",
                "&lt;": "<",
                "&gt;": ">",
                "&quot;": '"',
                "&#39;": "'"
            },
            dt = {
                "\\": "\\",
                "'": "'",
                "\n": "n",
                "\r": "r",
                "\u2028": "u2028",
                "\u2029": "u2029"
            },
            qe = parseFloat,
            Wt = parseInt,
            Le = typeof So == "object" && So && So.Object === Object && So,
            Xe = typeof self == "object" && self && self.Object === Object && self,
            ge = Le || Xe || Function("return this")(),
            Be = t && !t.nodeType && t,
            Ge = Be && !0 && r && !r.nodeType && r,
            Cr = Ge && Ge.exports === Be,
            Ze = Cr && Le.process,
            $e = function() {
                try {
                    var z = Ge && Ge.require && Ge.require("util").types;
                    return z || Ze && Ze.binding && Ze.binding("util")
                } catch {}
            }(),
            br = $e && $e.isArrayBuffer,
            _i = $e && $e.isDate,
            ni = $e && $e.isMap,
            Li = $e && $e.isRegExp,
            eo = $e && $e.isSet,
            Jn = $e && $e.isTypedArray;

        function sr(z, G, H) {
            switch (H.length) {
                case 0:
                    return z.call(G);
                case 1:
                    return z.call(G, H[0]);
                case 2:
                    return z.call(G, H[0], H[1]);
                case 3:
                    return z.call(G, H[0], H[1], H[2])
            }
            return z.apply(G, H)
        }

        function Ug(z, G, H, pt) {
            for (var Gt = -1, _e = z == null ? 0 : z.length; ++Gt < _e;) {
                var tr = z[Gt];
                G(pt, tr, H(tr), z)
            }
            return pt
        }

        function si(z, G) {
            for (var H = -1, pt = z == null ? 0 : z.length; ++H < pt && G(z[H], H, z) !== !1;);
            return z
        }

        function kg(z, G) {
            for (var H = z == null ? 0 : z.length; H-- && G(z[H], H, z) !== !1;);
            return z
        }

        function ol(z, G) {
            for (var H = -1, pt = z == null ? 0 : z.length; ++H < pt;)
                if (!G(z[H], H, z)) return !1;
            return !0
        }

        function En(z, G) {
            for (var H = -1, pt = z == null ? 0 : z.length, Gt = 0, _e = []; ++H < pt;) {
                var tr = z[H];
                G(tr, H, z) && (_e[Gt++] = tr)
            }
            return _e
        }

        function ua(z, G) {
            var H = z == null ? 0 : z.length;
            return !!H && _s(z, G, 0) > -1
        }

        function zc(z, G, H) {
            for (var pt = -1, Gt = z == null ? 0 : z.length; ++pt < Gt;)
                if (H(G, z[pt])) return !0;
            return !1
        }

        function je(z, G) {
            for (var H = -1, pt = z == null ? 0 : z.length, Gt = Array(pt); ++H < pt;) Gt[H] = G(z[H], H, z);
            return Gt
        }

        function In(z, G) {
            for (var H = -1, pt = G.length, Gt = z.length; ++H < pt;) z[Gt + H] = G[H];
            return z
        }

        function Fc(z, G, H, pt) {
            var Gt = -1,
                _e = z == null ? 0 : z.length;
            for (pt && _e && (H = z[++Gt]); ++Gt < _e;) H = G(H, z[Gt], Gt, z);
            return H
        }

        function Lg(z, G, H, pt) {
            var Gt = z == null ? 0 : z.length;
            for (pt && Gt && (H = z[--Gt]); Gt--;) H = G(H, z[Gt], Gt, z);
            return H
        }

        function Hc(z, G) {
            for (var H = -1, pt = z == null ? 0 : z.length; ++H < pt;)
                if (G(z[H], H, z)) return !0;
            return !1
        }
        var $g = Kc("length");

        function jg(z) {
            return z.split("")
        }

        function zg(z) {
            return z.match(Ht) || []
        }

        function al(z, G, H) {
            var pt;
            return H(z, function(Gt, _e, tr) {
                if (G(Gt, _e, tr)) return pt = _e, !1
            }), pt
        }

        function la(z, G, H, pt) {
            for (var Gt = z.length, _e = H + (pt ? 1 : -1); pt ? _e-- : ++_e < Gt;)
                if (G(z[_e], _e, z)) return _e;
            return -1
        }

        function _s(z, G, H) {
            return G === G ? t1(z, G, H) : la(z, cl, H)
        }

        function Fg(z, G, H, pt) {
            for (var Gt = H - 1, _e = z.length; ++Gt < _e;)
                if (pt(z[Gt], G)) return Gt;
            return -1
        }

        function cl(z) {
            return z !== z
        }

        function hl(z, G) {
            var H = z == null ? 0 : z.length;
            return H ? Gc(z, G) / H : E
        }

        function Kc(z) {
            return function(G) {
                return G == null ? e : G[z]
            }
        }

        function Vc(z) {
            return function(G) {
                return z == null ? e : z[G]
            }
        }

        function ul(z, G, H, pt, Gt) {
            return Gt(z, function(_e, tr, Ue) {
                H = pt ? (pt = !1, _e) : G(H, _e, tr, Ue)
            }), H
        }

        function Hg(z, G) {
            var H = z.length;
            for (z.sort(G); H--;) z[H] = z[H].value;
            return z
        }

        function Gc(z, G) {
            for (var H, pt = -1, Gt = z.length; ++pt < Gt;) {
                var _e = G(z[pt]);
                _e !== e && (H = H === e ? _e : H + _e)
            }
            return H
        }

        function Qc(z, G) {
            for (var H = -1, pt = Array(z); ++H < z;) pt[H] = G(H);
            return pt
        }

        function Kg(z, G) {
            return je(G, function(H) {
                return [H, z[H]]
            })
        }

        function ll(z) {
            return z && z.slice(0, gl(z) + 1).replace(Ut, "")
        }

        function Kr(z) {
            return function(G) {
                return z(G)
            }
        }

        function Wc(z, G) {
            return je(G, function(H) {
                return z[H]
            })
        }

        function ro(z, G) {
            return z.has(G)
        }

        function fl(z, G) {
            for (var H = -1, pt = z.length; ++H < pt && _s(G, z[H], 0) > -1;);
            return H
        }

        function dl(z, G) {
            for (var H = z.length; H-- && _s(G, z[H], 0) > -1;);
            return H
        }

        function Vg(z, G) {
            for (var H = z.length, pt = 0; H--;) z[H] === G && ++pt;
            return pt
        }
        var Gg = Vc(M),
            Qg = Vc(j);

        function Wg(z) {
            return "\\" + dt[z]
        }

        function Jg(z, G) {
            return z == null ? e : z[G]
        }

        function As(z) {
            return ca.test(z)
        }

        function Yg(z) {
            return Wn.test(z)
        }

        function Xg(z) {
            for (var G, H = []; !(G = z.next()).done;) H.push(G.value);
            return H
        }

        function Jc(z) {
            var G = -1,
                H = Array(z.size);
            return z.forEach(function(pt, Gt) {
                H[++G] = [Gt, pt]
            }), H
        }

        function pl(z, G) {
            return function(H) {
                return z(G(H))
            }
        }

        function Sn(z, G) {
            for (var H = -1, pt = z.length, Gt = 0, _e = []; ++H < pt;) {
                var tr = z[H];
                (tr === G || tr === _) && (z[H] = _, _e[Gt++] = H)
            }
            return _e
        }

        function fa(z) {
            var G = -1,
                H = Array(z.size);
            return z.forEach(function(pt) {
                H[++G] = pt
            }), H
        }

        function Zg(z) {
            var G = -1,
                H = Array(z.size);
            return z.forEach(function(pt) {
                H[++G] = [pt, pt]
            }), H
        }

        function t1(z, G, H) {
            for (var pt = H - 1, Gt = z.length; ++pt < Gt;)
                if (z[pt] === G) return pt;
            return -1
        }

        function e1(z, G, H) {
            for (var pt = H + 1; pt--;)
                if (z[pt] === G) return pt;
            return pt
        }

        function Es(z) {
            return As(z) ? i1(z) : $g(z)
        }

        function Ai(z) {
            return As(z) ? n1(z) : jg(z)
        }

        function gl(z) {
            for (var G = z.length; G-- && xe.test(z.charAt(G)););
            return G
        }
        var r1 = Vc(X);

        function i1(z) {
            for (var G = bs.lastIndex = 0; bs.test(z);) ++G;
            return G
        }

        function n1(z) {
            return z.match(bs) || []
        }

        function s1(z) {
            return z.match(aa) || []
        }
        var o1 = function z(G) {
                G = G == null ? ge : Is.defaults(ge.Object(), G, Is.pick(ge, ha));
                var H = G.Array,
                    pt = G.Date,
                    Gt = G.Error,
                    _e = G.Function,
                    tr = G.Math,
                    Ue = G.Object,
                    Yc = G.RegExp,
                    a1 = G.String,
                    oi = G.TypeError,
                    da = H.prototype,
                    c1 = _e.prototype,
                    Ss = Ue.prototype,
                    pa = G["__core-js_shared__"],
                    ga = c1.toString,
                    Ce = Ss.hasOwnProperty,
                    h1 = 0,
                    ml = function() {
                        var i = /[^.]+$/.exec(pa && pa.keys && pa.keys.IE_PROTO || "");
                        return i ? "Symbol(src)_1." + i : ""
                    }(),
                    ma = Ss.toString,
                    u1 = ga.call(Ue),
                    l1 = ge._,
                    f1 = Yc("^" + ga.call(Ce).replace(Ee, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"),
                    va = Cr ? G.Buffer : e,
                    xn = G.Symbol,
                    ya = G.Uint8Array,
                    vl = va ? va.allocUnsafe : e,
                    wa = pl(Ue.getPrototypeOf, Ue),
                    yl = Ue.create,
                    wl = Ss.propertyIsEnumerable,
                    ba = da.splice,
                    bl = xn ? xn.isConcatSpreadable : e,
                    io = xn ? xn.iterator : e,
                    Yn = xn ? xn.toStringTag : e,
                    _a = function() {
                        try {
                            var i = rs(Ue, "defineProperty");
                            return i({}, "", {}), i
                        } catch {}
                    }(),
                    d1 = G.clearTimeout !== ge.clearTimeout && G.clearTimeout,
                    p1 = pt && pt.now !== ge.Date.now && pt.now,
                    g1 = G.setTimeout !== ge.setTimeout && G.setTimeout,
                    Aa = tr.ceil,
                    Ea = tr.floor,
                    Xc = Ue.getOwnPropertySymbols,
                    m1 = va ? va.isBuffer : e,
                    _l = G.isFinite,
                    v1 = da.join,
                    y1 = pl(Ue.keys, Ue),
                    er = tr.max,
                    gr = tr.min,
                    w1 = pt.now,
                    b1 = G.parseInt,
                    Al = tr.random,
                    _1 = da.reverse,
                    Zc = rs(G, "DataView"),
                    no = rs(G, "Map"),
                    th = rs(G, "Promise"),
                    xs = rs(G, "Set"),
                    so = rs(G, "WeakMap"),
                    oo = rs(Ue, "create"),
                    Ia = so && new so,
                    Ps = {},
                    A1 = is(Zc),
                    E1 = is(no),
                    I1 = is(th),
                    S1 = is(xs),
                    x1 = is(so),
                    Sa = xn ? xn.prototype : e,
                    ao = Sa ? Sa.valueOf : e,
                    El = Sa ? Sa.toString : e;

                function A(i) {
                    if (Ke(i) && !Jt(i) && !(i instanceof le)) {
                        if (i instanceof ai) return i;
                        if (Ce.call(i, "__wrapped__")) return Sf(i)
                    }
                    return new ai(i)
                }
                var Ms = function() {
                    function i() {}
                    return function(s) {
                        if (!He(s)) return {};
                        if (yl) return yl(s);
                        i.prototype = s;
                        var c = new i;
                        return i.prototype = e, c
                    }
                }();

                function xa() {}

                function ai(i, s) {
                    this.__wrapped__ = i, this.__actions__ = [], this.__chain__ = !!s, this.__index__ = 0, this.__values__ = e
                }
                A.templateSettings = {
                    escape: Ae,
                    evaluate: Bt,
                    interpolate: Ot,
                    variable: "",
                    imports: {
                        _: A
                    }
                }, A.prototype = xa.prototype, A.prototype.constructor = A, ai.prototype = Ms(xa.prototype), ai.prototype.constructor = ai;

                function le(i) {
                    this.__wrapped__ = i, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = f, this.__views__ = []
                }

                function P1() {
                    var i = new le(this.__wrapped__);
                    return i.__actions__ = Nr(this.__actions__), i.__dir__ = this.__dir__, i.__filtered__ = this.__filtered__, i.__iteratees__ = Nr(this.__iteratees__), i.__takeCount__ = this.__takeCount__, i.__views__ = Nr(this.__views__), i
                }

                function M1() {
                    if (this.__filtered__) {
                        var i = new le(this);
                        i.__dir__ = -1, i.__filtered__ = !0
                    } else i = this.clone(), i.__dir__ *= -1;
                    return i
                }

                function C1() {
                    var i = this.__wrapped__.value(),
                        s = this.__dir__,
                        c = Jt(i),
                        l = s < 0,
                        w = c ? i.length : 0,
                        I = jm(0, w, this.__views__),
                        q = I.start,
                        $ = I.end,
                        F = $ - q,
                        J = l ? $ : q - 1,
                        Y = this.__iteratees__,
                        tt = Y.length,
                        ct = 0,
                        yt = gr(F, this.__takeCount__);
                    if (!c || !l && w == F && yt == F) return Gl(i, this.__actions__);
                    var Ct = [];
                    t: for (; F-- && ct < yt;) {
                        J += s;
                        for (var re = -1, Nt = i[J]; ++re < tt;) {
                            var ce = Y[re],
                                me = ce.iteratee,
                                Qr = ce.type,
                                Er = me(Nt);
                            if (Qr == v) Nt = Er;
                            else if (!Er) {
                                if (Qr == p) continue t;
                                break t
                            }
                        }
                        Ct[ct++] = Nt
                    }
                    return Ct
                }
                le.prototype = Ms(xa.prototype), le.prototype.constructor = le;

                function Xn(i) {
                    var s = -1,
                        c = i == null ? 0 : i.length;
                    for (this.clear(); ++s < c;) {
                        var l = i[s];
                        this.set(l[0], l[1])
                    }
                }

                function N1() {
                    this.__data__ = oo ? oo(null) : {}, this.size = 0
                }

                function R1(i) {
                    var s = this.has(i) && delete this.__data__[i];
                    return this.size -= s ? 1 : 0, s
                }

                function O1(i) {
                    var s = this.__data__;
                    if (oo) {
                        var c = s[i];
                        return c === b ? e : c
                    }
                    return Ce.call(s, i) ? s[i] : e
                }

                function T1(i) {
                    var s = this.__data__;
                    return oo ? s[i] !== e : Ce.call(s, i)
                }

                function D1(i, s) {
                    var c = this.__data__;
                    return this.size += this.has(i) ? 0 : 1, c[i] = oo && s === e ? b : s, this
                }
                Xn.prototype.clear = N1, Xn.prototype.delete = R1, Xn.prototype.get = O1, Xn.prototype.has = T1, Xn.prototype.set = D1;

                function sn(i) {
                    var s = -1,
                        c = i == null ? 0 : i.length;
                    for (this.clear(); ++s < c;) {
                        var l = i[s];
                        this.set(l[0], l[1])
                    }
                }

                function q1() {
                    this.__data__ = [], this.size = 0
                }

                function B1(i) {
                    var s = this.__data__,
                        c = Pa(s, i);
                    if (c < 0) return !1;
                    var l = s.length - 1;
                    return c == l ? s.pop() : ba.call(s, c, 1), --this.size, !0
                }

                function U1(i) {
                    var s = this.__data__,
                        c = Pa(s, i);
                    return c < 0 ? e : s[c][1]
                }

                function k1(i) {
                    return Pa(this.__data__, i) > -1
                }

                function L1(i, s) {
                    var c = this.__data__,
                        l = Pa(c, i);
                    return l < 0 ? (++this.size, c.push([i, s])) : c[l][1] = s, this
                }
                sn.prototype.clear = q1, sn.prototype.delete = B1, sn.prototype.get = U1, sn.prototype.has = k1, sn.prototype.set = L1;

                function on(i) {
                    var s = -1,
                        c = i == null ? 0 : i.length;
                    for (this.clear(); ++s < c;) {
                        var l = i[s];
                        this.set(l[0], l[1])
                    }
                }

                function $1() {
                    this.size = 0, this.__data__ = {
                        hash: new Xn,
                        map: new(no || sn),
                        string: new Xn
                    }
                }

                function j1(i) {
                    var s = La(this, i).delete(i);
                    return this.size -= s ? 1 : 0, s
                }

                function z1(i) {
                    return La(this, i).get(i)
                }

                function F1(i) {
                    return La(this, i).has(i)
                }

                function H1(i, s) {
                    var c = La(this, i),
                        l = c.size;
                    return c.set(i, s), this.size += c.size == l ? 0 : 1, this
                }
                on.prototype.clear = $1, on.prototype.delete = j1, on.prototype.get = z1, on.prototype.has = F1, on.prototype.set = H1;

                function Zn(i) {
                    var s = -1,
                        c = i == null ? 0 : i.length;
                    for (this.__data__ = new on; ++s < c;) this.add(i[s])
                }

                function K1(i) {
                    return this.__data__.set(i, b), this
                }

                function V1(i) {
                    return this.__data__.has(i)
                }
                Zn.prototype.add = Zn.prototype.push = K1, Zn.prototype.has = V1;

                function Ei(i) {
                    var s = this.__data__ = new sn(i);
                    this.size = s.size
                }

                function G1() {
                    this.__data__ = new sn, this.size = 0
                }

                function Q1(i) {
                    var s = this.__data__,
                        c = s.delete(i);
                    return this.size = s.size, c
                }

                function W1(i) {
                    return this.__data__.get(i)
                }

                function J1(i) {
                    return this.__data__.has(i)
                }

                function Y1(i, s) {
                    var c = this.__data__;
                    if (c instanceof sn) {
                        var l = c.__data__;
                        if (!no || l.length < o - 1) return l.push([i, s]), this.size = ++c.size, this;
                        c = this.__data__ = new on(l)
                    }
                    return c.set(i, s), this.size = c.size, this
                }
                Ei.prototype.clear = G1, Ei.prototype.delete = Q1, Ei.prototype.get = W1, Ei.prototype.has = J1, Ei.prototype.set = Y1;

                function Il(i, s) {
                    var c = Jt(i),
                        l = !c && ns(i),
                        w = !c && !l && Rn(i),
                        I = !c && !l && !w && Os(i),
                        q = c || l || w || I,
                        $ = q ? Qc(i.length, a1) : [],
                        F = $.length;
                    for (var J in i)(s || Ce.call(i, J)) && !(q && (J == "length" || w && (J == "offset" || J == "parent") || I && (J == "buffer" || J == "byteLength" || J == "byteOffset") || un(J, F))) && $.push(J);
                    return $
                }

                function Sl(i) {
                    var s = i.length;
                    return s ? i[lh(0, s - 1)] : e
                }

                function X1(i, s) {
                    return $a(Nr(i), ts(s, 0, i.length))
                }

                function Z1(i) {
                    return $a(Nr(i))
                }

                function eh(i, s, c) {
                    (c !== e && !Ii(i[s], c) || c === e && !(s in i)) && an(i, s, c)
                }

                function co(i, s, c) {
                    var l = i[s];
                    (!(Ce.call(i, s) && Ii(l, c)) || c === e && !(s in i)) && an(i, s, c)
                }

                function Pa(i, s) {
                    for (var c = i.length; c--;)
                        if (Ii(i[c][0], s)) return c;
                    return -1
                }

                function tm(i, s, c, l) {
                    return Pn(i, function(w, I, q) {
                        s(l, w, c(w), q)
                    }), l
                }

                function xl(i, s) {
                    return i && ji(s, or(s), i)
                }

                function em(i, s) {
                    return i && ji(s, Or(s), i)
                }

                function an(i, s, c) {
                    s == "__proto__" && _a ? _a(i, s, {
                        configurable: !0,
                        enumerable: !0,
                        value: c,
                        writable: !0
                    }) : i[s] = c
                }

                function rh(i, s) {
                    for (var c = -1, l = s.length, w = H(l), I = i == null; ++c < l;) w[c] = I ? e : Bh(i, s[c]);
                    return w
                }

                function ts(i, s, c) {
                    return i === i && (c !== e && (i = i <= c ? i : c), s !== e && (i = i >= s ? i : s)), i
                }

                function ci(i, s, c, l, w, I) {
                    var q, $ = s & S,
                        F = s & B,
                        J = s & k;
                    if (c && (q = w ? c(i, l, w, I) : c(i)), q !== e) return q;
                    if (!He(i)) return i;
                    var Y = Jt(i);
                    if (Y) {
                        if (q = Fm(i), !$) return Nr(i, q)
                    } else {
                        var tt = mr(i),
                            ct = tt == W || tt == rt;
                        if (Rn(i)) return Jl(i, $);
                        if (tt == vt || tt == y || ct && !w) {
                            if (q = F || ct ? {} : mf(i), !$) return F ? Om(i, em(q, i)) : Rm(i, xl(q, i))
                        } else {
                            if (!Te[tt]) return w ? i : {};
                            q = Hm(i, tt, $)
                        }
                    }
                    I || (I = new Ei);
                    var yt = I.get(i);
                    if (yt) return yt;
                    I.set(i, q), Kf(i) ? i.forEach(function(Nt) {
                        q.add(ci(Nt, s, c, Nt, i, I))
                    }) : Ff(i) && i.forEach(function(Nt, ce) {
                        q.set(ce, ci(Nt, s, c, ce, i, I))
                    });
                    var Ct = J ? F ? Ah : _h : F ? Or : or,
                        re = Y ? e : Ct(i);
                    return si(re || i, function(Nt, ce) {
                        re && (ce = Nt, Nt = i[ce]), co(q, ce, ci(Nt, s, c, ce, i, I))
                    }), q
                }

                function rm(i) {
                    var s = or(i);
                    return function(c) {
                        return Pl(c, i, s)
                    }
                }

                function Pl(i, s, c) {
                    var l = c.length;
                    if (i == null) return !l;
                    for (i = Ue(i); l--;) {
                        var w = c[l],
                            I = s[w],
                            q = i[w];
                        if (q === e && !(w in i) || !I(q)) return !1
                    }
                    return !0
                }

                function Ml(i, s, c) {
                    if (typeof i != "function") throw new oi(h);
                    return mo(function() {
                        i.apply(e, c)
                    }, s)
                }

                function ho(i, s, c, l) {
                    var w = -1,
                        I = ua,
                        q = !0,
                        $ = i.length,
                        F = [],
                        J = s.length;
                    if (!$) return F;
                    c && (s = je(s, Kr(c))), l ? (I = zc, q = !1) : s.length >= o && (I = ro, q = !1, s = new Zn(s));
                    t: for (; ++w < $;) {
                        var Y = i[w],
                            tt = c == null ? Y : c(Y);
                        if (Y = l || Y !== 0 ? Y : 0, q && tt === tt) {
                            for (var ct = J; ct--;)
                                if (s[ct] === tt) continue t;
                            F.push(Y)
                        } else I(s, tt, l) || F.push(Y)
                    }
                    return F
                }
                var Pn = ef($i),
                    Cl = ef(nh, !0);

                function im(i, s) {
                    var c = !0;
                    return Pn(i, function(l, w, I) {
                        return c = !!s(l, w, I), c
                    }), c
                }

                function Ma(i, s, c) {
                    for (var l = -1, w = i.length; ++l < w;) {
                        var I = i[l],
                            q = s(I);
                        if (q != null && ($ === e ? q === q && !Gr(q) : c(q, $))) var $ = q,
                            F = I
                    }
                    return F
                }

                function nm(i, s, c, l) {
                    var w = i.length;
                    for (c = Xt(c), c < 0 && (c = -c > w ? 0 : w + c), l = l === e || l > w ? w : Xt(l), l < 0 && (l += w), l = c > l ? 0 : Gf(l); c < l;) i[c++] = s;
                    return i
                }

                function Nl(i, s) {
                    var c = [];
                    return Pn(i, function(l, w, I) {
                        s(l, w, I) && c.push(l)
                    }), c
                }

                function hr(i, s, c, l, w) {
                    var I = -1,
                        q = i.length;
                    for (c || (c = Vm), w || (w = []); ++I < q;) {
                        var $ = i[I];
                        s > 0 && c($) ? s > 1 ? hr($, s - 1, c, l, w) : In(w, $) : l || (w[w.length] = $)
                    }
                    return w
                }
                var ih = rf(),
                    Rl = rf(!0);

                function $i(i, s) {
                    return i && ih(i, s, or)
                }

                function nh(i, s) {
                    return i && Rl(i, s, or)
                }

                function Ca(i, s) {
                    return En(s, function(c) {
                        return ln(i[c])
                    })
                }

                function es(i, s) {
                    s = Cn(s, i);
                    for (var c = 0, l = s.length; i != null && c < l;) i = i[zi(s[c++])];
                    return c && c == l ? i : e
                }

                function Ol(i, s, c) {
                    var l = s(i);
                    return Jt(i) ? l : In(l, c(i))
                }

                function _r(i) {
                    return i == null ? i === e ? be : bt : Yn && Yn in Ue(i) ? $m(i) : Zm(i)
                }

                function sh(i, s) {
                    return i > s
                }

                function sm(i, s) {
                    return i != null && Ce.call(i, s)
                }

                function om(i, s) {
                    return i != null && s in Ue(i)
                }

                function am(i, s, c) {
                    return i >= gr(s, c) && i < er(s, c)
                }

                function oh(i, s, c) {
                    for (var l = c ? zc : ua, w = i[0].length, I = i.length, q = I, $ = H(I), F = 1 / 0, J = []; q--;) {
                        var Y = i[q];
                        q && s && (Y = je(Y, Kr(s))), F = gr(Y.length, F), $[q] = !c && (s || w >= 120 && Y.length >= 120) ? new Zn(q && Y) : e
                    }
                    Y = i[0];
                    var tt = -1,
                        ct = $[0];
                    t: for (; ++tt < w && J.length < F;) {
                        var yt = Y[tt],
                            Ct = s ? s(yt) : yt;
                        if (yt = c || yt !== 0 ? yt : 0, !(ct ? ro(ct, Ct) : l(J, Ct, c))) {
                            for (q = I; --q;) {
                                var re = $[q];
                                if (!(re ? ro(re, Ct) : l(i[q], Ct, c))) continue t
                            }
                            ct && ct.push(Ct), J.push(yt)
                        }
                    }
                    return J
                }

                function cm(i, s, c, l) {
                    return $i(i, function(w, I, q) {
                        s(l, c(w), I, q)
                    }), l
                }

                function uo(i, s, c) {
                    s = Cn(s, i), i = bf(i, s);
                    var l = i == null ? i : i[zi(ui(s))];
                    return l == null ? e : sr(l, i, c)
                }

                function Tl(i) {
                    return Ke(i) && _r(i) == y
                }

                function hm(i) {
                    return Ke(i) && _r(i) == te
                }

                function um(i) {
                    return Ke(i) && _r(i) == U
                }

                function lo(i, s, c, l, w) {
                    return i === s ? !0 : i == null || s == null || !Ke(i) && !Ke(s) ? i !== i && s !== s : lm(i, s, c, l, lo, w)
                }

                function lm(i, s, c, l, w, I) {
                    var q = Jt(i),
                        $ = Jt(s),
                        F = q ? V : mr(i),
                        J = $ ? V : mr(s);
                    F = F == y ? vt : F, J = J == y ? vt : J;
                    var Y = F == vt,
                        tt = J == vt,
                        ct = F == J;
                    if (ct && Rn(i)) {
                        if (!Rn(s)) return !1;
                        q = !0, Y = !1
                    }
                    if (ct && !Y) return I || (I = new Ei), q || Os(i) ? df(i, s, c, l, w, I) : km(i, s, F, c, l, w, I);
                    if (!(c & L)) {
                        var yt = Y && Ce.call(i, "__wrapped__"),
                            Ct = tt && Ce.call(s, "__wrapped__");
                        if (yt || Ct) {
                            var re = yt ? i.value() : i,
                                Nt = Ct ? s.value() : s;
                            return I || (I = new Ei), w(re, Nt, c, l, I)
                        }
                    }
                    return ct ? (I || (I = new Ei), Lm(i, s, c, l, w, I)) : !1
                }

                function fm(i) {
                    return Ke(i) && mr(i) == Z
                }

                function ah(i, s, c, l) {
                    var w = c.length,
                        I = w,
                        q = !l;
                    if (i == null) return !I;
                    for (i = Ue(i); w--;) {
                        var $ = c[w];
                        if (q && $[2] ? $[1] !== i[$[0]] : !($[0] in i)) return !1
                    }
                    for (; ++w < I;) {
                        $ = c[w];
                        var F = $[0],
                            J = i[F],
                            Y = $[1];
                        if (q && $[2]) {
                            if (J === e && !(F in i)) return !1
                        } else {
                            var tt = new Ei;
                            if (l) var ct = l(J, Y, F, i, s, tt);
                            if (!(ct === e ? lo(Y, J, L | K, l, tt) : ct)) return !1
                        }
                    }
                    return !0
                }

                function Dl(i) {
                    if (!He(i) || Qm(i)) return !1;
                    var s = ln(i) ? f1 : ei;
                    return s.test(is(i))
                }

                function dm(i) {
                    return Ke(i) && _r(i) == Rt
                }

                function pm(i) {
                    return Ke(i) && mr(i) == ne
                }

                function gm(i) {
                    return Ke(i) && Va(i.length) && !!De[_r(i)]
                }

                function ql(i) {
                    return typeof i == "function" ? i : i == null ? Tr : typeof i == "object" ? Jt(i) ? kl(i[0], i[1]) : Ul(i) : nd(i)
                }

                function ch(i) {
                    if (!go(i)) return y1(i);
                    var s = [];
                    for (var c in Ue(i)) Ce.call(i, c) && c != "constructor" && s.push(c);
                    return s
                }

                function mm(i) {
                    if (!He(i)) return Xm(i);
                    var s = go(i),
                        c = [];
                    for (var l in i) l == "constructor" && (s || !Ce.call(i, l)) || c.push(l);
                    return c
                }

                function hh(i, s) {
                    return i < s
                }

                function Bl(i, s) {
                    var c = -1,
                        l = Rr(i) ? H(i.length) : [];
                    return Pn(i, function(w, I, q) {
                        l[++c] = s(w, I, q)
                    }), l
                }

                function Ul(i) {
                    var s = Ih(i);
                    return s.length == 1 && s[0][2] ? yf(s[0][0], s[0][1]) : function(c) {
                        return c === i || ah(c, i, s)
                    }
                }

                function kl(i, s) {
                    return xh(i) && vf(s) ? yf(zi(i), s) : function(c) {
                        var l = Bh(c, i);
                        return l === e && l === s ? Uh(c, i) : lo(s, l, L | K)
                    }
                }

                function Na(i, s, c, l, w) {
                    i !== s && ih(s, function(I, q) {
                        if (w || (w = new Ei), He(I)) vm(i, s, q, c, Na, l, w);
                        else {
                            var $ = l ? l(Mh(i, q), I, q + "", i, s, w) : e;
                            $ === e && ($ = I), eh(i, q, $)
                        }
                    }, Or)
                }

                function vm(i, s, c, l, w, I, q) {
                    var $ = Mh(i, c),
                        F = Mh(s, c),
                        J = q.get(F);
                    if (J) {
                        eh(i, c, J);
                        return
                    }
                    var Y = I ? I($, F, c + "", i, s, q) : e,
                        tt = Y === e;
                    if (tt) {
                        var ct = Jt(F),
                            yt = !ct && Rn(F),
                            Ct = !ct && !yt && Os(F);
                        Y = F, ct || yt || Ct ? Jt($) ? Y = $ : Qe($) ? Y = Nr($) : yt ? (tt = !1, Y = Jl(F, !0)) : Ct ? (tt = !1, Y = Yl(F, !0)) : Y = [] : vo(F) || ns(F) ? (Y = $, ns($) ? Y = Qf($) : (!He($) || ln($)) && (Y = mf(F))) : tt = !1
                    }
                    tt && (q.set(F, Y), w(Y, F, l, I, q), q.delete(F)), eh(i, c, Y)
                }

                function Ll(i, s) {
                    var c = i.length;
                    if (c) return s += s < 0 ? c : 0, un(s, c) ? i[s] : e
                }

                function $l(i, s, c) {
                    s.length ? s = je(s, function(I) {
                        return Jt(I) ? function(q) {
                            return es(q, I.length === 1 ? I[0] : I)
                        } : I
                    }) : s = [Tr];
                    var l = -1;
                    s = je(s, Kr(Pt()));
                    var w = Bl(i, function(I, q, $) {
                        var F = je(s, function(J) {
                            return J(I)
                        });
                        return {
                            criteria: F,
                            index: ++l,
                            value: I
                        }
                    });
                    return Hg(w, function(I, q) {
                        return Nm(I, q, c)
                    })
                }

                function ym(i, s) {
                    return jl(i, s, function(c, l) {
                        return Uh(i, l)
                    })
                }

                function jl(i, s, c) {
                    for (var l = -1, w = s.length, I = {}; ++l < w;) {
                        var q = s[l],
                            $ = es(i, q);
                        c($, q) && fo(I, Cn(q, i), $)
                    }
                    return I
                }

                function wm(i) {
                    return function(s) {
                        return es(s, i)
                    }
                }

                function uh(i, s, c, l) {
                    var w = l ? Fg : _s,
                        I = -1,
                        q = s.length,
                        $ = i;
                    for (i === s && (s = Nr(s)), c && ($ = je(i, Kr(c))); ++I < q;)
                        for (var F = 0, J = s[I], Y = c ? c(J) : J;
                            (F = w($, Y, F, l)) > -1;) $ !== i && ba.call($, F, 1), ba.call(i, F, 1);
                    return i
                }

                function zl(i, s) {
                    for (var c = i ? s.length : 0, l = c - 1; c--;) {
                        var w = s[c];
                        if (c == l || w !== I) {
                            var I = w;
                            un(w) ? ba.call(i, w, 1) : ph(i, w)
                        }
                    }
                    return i
                }

                function lh(i, s) {
                    return i + Ea(Al() * (s - i + 1))
                }

                function bm(i, s, c, l) {
                    for (var w = -1, I = er(Aa((s - i) / (c || 1)), 0), q = H(I); I--;) q[l ? I : ++w] = i, i += c;
                    return q
                }

                function fh(i, s) {
                    var c = "";
                    if (!i || s < 1 || s > R) return c;
                    do s % 2 && (c += i), s = Ea(s / 2), s && (i += i); while (s);
                    return c
                }

                function ie(i, s) {
                    return Ch(wf(i, s, Tr), i + "")
                }

                function _m(i) {
                    return Sl(Ts(i))
                }

                function Am(i, s) {
                    var c = Ts(i);
                    return $a(c, ts(s, 0, c.length))
                }

                function fo(i, s, c, l) {
                    if (!He(i)) return i;
                    s = Cn(s, i);
                    for (var w = -1, I = s.length, q = I - 1, $ = i; $ != null && ++w < I;) {
                        var F = zi(s[w]),
                            J = c;
                        if (F === "__proto__" || F === "constructor" || F === "prototype") return i;
                        if (w != q) {
                            var Y = $[F];
                            J = l ? l(Y, F, $) : e, J === e && (J = He(Y) ? Y : un(s[w + 1]) ? [] : {})
                        }
                        co($, F, J), $ = $[F]
                    }
                    return i
                }
                var Fl = Ia ? function(i, s) {
                        return Ia.set(i, s), i
                    } : Tr,
                    Em = _a ? function(i, s) {
                        return _a(i, "toString", {
                            configurable: !0,
                            enumerable: !1,
                            value: Lh(s),
                            writable: !0
                        })
                    } : Tr;

                function Im(i) {
                    return $a(Ts(i))
                }

                function hi(i, s, c) {
                    var l = -1,
                        w = i.length;
                    s < 0 && (s = -s > w ? 0 : w + s), c = c > w ? w : c, c < 0 && (c += w), w = s > c ? 0 : c - s >>> 0, s >>>= 0;
                    for (var I = H(w); ++l < w;) I[l] = i[l + s];
                    return I
                }

                function Sm(i, s) {
                    var c;
                    return Pn(i, function(l, w, I) {
                        return c = s(l, w, I), !c
                    }), !!c
                }

                function Ra(i, s, c) {
                    var l = 0,
                        w = i == null ? l : i.length;
                    if (typeof s == "number" && s === s && w <= ht) {
                        for (; l < w;) {
                            var I = l + w >>> 1,
                                q = i[I];
                            q !== null && !Gr(q) && (c ? q <= s : q < s) ? l = I + 1 : w = I
                        }
                        return w
                    }
                    return dh(i, s, Tr, c)
                }

                function dh(i, s, c, l) {
                    var w = 0,
                        I = i == null ? 0 : i.length;
                    if (I === 0) return 0;
                    s = c(s);
                    for (var q = s !== s, $ = s === null, F = Gr(s), J = s === e; w < I;) {
                        var Y = Ea((w + I) / 2),
                            tt = c(i[Y]),
                            ct = tt !== e,
                            yt = tt === null,
                            Ct = tt === tt,
                            re = Gr(tt);
                        if (q) var Nt = l || Ct;
                        else J ? Nt = Ct && (l || ct) : $ ? Nt = Ct && ct && (l || !yt) : F ? Nt = Ct && ct && !yt && (l || !re) : yt || re ? Nt = !1 : Nt = l ? tt <= s : tt < s;
                        Nt ? w = Y + 1 : I = Y
                    }
                    return gr(I, x)
                }

                function Hl(i, s) {
                    for (var c = -1, l = i.length, w = 0, I = []; ++c < l;) {
                        var q = i[c],
                            $ = s ? s(q) : q;
                        if (!c || !Ii($, F)) {
                            var F = $;
                            I[w++] = q === 0 ? 0 : q
                        }
                    }
                    return I
                }

                function Kl(i) {
                    return typeof i == "number" ? i : Gr(i) ? E : +i
                }

                function Vr(i) {
                    if (typeof i == "string") return i;
                    if (Jt(i)) return je(i, Vr) + "";
                    if (Gr(i)) return El ? El.call(i) : "";
                    var s = i + "";
                    return s == "0" && 1 / i == -C ? "-0" : s
                }

                function Mn(i, s, c) {
                    var l = -1,
                        w = ua,
                        I = i.length,
                        q = !0,
                        $ = [],
                        F = $;
                    if (c) q = !1, w = zc;
                    else if (I >= o) {
                        var J = s ? null : Bm(i);
                        if (J) return fa(J);
                        q = !1, w = ro, F = new Zn
                    } else F = s ? [] : $;
                    t: for (; ++l < I;) {
                        var Y = i[l],
                            tt = s ? s(Y) : Y;
                        if (Y = c || Y !== 0 ? Y : 0, q && tt === tt) {
                            for (var ct = F.length; ct--;)
                                if (F[ct] === tt) continue t;
                            s && F.push(tt), $.push(Y)
                        } else w(F, tt, c) || (F !== $ && F.push(tt), $.push(Y))
                    }
                    return $
                }

                function ph(i, s) {
                    return s = Cn(s, i), i = bf(i, s), i == null || delete i[zi(ui(s))]
                }

                function Vl(i, s, c, l) {
                    return fo(i, s, c(es(i, s)), l)
                }

                function Oa(i, s, c, l) {
                    for (var w = i.length, I = l ? w : -1;
                        (l ? I-- : ++I < w) && s(i[I], I, i););
                    return c ? hi(i, l ? 0 : I, l ? I + 1 : w) : hi(i, l ? I + 1 : 0, l ? w : I)
                }

                function Gl(i, s) {
                    var c = i;
                    return c instanceof le && (c = c.value()), Fc(s, function(l, w) {
                        return w.func.apply(w.thisArg, In([l], w.args))
                    }, c)
                }

                function gh(i, s, c) {
                    var l = i.length;
                    if (l < 2) return l ? Mn(i[0]) : [];
                    for (var w = -1, I = H(l); ++w < l;)
                        for (var q = i[w], $ = -1; ++$ < l;) $ != w && (I[w] = ho(I[w] || q, i[$], s, c));
                    return Mn(hr(I, 1), s, c)
                }

                function Ql(i, s, c) {
                    for (var l = -1, w = i.length, I = s.length, q = {}; ++l < w;) {
                        var $ = l < I ? s[l] : e;
                        c(q, i[l], $)
                    }
                    return q
                }

                function mh(i) {
                    return Qe(i) ? i : []
                }

                function vh(i) {
                    return typeof i == "function" ? i : Tr
                }

                function Cn(i, s) {
                    return Jt(i) ? i : xh(i, s) ? [i] : If(Ie(i))
                }
                var xm = ie;

                function Nn(i, s, c) {
                    var l = i.length;
                    return c = c === e ? l : c, !s && c >= l ? i : hi(i, s, c)
                }
                var Wl = d1 || function(i) {
                    return ge.clearTimeout(i)
                };

                function Jl(i, s) {
                    if (s) return i.slice();
                    var c = i.length,
                        l = vl ? vl(c) : new i.constructor(c);
                    return i.copy(l), l
                }

                function yh(i) {
                    var s = new i.constructor(i.byteLength);
                    return new ya(s).set(new ya(i)), s
                }

                function Pm(i, s) {
                    var c = s ? yh(i.buffer) : i.buffer;
                    return new i.constructor(c, i.byteOffset, i.byteLength)
                }

                function Mm(i) {
                    var s = new i.constructor(i.source, se.exec(i));
                    return s.lastIndex = i.lastIndex, s
                }

                function Cm(i) {
                    return ao ? Ue(ao.call(i)) : {}
                }

                function Yl(i, s) {
                    var c = s ? yh(i.buffer) : i.buffer;
                    return new i.constructor(c, i.byteOffset, i.length)
                }

                function Xl(i, s) {
                    if (i !== s) {
                        var c = i !== e,
                            l = i === null,
                            w = i === i,
                            I = Gr(i),
                            q = s !== e,
                            $ = s === null,
                            F = s === s,
                            J = Gr(s);
                        if (!$ && !J && !I && i > s || I && q && F && !$ && !J || l && q && F || !c && F || !w) return 1;
                        if (!l && !I && !J && i < s || J && c && w && !l && !I || $ && c && w || !q && w || !F) return -1
                    }
                    return 0
                }

                function Nm(i, s, c) {
                    for (var l = -1, w = i.criteria, I = s.criteria, q = w.length, $ = c.length; ++l < q;) {
                        var F = Xl(w[l], I[l]);
                        if (F) {
                            if (l >= $) return F;
                            var J = c[l];
                            return F * (J == "desc" ? -1 : 1)
                        }
                    }
                    return i.index - s.index
                }

                function Zl(i, s, c, l) {
                    for (var w = -1, I = i.length, q = c.length, $ = -1, F = s.length, J = er(I - q, 0), Y = H(F + J), tt = !l; ++$ < F;) Y[$] = s[$];
                    for (; ++w < q;)(tt || w < I) && (Y[c[w]] = i[w]);
                    for (; J--;) Y[$++] = i[w++];
                    return Y
                }

                function tf(i, s, c, l) {
                    for (var w = -1, I = i.length, q = -1, $ = c.length, F = -1, J = s.length, Y = er(I - $, 0), tt = H(Y + J), ct = !l; ++w < Y;) tt[w] = i[w];
                    for (var yt = w; ++F < J;) tt[yt + F] = s[F];
                    for (; ++q < $;)(ct || w < I) && (tt[yt + c[q]] = i[w++]);
                    return tt
                }

                function Nr(i, s) {
                    var c = -1,
                        l = i.length;
                    for (s || (s = H(l)); ++c < l;) s[c] = i[c];
                    return s
                }

                function ji(i, s, c, l) {
                    var w = !c;
                    c || (c = {});
                    for (var I = -1, q = s.length; ++I < q;) {
                        var $ = s[I],
                            F = l ? l(c[$], i[$], $, c, i) : e;
                        F === e && (F = i[$]), w ? an(c, $, F) : co(c, $, F)
                    }
                    return c
                }

                function Rm(i, s) {
                    return ji(i, Sh(i), s)
                }

                function Om(i, s) {
                    return ji(i, pf(i), s)
                }

                function Ta(i, s) {
                    return function(c, l) {
                        var w = Jt(c) ? Ug : tm,
                            I = s ? s() : {};
                        return w(c, i, Pt(l, 2), I)
                    }
                }

                function Cs(i) {
                    return ie(function(s, c) {
                        var l = -1,
                            w = c.length,
                            I = w > 1 ? c[w - 1] : e,
                            q = w > 2 ? c[2] : e;
                        for (I = i.length > 3 && typeof I == "function" ? (w--, I) : e, q && Ar(c[0], c[1], q) && (I = w < 3 ? e : I, w = 1), s = Ue(s); ++l < w;) {
                            var $ = c[l];
                            $ && i(s, $, l, I)
                        }
                        return s
                    })
                }

                function ef(i, s) {
                    return function(c, l) {
                        if (c == null) return c;
                        if (!Rr(c)) return i(c, l);
                        for (var w = c.length, I = s ? w : -1, q = Ue(c);
                            (s ? I-- : ++I < w) && l(q[I], I, q) !== !1;);
                        return c
                    }
                }

                function rf(i) {
                    return function(s, c, l) {
                        for (var w = -1, I = Ue(s), q = l(s), $ = q.length; $--;) {
                            var F = q[i ? $ : ++w];
                            if (c(I[F], F, I) === !1) break
                        }
                        return s
                    }
                }

                function Tm(i, s, c) {
                    var l = s & Q,
                        w = po(i);

                    function I() {
                        var q = this && this !== ge && this instanceof I ? w : i;
                        return q.apply(l ? c : this, arguments)
                    }
                    return I
                }

                function nf(i) {
                    return function(s) {
                        s = Ie(s);
                        var c = As(s) ? Ai(s) : e,
                            l = c ? c[0] : s.charAt(0),
                            w = c ? Nn(c, 1).join("") : s.slice(1);
                        return l[i]() + w
                    }
                }

                function Ns(i) {
                    return function(s) {
                        return Fc(rd(ed(s).replace(to, "")), i, "")
                    }
                }

                function po(i) {
                    return function() {
                        var s = arguments;
                        switch (s.length) {
                            case 0:
                                return new i;
                            case 1:
                                return new i(s[0]);
                            case 2:
                                return new i(s[0], s[1]);
                            case 3:
                                return new i(s[0], s[1], s[2]);
                            case 4:
                                return new i(s[0], s[1], s[2], s[3]);
                            case 5:
                                return new i(s[0], s[1], s[2], s[3], s[4]);
                            case 6:
                                return new i(s[0], s[1], s[2], s[3], s[4], s[5]);
                            case 7:
                                return new i(s[0], s[1], s[2], s[3], s[4], s[5], s[6])
                        }
                        var c = Ms(i.prototype),
                            l = i.apply(c, s);
                        return He(l) ? l : c
                    }
                }

                function Dm(i, s, c) {
                    var l = po(i);

                    function w() {
                        for (var I = arguments.length, q = H(I), $ = I, F = Rs(w); $--;) q[$] = arguments[$];
                        var J = I < 3 && q[0] !== F && q[I - 1] !== F ? [] : Sn(q, F);
                        if (I -= J.length, I < c) return hf(i, s, Da, w.placeholder, e, q, J, e, e, c - I);
                        var Y = this && this !== ge && this instanceof w ? l : i;
                        return sr(Y, this, q)
                    }
                    return w
                }

                function sf(i) {
                    return function(s, c, l) {
                        var w = Ue(s);
                        if (!Rr(s)) {
                            var I = Pt(c, 3);
                            s = or(s), c = function($) {
                                return I(w[$], $, w)
                            }
                        }
                        var q = i(s, c, l);
                        return q > -1 ? w[I ? s[q] : q] : e
                    }
                }

                function of (i) {
                    return hn(function(s) {
                        var c = s.length,
                            l = c,
                            w = ai.prototype.thru;
                        for (i && s.reverse(); l--;) {
                            var I = s[l];
                            if (typeof I != "function") throw new oi(h);
                            if (w && !q && ka(I) == "wrapper") var q = new ai([], !0)
                        }
                        for (l = q ? l : c; ++l < c;) {
                            I = s[l];
                            var $ = ka(I),
                                F = $ == "wrapper" ? Eh(I) : e;
                            F && Ph(F[0]) && F[1] == (it | ut | st | mt) && !F[4].length && F[9] == 1 ? q = q[ka(F[0])].apply(q, F[3]) : q = I.length == 1 && Ph(I) ? q[$]() : q.thru(I)
                        }
                        return function() {
                            var J = arguments,
                                Y = J[0];
                            if (q && J.length == 1 && Jt(Y)) return q.plant(Y).value();
                            for (var tt = 0, ct = c ? s[tt].apply(this, J) : Y; ++tt < c;) ct = s[tt].call(this, ct);
                            return ct
                        }
                    })
                }

                function Da(i, s, c, l, w, I, q, $, F, J) {
                    var Y = s & it,
                        tt = s & Q,
                        ct = s & et,
                        yt = s & (ut | ft),
                        Ct = s & Zt,
                        re = ct ? e : po(i);

                    function Nt() {
                        for (var ce = arguments.length, me = H(ce), Qr = ce; Qr--;) me[Qr] = arguments[Qr];
                        if (yt) var Er = Rs(Nt),
                            Wr = Vg(me, Er);
                        if (l && (me = Zl(me, l, w, yt)), I && (me = tf(me, I, q, yt)), ce -= Wr, yt && ce < J) {
                            var We = Sn(me, Er);
                            return hf(i, s, Da, Nt.placeholder, c, me, We, $, F, J - ce)
                        }
                        var Si = tt ? c : this,
                            dn = ct ? Si[i] : i;
                        return ce = me.length, $ ? me = tv(me, $) : Ct && ce > 1 && me.reverse(), Y && F < ce && (me.length = F), this && this !== ge && this instanceof Nt && (dn = re || po(dn)), dn.apply(Si, me)
                    }
                    return Nt
                }

                function af(i, s) {
                    return function(c, l) {
                        return cm(c, i, s(l), {})
                    }
                }

                function qa(i, s) {
                    return function(c, l) {
                        var w;
                        if (c === e && l === e) return s;
                        if (c !== e && (w = c), l !== e) {
                            if (w === e) return l;
                            typeof c == "string" || typeof l == "string" ? (c = Vr(c), l = Vr(l)) : (c = Kl(c), l = Kl(l)), w = i(c, l)
                        }
                        return w
                    }
                }

                function wh(i) {
                    return hn(function(s) {
                        return s = je(s, Kr(Pt())), ie(function(c) {
                            var l = this;
                            return i(s, function(w) {
                                return sr(w, l, c)
                            })
                        })
                    })
                }

                function Ba(i, s) {
                    s = s === e ? " " : Vr(s);
                    var c = s.length;
                    if (c < 2) return c ? fh(s, i) : s;
                    var l = fh(s, Aa(i / Es(s)));
                    return As(s) ? Nn(Ai(l), 0, i).join("") : l.slice(0, i)
                }

                function qm(i, s, c, l) {
                    var w = s & Q,
                        I = po(i);

                    function q() {
                        for (var $ = -1, F = arguments.length, J = -1, Y = l.length, tt = H(Y + F), ct = this && this !== ge && this instanceof q ? I : i; ++J < Y;) tt[J] = l[J];
                        for (; F--;) tt[J++] = arguments[++$];
                        return sr(ct, w ? c : this, tt)
                    }
                    return q
                }

                function cf(i) {
                    return function(s, c, l) {
                        return l && typeof l != "number" && Ar(s, c, l) && (c = l = e), s = fn(s), c === e ? (c = s, s = 0) : c = fn(c), l = l === e ? s < c ? 1 : -1 : fn(l), bm(s, c, l, i)
                    }
                }

                function Ua(i) {
                    return function(s, c) {
                        return typeof s == "string" && typeof c == "string" || (s = li(s), c = li(c)), i(s, c)
                    }
                }

                function hf(i, s, c, l, w, I, q, $, F, J) {
                    var Y = s & ut,
                        tt = Y ? q : e,
                        ct = Y ? e : q,
                        yt = Y ? I : e,
                        Ct = Y ? e : I;
                    s |= Y ? st : ot, s &= ~(Y ? ot : st), s & at || (s &= ~(Q | et));
                    var re = [i, s, w, yt, tt, Ct, ct, $, F, J],
                        Nt = c.apply(e, re);
                    return Ph(i) && _f(Nt, re), Nt.placeholder = l, Af(Nt, i, s)
                }

                function bh(i) {
                    var s = tr[i];
                    return function(c, l) {
                        if (c = li(c), l = l == null ? 0 : gr(Xt(l), 292), l && _l(c)) {
                            var w = (Ie(c) + "e").split("e"),
                                I = s(w[0] + "e" + (+w[1] + l));
                            return w = (Ie(I) + "e").split("e"), +(w[0] + "e" + (+w[1] - l))
                        }
                        return s(c)
                    }
                }
                var Bm = xs && 1 / fa(new xs([, -0]))[1] == C ? function(i) {
                    return new xs(i)
                } : zh;

                function uf(i) {
                    return function(s) {
                        var c = mr(s);
                        return c == Z ? Jc(s) : c == ne ? Zg(s) : Kg(s, i(s))
                    }
                }

                function cn(i, s, c, l, w, I, q, $) {
                    var F = s & et;
                    if (!F && typeof i != "function") throw new oi(h);
                    var J = l ? l.length : 0;
                    if (J || (s &= ~(st | ot), l = w = e), q = q === e ? q : er(Xt(q), 0), $ = $ === e ? $ : Xt($), J -= w ? w.length : 0, s & ot) {
                        var Y = l,
                            tt = w;
                        l = w = e
                    }
                    var ct = F ? e : Eh(i),
                        yt = [i, s, c, l, w, Y, tt, I, q, $];
                    if (ct && Ym(yt, ct), i = yt[0], s = yt[1], c = yt[2], l = yt[3], w = yt[4], $ = yt[9] = yt[9] === e ? F ? 0 : i.length : er(yt[9] - J, 0), !$ && s & (ut | ft) && (s &= ~(ut | ft)), !s || s == Q) var Ct = Tm(i, s, c);
                    else s == ut || s == ft ? Ct = Dm(i, s, $) : (s == st || s == (Q | st)) && !w.length ? Ct = qm(i, s, c, l) : Ct = Da.apply(e, yt);
                    var re = ct ? Fl : _f;
                    return Af(re(Ct, yt), i, s)
                }

                function lf(i, s, c, l) {
                    return i === e || Ii(i, Ss[c]) && !Ce.call(l, c) ? s : i
                }

                function ff(i, s, c, l, w, I) {
                    return He(i) && He(s) && (I.set(s, i), Na(i, s, e, ff, I), I.delete(s)), i
                }

                function Um(i) {
                    return vo(i) ? e : i
                }

                function df(i, s, c, l, w, I) {
                    var q = c & L,
                        $ = i.length,
                        F = s.length;
                    if ($ != F && !(q && F > $)) return !1;
                    var J = I.get(i),
                        Y = I.get(s);
                    if (J && Y) return J == s && Y == i;
                    var tt = -1,
                        ct = !0,
                        yt = c & K ? new Zn : e;
                    for (I.set(i, s), I.set(s, i); ++tt < $;) {
                        var Ct = i[tt],
                            re = s[tt];
                        if (l) var Nt = q ? l(re, Ct, tt, s, i, I) : l(Ct, re, tt, i, s, I);
                        if (Nt !== e) {
                            if (Nt) continue;
                            ct = !1;
                            break
                        }
                        if (yt) {
                            if (!Hc(s, function(ce, me) {
                                    if (!ro(yt, me) && (Ct === ce || w(Ct, ce, c, l, I))) return yt.push(me)
                                })) {
                                ct = !1;
                                break
                            }
                        } else if (!(Ct === re || w(Ct, re, c, l, I))) {
                            ct = !1;
                            break
                        }
                    }
                    return I.delete(i), I.delete(s), ct
                }

                function km(i, s, c, l, w, I, q) {
                    switch (c) {
                        case At:
                            if (i.byteLength != s.byteLength || i.byteOffset != s.byteOffset) return !1;
                            i = i.buffer, s = s.buffer;
                        case te:
                            return !(i.byteLength != s.byteLength || !I(new ya(i), new ya(s)));
                        case D:
                        case U:
                        case wt:
                            return Ii(+i, +s);
                        case N:
                            return i.name == s.name && i.message == s.message;
                        case Rt:
                        case It:
                            return i == s + "";
                        case Z:
                            var $ = Jc;
                        case ne:
                            var F = l & L;
                            if ($ || ($ = fa), i.size != s.size && !F) return !1;
                            var J = q.get(i);
                            if (J) return J == s;
                            l |= K, q.set(i, s);
                            var Y = df($(i), $(s), l, w, I, q);
                            return q.delete(i), Y;
                        case St:
                            if (ao) return ao.call(i) == ao.call(s)
                    }
                    return !1
                }

                function Lm(i, s, c, l, w, I) {
                    var q = c & L,
                        $ = _h(i),
                        F = $.length,
                        J = _h(s),
                        Y = J.length;
                    if (F != Y && !q) return !1;
                    for (var tt = F; tt--;) {
                        var ct = $[tt];
                        if (!(q ? ct in s : Ce.call(s, ct))) return !1
                    }
                    var yt = I.get(i),
                        Ct = I.get(s);
                    if (yt && Ct) return yt == s && Ct == i;
                    var re = !0;
                    I.set(i, s), I.set(s, i);
                    for (var Nt = q; ++tt < F;) {
                        ct = $[tt];
                        var ce = i[ct],
                            me = s[ct];
                        if (l) var Qr = q ? l(me, ce, ct, s, i, I) : l(ce, me, ct, i, s, I);
                        if (!(Qr === e ? ce === me || w(ce, me, c, l, I) : Qr)) {
                            re = !1;
                            break
                        }
                        Nt || (Nt = ct == "constructor")
                    }
                    if (re && !Nt) {
                        var Er = i.constructor,
                            Wr = s.constructor;
                        Er != Wr && "constructor" in i && "constructor" in s && !(typeof Er == "function" && Er instanceof Er && typeof Wr == "function" && Wr instanceof Wr) && (re = !1)
                    }
                    return I.delete(i), I.delete(s), re
                }

                function hn(i) {
                    return Ch(wf(i, e, Mf), i + "")
                }

                function _h(i) {
                    return Ol(i, or, Sh)
                }

                function Ah(i) {
                    return Ol(i, Or, pf)
                }
                var Eh = Ia ? function(i) {
                    return Ia.get(i)
                } : zh;

                function ka(i) {
                    for (var s = i.name + "", c = Ps[s], l = Ce.call(Ps, s) ? c.length : 0; l--;) {
                        var w = c[l],
                            I = w.func;
                        if (I == null || I == i) return w.name
                    }
                    return s
                }

                function Rs(i) {
                    var s = Ce.call(A, "placeholder") ? A : i;
                    return s.placeholder
                }

                function Pt() {
                    var i = A.iteratee || $h;
                    return i = i === $h ? ql : i, arguments.length ? i(arguments[0], arguments[1]) : i
                }

                function La(i, s) {
                    var c = i.__data__;
                    return Gm(s) ? c[typeof s == "string" ? "string" : "hash"] : c.map
                }

                function Ih(i) {
                    for (var s = or(i), c = s.length; c--;) {
                        var l = s[c],
                            w = i[l];
                        s[c] = [l, w, vf(w)]
                    }
                    return s
                }

                function rs(i, s) {
                    var c = Jg(i, s);
                    return Dl(c) ? c : e
                }

                function $m(i) {
                    var s = Ce.call(i, Yn),
                        c = i[Yn];
                    try {
                        i[Yn] = e;
                        var l = !0
                    } catch {}
                    var w = ma.call(i);
                    return l && (s ? i[Yn] = c : delete i[Yn]), w
                }
                var Sh = Xc ? function(i) {
                        return i == null ? [] : (i = Ue(i), En(Xc(i), function(s) {
                            return wl.call(i, s)
                        }))
                    } : Fh,
                    pf = Xc ? function(i) {
                        for (var s = []; i;) In(s, Sh(i)), i = wa(i);
                        return s
                    } : Fh,
                    mr = _r;
                (Zc && mr(new Zc(new ArrayBuffer(1))) != At || no && mr(new no) != Z || th && mr(th.resolve()) != Re || xs && mr(new xs) != ne || so && mr(new so) != _t) && (mr = function(i) {
                    var s = _r(i),
                        c = s == vt ? i.constructor : e,
                        l = c ? is(c) : "";
                    if (l) switch (l) {
                        case A1:
                            return At;
                        case E1:
                            return Z;
                        case I1:
                            return Re;
                        case S1:
                            return ne;
                        case x1:
                            return _t
                    }
                    return s
                });

                function jm(i, s, c) {
                    for (var l = -1, w = c.length; ++l < w;) {
                        var I = c[l],
                            q = I.size;
                        switch (I.type) {
                            case "drop":
                                i += q;
                                break;
                            case "dropRight":
                                s -= q;
                                break;
                            case "take":
                                s = gr(s, i + q);
                                break;
                            case "takeRight":
                                i = er(i, s - q);
                                break
                        }
                    }
                    return {
                        start: i,
                        end: s
                    }
                }

                function zm(i) {
                    var s = i.match(Et);
                    return s ? s[1].split(Oe) : []
                }

                function gf(i, s, c) {
                    s = Cn(s, i);
                    for (var l = -1, w = s.length, I = !1; ++l < w;) {
                        var q = zi(s[l]);
                        if (!(I = i != null && c(i, q))) break;
                        i = i[q]
                    }
                    return I || ++l != w ? I : (w = i == null ? 0 : i.length, !!w && Va(w) && un(q, w) && (Jt(i) || ns(i)))
                }

                function Fm(i) {
                    var s = i.length,
                        c = new i.constructor(s);
                    return s && typeof i[0] == "string" && Ce.call(i, "index") && (c.index = i.index, c.input = i.input), c
                }

                function mf(i) {
                    return typeof i.constructor == "function" && !go(i) ? Ms(wa(i)) : {}
                }

                function Hm(i, s, c) {
                    var l = i.constructor;
                    switch (s) {
                        case te:
                            return yh(i);
                        case D:
                        case U:
                            return new l(+i);
                        case At:
                            return Pm(i, c);
                        case Dt:
                        case ae:
                        case $t:
                        case Kt:
                        case ke:
                        case Qt:
                        case Vt:
                        case ze:
                        case ee:
                            return Yl(i, c);
                        case Z:
                            return new l;
                        case wt:
                        case It:
                            return new l(i);
                        case Rt:
                            return Mm(i);
                        case ne:
                            return new l;
                        case St:
                            return Cm(i)
                    }
                }

                function Km(i, s) {
                    var c = s.length;
                    if (!c) return i;
                    var l = c - 1;
                    return s[l] = (c > 1 ? "& " : "") + s[l], s = s.join(c > 2 ? ", " : " "), i.replace(kt, `{
/* [wrapped with ` + s + `] */
`)
                }

                function Vm(i) {
                    return Jt(i) || ns(i) || !!(bl && i && i[bl])
                }

                function un(i, s) {
                    var c = typeof i;
                    return s = s ? ? R, !!s && (c == "number" || c != "symbol" && ii.test(i)) && i > -1 && i % 1 == 0 && i < s
                }

                function Ar(i, s, c) {
                    if (!He(c)) return !1;
                    var l = typeof s;
                    return (l == "number" ? Rr(c) && un(s, c.length) : l == "string" && s in c) ? Ii(c[s], i) : !1
                }

                function xh(i, s) {
                    if (Jt(i)) return !1;
                    var c = typeof i;
                    return c == "number" || c == "symbol" || c == "boolean" || i == null || Gr(i) ? !0 : jt.test(i) || !we.test(i) || s != null && i in Ue(s)
                }

                function Gm(i) {
                    var s = typeof i;
                    return s == "string" || s == "number" || s == "symbol" || s == "boolean" ? i !== "__proto__" : i === null
                }

                function Ph(i) {
                    var s = ka(i),
                        c = A[s];
                    if (typeof c != "function" || !(s in le.prototype)) return !1;
                    if (i === c) return !0;
                    var l = Eh(c);
                    return !!l && i === l[0]
                }

                function Qm(i) {
                    return !!ml && ml in i
                }
                var Wm = pa ? ln : Hh;

                function go(i) {
                    var s = i && i.constructor,
                        c = typeof s == "function" && s.prototype || Ss;
                    return i === c
                }

                function vf(i) {
                    return i === i && !He(i)
                }

                function yf(i, s) {
                    return function(c) {
                        return c == null ? !1 : c[i] === s && (s !== e || i in Ue(c))
                    }
                }

                function Jm(i) {
                    var s = Ha(i, function(l) {
                            return c.size === m && c.clear(), l
                        }),
                        c = s.cache;
                    return s
                }

                function Ym(i, s) {
                    var c = i[1],
                        l = s[1],
                        w = c | l,
                        I = w < (Q | et | it),
                        q = l == it && c == ut || l == it && c == mt && i[7].length <= s[8] || l == (it | mt) && s[7].length <= s[8] && c == ut;
                    if (!(I || q)) return i;
                    l & Q && (i[2] = s[2], w |= c & Q ? 0 : at);
                    var $ = s[3];
                    if ($) {
                        var F = i[3];
                        i[3] = F ? Zl(F, $, s[4]) : $, i[4] = F ? Sn(i[3], _) : s[4]
                    }
                    return $ = s[5], $ && (F = i[5], i[5] = F ? tf(F, $, s[6]) : $, i[6] = F ? Sn(i[5], _) : s[6]), $ = s[7], $ && (i[7] = $), l & it && (i[8] = i[8] == null ? s[8] : gr(i[8], s[8])), i[9] == null && (i[9] = s[9]), i[0] = s[0], i[1] = w, i
                }

                function Xm(i) {
                    var s = [];
                    if (i != null)
                        for (var c in Ue(i)) s.push(c);
                    return s
                }

                function Zm(i) {
                    return ma.call(i)
                }

                function wf(i, s, c) {
                    return s = er(s === e ? i.length - 1 : s, 0),
                        function() {
                            for (var l = arguments, w = -1, I = er(l.length - s, 0), q = H(I); ++w < I;) q[w] = l[s + w];
                            w = -1;
                            for (var $ = H(s + 1); ++w < s;) $[w] = l[w];
                            return $[s] = c(q), sr(i, this, $)
                        }
                }

                function bf(i, s) {
                    return s.length < 2 ? i : es(i, hi(s, 0, -1))
                }

                function tv(i, s) {
                    for (var c = i.length, l = gr(s.length, c), w = Nr(i); l--;) {
                        var I = s[l];
                        i[l] = un(I, c) ? w[I] : e
                    }
                    return i
                }

                function Mh(i, s) {
                    if (!(s === "constructor" && typeof i[s] == "function") && s != "__proto__") return i[s]
                }
                var _f = Ef(Fl),
                    mo = g1 || function(i, s) {
                        return ge.setTimeout(i, s)
                    },
                    Ch = Ef(Em);

                function Af(i, s, c) {
                    var l = s + "";
                    return Ch(i, Km(l, ev(zm(l), c)))
                }

                function Ef(i) {
                    var s = 0,
                        c = 0;
                    return function() {
                        var l = w1(),
                            w = u - (l - c);
                        if (c = l, w > 0) {
                            if (++s >= ve) return arguments[0]
                        } else s = 0;
                        return i.apply(e, arguments)
                    }
                }

                function $a(i, s) {
                    var c = -1,
                        l = i.length,
                        w = l - 1;
                    for (s = s === e ? l : s; ++c < s;) {
                        var I = lh(c, w),
                            q = i[I];
                        i[I] = i[c], i[c] = q
                    }
                    return i.length = s, i
                }
                var If = Jm(function(i) {
                    var s = [];
                    return i.charCodeAt(0) === 46 && s.push(""), i.replace(zt, function(c, l, w, I) {
                        s.push(w ? I.replace(bi, "$1") : l || c)
                    }), s
                });

                function zi(i) {
                    if (typeof i == "string" || Gr(i)) return i;
                    var s = i + "";
                    return s == "0" && 1 / i == -C ? "-0" : s
                }

                function is(i) {
                    if (i != null) {
                        try {
                            return ga.call(i)
                        } catch {}
                        try {
                            return i + ""
                        } catch {}
                    }
                    return ""
                }

                function ev(i, s) {
                    return si(gt, function(c) {
                        var l = "_." + c[0];
                        s & c[1] && !ua(i, l) && i.push(l)
                    }), i.sort()
                }

                function Sf(i) {
                    if (i instanceof le) return i.clone();
                    var s = new ai(i.__wrapped__, i.__chain__);
                    return s.__actions__ = Nr(i.__actions__), s.__index__ = i.__index__, s.__values__ = i.__values__, s
                }

                function rv(i, s, c) {
                    (c ? Ar(i, s, c) : s === e) ? s = 1: s = er(Xt(s), 0);
                    var l = i == null ? 0 : i.length;
                    if (!l || s < 1) return [];
                    for (var w = 0, I = 0, q = H(Aa(l / s)); w < l;) q[I++] = hi(i, w, w += s);
                    return q
                }

                function iv(i) {
                    for (var s = -1, c = i == null ? 0 : i.length, l = 0, w = []; ++s < c;) {
                        var I = i[s];
                        I && (w[l++] = I)
                    }
                    return w
                }

                function nv() {
                    var i = arguments.length;
                    if (!i) return [];
                    for (var s = H(i - 1), c = arguments[0], l = i; l--;) s[l - 1] = arguments[l];
                    return In(Jt(c) ? Nr(c) : [c], hr(s, 1))
                }
                var sv = ie(function(i, s) {
                        return Qe(i) ? ho(i, hr(s, 1, Qe, !0)) : []
                    }),
                    ov = ie(function(i, s) {
                        var c = ui(s);
                        return Qe(c) && (c = e), Qe(i) ? ho(i, hr(s, 1, Qe, !0), Pt(c, 2)) : []
                    }),
                    av = ie(function(i, s) {
                        var c = ui(s);
                        return Qe(c) && (c = e), Qe(i) ? ho(i, hr(s, 1, Qe, !0), e, c) : []
                    });

                function cv(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    return l ? (s = c || s === e ? 1 : Xt(s), hi(i, s < 0 ? 0 : s, l)) : []
                }

                function hv(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    return l ? (s = c || s === e ? 1 : Xt(s), s = l - s, hi(i, 0, s < 0 ? 0 : s)) : []
                }

                function uv(i, s) {
                    return i && i.length ? Oa(i, Pt(s, 3), !0, !0) : []
                }

                function lv(i, s) {
                    return i && i.length ? Oa(i, Pt(s, 3), !0) : []
                }

                function fv(i, s, c, l) {
                    var w = i == null ? 0 : i.length;
                    return w ? (c && typeof c != "number" && Ar(i, s, c) && (c = 0, l = w), nm(i, s, c, l)) : []
                }

                function xf(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    if (!l) return -1;
                    var w = c == null ? 0 : Xt(c);
                    return w < 0 && (w = er(l + w, 0)), la(i, Pt(s, 3), w)
                }

                function Pf(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    if (!l) return -1;
                    var w = l - 1;
                    return c !== e && (w = Xt(c), w = c < 0 ? er(l + w, 0) : gr(w, l - 1)), la(i, Pt(s, 3), w, !0)
                }

                function Mf(i) {
                    var s = i == null ? 0 : i.length;
                    return s ? hr(i, 1) : []
                }

                function dv(i) {
                    var s = i == null ? 0 : i.length;
                    return s ? hr(i, C) : []
                }

                function pv(i, s) {
                    var c = i == null ? 0 : i.length;
                    return c ? (s = s === e ? 1 : Xt(s), hr(i, s)) : []
                }

                function gv(i) {
                    for (var s = -1, c = i == null ? 0 : i.length, l = {}; ++s < c;) {
                        var w = i[s];
                        l[w[0]] = w[1]
                    }
                    return l
                }

                function Cf(i) {
                    return i && i.length ? i[0] : e
                }

                function mv(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    if (!l) return -1;
                    var w = c == null ? 0 : Xt(c);
                    return w < 0 && (w = er(l + w, 0)), _s(i, s, w)
                }

                function vv(i) {
                    var s = i == null ? 0 : i.length;
                    return s ? hi(i, 0, -1) : []
                }
                var yv = ie(function(i) {
                        var s = je(i, mh);
                        return s.length && s[0] === i[0] ? oh(s) : []
                    }),
                    wv = ie(function(i) {
                        var s = ui(i),
                            c = je(i, mh);
                        return s === ui(c) ? s = e : c.pop(), c.length && c[0] === i[0] ? oh(c, Pt(s, 2)) : []
                    }),
                    bv = ie(function(i) {
                        var s = ui(i),
                            c = je(i, mh);
                        return s = typeof s == "function" ? s : e, s && c.pop(), c.length && c[0] === i[0] ? oh(c, e, s) : []
                    });

                function _v(i, s) {
                    return i == null ? "" : v1.call(i, s)
                }

                function ui(i) {
                    var s = i == null ? 0 : i.length;
                    return s ? i[s - 1] : e
                }

                function Av(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    if (!l) return -1;
                    var w = l;
                    return c !== e && (w = Xt(c), w = w < 0 ? er(l + w, 0) : gr(w, l - 1)), s === s ? e1(i, s, w) : la(i, cl, w, !0)
                }

                function Ev(i, s) {
                    return i && i.length ? Ll(i, Xt(s)) : e
                }
                var Iv = ie(Nf);

                function Nf(i, s) {
                    return i && i.length && s && s.length ? uh(i, s) : i
                }

                function Sv(i, s, c) {
                    return i && i.length && s && s.length ? uh(i, s, Pt(c, 2)) : i
                }

                function xv(i, s, c) {
                    return i && i.length && s && s.length ? uh(i, s, e, c) : i
                }
                var Pv = hn(function(i, s) {
                    var c = i == null ? 0 : i.length,
                        l = rh(i, s);
                    return zl(i, je(s, function(w) {
                        return un(w, c) ? +w : w
                    }).sort(Xl)), l
                });

                function Mv(i, s) {
                    var c = [];
                    if (!(i && i.length)) return c;
                    var l = -1,
                        w = [],
                        I = i.length;
                    for (s = Pt(s, 3); ++l < I;) {
                        var q = i[l];
                        s(q, l, i) && (c.push(q), w.push(l))
                    }
                    return zl(i, w), c
                }

                function Nh(i) {
                    return i == null ? i : _1.call(i)
                }

                function Cv(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    return l ? (c && typeof c != "number" && Ar(i, s, c) ? (s = 0, c = l) : (s = s == null ? 0 : Xt(s), c = c === e ? l : Xt(c)), hi(i, s, c)) : []
                }

                function Nv(i, s) {
                    return Ra(i, s)
                }

                function Rv(i, s, c) {
                    return dh(i, s, Pt(c, 2))
                }

                function Ov(i, s) {
                    var c = i == null ? 0 : i.length;
                    if (c) {
                        var l = Ra(i, s);
                        if (l < c && Ii(i[l], s)) return l
                    }
                    return -1
                }

                function Tv(i, s) {
                    return Ra(i, s, !0)
                }

                function Dv(i, s, c) {
                    return dh(i, s, Pt(c, 2), !0)
                }

                function qv(i, s) {
                    var c = i == null ? 0 : i.length;
                    if (c) {
                        var l = Ra(i, s, !0) - 1;
                        if (Ii(i[l], s)) return l
                    }
                    return -1
                }

                function Bv(i) {
                    return i && i.length ? Hl(i) : []
                }

                function Uv(i, s) {
                    return i && i.length ? Hl(i, Pt(s, 2)) : []
                }

                function kv(i) {
                    var s = i == null ? 0 : i.length;
                    return s ? hi(i, 1, s) : []
                }

                function Lv(i, s, c) {
                    return i && i.length ? (s = c || s === e ? 1 : Xt(s), hi(i, 0, s < 0 ? 0 : s)) : []
                }

                function $v(i, s, c) {
                    var l = i == null ? 0 : i.length;
                    return l ? (s = c || s === e ? 1 : Xt(s), s = l - s, hi(i, s < 0 ? 0 : s, l)) : []
                }

                function jv(i, s) {
                    return i && i.length ? Oa(i, Pt(s, 3), !1, !0) : []
                }

                function zv(i, s) {
                    return i && i.length ? Oa(i, Pt(s, 3)) : []
                }
                var Fv = ie(function(i) {
                        return Mn(hr(i, 1, Qe, !0))
                    }),
                    Hv = ie(function(i) {
                        var s = ui(i);
                        return Qe(s) && (s = e), Mn(hr(i, 1, Qe, !0), Pt(s, 2))
                    }),
                    Kv = ie(function(i) {
                        var s = ui(i);
                        return s = typeof s == "function" ? s : e, Mn(hr(i, 1, Qe, !0), e, s)
                    });

                function Vv(i) {
                    return i && i.length ? Mn(i) : []
                }

                function Gv(i, s) {
                    return i && i.length ? Mn(i, Pt(s, 2)) : []
                }

                function Qv(i, s) {
                    return s = typeof s == "function" ? s : e, i && i.length ? Mn(i, e, s) : []
                }

                function Rh(i) {
                    if (!(i && i.length)) return [];
                    var s = 0;
                    return i = En(i, function(c) {
                        if (Qe(c)) return s = er(c.length, s), !0
                    }), Qc(s, function(c) {
                        return je(i, Kc(c))
                    })
                }

                function Rf(i, s) {
                    if (!(i && i.length)) return [];
                    var c = Rh(i);
                    return s == null ? c : je(c, function(l) {
                        return sr(s, e, l)
                    })
                }
                var Wv = ie(function(i, s) {
                        return Qe(i) ? ho(i, s) : []
                    }),
                    Jv = ie(function(i) {
                        return gh(En(i, Qe))
                    }),
                    Yv = ie(function(i) {
                        var s = ui(i);
                        return Qe(s) && (s = e), gh(En(i, Qe), Pt(s, 2))
                    }),
                    Xv = ie(function(i) {
                        var s = ui(i);
                        return s = typeof s == "function" ? s : e, gh(En(i, Qe), e, s)
                    }),
                    Zv = ie(Rh);

                function ty(i, s) {
                    return Ql(i || [], s || [], co)
                }

                function ey(i, s) {
                    return Ql(i || [], s || [], fo)
                }
                var ry = ie(function(i) {
                    var s = i.length,
                        c = s > 1 ? i[s - 1] : e;
                    return c = typeof c == "function" ? (i.pop(), c) : e, Rf(i, c)
                });

                function Of(i) {
                    var s = A(i);
                    return s.__chain__ = !0, s
                }

                function iy(i, s) {
                    return s(i), i
                }

                function ja(i, s) {
                    return s(i)
                }
                var ny = hn(function(i) {
                    var s = i.length,
                        c = s ? i[0] : 0,
                        l = this.__wrapped__,
                        w = function(I) {
                            return rh(I, i)
                        };
                    return s > 1 || this.__actions__.length || !(l instanceof le) || !un(c) ? this.thru(w) : (l = l.slice(c, +c + (s ? 1 : 0)), l.__actions__.push({
                        func: ja,
                        args: [w],
                        thisArg: e
                    }), new ai(l, this.__chain__).thru(function(I) {
                        return s && !I.length && I.push(e), I
                    }))
                });

                function sy() {
                    return Of(this)
                }

                function oy() {
                    return new ai(this.value(), this.__chain__)
                }

                function ay() {
                    this.__values__ === e && (this.__values__ = Vf(this.value()));
                    var i = this.__index__ >= this.__values__.length,
                        s = i ? e : this.__values__[this.__index__++];
                    return {
                        done: i,
                        value: s
                    }
                }

                function cy() {
                    return this
                }

                function hy(i) {
                    for (var s, c = this; c instanceof xa;) {
                        var l = Sf(c);
                        l.__index__ = 0, l.__values__ = e, s ? w.__wrapped__ = l : s = l;
                        var w = l;
                        c = c.__wrapped__
                    }
                    return w.__wrapped__ = i, s
                }

                function uy() {
                    var i = this.__wrapped__;
                    if (i instanceof le) {
                        var s = i;
                        return this.__actions__.length && (s = new le(this)), s = s.reverse(), s.__actions__.push({
                            func: ja,
                            args: [Nh],
                            thisArg: e
                        }), new ai(s, this.__chain__)
                    }
                    return this.thru(Nh)
                }

                function ly() {
                    return Gl(this.__wrapped__, this.__actions__)
                }
                var fy = Ta(function(i, s, c) {
                    Ce.call(i, c) ? ++i[c] : an(i, c, 1)
                });

                function dy(i, s, c) {
                    var l = Jt(i) ? ol : im;
                    return c && Ar(i, s, c) && (s = e), l(i, Pt(s, 3))
                }

                function py(i, s) {
                    var c = Jt(i) ? En : Nl;
                    return c(i, Pt(s, 3))
                }
                var gy = sf(xf),
                    my = sf(Pf);

                function vy(i, s) {
                    return hr(za(i, s), 1)
                }

                function yy(i, s) {
                    return hr(za(i, s), C)
                }

                function wy(i, s, c) {
                    return c = c === e ? 1 : Xt(c), hr(za(i, s), c)
                }

                function Tf(i, s) {
                    var c = Jt(i) ? si : Pn;
                    return c(i, Pt(s, 3))
                }

                function Df(i, s) {
                    var c = Jt(i) ? kg : Cl;
                    return c(i, Pt(s, 3))
                }
                var by = Ta(function(i, s, c) {
                    Ce.call(i, c) ? i[c].push(s) : an(i, c, [s])
                });

                function _y(i, s, c, l) {
                    i = Rr(i) ? i : Ts(i), c = c && !l ? Xt(c) : 0;
                    var w = i.length;
                    return c < 0 && (c = er(w + c, 0)), Ga(i) ? c <= w && i.indexOf(s, c) > -1 : !!w && _s(i, s, c) > -1
                }
                var Ay = ie(function(i, s, c) {
                        var l = -1,
                            w = typeof s == "function",
                            I = Rr(i) ? H(i.length) : [];
                        return Pn(i, function(q) {
                            I[++l] = w ? sr(s, q, c) : uo(q, s, c)
                        }), I
                    }),
                    Ey = Ta(function(i, s, c) {
                        an(i, c, s)
                    });

                function za(i, s) {
                    var c = Jt(i) ? je : Bl;
                    return c(i, Pt(s, 3))
                }

                function Iy(i, s, c, l) {
                    return i == null ? [] : (Jt(s) || (s = s == null ? [] : [s]), c = l ? e : c, Jt(c) || (c = c == null ? [] : [c]), $l(i, s, c))
                }
                var Sy = Ta(function(i, s, c) {
                    i[c ? 0 : 1].push(s)
                }, function() {
                    return [
                        [],
                        []
                    ]
                });

                function xy(i, s, c) {
                    var l = Jt(i) ? Fc : ul,
                        w = arguments.length < 3;
                    return l(i, Pt(s, 4), c, w, Pn)
                }

                function Py(i, s, c) {
                    var l = Jt(i) ? Lg : ul,
                        w = arguments.length < 3;
                    return l(i, Pt(s, 4), c, w, Cl)
                }

                function My(i, s) {
                    var c = Jt(i) ? En : Nl;
                    return c(i, Ka(Pt(s, 3)))
                }

                function Cy(i) {
                    var s = Jt(i) ? Sl : _m;
                    return s(i)
                }

                function Ny(i, s, c) {
                    (c ? Ar(i, s, c) : s === e) ? s = 1: s = Xt(s);
                    var l = Jt(i) ? X1 : Am;
                    return l(i, s)
                }

                function Ry(i) {
                    var s = Jt(i) ? Z1 : Im;
                    return s(i)
                }

                function Oy(i) {
                    if (i == null) return 0;
                    if (Rr(i)) return Ga(i) ? Es(i) : i.length;
                    var s = mr(i);
                    return s == Z || s == ne ? i.size : ch(i).length
                }

                function Ty(i, s, c) {
                    var l = Jt(i) ? Hc : Sm;
                    return c && Ar(i, s, c) && (s = e), l(i, Pt(s, 3))
                }
                var Dy = ie(function(i, s) {
                        if (i == null) return [];
                        var c = s.length;
                        return c > 1 && Ar(i, s[0], s[1]) ? s = [] : c > 2 && Ar(s[0], s[1], s[2]) && (s = [s[0]]), $l(i, hr(s, 1), [])
                    }),
                    Fa = p1 || function() {
                        return ge.Date.now()
                    };

                function qy(i, s) {
                    if (typeof s != "function") throw new oi(h);
                    return i = Xt(i),
                        function() {
                            if (--i < 1) return s.apply(this, arguments)
                        }
                }

                function qf(i, s, c) {
                    return s = c ? e : s, s = i && s == null ? i.length : s, cn(i, it, e, e, e, e, s)
                }

                function Bf(i, s) {
                    var c;
                    if (typeof s != "function") throw new oi(h);
                    return i = Xt(i),
                        function() {
                            return --i > 0 && (c = s.apply(this, arguments)), i <= 1 && (s = e), c
                        }
                }
                var Oh = ie(function(i, s, c) {
                        var l = Q;
                        if (c.length) {
                            var w = Sn(c, Rs(Oh));
                            l |= st
                        }
                        return cn(i, l, s, c, w)
                    }),
                    Uf = ie(function(i, s, c) {
                        var l = Q | et;
                        if (c.length) {
                            var w = Sn(c, Rs(Uf));
                            l |= st
                        }
                        return cn(s, l, i, c, w)
                    });

                function kf(i, s, c) {
                    s = c ? e : s;
                    var l = cn(i, ut, e, e, e, e, e, s);
                    return l.placeholder = kf.placeholder, l
                }

                function Lf(i, s, c) {
                    s = c ? e : s;
                    var l = cn(i, ft, e, e, e, e, e, s);
                    return l.placeholder = Lf.placeholder, l
                }

                function $f(i, s, c) {
                    var l, w, I, q, $, F, J = 0,
                        Y = !1,
                        tt = !1,
                        ct = !0;
                    if (typeof i != "function") throw new oi(h);
                    s = li(s) || 0, He(c) && (Y = !!c.leading, tt = "maxWait" in c, I = tt ? er(li(c.maxWait) || 0, s) : I, ct = "trailing" in c ? !!c.trailing : ct);

                    function yt(We) {
                        var Si = l,
                            dn = w;
                        return l = w = e, J = We, q = i.apply(dn, Si), q
                    }

                    function Ct(We) {
                        return J = We, $ = mo(ce, s), Y ? yt(We) : q
                    }

                    function re(We) {
                        var Si = We - F,
                            dn = We - J,
                            sd = s - Si;
                        return tt ? gr(sd, I - dn) : sd
                    }

                    function Nt(We) {
                        var Si = We - F,
                            dn = We - J;
                        return F === e || Si >= s || Si < 0 || tt && dn >= I
                    }

                    function ce() {
                        var We = Fa();
                        if (Nt(We)) return me(We);
                        $ = mo(ce, re(We))
                    }

                    function me(We) {
                        return $ = e, ct && l ? yt(We) : (l = w = e, q)
                    }

                    function Qr() {
                        $ !== e && Wl($), J = 0, l = F = w = $ = e
                    }

                    function Er() {
                        return $ === e ? q : me(Fa())
                    }

                    function Wr() {
                        var We = Fa(),
                            Si = Nt(We);
                        if (l = arguments, w = this, F = We, Si) {
                            if ($ === e) return Ct(F);
                            if (tt) return Wl($), $ = mo(ce, s), yt(F)
                        }
                        return $ === e && ($ = mo(ce, s)), q
                    }
                    return Wr.cancel = Qr, Wr.flush = Er, Wr
                }
                var By = ie(function(i, s) {
                        return Ml(i, 1, s)
                    }),
                    Uy = ie(function(i, s, c) {
                        return Ml(i, li(s) || 0, c)
                    });

                function ky(i) {
                    return cn(i, Zt)
                }

                function Ha(i, s) {
                    if (typeof i != "function" || s != null && typeof s != "function") throw new oi(h);
                    var c = function() {
                        var l = arguments,
                            w = s ? s.apply(this, l) : l[0],
                            I = c.cache;
                        if (I.has(w)) return I.get(w);
                        var q = i.apply(this, l);
                        return c.cache = I.set(w, q) || I, q
                    };
                    return c.cache = new(Ha.Cache || on), c
                }
                Ha.Cache = on;

                function Ka(i) {
                    if (typeof i != "function") throw new oi(h);
                    return function() {
                        var s = arguments;
                        switch (s.length) {
                            case 0:
                                return !i.call(this);
                            case 1:
                                return !i.call(this, s[0]);
                            case 2:
                                return !i.call(this, s[0], s[1]);
                            case 3:
                                return !i.call(this, s[0], s[1], s[2])
                        }
                        return !i.apply(this, s)
                    }
                }

                function Ly(i) {
                    return Bf(2, i)
                }
                var $y = xm(function(i, s) {
                        s = s.length == 1 && Jt(s[0]) ? je(s[0], Kr(Pt())) : je(hr(s, 1), Kr(Pt()));
                        var c = s.length;
                        return ie(function(l) {
                            for (var w = -1, I = gr(l.length, c); ++w < I;) l[w] = s[w].call(this, l[w]);
                            return sr(i, this, l)
                        })
                    }),
                    Th = ie(function(i, s) {
                        var c = Sn(s, Rs(Th));
                        return cn(i, st, e, s, c)
                    }),
                    jf = ie(function(i, s) {
                        var c = Sn(s, Rs(jf));
                        return cn(i, ot, e, s, c)
                    }),
                    jy = hn(function(i, s) {
                        return cn(i, mt, e, e, e, s)
                    });

                function zy(i, s) {
                    if (typeof i != "function") throw new oi(h);
                    return s = s === e ? s : Xt(s), ie(i, s)
                }

                function Fy(i, s) {
                    if (typeof i != "function") throw new oi(h);
                    return s = s == null ? 0 : er(Xt(s), 0), ie(function(c) {
                        var l = c[s],
                            w = Nn(c, 0, s);
                        return l && In(w, l), sr(i, this, w)
                    })
                }

                function Hy(i, s, c) {
                    var l = !0,
                        w = !0;
                    if (typeof i != "function") throw new oi(h);
                    return He(c) && (l = "leading" in c ? !!c.leading : l, w = "trailing" in c ? !!c.trailing : w), $f(i, s, {
                        leading: l,
                        maxWait: s,
                        trailing: w
                    })
                }

                function Ky(i) {
                    return qf(i, 1)
                }

                function Vy(i, s) {
                    return Th(vh(s), i)
                }

                function Gy() {
                    if (!arguments.length) return [];
                    var i = arguments[0];
                    return Jt(i) ? i : [i]
                }

                function Qy(i) {
                    return ci(i, k)
                }

                function Wy(i, s) {
                    return s = typeof s == "function" ? s : e, ci(i, k, s)
                }

                function Jy(i) {
                    return ci(i, S | k)
                }

                function Yy(i, s) {
                    return s = typeof s == "function" ? s : e, ci(i, S | k, s)
                }

                function Xy(i, s) {
                    return s == null || Pl(i, s, or(s))
                }

                function Ii(i, s) {
                    return i === s || i !== i && s !== s
                }
                var Zy = Ua(sh),
                    tw = Ua(function(i, s) {
                        return i >= s
                    }),
                    ns = Tl(function() {
                        return arguments
                    }()) ? Tl : function(i) {
                        return Ke(i) && Ce.call(i, "callee") && !wl.call(i, "callee")
                    },
                    Jt = H.isArray,
                    ew = br ? Kr(br) : hm;

                function Rr(i) {
                    return i != null && Va(i.length) && !ln(i)
                }

                function Qe(i) {
                    return Ke(i) && Rr(i)
                }

                function rw(i) {
                    return i === !0 || i === !1 || Ke(i) && _r(i) == D
                }
                var Rn = m1 || Hh,
                    iw = _i ? Kr(_i) : um;

                function nw(i) {
                    return Ke(i) && i.nodeType === 1 && !vo(i)
                }

                function sw(i) {
                    if (i == null) return !0;
                    if (Rr(i) && (Jt(i) || typeof i == "string" || typeof i.splice == "function" || Rn(i) || Os(i) || ns(i))) return !i.length;
                    var s = mr(i);
                    if (s == Z || s == ne) return !i.size;
                    if (go(i)) return !ch(i).length;
                    for (var c in i)
                        if (Ce.call(i, c)) return !1;
                    return !0
                }

                function ow(i, s) {
                    return lo(i, s)
                }

                function aw(i, s, c) {
                    c = typeof c == "function" ? c : e;
                    var l = c ? c(i, s) : e;
                    return l === e ? lo(i, s, e, c) : !!l
                }

                function Dh(i) {
                    if (!Ke(i)) return !1;
                    var s = _r(i);
                    return s == N || s == d || typeof i.message == "string" && typeof i.name == "string" && !vo(i)
                }

                function cw(i) {
                    return typeof i == "number" && _l(i)
                }

                function ln(i) {
                    if (!He(i)) return !1;
                    var s = _r(i);
                    return s == W || s == rt || s == O || s == Lt
                }

                function zf(i) {
                    return typeof i == "number" && i == Xt(i)
                }

                function Va(i) {
                    return typeof i == "number" && i > -1 && i % 1 == 0 && i <= R
                }

                function He(i) {
                    var s = typeof i;
                    return i != null && (s == "object" || s == "function")
                }

                function Ke(i) {
                    return i != null && typeof i == "object"
                }
                var Ff = ni ? Kr(ni) : fm;

                function hw(i, s) {
                    return i === s || ah(i, s, Ih(s))
                }

                function uw(i, s, c) {
                    return c = typeof c == "function" ? c : e, ah(i, s, Ih(s), c)
                }

                function lw(i) {
                    return Hf(i) && i != +i
                }

                function fw(i) {
                    if (Wm(i)) throw new Gt(a);
                    return Dl(i)
                }

                function dw(i) {
                    return i === null
                }

                function pw(i) {
                    return i == null
                }

                function Hf(i) {
                    return typeof i == "number" || Ke(i) && _r(i) == wt
                }

                function vo(i) {
                    if (!Ke(i) || _r(i) != vt) return !1;
                    var s = wa(i);
                    if (s === null) return !0;
                    var c = Ce.call(s, "constructor") && s.constructor;
                    return typeof c == "function" && c instanceof c && ga.call(c) == u1
                }
                var qh = Li ? Kr(Li) : dm;

                function gw(i) {
                    return zf(i) && i >= -R && i <= R
                }
                var Kf = eo ? Kr(eo) : pm;

                function Ga(i) {
                    return typeof i == "string" || !Jt(i) && Ke(i) && _r(i) == It
                }

                function Gr(i) {
                    return typeof i == "symbol" || Ke(i) && _r(i) == St
                }
                var Os = Jn ? Kr(Jn) : gm;

                function mw(i) {
                    return i === e
                }

                function vw(i) {
                    return Ke(i) && mr(i) == _t
                }

                function yw(i) {
                    return Ke(i) && _r(i) == xt
                }
                var ww = Ua(hh),
                    bw = Ua(function(i, s) {
                        return i <= s
                    });

                function Vf(i) {
                    if (!i) return [];
                    if (Rr(i)) return Ga(i) ? Ai(i) : Nr(i);
                    if (io && i[io]) return Xg(i[io]());
                    var s = mr(i),
                        c = s == Z ? Jc : s == ne ? fa : Ts;
                    return c(i)
                }

                function fn(i) {
                    if (!i) return i === 0 ? i : 0;
                    if (i = li(i), i === C || i === -C) {
                        var s = i < 0 ? -1 : 1;
                        return s * T
                    }
                    return i === i ? i : 0
                }

                function Xt(i) {
                    var s = fn(i),
                        c = s % 1;
                    return s === s ? c ? s - c : s : 0
                }

                function Gf(i) {
                    return i ? ts(Xt(i), 0, f) : 0
                }

                function li(i) {
                    if (typeof i == "number") return i;
                    if (Gr(i)) return E;
                    if (He(i)) {
                        var s = typeof i.valueOf == "function" ? i.valueOf() : i;
                        i = He(s) ? s + "" : s
                    }
                    if (typeof i != "string") return i === 0 ? i : +i;
                    i = ll(i);
                    var c = ti.test(i);
                    return c || ri.test(i) ? Wt(i.slice(2), c ? 2 : 8) : Zr.test(i) ? E : +i
                }

                function Qf(i) {
                    return ji(i, Or(i))
                }

                function _w(i) {
                    return i ? ts(Xt(i), -R, R) : i === 0 ? i : 0
                }

                function Ie(i) {
                    return i == null ? "" : Vr(i)
                }
                var Aw = Cs(function(i, s) {
                        if (go(s) || Rr(s)) {
                            ji(s, or(s), i);
                            return
                        }
                        for (var c in s) Ce.call(s, c) && co(i, c, s[c])
                    }),
                    Wf = Cs(function(i, s) {
                        ji(s, Or(s), i)
                    }),
                    Qa = Cs(function(i, s, c, l) {
                        ji(s, Or(s), i, l)
                    }),
                    Ew = Cs(function(i, s, c, l) {
                        ji(s, or(s), i, l)
                    }),
                    Iw = hn(rh);

                function Sw(i, s) {
                    var c = Ms(i);
                    return s == null ? c : xl(c, s)
                }
                var xw = ie(function(i, s) {
                        i = Ue(i);
                        var c = -1,
                            l = s.length,
                            w = l > 2 ? s[2] : e;
                        for (w && Ar(s[0], s[1], w) && (l = 1); ++c < l;)
                            for (var I = s[c], q = Or(I), $ = -1, F = q.length; ++$ < F;) {
                                var J = q[$],
                                    Y = i[J];
                                (Y === e || Ii(Y, Ss[J]) && !Ce.call(i, J)) && (i[J] = I[J])
                            }
                        return i
                    }),
                    Pw = ie(function(i) {
                        return i.push(e, ff), sr(Jf, e, i)
                    });

                function Mw(i, s) {
                    return al(i, Pt(s, 3), $i)
                }

                function Cw(i, s) {
                    return al(i, Pt(s, 3), nh)
                }

                function Nw(i, s) {
                    return i == null ? i : ih(i, Pt(s, 3), Or)
                }

                function Rw(i, s) {
                    return i == null ? i : Rl(i, Pt(s, 3), Or)
                }

                function Ow(i, s) {
                    return i && $i(i, Pt(s, 3))
                }

                function Tw(i, s) {
                    return i && nh(i, Pt(s, 3))
                }

                function Dw(i) {
                    return i == null ? [] : Ca(i, or(i))
                }

                function qw(i) {
                    return i == null ? [] : Ca(i, Or(i))
                }

                function Bh(i, s, c) {
                    var l = i == null ? e : es(i, s);
                    return l === e ? c : l
                }

                function Bw(i, s) {
                    return i != null && gf(i, s, sm)
                }

                function Uh(i, s) {
                    return i != null && gf(i, s, om)
                }
                var Uw = af(function(i, s, c) {
                        s != null && typeof s.toString != "function" && (s = ma.call(s)), i[s] = c
                    }, Lh(Tr)),
                    kw = af(function(i, s, c) {
                        s != null && typeof s.toString != "function" && (s = ma.call(s)), Ce.call(i, s) ? i[s].push(c) : i[s] = [c]
                    }, Pt),
                    Lw = ie(uo);

                function or(i) {
                    return Rr(i) ? Il(i) : ch(i)
                }

                function Or(i) {
                    return Rr(i) ? Il(i, !0) : mm(i)
                }

                function $w(i, s) {
                    var c = {};
                    return s = Pt(s, 3), $i(i, function(l, w, I) {
                        an(c, s(l, w, I), l)
                    }), c
                }

                function jw(i, s) {
                    var c = {};
                    return s = Pt(s, 3), $i(i, function(l, w, I) {
                        an(c, w, s(l, w, I))
                    }), c
                }
                var zw = Cs(function(i, s, c) {
                        Na(i, s, c)
                    }),
                    Jf = Cs(function(i, s, c, l) {
                        Na(i, s, c, l)
                    }),
                    Fw = hn(function(i, s) {
                        var c = {};
                        if (i == null) return c;
                        var l = !1;
                        s = je(s, function(I) {
                            return I = Cn(I, i), l || (l = I.length > 1), I
                        }), ji(i, Ah(i), c), l && (c = ci(c, S | B | k, Um));
                        for (var w = s.length; w--;) ph(c, s[w]);
                        return c
                    });

                function Hw(i, s) {
                    return Yf(i, Ka(Pt(s)))
                }
                var Kw = hn(function(i, s) {
                    return i == null ? {} : ym(i, s)
                });

                function Yf(i, s) {
                    if (i == null) return {};
                    var c = je(Ah(i), function(l) {
                        return [l]
                    });
                    return s = Pt(s), jl(i, c, function(l, w) {
                        return s(l, w[0])
                    })
                }

                function Vw(i, s, c) {
                    s = Cn(s, i);
                    var l = -1,
                        w = s.length;
                    for (w || (w = 1, i = e); ++l < w;) {
                        var I = i == null ? e : i[zi(s[l])];
                        I === e && (l = w, I = c), i = ln(I) ? I.call(i) : I
                    }
                    return i
                }

                function Gw(i, s, c) {
                    return i == null ? i : fo(i, s, c)
                }

                function Qw(i, s, c, l) {
                    return l = typeof l == "function" ? l : e, i == null ? i : fo(i, s, c, l)
                }
                var Xf = uf(or),
                    Zf = uf(Or);

                function Ww(i, s, c) {
                    var l = Jt(i),
                        w = l || Rn(i) || Os(i);
                    if (s = Pt(s, 4), c == null) {
                        var I = i && i.constructor;
                        w ? c = l ? new I : [] : He(i) ? c = ln(I) ? Ms(wa(i)) : {} : c = {}
                    }
                    return (w ? si : $i)(i, function(q, $, F) {
                        return s(c, q, $, F)
                    }), c
                }

                function Jw(i, s) {
                    return i == null ? !0 : ph(i, s)
                }

                function Yw(i, s, c) {
                    return i == null ? i : Vl(i, s, vh(c))
                }

                function Xw(i, s, c, l) {
                    return l = typeof l == "function" ? l : e, i == null ? i : Vl(i, s, vh(c), l)
                }

                function Ts(i) {
                    return i == null ? [] : Wc(i, or(i))
                }

                function Zw(i) {
                    return i == null ? [] : Wc(i, Or(i))
                }

                function tb(i, s, c) {
                    return c === e && (c = s, s = e), c !== e && (c = li(c), c = c === c ? c : 0), s !== e && (s = li(s), s = s === s ? s : 0), ts(li(i), s, c)
                }

                function eb(i, s, c) {
                    return s = fn(s), c === e ? (c = s, s = 0) : c = fn(c), i = li(i), am(i, s, c)
                }

                function rb(i, s, c) {
                    if (c && typeof c != "boolean" && Ar(i, s, c) && (s = c = e), c === e && (typeof s == "boolean" ? (c = s, s = e) : typeof i == "boolean" && (c = i, i = e)), i === e && s === e ? (i = 0, s = 1) : (i = fn(i), s === e ? (s = i, i = 0) : s = fn(s)), i > s) {
                        var l = i;
                        i = s, s = l
                    }
                    if (c || i % 1 || s % 1) {
                        var w = Al();
                        return gr(i + w * (s - i + qe("1e-" + ((w + "").length - 1))), s)
                    }
                    return lh(i, s)
                }
                var ib = Ns(function(i, s, c) {
                    return s = s.toLowerCase(), i + (c ? td(s) : s)
                });

                function td(i) {
                    return kh(Ie(i).toLowerCase())
                }

                function ed(i) {
                    return i = Ie(i), i && i.replace(nr, Gg).replace($c, "")
                }

                function nb(i, s, c) {
                    i = Ie(i), s = Vr(s);
                    var l = i.length;
                    c = c === e ? l : ts(Xt(c), 0, l);
                    var w = c;
                    return c -= s.length, c >= 0 && i.slice(c, w) == s
                }

                function sb(i) {
                    return i = Ie(i), i && Mt.test(i) ? i.replace(yr, Qg) : i
                }

                function ob(i) {
                    return i = Ie(i), i && Ft.test(i) ? i.replace(Ee, "\\$&") : i
                }
                var ab = Ns(function(i, s, c) {
                        return i + (c ? "-" : "") + s.toLowerCase()
                    }),
                    cb = Ns(function(i, s, c) {
                        return i + (c ? " " : "") + s.toLowerCase()
                    }),
                    hb = nf("toLowerCase");

                function ub(i, s, c) {
                    i = Ie(i), s = Xt(s);
                    var l = s ? Es(i) : 0;
                    if (!s || l >= s) return i;
                    var w = (s - l) / 2;
                    return Ba(Ea(w), c) + i + Ba(Aa(w), c)
                }

                function lb(i, s, c) {
                    i = Ie(i), s = Xt(s);
                    var l = s ? Es(i) : 0;
                    return s && l < s ? i + Ba(s - l, c) : i
                }

                function fb(i, s, c) {
                    i = Ie(i), s = Xt(s);
                    var l = s ? Es(i) : 0;
                    return s && l < s ? Ba(s - l, c) + i : i
                }

                function db(i, s, c) {
                    return c || s == null ? s = 0 : s && (s = +s), b1(Ie(i).replace(Ut, ""), s || 0)
                }

                function pb(i, s, c) {
                    return (c ? Ar(i, s, c) : s === e) ? s = 1 : s = Xt(s), fh(Ie(i), s)
                }

                function gb() {
                    var i = arguments,
                        s = Ie(i[0]);
                    return i.length < 3 ? s : s.replace(i[1], i[2])
                }
                var mb = Ns(function(i, s, c) {
                    return i + (c ? "_" : "") + s.toLowerCase()
                });

                function vb(i, s, c) {
                    return c && typeof c != "number" && Ar(i, s, c) && (s = c = e), c = c === e ? f : c >>> 0, c ? (i = Ie(i), i && (typeof s == "string" || s != null && !qh(s)) && (s = Vr(s), !s && As(i)) ? Nn(Ai(i), 0, c) : i.split(s, c)) : []
                }
                var yb = Ns(function(i, s, c) {
                    return i + (c ? " " : "") + kh(s)
                });

                function wb(i, s, c) {
                    return i = Ie(i), c = c == null ? 0 : ts(Xt(c), 0, i.length), s = Vr(s), i.slice(c, c + s.length) == s
                }

                function bb(i, s, c) {
                    var l = A.templateSettings;
                    c && Ar(i, s, c) && (s = e), i = Ie(i), s = Qa({}, s, l, lf);
                    var w = Qa({}, s.imports, l.imports, lf),
                        I = or(w),
                        q = Wc(w, I),
                        $, F, J = 0,
                        Y = s.interpolate || qi,
                        tt = "__p += '",
                        ct = Yc((s.escape || qi).source + "|" + Y.source + "|" + (Y === Ot ? Me : qi).source + "|" + (s.evaluate || qi).source + "|$", "g"),
                        yt = "//# sourceURL=" + (Ce.call(s, "sourceURL") ? (s.sourceURL + "").replace(/\s/g, " ") : "lodash.templateSources[" + ++jc + "]") + `
`;
                    i.replace(ct, function(Nt, ce, me, Qr, Er, Wr) {
                        return me || (me = Qr), tt += i.slice(J, Wr).replace(Ln, Wg), ce && ($ = !0, tt += `' +
__e(` + ce + `) +
'`), Er && (F = !0, tt += `';
` + Er + `;
__p += '`), me && (tt += `' +
((__t = (` + me + `)) == null ? '' : __t) +
'`), J = Wr + Nt.length, Nt
                    }), tt += `';
`;
                    var Ct = Ce.call(s, "variable") && s.variable;
                    if (!Ct) tt = `with (obj) {
` + tt + `
}
`;
                    else if (Pe.test(Ct)) throw new Gt(g);
                    tt = (F ? tt.replace(ue, "") : tt).replace(Fe, "$1").replace(pe, "$1;"), tt = "function(" + (Ct || "obj") + `) {
` + (Ct ? "" : `obj || (obj = {});
`) + "var __t, __p = ''" + ($ ? ", __e = _.escape" : "") + (F ? `, __j = Array.prototype.join;
function print() { __p += __j.call(arguments, '') }
` : `;
`) + tt + `return __p
}`;
                    var re = id(function() {
                        return _e(I, yt + "return " + tt).apply(e, q)
                    });
                    if (re.source = tt, Dh(re)) throw re;
                    return re
                }

                function _b(i) {
                    return Ie(i).toLowerCase()
                }

                function Ab(i) {
                    return Ie(i).toUpperCase()
                }

                function Eb(i, s, c) {
                    if (i = Ie(i), i && (c || s === e)) return ll(i);
                    if (!i || !(s = Vr(s))) return i;
                    var l = Ai(i),
                        w = Ai(s),
                        I = fl(l, w),
                        q = dl(l, w) + 1;
                    return Nn(l, I, q).join("")
                }

                function Ib(i, s, c) {
                    if (i = Ie(i), i && (c || s === e)) return i.slice(0, gl(i) + 1);
                    if (!i || !(s = Vr(s))) return i;
                    var l = Ai(i),
                        w = dl(l, Ai(s)) + 1;
                    return Nn(l, 0, w).join("")
                }

                function Sb(i, s, c) {
                    if (i = Ie(i), i && (c || s === e)) return i.replace(Ut, "");
                    if (!i || !(s = Vr(s))) return i;
                    var l = Ai(i),
                        w = fl(l, Ai(s));
                    return Nn(l, w).join("")
                }

                function xb(i, s) {
                    var c = oe,
                        l = Tt;
                    if (He(s)) {
                        var w = "separator" in s ? s.separator : w;
                        c = "length" in s ? Xt(s.length) : c, l = "omission" in s ? Vr(s.omission) : l
                    }
                    i = Ie(i);
                    var I = i.length;
                    if (As(i)) {
                        var q = Ai(i);
                        I = q.length
                    }
                    if (c >= I) return i;
                    var $ = c - Es(l);
                    if ($ < 1) return l;
                    var F = q ? Nn(q, 0, $).join("") : i.slice(0, $);
                    if (w === e) return F + l;
                    if (q && ($ += F.length - $), qh(w)) {
                        if (i.slice($).search(w)) {
                            var J, Y = F;
                            for (w.global || (w = Yc(w.source, Ie(se.exec(w)) + "g")), w.lastIndex = 0; J = w.exec(Y);) var tt = J.index;
                            F = F.slice(0, tt === e ? $ : tt)
                        }
                    } else if (i.indexOf(Vr(w), $) != $) {
                        var ct = F.lastIndexOf(w);
                        ct > -1 && (F = F.slice(0, ct))
                    }
                    return F + l
                }

                function Pb(i) {
                    return i = Ie(i), i && qt.test(i) ? i.replace(ye, r1) : i
                }
                var Mb = Ns(function(i, s, c) {
                        return i + (c ? " " : "") + s.toUpperCase()
                    }),
                    kh = nf("toUpperCase");

                function rd(i, s, c) {
                    return i = Ie(i), s = c ? e : s, s === e ? Yg(i) ? s1(i) : zg(i) : i.match(s) || []
                }
                var id = ie(function(i, s) {
                        try {
                            return sr(i, e, s)
                        } catch (c) {
                            return Dh(c) ? c : new Gt(c)
                        }
                    }),
                    Cb = hn(function(i, s) {
                        return si(s, function(c) {
                            c = zi(c), an(i, c, Oh(i[c], i))
                        }), i
                    });

                function Nb(i) {
                    var s = i == null ? 0 : i.length,
                        c = Pt();
                    return i = s ? je(i, function(l) {
                        if (typeof l[1] != "function") throw new oi(h);
                        return [c(l[0]), l[1]]
                    }) : [], ie(function(l) {
                        for (var w = -1; ++w < s;) {
                            var I = i[w];
                            if (sr(I[0], this, l)) return sr(I[1], this, l)
                        }
                    })
                }

                function Rb(i) {
                    return rm(ci(i, S))
                }

                function Lh(i) {
                    return function() {
                        return i
                    }
                }

                function Ob(i, s) {
                    return i == null || i !== i ? s : i
                }
                var Tb = of (),
                    Db = of (!0);

                function Tr(i) {
                    return i
                }

                function $h(i) {
                    return ql(typeof i == "function" ? i : ci(i, S))
                }

                function qb(i) {
                    return Ul(ci(i, S))
                }

                function Bb(i, s) {
                    return kl(i, ci(s, S))
                }
                var Ub = ie(function(i, s) {
                        return function(c) {
                            return uo(c, i, s)
                        }
                    }),
                    kb = ie(function(i, s) {
                        return function(c) {
                            return uo(i, c, s)
                        }
                    });

                function jh(i, s, c) {
                    var l = or(s),
                        w = Ca(s, l);
                    c == null && !(He(s) && (w.length || !l.length)) && (c = s, s = i, i = this, w = Ca(s, or(s)));
                    var I = !(He(c) && "chain" in c) || !!c.chain,
                        q = ln(i);
                    return si(w, function($) {
                        var F = s[$];
                        i[$] = F, q && (i.prototype[$] = function() {
                            var J = this.__chain__;
                            if (I || J) {
                                var Y = i(this.__wrapped__),
                                    tt = Y.__actions__ = Nr(this.__actions__);
                                return tt.push({
                                    func: F,
                                    args: arguments,
                                    thisArg: i
                                }), Y.__chain__ = J, Y
                            }
                            return F.apply(i, In([this.value()], arguments))
                        })
                    }), i
                }

                function Lb() {
                    return ge._ === this && (ge._ = l1), this
                }

                function zh() {}

                function $b(i) {
                    return i = Xt(i), ie(function(s) {
                        return Ll(s, i)
                    })
                }
                var jb = wh(je),
                    zb = wh(ol),
                    Fb = wh(Hc);

                function nd(i) {
                    return xh(i) ? Kc(zi(i)) : wm(i)
                }

                function Hb(i) {
                    return function(s) {
                        return i == null ? e : es(i, s)
                    }
                }
                var Kb = cf(),
                    Vb = cf(!0);

                function Fh() {
                    return []
                }

                function Hh() {
                    return !1
                }

                function Gb() {
                    return {}
                }

                function Qb() {
                    return ""
                }

                function Wb() {
                    return !0
                }

                function Jb(i, s) {
                    if (i = Xt(i), i < 1 || i > R) return [];
                    var c = f,
                        l = gr(i, f);
                    s = Pt(s), i -= f;
                    for (var w = Qc(l, s); ++c < i;) s(c);
                    return w
                }

                function Yb(i) {
                    return Jt(i) ? je(i, zi) : Gr(i) ? [i] : Nr(If(Ie(i)))
                }

                function Xb(i) {
                    var s = ++h1;
                    return Ie(i) + s
                }
                var Zb = qa(function(i, s) {
                        return i + s
                    }, 0),
                    t2 = bh("ceil"),
                    e2 = qa(function(i, s) {
                        return i / s
                    }, 1),
                    r2 = bh("floor");

                function i2(i) {
                    return i && i.length ? Ma(i, Tr, sh) : e
                }

                function n2(i, s) {
                    return i && i.length ? Ma(i, Pt(s, 2), sh) : e
                }

                function s2(i) {
                    return hl(i, Tr)
                }

                function o2(i, s) {
                    return hl(i, Pt(s, 2))
                }

                function a2(i) {
                    return i && i.length ? Ma(i, Tr, hh) : e
                }

                function c2(i, s) {
                    return i && i.length ? Ma(i, Pt(s, 2), hh) : e
                }
                var h2 = qa(function(i, s) {
                        return i * s
                    }, 1),
                    u2 = bh("round"),
                    l2 = qa(function(i, s) {
                        return i - s
                    }, 0);

                function f2(i) {
                    return i && i.length ? Gc(i, Tr) : 0
                }

                function d2(i, s) {
                    return i && i.length ? Gc(i, Pt(s, 2)) : 0
                }
                return A.after = qy, A.ary = qf, A.assign = Aw, A.assignIn = Wf, A.assignInWith = Qa, A.assignWith = Ew, A.at = Iw, A.before = Bf, A.bind = Oh, A.bindAll = Cb, A.bindKey = Uf, A.castArray = Gy, A.chain = Of, A.chunk = rv, A.compact = iv, A.concat = nv, A.cond = Nb, A.conforms = Rb, A.constant = Lh, A.countBy = fy, A.create = Sw, A.curry = kf, A.curryRight = Lf, A.debounce = $f, A.defaults = xw, A.defaultsDeep = Pw, A.defer = By, A.delay = Uy, A.difference = sv, A.differenceBy = ov, A.differenceWith = av, A.drop = cv, A.dropRight = hv, A.dropRightWhile = uv, A.dropWhile = lv, A.fill = fv, A.filter = py, A.flatMap = vy, A.flatMapDeep = yy, A.flatMapDepth = wy, A.flatten = Mf, A.flattenDeep = dv, A.flattenDepth = pv, A.flip = ky, A.flow = Tb, A.flowRight = Db, A.fromPairs = gv, A.functions = Dw, A.functionsIn = qw, A.groupBy = by, A.initial = vv, A.intersection = yv, A.intersectionBy = wv, A.intersectionWith = bv, A.invert = Uw, A.invertBy = kw, A.invokeMap = Ay, A.iteratee = $h, A.keyBy = Ey, A.keys = or, A.keysIn = Or, A.map = za, A.mapKeys = $w, A.mapValues = jw, A.matches = qb, A.matchesProperty = Bb, A.memoize = Ha, A.merge = zw, A.mergeWith = Jf, A.method = Ub, A.methodOf = kb, A.mixin = jh, A.negate = Ka, A.nthArg = $b, A.omit = Fw, A.omitBy = Hw, A.once = Ly, A.orderBy = Iy, A.over = jb, A.overArgs = $y, A.overEvery = zb, A.overSome = Fb, A.partial = Th, A.partialRight = jf, A.partition = Sy, A.pick = Kw, A.pickBy = Yf, A.property = nd, A.propertyOf = Hb, A.pull = Iv, A.pullAll = Nf, A.pullAllBy = Sv, A.pullAllWith = xv, A.pullAt = Pv, A.range = Kb, A.rangeRight = Vb, A.rearg = jy, A.reject = My, A.remove = Mv, A.rest = zy, A.reverse = Nh, A.sampleSize = Ny, A.set = Gw, A.setWith = Qw, A.shuffle = Ry, A.slice = Cv, A.sortBy = Dy, A.sortedUniq = Bv, A.sortedUniqBy = Uv, A.split = vb, A.spread = Fy, A.tail = kv, A.take = Lv, A.takeRight = $v, A.takeRightWhile = jv, A.takeWhile = zv, A.tap = iy, A.throttle = Hy, A.thru = ja, A.toArray = Vf, A.toPairs = Xf, A.toPairsIn = Zf, A.toPath = Yb, A.toPlainObject = Qf, A.transform = Ww, A.unary = Ky, A.union = Fv, A.unionBy = Hv, A.unionWith = Kv, A.uniq = Vv, A.uniqBy = Gv, A.uniqWith = Qv, A.unset = Jw, A.unzip = Rh, A.unzipWith = Rf, A.update = Yw, A.updateWith = Xw, A.values = Ts, A.valuesIn = Zw, A.without = Wv, A.words = rd, A.wrap = Vy, A.xor = Jv, A.xorBy = Yv, A.xorWith = Xv, A.zip = Zv, A.zipObject = ty, A.zipObjectDeep = ey, A.zipWith = ry, A.entries = Xf, A.entriesIn = Zf, A.extend = Wf, A.extendWith = Qa, jh(A, A), A.add = Zb, A.attempt = id, A.camelCase = ib, A.capitalize = td, A.ceil = t2, A.clamp = tb, A.clone = Qy, A.cloneDeep = Jy, A.cloneDeepWith = Yy, A.cloneWith = Wy, A.conformsTo = Xy, A.deburr = ed, A.defaultTo = Ob, A.divide = e2, A.endsWith = nb, A.eq = Ii, A.escape = sb, A.escapeRegExp = ob, A.every = dy, A.find = gy, A.findIndex = xf, A.findKey = Mw, A.findLast = my, A.findLastIndex = Pf, A.findLastKey = Cw, A.floor = r2, A.forEach = Tf, A.forEachRight = Df, A.forIn = Nw, A.forInRight = Rw, A.forOwn = Ow, A.forOwnRight = Tw, A.get = Bh, A.gt = Zy, A.gte = tw, A.has = Bw, A.hasIn = Uh, A.head = Cf, A.identity = Tr, A.includes = _y, A.indexOf = mv, A.inRange = eb, A.invoke = Lw, A.isArguments = ns, A.isArray = Jt, A.isArrayBuffer = ew, A.isArrayLike = Rr, A.isArrayLikeObject = Qe, A.isBoolean = rw, A.isBuffer = Rn, A.isDate = iw, A.isElement = nw, A.isEmpty = sw, A.isEqual = ow, A.isEqualWith = aw, A.isError = Dh, A.isFinite = cw, A.isFunction = ln, A.isInteger = zf, A.isLength = Va, A.isMap = Ff, A.isMatch = hw, A.isMatchWith = uw, A.isNaN = lw, A.isNative = fw, A.isNil = pw, A.isNull = dw, A.isNumber = Hf, A.isObject = He, A.isObjectLike = Ke, A.isPlainObject = vo, A.isRegExp = qh, A.isSafeInteger = gw, A.isSet = Kf, A.isString = Ga, A.isSymbol = Gr, A.isTypedArray = Os, A.isUndefined = mw, A.isWeakMap = vw, A.isWeakSet = yw, A.join = _v, A.kebabCase = ab, A.last = ui, A.lastIndexOf = Av, A.lowerCase = cb, A.lowerFirst = hb, A.lt = ww, A.lte = bw, A.max = i2, A.maxBy = n2, A.mean = s2, A.meanBy = o2, A.min = a2, A.minBy = c2, A.stubArray = Fh, A.stubFalse = Hh, A.stubObject = Gb, A.stubString = Qb, A.stubTrue = Wb, A.multiply = h2, A.nth = Ev, A.noConflict = Lb, A.noop = zh, A.now = Fa, A.pad = ub, A.padEnd = lb, A.padStart = fb, A.parseInt = db, A.random = rb, A.reduce = xy, A.reduceRight = Py, A.repeat = pb, A.replace = gb, A.result = Vw, A.round = u2, A.runInContext = z, A.sample = Cy, A.size = Oy, A.snakeCase = mb, A.some = Ty, A.sortedIndex = Nv, A.sortedIndexBy = Rv, A.sortedIndexOf = Ov, A.sortedLastIndex = Tv, A.sortedLastIndexBy = Dv, A.sortedLastIndexOf = qv, A.startCase = yb, A.startsWith = wb, A.subtract = l2, A.sum = f2, A.sumBy = d2, A.template = bb, A.times = Jb, A.toFinite = fn, A.toInteger = Xt, A.toLength = Gf, A.toLower = _b, A.toNumber = li, A.toSafeInteger = _w, A.toString = Ie, A.toUpper = Ab, A.trim = Eb, A.trimEnd = Ib, A.trimStart = Sb, A.truncate = xb, A.unescape = Pb, A.uniqueId = Xb, A.upperCase = Mb, A.upperFirst = kh, A.each = Tf, A.eachRight = Df, A.first = Cf, jh(A, function() {
                    var i = {};
                    return $i(A, function(s, c) {
                        Ce.call(A.prototype, c) || (i[c] = s)
                    }), i
                }(), {
                    chain: !1
                }), A.VERSION = n, si(["bind", "bindKey", "curry", "curryRight", "partial", "partialRight"], function(i) {
                    A[i].placeholder = A
                }), si(["drop", "take"], function(i, s) {
                    le.prototype[i] = function(c) {
                        c = c === e ? 1 : er(Xt(c), 0);
                        var l = this.__filtered__ && !s ? new le(this) : this.clone();
                        return l.__filtered__ ? l.__takeCount__ = gr(c, l.__takeCount__) : l.__views__.push({
                            size: gr(c, f),
                            type: i + (l.__dir__ < 0 ? "Right" : "")
                        }), l
                    }, le.prototype[i + "Right"] = function(c) {
                        return this.reverse()[i](c).reverse()
                    }
                }), si(["filter", "map", "takeWhile"], function(i, s) {
                    var c = s + 1,
                        l = c == p || c == P;
                    le.prototype[i] = function(w) {
                        var I = this.clone();
                        return I.__iteratees__.push({
                            iteratee: Pt(w, 3),
                            type: c
                        }), I.__filtered__ = I.__filtered__ || l, I
                    }
                }), si(["head", "last"], function(i, s) {
                    var c = "take" + (s ? "Right" : "");
                    le.prototype[i] = function() {
                        return this[c](1).value()[0]
                    }
                }), si(["initial", "tail"], function(i, s) {
                    var c = "drop" + (s ? "" : "Right");
                    le.prototype[i] = function() {
                        return this.__filtered__ ? new le(this) : this[c](1)
                    }
                }), le.prototype.compact = function() {
                    return this.filter(Tr)
                }, le.prototype.find = function(i) {
                    return this.filter(i).head()
                }, le.prototype.findLast = function(i) {
                    return this.reverse().find(i)
                }, le.prototype.invokeMap = ie(function(i, s) {
                    return typeof i == "function" ? new le(this) : this.map(function(c) {
                        return uo(c, i, s)
                    })
                }), le.prototype.reject = function(i) {
                    return this.filter(Ka(Pt(i)))
                }, le.prototype.slice = function(i, s) {
                    i = Xt(i);
                    var c = this;
                    return c.__filtered__ && (i > 0 || s < 0) ? new le(c) : (i < 0 ? c = c.takeRight(-i) : i && (c = c.drop(i)), s !== e && (s = Xt(s), c = s < 0 ? c.dropRight(-s) : c.take(s - i)), c)
                }, le.prototype.takeRightWhile = function(i) {
                    return this.reverse().takeWhile(i).reverse()
                }, le.prototype.toArray = function() {
                    return this.take(f)
                }, $i(le.prototype, function(i, s) {
                    var c = /^(?:filter|find|map|reject)|While$/.test(s),
                        l = /^(?:head|last)$/.test(s),
                        w = A[l ? "take" + (s == "last" ? "Right" : "") : s],
                        I = l || /^find/.test(s);
                    w && (A.prototype[s] = function() {
                        var q = this.__wrapped__,
                            $ = l ? [1] : arguments,
                            F = q instanceof le,
                            J = $[0],
                            Y = F || Jt(q),
                            tt = function(ce) {
                                var me = w.apply(A, In([ce], $));
                                return l && ct ? me[0] : me
                            };
                        Y && c && typeof J == "function" && J.length != 1 && (F = Y = !1);
                        var ct = this.__chain__,
                            yt = !!this.__actions__.length,
                            Ct = I && !ct,
                            re = F && !yt;
                        if (!I && Y) {
                            q = re ? q : new le(this);
                            var Nt = i.apply(q, $);
                            return Nt.__actions__.push({
                                func: ja,
                                args: [tt],
                                thisArg: e
                            }), new ai(Nt, ct)
                        }
                        return Ct && re ? i.apply(this, $) : (Nt = this.thru(tt), Ct ? l ? Nt.value()[0] : Nt.value() : Nt)
                    })
                }), si(["pop", "push", "shift", "sort", "splice", "unshift"], function(i) {
                    var s = da[i],
                        c = /^(?:push|sort|unshift)$/.test(i) ? "tap" : "thru",
                        l = /^(?:pop|shift)$/.test(i);
                    A.prototype[i] = function() {
                        var w = arguments;
                        if (l && !this.__chain__) {
                            var I = this.value();
                            return s.apply(Jt(I) ? I : [], w)
                        }
                        return this[c](function(q) {
                            return s.apply(Jt(q) ? q : [], w)
                        })
                    }
                }), $i(le.prototype, function(i, s) {
                    var c = A[s];
                    if (c) {
                        var l = c.name + "";
                        Ce.call(Ps, l) || (Ps[l] = []), Ps[l].push({
                            name: s,
                            func: c
                        })
                    }
                }), Ps[Da(e, et).name] = [{
                    name: "wrapper",
                    func: e
                }], le.prototype.clone = P1, le.prototype.reverse = M1, le.prototype.value = C1, A.prototype.at = ny, A.prototype.chain = sy, A.prototype.commit = oy, A.prototype.next = ay, A.prototype.plant = hy, A.prototype.reverse = uy, A.prototype.toJSON = A.prototype.valueOf = A.prototype.value = ly, A.prototype.first = A.prototype.head, io && (A.prototype[io] = cy), A
            },
            Is = o1();
        Ge ? ((Ge.exports = Is)._ = Is, Be._ = Is) : ge._ = Is
    }).call(So)
})(qu, qu.exports);
var s4 = Object.defineProperty,
    o4 = Object.defineProperties,
    a4 = Object.getOwnPropertyDescriptors,
    Kp = Object.getOwnPropertySymbols,
    c4 = Object.prototype.hasOwnProperty,
    h4 = Object.prototype.propertyIsEnumerable,
    Vp = (r, t, e) => t in r ? s4(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    ic = (r, t) => {
        for (var e in t || (t = {})) c4.call(t, e) && Vp(r, e, t[e]);
        if (Kp)
            for (var e of Kp(t)) h4.call(t, e) && Vp(r, e, t[e]);
        return r
    },
    u4 = (r, t) => o4(r, a4(t));

function Oi(r, t, e) {
    var n;
    const o = Ro(r);
    return ((n = t.rpcMap) == null ? void 0 : n[o.reference]) || `${n4}?chainId=${o.namespace}:${o.reference}&projectId=${e}`
}

function ms(r) {
    return r.includes(":") ? r.split(":")[1] : r
}

function qg(r) {
    return r.map(t => `${t.split(":")[0]}:${t.split(":")[1]}`)
}

function l4(r, t) {
    const e = Object.keys(t.namespaces).filter(o => o.includes(r));
    if (!e.length) return [];
    const n = [];
    return e.forEach(o => {
        const a = t.namespaces[o].accounts;
        n.push(...a)
    }), n
}

function mu(r = {}, t = {}) {
    const e = Gp(r),
        n = Gp(t);
    return qu.exports.merge(e, n)
}

function Gp(r) {
    var t, e, n, o;
    const a = {};
    if (!Uo(r)) return a;
    for (const [h, g] of Object.entries(r)) {
        const b = Xu(h) ? [h] : g.chains,
            m = g.methods || [],
            _ = g.events || [],
            S = g.rpcMap || {},
            B = Mo(h);
        a[B] = u4(ic(ic({}, a[B]), g), {
            chains: cc(b, (t = a[B]) == null ? void 0 : t.chains),
            methods: cc(m, (e = a[B]) == null ? void 0 : e.methods),
            events: cc(_, (n = a[B]) == null ? void 0 : n.events),
            rpcMap: ic(ic({}, S), (o = a[B]) == null ? void 0 : o.rpcMap)
        })
    }
    return a
}

function f4(r) {
    return r.includes(":") ? r.split(":")[2] : r
}

function Qp(r) {
    const t = {};
    for (const [e, n] of Object.entries(r)) {
        const o = n.methods || [],
            a = n.events || [],
            h = n.accounts || [],
            g = Xu(e) ? [e] : n.chains ? n.chains : qg(n.accounts);
        t[e] = {
            chains: g,
            methods: o,
            events: a,
            accounts: h
        }
    }
    return t
}

function vu(r) {
    return typeof r == "number" ? r : r.includes("0x") ? parseInt(r, 16) : (r = r.includes(":") ? r.split(":")[1] : r, isNaN(Number(r)) ? r : Number(r))
}
const Bg = {},
    Se = r => Bg[r],
    yu = (r, t) => {
        Bg[r] = t
    };
class d4 {
    constructor(t) {
        this.name = "polkadot", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${t}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]) || [] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            const o = ms(e);
            t[o] = this.createHttpProvider(o, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
var p4 = Object.defineProperty,
    g4 = Object.defineProperties,
    m4 = Object.getOwnPropertyDescriptors,
    Wp = Object.getOwnPropertySymbols,
    v4 = Object.prototype.hasOwnProperty,
    y4 = Object.prototype.propertyIsEnumerable,
    Jp = (r, t, e) => t in r ? p4(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Yp = (r, t) => {
        for (var e in t || (t = {})) v4.call(t, e) && Jp(r, e, t[e]);
        if (Wp)
            for (var e of Wp(t)) y4.call(t, e) && Jp(r, e, t[e]);
        return r
    },
    Xp = (r, t) => g4(r, m4(t));
class w4 {
    constructor(t) {
        this.name = "eip155", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.httpProviders = this.createHttpProviders(), this.chainId = parseInt(this.getDefaultChain())
    }
    async request(t) {
        switch (t.request.method) {
            case "eth_requestAccounts":
                return this.getAccounts();
            case "eth_accounts":
                return this.getAccounts();
            case "wallet_switchEthereumChain":
                return await this.handleSwitchChain(t);
            case "eth_chainId":
                return parseInt(this.getDefaultChain());
            case "wallet_getCapabilities":
                return await this.getCapabilities(t)
        }
        return this.namespace.methods.includes(t.request.method) ? await this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(parseInt(t), e), this.chainId = parseInt(t), this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${t}`)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId.toString();
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    createHttpProvider(t, e) {
        const n = e || Oi(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            const o = parseInt(ms(e));
            t[o] = this.createHttpProvider(o, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    getHttpProvider() {
        const t = this.chainId,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    async handleSwitchChain(t) {
        var e, n;
        let o = t.request.params ? (e = t.request.params[0]) == null ? void 0 : e.chainId : "0x0";
        o = o.startsWith("0x") ? o : `0x${o}`;
        const a = parseInt(o, 16);
        if (this.isChainApproved(a)) this.setDefaultChain(`${a}`);
        else if (this.namespace.methods.includes("wallet_switchEthereumChain")) await this.client.request({
            topic: t.topic,
            request: {
                method: t.request.method,
                params: [{
                    chainId: o
                }]
            },
            chainId: (n = this.namespace.chains) == null ? void 0 : n[0]
        }), this.setDefaultChain(`${a}`);
        else throw new Error(`Failed to switch to chain 'eip155:${a}'. The chain is not approved or the wallet does not support 'wallet_switchEthereumChain' method.`);
        return null
    }
    isChainApproved(t) {
        return this.namespace.chains.includes(`${this.name}:${t}`)
    }
    async getCapabilities(t) {
        var e, n, o;
        const a = (n = (e = t.request) == null ? void 0 : e.params) == null ? void 0 : n[0];
        if (!a) throw new Error("Missing address parameter in `wallet_getCapabilities` request");
        const h = this.client.session.get(t.topic),
            g = ((o = h == null ? void 0 : h.sessionProperties) == null ? void 0 : o.capabilities) || {};
        if (g != null && g[a]) return g == null ? void 0 : g[a];
        const b = await this.client.request(t);
        try {
            await this.client.session.update(t.topic, {
                sessionProperties: Xp(Yp({}, h.sessionProperties || {}), {
                    capabilities: Xp(Yp({}, g || {}), {
                        [a]: b
                    })
                })
            })
        } catch (m) {
            console.warn("Failed to update session with capabilities", m)
        }
        return b
    }
}
class b4 {
    constructor(t) {
        this.name = "solana", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${t}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            const o = ms(e);
            t[o] = this.createHttpProvider(o, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
class _4 {
    constructor(t) {
        this.name = "cosmos", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            const o = ms(e);
            t[o] = this.createHttpProvider(o, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
class A4 {
    constructor(t) {
        this.name = "algorand", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        if (!this.httpProviders[t]) {
            const n = e || Oi(`${this.name}:${t}`, this.namespace, this.client.core.projectId);
            if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, n)
        }
        this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            t[e] = this.createHttpProvider(e, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        return typeof n > "u" ? void 0 : new Ti(new en(n, Se("disableProviderPing")))
    }
}
class E4 {
    constructor(t) {
        this.name = "cip34", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            const n = this.getCardanoRPCUrl(e),
                o = ms(e);
            t[o] = this.createHttpProvider(o, n)
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    getCardanoRPCUrl(t) {
        const e = this.namespace.rpcMap;
        if (e) return e[t]
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || this.getCardanoRPCUrl(t);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
class I4 {
    constructor(t) {
        this.name = "elrond", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${t}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            const o = ms(e);
            t[o] = this.createHttpProvider(o, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
class S4 {
    constructor(t) {
        this.name = "multiversx", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${t}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            const o = ms(e);
            t[o] = this.createHttpProvider(o, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
class x4 {
    constructor(t) {
        this.name = "near", this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace = Object.assign(this.namespace, t)
    }
    requestAccounts() {
        return this.getAccounts()
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider().request(t.request)
    }
    setDefaultChain(t, e) {
        if (this.chainId = t, !this.httpProviders[t]) {
            const n = e || Oi(`${this.name}:${t}`, this.namespace);
            if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
            this.setHttpProvider(t, n)
        }
        this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${this.chainId}`)
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]) || [] : []
    }
    createHttpProviders() {
        const t = {};
        return this.namespace.chains.forEach(e => {
            var n;
            t[e] = this.createHttpProvider(e, (n = this.namespace.rpcMap) == null ? void 0 : n[e])
        }), t
    }
    getHttpProvider() {
        const t = `${this.name}:${this.chainId}`,
            e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace);
        return typeof n > "u" ? void 0 : new Ti(new en(n, Se("disableProviderPing")))
    }
}
class P4 {
    constructor(t) {
        this.name = Bs, this.namespace = t.namespace, this.events = Se("events"), this.client = Se("client"), this.chainId = this.getDefaultChain(), this.httpProviders = this.createHttpProviders()
    }
    updateNamespace(t) {
        this.namespace.chains = [...new Set((this.namespace.chains || []).concat(t.chains || []))], this.namespace.accounts = [...new Set((this.namespace.accounts || []).concat(t.accounts || []))], this.namespace.methods = [...new Set((this.namespace.methods || []).concat(t.methods || []))], this.namespace.events = [...new Set((this.namespace.events || []).concat(t.events || []))], this.httpProviders = this.createHttpProviders()
    }
    requestAccounts() {
        return this.getAccounts()
    }
    request(t) {
        return this.namespace.methods.includes(t.request.method) ? this.client.request(t) : this.getHttpProvider(t.chainId).request(t.request)
    }
    setDefaultChain(t, e) {
        this.httpProviders[t] || this.setHttpProvider(t, e), this.chainId = t, this.events.emit(Di.DEFAULT_CHAIN_CHANGED, `${this.name}:${t}`)
    }
    getDefaultChain() {
        if (this.chainId) return this.chainId;
        if (this.namespace.defaultChain) return this.namespace.defaultChain;
        const t = this.namespace.chains[0];
        if (!t) throw new Error("ChainId not found");
        return t.split(":")[1]
    }
    getAccounts() {
        const t = this.namespace.accounts;
        return t ? [...new Set(t.filter(e => e.split(":")[1] === this.chainId.toString()).map(e => e.split(":")[2]))] : []
    }
    createHttpProviders() {
        var t, e;
        const n = {};
        return (e = (t = this.namespace) == null ? void 0 : t.accounts) == null || e.forEach(o => {
            const a = Ro(o);
            n[`${a.namespace}:${a.reference}`] = this.createHttpProvider(o)
        }), n
    }
    getHttpProvider(t) {
        const e = this.httpProviders[t];
        if (typeof e > "u") throw new Error(`JSON-RPC provider for ${t} not found`);
        return e
    }
    setHttpProvider(t, e) {
        const n = this.createHttpProvider(t, e);
        n && (this.httpProviders[t] = n)
    }
    createHttpProvider(t, e) {
        const n = e || Oi(t, this.namespace, this.client.core.projectId);
        if (!n) throw new Error(`No RPC url provided for chainId: ${t}`);
        return new Ti(new en(n, Se("disableProviderPing")))
    }
}
var M4 = Object.defineProperty,
    C4 = Object.defineProperties,
    N4 = Object.getOwnPropertyDescriptors,
    Zp = Object.getOwnPropertySymbols,
    R4 = Object.prototype.hasOwnProperty,
    O4 = Object.prototype.propertyIsEnumerable,
    t0 = (r, t, e) => t in r ? M4(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    nc = (r, t) => {
        for (var e in t || (t = {})) R4.call(t, e) && t0(r, e, t[e]);
        if (Zp)
            for (var e of Zp(t)) O4.call(t, e) && t0(r, e, t[e]);
        return r
    },
    wu = (r, t) => C4(r, N4(t));
class nl {
    constructor(t) {
        this.events = new ku, this.rpcProviders = {}, this.shouldAbortPairingAttempt = !1, this.maxPairingAttempts = 10, this.disableProviderPing = !1, this.providerOpts = t, this.logger = typeof(t == null ? void 0 : t.logger) < "u" && typeof(t == null ? void 0 : t.logger) != "string" ? t.logger : ko(Cc({
            level: (t == null ? void 0 : t.logger) || Fp
        })), this.disableProviderPing = (t == null ? void 0 : t.disableProviderPing) || !1
    }
    static async init(t) {
        const e = new nl(t);
        return await e.initialize(), e
    }
    async request(t, e, n) {
        const [o, a] = this.validateChain(e);
        if (!this.session) throw new Error("Please call connect() before request()");
        return await this.getProvider(o).request({
            request: nc({}, t),
            chainId: `${o}:${a}`,
            topic: this.session.topic,
            expiry: n
        })
    }
    sendAsync(t, e, n, o) {
        const a = new Date().getTime();
        this.request(t, n, o).then(h => e(null, Nc(a, h))).catch(h => e(h, void 0))
    }
    async enable() {
        if (!this.client) throw new Error("Sign Client not initialized");
        return this.session || await this.connect({
            namespaces: this.namespaces,
            optionalNamespaces: this.optionalNamespaces,
            sessionProperties: this.sessionProperties
        }), await this.requestAccounts()
    }
    async disconnect() {
        var t;
        if (!this.session) throw new Error("Please call connect() before enable()");
        await this.client.disconnect({
            topic: (t = this.session) == null ? void 0 : t.topic,
            reason: Ne("USER_DISCONNECTED")
        }), await this.cleanup()
    }
    async connect(t) {
        if (!this.client) throw new Error("Sign Client not initialized");
        if (this.setNamespaces(t), await this.cleanupPendingPairings(), !t.skipPairing) return await this.pair(t.pairingTopic)
    }
    async authenticate(t) {
        if (!this.client) throw new Error("Sign Client not initialized");
        this.setNamespaces(t), await this.cleanupPendingPairings();
        const {
            uri: e,
            response: n
        } = await this.client.authenticate(t);
        e && (this.uri = e, this.events.emit("display_uri", e));
        const o = await n();
        if (this.session = o.session, this.session) {
            const a = Qp(this.session.namespaces);
            this.namespaces = mu(this.namespaces, a), this.persist("namespaces", this.namespaces), this.onConnect()
        }
        return o
    }
    on(t, e) {
        this.events.on(t, e)
    }
    once(t, e) {
        this.events.once(t, e)
    }
    removeListener(t, e) {
        this.events.removeListener(t, e)
    }
    off(t, e) {
        this.events.off(t, e)
    }
    get isWalletConnect() {
        return !0
    }
    async pair(t) {
        this.shouldAbortPairingAttempt = !1;
        let e = 0;
        do {
            if (this.shouldAbortPairingAttempt) throw new Error("Pairing aborted");
            if (e >= this.maxPairingAttempts) throw new Error("Max auto pairing attempts reached");
            const {
                uri: n,
                approval: o
            } = await this.client.connect({
                pairingTopic: t,
                requiredNamespaces: this.namespaces,
                optionalNamespaces: this.optionalNamespaces,
                sessionProperties: this.sessionProperties
            });
            n && (this.uri = n, this.events.emit("display_uri", n)), await o().then(a => {
                this.session = a;
                const h = Qp(a.namespaces);
                this.namespaces = mu(this.namespaces, h), this.persist("namespaces", this.namespaces)
            }).catch(a => {
                if (a.message !== Dg) throw a;
                e++
            })
        } while (!this.session);
        return this.onConnect(), this.session
    }
    setDefaultChain(t, e) {
        try {
            if (!this.session) return;
            const [n, o] = this.validateChain(t), a = this.getProvider(n);
            a.name === Bs ? a.setDefaultChain(`${n}:${o}`, e) : a.setDefaultChain(o, e)
        } catch (n) {
            if (!/Please call connect/.test(n.message)) throw n
        }
    }
    async cleanupPendingPairings(t = {}) {
        this.logger.info("Cleaning up inactive pairings...");
        const e = this.client.pairing.getAll();
        if (tn(e)) {
            for (const n of e) t.deletePairings ? this.client.core.expirer.set(n.topic, 0) : await this.client.core.relayer.subscriber.unsubscribe(n.topic);
            this.logger.info(`Inactive pairings cleared: ${e.length}`)
        }
    }
    abortPairingAttempt() {
        this.shouldAbortPairingAttempt = !0
    }
    async checkStorage() {
        if (this.namespaces = await this.getFromStore("namespaces"), this.optionalNamespaces = await this.getFromStore("optionalNamespaces") || {}, this.client.session.length) {
            const t = this.client.session.keys.length - 1;
            this.session = this.client.session.get(this.client.session.keys[t]), this.createProviders()
        }
    }
    async initialize() {
        this.logger.trace("Initialized"), await this.createClient(), await this.checkStorage(), this.registerEventListeners()
    }
    async createClient() {
        this.client = this.providerOpts.client || await il.init({
            logger: this.providerOpts.logger || Fp,
            relayUrl: this.providerOpts.relayUrl || e4,
            projectId: this.providerOpts.projectId,
            metadata: this.providerOpts.metadata,
            storageOptions: this.providerOpts.storageOptions,
            storage: this.providerOpts.storage,
            name: this.providerOpts.name
        }), this.logger.trace("SignClient Initialized")
    }
    createProviders() {
        if (!this.client) throw new Error("Sign Client not initialized");
        if (!this.session) throw new Error("Session not initialized. Please call connect() before enable()");
        const t = [...new Set(Object.keys(this.session.namespaces).map(e => Mo(e)))];
        yu("client", this.client), yu("events", this.events), yu("disableProviderPing", this.disableProviderPing), t.forEach(e => {
            if (!this.session) return;
            const n = l4(e, this.session),
                o = qg(n),
                a = mu(this.namespaces, this.optionalNamespaces),
                h = wu(nc({}, a[e]), {
                    accounts: n,
                    chains: o
                });
            switch (e) {
                case "eip155":
                    this.rpcProviders[e] = new w4({
                        namespace: h
                    });
                    break;
                case "algorand":
                    this.rpcProviders[e] = new A4({
                        namespace: h
                    });
                    break;
                case "solana":
                    this.rpcProviders[e] = new b4({
                        namespace: h
                    });
                    break;
                case "cosmos":
                    this.rpcProviders[e] = new _4({
                        namespace: h
                    });
                    break;
                case "polkadot":
                    this.rpcProviders[e] = new d4({
                        namespace: h
                    });
                    break;
                case "cip34":
                    this.rpcProviders[e] = new E4({
                        namespace: h
                    });
                    break;
                case "elrond":
                    this.rpcProviders[e] = new I4({
                        namespace: h
                    });
                    break;
                case "multiversx":
                    this.rpcProviders[e] = new S4({
                        namespace: h
                    });
                    break;
                case "near":
                    this.rpcProviders[e] = new x4({
                        namespace: h
                    });
                    break;
                default:
                    this.rpcProviders[Bs] ? this.rpcProviders[Bs].updateNamespace(h) : this.rpcProviders[Bs] = new P4({
                        namespace: h
                    })
            }
        })
    }
    registerEventListeners() {
        if (typeof this.client > "u") throw new Error("Sign Client is not initialized");
        this.client.on("session_ping", t => {
            this.events.emit("session_ping", t)
        }), this.client.on("session_event", t => {
            const {
                params: e
            } = t, {
                event: n
            } = e;
            if (n.name === "accountsChanged") {
                const o = n.data;
                o && tn(o) && this.events.emit("accountsChanged", o.map(f4))
            } else if (n.name === "chainChanged") {
                const o = e.chainId,
                    a = e.event.data,
                    h = Mo(o),
                    g = vu(o) !== vu(a) ? `${h}:${vu(a)}` : o;
                this.onChainChanged(g)
            } else this.events.emit(n.name, n.data);
            this.events.emit("session_event", t)
        }), this.client.on("session_update", ({
            topic: t,
            params: e
        }) => {
            var n;
            const {
                namespaces: o
            } = e, a = (n = this.client) == null ? void 0 : n.session.get(t);
            this.session = wu(nc({}, a), {
                namespaces: o
            }), this.onSessionUpdate(), this.events.emit("session_update", {
                topic: t,
                params: e
            })
        }), this.client.on("session_delete", async t => {
            await this.cleanup(), this.events.emit("session_delete", t), this.events.emit("disconnect", wu(nc({}, Ne("USER_DISCONNECTED")), {
                data: t.topic
            }))
        }), this.on(Di.DEFAULT_CHAIN_CHANGED, t => {
            this.onChainChanged(t, !0)
        })
    }
    getProvider(t) {
        return this.rpcProviders[t] || this.rpcProviders[Bs]
    }
    onSessionUpdate() {
        Object.keys(this.rpcProviders).forEach(t => {
            var e;
            this.getProvider(t).updateNamespace((e = this.session) == null ? void 0 : e.namespaces[t])
        })
    }
    setNamespaces(t) {
        const {
            namespaces: e,
            optionalNamespaces: n,
            sessionProperties: o
        } = t;
        e && Object.keys(e).length && (this.namespaces = e), n && Object.keys(n).length && (this.optionalNamespaces = n), this.sessionProperties = o, this.persist("namespaces", e), this.persist("optionalNamespaces", n)
    }
    validateChain(t) {
        const [e, n] = (t == null ? void 0 : t.split(":")) || ["", ""];
        if (!this.namespaces || !Object.keys(this.namespaces).length) return [e, n];
        if (e && !Object.keys(this.namespaces || {}).map(h => Mo(h)).includes(e)) throw new Error(`Namespace '${e}' is not configured. Please call connect() first with namespace config.`);
        if (e && n) return [e, n];
        const o = Mo(Object.keys(this.namespaces)[0]),
            a = this.rpcProviders[o].getDefaultChain();
        return [o, a]
    }
    async requestAccounts() {
        const [t] = this.validateChain();
        return await this.getProvider(t).requestAccounts()
    }
    onChainChanged(t, e = !1) {
        if (!this.namespaces) return;
        const [n, o] = this.validateChain(t);
        o && (e || this.getProvider(n).setDefaultChain(o), this.namespaces[n] ? this.namespaces[n].defaultChain = o : this.namespaces[`${n}:${o}`] ? this.namespaces[`${n}:${o}`].defaultChain = o : this.namespaces[`${n}:${o}`] = {
            defaultChain: o
        }, this.persist("namespaces", this.namespaces), this.events.emit("chainChanged", o))
    }
    onConnect() {
        this.createProviders(), this.events.emit("connect", {
            session: this.session
        })
    }
    async cleanup() {
        this.session = void 0, this.namespaces = void 0, this.optionalNamespaces = void 0, this.sessionProperties = void 0, this.persist("namespaces", void 0), this.persist("optionalNamespaces", void 0), this.persist("sessionProperties", void 0), await this.cleanupPendingPairings({
            deletePairings: !0
        })
    }
    persist(t, e) {
        this.client.core.storage.setItem(`${Hp}/${t}`, e)
    }
    async getFromStore(t) {
        return await this.client.core.storage.getItem(`${Hp}/${t}`)
    }
}
const T4 = nl,
    D4 = "wc",
    q4 = "ethereum_provider",
    B4 = `${D4}@2:${q4}:`,
    U4 = "https://rpc.walletconnect.com/v1/",
    Bu = ["eth_sendTransaction", "personal_sign"],
    k4 = ["eth_accounts", "eth_requestAccounts", "eth_sendRawTransaction", "eth_sign", "eth_signTransaction", "eth_signTypedData", "eth_signTypedData_v3", "eth_signTypedData_v4", "eth_sendTransaction", "personal_sign", "wallet_switchEthereumChain", "wallet_addEthereumChain", "wallet_getPermissions", "wallet_requestPermissions", "wallet_registerOnboarding", "wallet_watchAsset", "wallet_scanQRCode", "wallet_sendCalls", "wallet_getCapabilities", "wallet_getCallsStatus", "wallet_showCallsStatus"],
    Uu = ["chainChanged", "accountsChanged"],
    L4 = ["chainChanged", "accountsChanged", "message", "disconnect", "connect"];
var $4 = Object.defineProperty,
    j4 = Object.defineProperties,
    z4 = Object.getOwnPropertyDescriptors,
    e0 = Object.getOwnPropertySymbols,
    F4 = Object.prototype.hasOwnProperty,
    H4 = Object.prototype.propertyIsEnumerable,
    r0 = (r, t, e) => t in r ? $4(r, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : r[t] = e,
    Us = (r, t) => {
        for (var e in t || (t = {})) F4.call(t, e) && r0(r, e, t[e]);
        if (e0)
            for (var e of e0(t)) H4.call(t, e) && r0(r, e, t[e]);
        return r
    },
    bu = (r, t) => j4(r, z4(t));

function Pc(r) {
    return Number(r[0].split(":")[1])
}

function sc(r) {
    return `0x${r.toString(16)}`
}

function K4(r) {
    const {
        chains: t,
        optionalChains: e,
        methods: n,
        optionalMethods: o,
        events: a,
        optionalEvents: h,
        rpcMap: g
    } = r;
    if (!tn(t)) throw new Error("Invalid chains");
    const b = {
            chains: t,
            methods: n || Bu,
            events: a || Uu,
            rpcMap: Us({}, t.length ? {
                [Pc(t)]: g[Pc(t)]
            } : {})
        },
        m = a == null ? void 0 : a.filter(k => !Uu.includes(k)),
        _ = n == null ? void 0 : n.filter(k => !Bu.includes(k));
    if (!e && !h && !o && !(m != null && m.length) && !(_ != null && _.length)) return {
        required: t.length ? b : void 0
    };
    const S = (m == null ? void 0 : m.length) && (_ == null ? void 0 : _.length) || !e,
        B = {
            chains: [...new Set(S ? b.chains.concat(e || []) : e)],
            methods: [...new Set(b.methods.concat(o != null && o.length ? o : k4))],
            events: [...new Set(b.events.concat(h != null && h.length ? h : L4))],
            rpcMap: g
        };
    return {
        required: t.length ? b : void 0,
        optional: e.length ? B : void 0
    }
}
class sl {
    constructor() {
        this.events = new wi.EventEmitter, this.namespace = "eip155", this.accounts = [], this.chainId = 1, this.STORAGE_KEY = B4, this.on = (t, e) => (this.events.on(t, e), this), this.once = (t, e) => (this.events.once(t, e), this), this.removeListener = (t, e) => (this.events.removeListener(t, e), this), this.off = (t, e) => (this.events.off(t, e), this), this.parseAccount = t => this.isCompatibleChainId(t) ? this.parseAccountId(t).address : t, this.signer = {}, this.rpc = {}
    }
    static async init(t) {
        const e = new sl;
        return await e.initialize(t), e
    }
    async request(t, e) {
        return await this.signer.request(t, this.formatChainId(this.chainId), e)
    }
    sendAsync(t, e, n) {
        this.signer.sendAsync(t, e, this.formatChainId(this.chainId), n)
    }
    get connected() {
        return this.signer.client ? this.signer.client.core.relayer.connected : !1
    }
    get connecting() {
        return this.signer.client ? this.signer.client.core.relayer.connecting : !1
    }
    async enable() {
        return this.session || await this.connect(), await this.request({
            method: "eth_requestAccounts"
        })
    }
    async connect(t) {
        if (!this.signer.client) throw new Error("Provider not initialized. Call init() first");
        this.loadConnectOpts(t);
        const {
            required: e,
            optional: n
        } = K4(this.rpc);
        try {
            const o = await new Promise(async (h, g) => {
                var b;
                this.rpc.showQrModal && ((b = this.modal) == null || b.subscribeModal(m => {
                    !m.open && !this.signer.session && (this.signer.abortPairingAttempt(), g(new Error("Connection request reset. Please try again.")))
                })), await this.signer.connect(bu(Us({
                    namespaces: Us({}, e && {
                        [this.namespace]: e
                    })
                }, n && {
                    optionalNamespaces: {
                        [this.namespace]: n
                    }
                }), {
                    pairingTopic: t == null ? void 0 : t.pairingTopic
                })).then(m => {
                    h(m)
                }).catch(m => {
                    g(new Error(m.message))
                })
            });
            if (!o) return;
            const a = Td(o.namespaces, [this.namespace]);
            this.setChainIds(this.rpc.chains.length ? this.rpc.chains : a), this.setAccounts(a), this.events.emit("connect", {
                chainId: sc(this.chainId)
            })
        } catch (o) {
            throw this.signer.logger.error(o), o
        } finally {
            this.modal && this.modal.closeModal()
        }
    }
    async authenticate(t) {
        if (!this.signer.client) throw new Error("Provider not initialized. Call init() first");
        this.loadConnectOpts({
            chains: t == null ? void 0 : t.chains
        });
        try {
            const e = await new Promise(async (o, a) => {
                    var h;
                    this.rpc.showQrModal && ((h = this.modal) == null || h.subscribeModal(g => {
                        !g.open && !this.signer.session && (this.signer.abortPairingAttempt(), a(new Error("Connection request reset. Please try again.")))
                    })), await this.signer.authenticate(bu(Us({}, t), {
                        chains: this.rpc.chains
                    })).then(g => {
                        o(g)
                    }).catch(g => {
                        a(new Error(g.message))
                    })
                }),
                n = e.session;
            if (n) {
                const o = Td(n.namespaces, [this.namespace]);
                this.setChainIds(this.rpc.chains.length ? this.rpc.chains : o), this.setAccounts(o), this.events.emit("connect", {
                    chainId: sc(this.chainId)
                })
            }
            return e
        } catch (e) {
            throw this.signer.logger.error(e), e
        } finally {
            this.modal && this.modal.closeModal()
        }
    }
    async disconnect() {
        this.session && await this.signer.disconnect(), this.reset()
    }
    get isWalletConnect() {
        return !0
    }
    get session() {
        return this.signer.session
    }
    registerEventListeners() {
        this.signer.on("session_event", t => {
            const {
                params: e
            } = t, {
                event: n
            } = e;
            n.name === "accountsChanged" ? (this.accounts = this.parseAccounts(n.data), this.events.emit("accountsChanged", this.accounts)) : n.name === "chainChanged" ? this.setChainId(this.formatChainId(n.data)) : this.events.emit(n.name, n.data), this.events.emit("session_event", t)
        }), this.signer.on("chainChanged", t => {
            const e = parseInt(t);
            this.chainId = e, this.events.emit("chainChanged", sc(this.chainId)), this.persist()
        }), this.signer.on("session_update", t => {
            this.events.emit("session_update", t)
        }), this.signer.on("session_delete", t => {
            this.reset(), this.events.emit("session_delete", t), this.events.emit("disconnect", bu(Us({}, Ne("USER_DISCONNECTED")), {
                data: t.topic,
                name: "USER_DISCONNECTED"
            }))
        }), this.signer.on("display_uri", t => {
            var e, n;
            this.rpc.showQrModal && ((e = this.modal) == null || e.closeModal(), (n = this.modal) == null || n.openModal({
                uri: t
            })), this.events.emit("display_uri", t)
        })
    }
    switchEthereumChain(t) {
        this.request({
            method: "wallet_switchEthereumChain",
            params: [{
                chainId: t.toString(16)
            }]
        })
    }
    isCompatibleChainId(t) {
        return typeof t == "string" ? t.startsWith(`${this.namespace}:`) : !1
    }
    formatChainId(t) {
        return `${this.namespace}:${t}`
    }
    parseChainId(t) {
        return Number(t.split(":")[1])
    }
    setChainIds(t) {
        const e = t.filter(n => this.isCompatibleChainId(n)).map(n => this.parseChainId(n));
        e.length && (this.chainId = e[0], this.events.emit("chainChanged", sc(this.chainId)), this.persist())
    }
    setChainId(t) {
        if (this.isCompatibleChainId(t)) {
            const e = this.parseChainId(t);
            this.chainId = e, this.switchEthereumChain(e)
        }
    }
    parseAccountId(t) {
        const [e, n, o] = t.split(":");
        return {
            chainId: `${e}:${n}`,
            address: o
        }
    }
    setAccounts(t) {
        this.accounts = t.filter(e => this.parseChainId(this.parseAccountId(e).chainId) === this.chainId).map(e => this.parseAccountId(e).address), this.events.emit("accountsChanged", this.accounts)
    }
    getRpcConfig(t) {
        var e, n;
        const o = (e = t == null ? void 0 : t.chains) != null ? e : [],
            a = (n = t == null ? void 0 : t.optionalChains) != null ? n : [],
            h = o.concat(a);
        if (!h.length) throw new Error("No chains specified in either `chains` or `optionalChains`");
        const g = o.length ? (t == null ? void 0 : t.methods) || Bu : [],
            b = o.length ? (t == null ? void 0 : t.events) || Uu : [],
            m = (t == null ? void 0 : t.optionalMethods) || [],
            _ = (t == null ? void 0 : t.optionalEvents) || [],
            S = (t == null ? void 0 : t.rpcMap) || this.buildRpcMap(h, t.projectId),
            B = (t == null ? void 0 : t.qrModalOptions) || void 0;
        return {
            chains: o == null ? void 0 : o.map(k => this.formatChainId(k)),
            optionalChains: a.map(k => this.formatChainId(k)),
            methods: g,
            events: b,
            optionalMethods: m,
            optionalEvents: _,
            rpcMap: S,
            showQrModal: !!(t != null && t.showQrModal),
            qrModalOptions: B,
            projectId: t.projectId,
            metadata: t.metadata
        }
    }
    buildRpcMap(t, e) {
        const n = {};
        return t.forEach(o => {
            n[o] = this.getRpcUrl(o, e)
        }), n
    }
    async initialize(t) {
        if (this.rpc = this.getRpcConfig(t), this.chainId = this.rpc.chains.length ? Pc(this.rpc.chains) : Pc(this.rpc.optionalChains), this.signer = await T4.init({
                projectId: this.rpc.projectId,
                metadata: this.rpc.metadata,
                disableProviderPing: t.disableProviderPing,
                relayUrl: t.relayUrl,
                storageOptions: t.storageOptions
            }), this.registerEventListeners(), await this.loadPersistedSession(), this.rpc.showQrModal) {
            let e;
            try {
                const {
                    WalletConnectModal: n
                } = await m2(() =>
                    import ("./index-CD0hpVXv.js").then(o => o.i), __vite__mapDeps([0, 1, 2]));
                e = n
            } catch {
                throw new Error("To use QR modal, please install @walletconnect/modal package")
            }
            if (e) try {
                this.modal = new e(Us({
                    projectId: this.rpc.projectId
                }, this.rpc.qrModalOptions))
            } catch (n) {
                throw this.signer.logger.error(n), new Error("Could not generate WalletConnectModal Instance")
            }
        }
    }
    loadConnectOpts(t) {
        if (!t) return;
        const {
            chains: e,
            optionalChains: n,
            rpcMap: o
        } = t;
        e && tn(e) && (this.rpc.chains = e.map(a => this.formatChainId(a)), e.forEach(a => {
            this.rpc.rpcMap[a] = (o == null ? void 0 : o[a]) || this.getRpcUrl(a)
        })), n && tn(n) && (this.rpc.optionalChains = [], this.rpc.optionalChains = n == null ? void 0 : n.map(a => this.formatChainId(a)), n.forEach(a => {
            this.rpc.rpcMap[a] = (o == null ? void 0 : o[a]) || this.getRpcUrl(a)
        }))
    }
    getRpcUrl(t, e) {
        var n;
        return ((n = this.rpc.rpcMap) == null ? void 0 : n[t]) || `${U4}?chainId=eip155:${t}&projectId=${e||this.rpc.projectId}`
    }
    async loadPersistedSession() {
        if (this.session) try {
            const t = await this.signer.client.core.storage.getItem(`${this.STORAGE_KEY}/chainId`),
                e = this.session.namespaces[`${this.namespace}:${t}`] ? this.session.namespaces[`${this.namespace}:${t}`] : this.session.namespaces[this.namespace];
            this.setChainIds(t ? [this.formatChainId(t)] : e == null ? void 0 : e.accounts), this.setAccounts(e == null ? void 0 : e.accounts)
        } catch (t) {
            this.signer.logger.error("Failed to load persisted session, clearing state..."), this.signer.logger.error(t), await this.disconnect().catch(e => this.signer.logger.warn(e))
        }
    }
    reset() {
        this.chainId = 1, this.accounts = []
    }
    persist() {
        this.session && this.signer.client.core.storage.setItem(`${this.STORAGE_KEY}/chainId`, this.chainId)
    }
    parseAccounts(t) {
        return typeof t == "string" || t instanceof String ? [this.parseAccount(t)] : t.map(e => this.parseAccount(e))
    }
}
const mx = sl;
export {
    mx as EthereumProvider, L4 as OPTIONAL_EVENTS, k4 as OPTIONAL_METHODS, Uu as REQUIRED_EVENTS, Bu as REQUIRED_METHODS, sl as
    default
};