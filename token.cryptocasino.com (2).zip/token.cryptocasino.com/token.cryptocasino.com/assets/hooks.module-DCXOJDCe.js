import {
    u as mr,
    q as Ke,
    o as nn,
    v as Pe,
    d as me
} from "./index-B7sV4wI7.js";
import {
    r as an
} from "./___vite-browser-external_commonjs-proxy-C_4t5wKq.js";
const Vn = Object.freeze(Object.defineProperty({
        __proto__: null,
        EventEmitter: mr,
        default: mr
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Qa = Ke(Vn);
var or = {
        exports: {}
    },
    on = nn.EventEmitter,
    Xt, Sr;

function Kn() {
    if (Sr) return Xt;
    Sr = 1;

    function e(R, A) {
        var x = Object.keys(R);
        if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(R);
            A && (s = s.filter(function(p) {
                return Object.getOwnPropertyDescriptor(R, p).enumerable
            })), x.push.apply(x, s)
        }
        return x
    }

    function t(R) {
        for (var A = 1; A < arguments.length; A++) {
            var x = arguments[A] != null ? arguments[A] : {};
            A % 2 ? e(Object(x), !0).forEach(function(s) {
                r(R, s, x[s])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(R, Object.getOwnPropertyDescriptors(x)) : e(Object(x)).forEach(function(s) {
                Object.defineProperty(R, s, Object.getOwnPropertyDescriptor(x, s))
            })
        }
        return R
    }

    function r(R, A, x) {
        return A = l(A), A in R ? Object.defineProperty(R, A, {
            value: x,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : R[A] = x, R
    }

    function n(R, A) {
        if (!(R instanceof A)) throw new TypeError("Cannot call a class as a function")
    }

    function i(R, A) {
        for (var x = 0; x < A.length; x++) {
            var s = A[x];
            s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(R, l(s.key), s)
        }
    }

    function f(R, A, x) {
        return A && i(R.prototype, A), Object.defineProperty(R, "prototype", {
            writable: !1
        }), R
    }

    function l(R) {
        var A = h(R, "string");
        return typeof A == "symbol" ? A : String(A)
    }

    function h(R, A) {
        if (typeof R != "object" || R === null) return R;
        var x = R[Symbol.toPrimitive];
        if (x !== void 0) {
            var s = x.call(R, A || "default");
            if (typeof s != "object") return s;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return (A === "string" ? String : Number)(R)
    }
    var _ = Pe,
        b = _.Buffer,
        w = an,
        u = w.inspect,
        m = u && u.custom || "inspect";

    function v(R, A, x) {
        b.prototype.copy.call(R, A, x)
    }
    return Xt = function() {
        function R() {
            n(this, R), this.head = null, this.tail = null, this.length = 0
        }
        return f(R, [{
            key: "push",
            value: function(x) {
                var s = {
                    data: x,
                    next: null
                };
                this.length > 0 ? this.tail.next = s : this.head = s, this.tail = s, ++this.length
            }
        }, {
            key: "unshift",
            value: function(x) {
                var s = {
                    data: x,
                    next: this.head
                };
                this.length === 0 && (this.tail = s), this.head = s, ++this.length
            }
        }, {
            key: "shift",
            value: function() {
                if (this.length !== 0) {
                    var x = this.head.data;
                    return this.length === 1 ? this.head = this.tail = null : this.head = this.head.next, --this.length, x
                }
            }
        }, {
            key: "clear",
            value: function() {
                this.head = this.tail = null, this.length = 0
            }
        }, {
            key: "join",
            value: function(x) {
                if (this.length === 0) return "";
                for (var s = this.head, p = "" + s.data; s = s.next;) p += x + s.data;
                return p
            }
        }, {
            key: "concat",
            value: function(x) {
                if (this.length === 0) return b.alloc(0);
                for (var s = b.allocUnsafe(x >>> 0), p = this.head, y = 0; p;) v(p.data, s, y), y += p.data.length, p = p.next;
                return s
            }
        }, {
            key: "consume",
            value: function(x, s) {
                var p;
                return x < this.head.data.length ? (p = this.head.data.slice(0, x), this.head.data = this.head.data.slice(x)) : x === this.head.data.length ? p = this.shift() : p = s ? this._getString(x) : this._getBuffer(x), p
            }
        }, {
            key: "first",
            value: function() {
                return this.head.data
            }
        }, {
            key: "_getString",
            value: function(x) {
                var s = this.head,
                    p = 1,
                    y = s.data;
                for (x -= y.length; s = s.next;) {
                    var S = s.data,
                        T = x > S.length ? S.length : x;
                    if (T === S.length ? y += S : y += S.slice(0, x), x -= T, x === 0) {
                        T === S.length ? (++p, s.next ? this.head = s.next : this.head = this.tail = null) : (this.head = s, s.data = S.slice(T));
                        break
                    }++p
                }
                return this.length -= p, y
            }
        }, {
            key: "_getBuffer",
            value: function(x) {
                var s = b.allocUnsafe(x),
                    p = this.head,
                    y = 1;
                for (p.data.copy(s), x -= p.data.length; p = p.next;) {
                    var S = p.data,
                        T = x > S.length ? S.length : x;
                    if (S.copy(s, s.length - x, 0, T), x -= T, x === 0) {
                        T === S.length ? (++y, p.next ? this.head = p.next : this.head = this.tail = null) : (this.head = p, p.data = S.slice(T));
                        break
                    }++y
                }
                return this.length -= y, s
            }
        }, {
            key: m,
            value: function(x, s) {
                return u(this, t(t({}, s), {}, {
                    depth: 0,
                    customInspect: !1
                }))
            }
        }]), R
    }(), Xt
}

function Yn(e, t) {
    var r = this,
        n = this._readableState && this._readableState.destroyed,
        i = this._writableState && this._writableState.destroyed;
    return n || i ? (t ? t(e) : e && (this._writableState ? this._writableState.errorEmitted || (this._writableState.errorEmitted = !0, process.nextTick(fr, this, e)) : process.nextTick(fr, this, e)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(e || null, function(f) {
        !t && f ? r._writableState ? r._writableState.errorEmitted ? process.nextTick(We, r) : (r._writableState.errorEmitted = !0, process.nextTick(Rr, r, f)) : process.nextTick(Rr, r, f) : t ? (process.nextTick(We, r), t(f)) : process.nextTick(We, r)
    }), this)
}

function Rr(e, t) {
    fr(e, t), We(e)
}

function We(e) {
    e._writableState && !e._writableState.emitClose || e._readableState && !e._readableState.emitClose || e.emit("close")
}

function Xn() {
    this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1)
}

function fr(e, t) {
    e.emit("error", t)
}

function Jn(e, t) {
    var r = e._readableState,
        n = e._writableState;
    r && r.autoDestroy || n && n.autoDestroy ? e.destroy(t) : e.emit("error", t)
}
var fn = {
        destroy: Yn,
        undestroy: Xn,
        errorOrDestroy: Jn
    },
    be = {};

function Qn(e, t) {
    e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
}
var sn = {};

function X(e, t, r) {
    r || (r = Error);

    function n(f, l, h) {
        return typeof t == "string" ? t : t(f, l, h)
    }
    var i = function(f) {
        Qn(l, f);

        function l(h, _, b) {
            return f.call(this, n(h, _, b)) || this
        }
        return l
    }(r);
    i.prototype.name = r.name, i.prototype.code = e, sn[e] = i
}

function Tr(e, t) {
    if (Array.isArray(e)) {
        var r = e.length;
        return e = e.map(function(n) {
            return String(n)
        }), r > 2 ? "one of ".concat(t, " ").concat(e.slice(0, r - 1).join(", "), ", or ") + e[r - 1] : r === 2 ? "one of ".concat(t, " ").concat(e[0], " or ").concat(e[1]) : "of ".concat(t, " ").concat(e[0])
    } else return "of ".concat(t, " ").concat(String(e))
}

function Zn(e, t, r) {
    return e.substr(0, t.length) === t
}

function ei(e, t, r) {
    return (r === void 0 || r > e.length) && (r = e.length), e.substring(r - t.length, r) === t
}

function ti(e, t, r) {
    return typeof r != "number" && (r = 0), r + t.length > e.length ? !1 : e.indexOf(t, r) !== -1
}
X("ERR_INVALID_OPT_VALUE", function(e, t) {
    return 'The value "' + t + '" is invalid for option "' + e + '"'
}, TypeError);
X("ERR_INVALID_ARG_TYPE", function(e, t, r) {
    var n;
    typeof t == "string" && Zn(t, "not ") ? (n = "must not be", t = t.replace(/^not /, "")) : n = "must be";
    var i;
    if (ei(e, " argument")) i = "The ".concat(e, " ").concat(n, " ").concat(Tr(t, "type"));
    else {
        var f = ti(e, ".") ? "property" : "argument";
        i = 'The "'.concat(e, '" ').concat(f, " ").concat(n, " ").concat(Tr(t, "type"))
    }
    return i += ". Received type ".concat(typeof r), i
}, TypeError);
X("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF");
X("ERR_METHOD_NOT_IMPLEMENTED", function(e) {
    return "The " + e + " method is not implemented"
});
X("ERR_STREAM_PREMATURE_CLOSE", "Premature close");
X("ERR_STREAM_DESTROYED", function(e) {
    return "Cannot call " + e + " after a stream was destroyed"
});
X("ERR_MULTIPLE_CALLBACK", "Callback called multiple times");
X("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable");
X("ERR_STREAM_WRITE_AFTER_END", "write after end");
X("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError);
X("ERR_UNKNOWN_ENCODING", function(e) {
    return "Unknown encoding: " + e
}, TypeError);
X("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event");
be.codes = sn;
var ri = be.codes.ERR_INVALID_OPT_VALUE;

function ni(e, t, r) {
    return e.highWaterMark != null ? e.highWaterMark : t ? e[r] : null
}

function ii(e, t, r, n) {
    var i = ni(t, n, r);
    if (i != null) {
        if (!(isFinite(i) && Math.floor(i) === i) || i < 0) {
            var f = n ? r : "highWaterMark";
            throw new ri(f, i)
        }
        return Math.floor(i)
    }
    return e.objectMode ? 16 : 16 * 1024
}
var ln = {
        getHighWaterMark: ii
    },
    sr = {
        exports: {}
    };
typeof Object.create == "function" ? sr.exports = function(t, r) {
    r && (t.super_ = r, t.prototype = Object.create(r.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }))
} : sr.exports = function(t, r) {
    if (r) {
        t.super_ = r;
        var n = function() {};
        n.prototype = r.prototype, t.prototype = new n, t.prototype.constructor = t
    }
};
var J = sr.exports,
    ai = oi;

function oi(e, t) {
    if (Jt("noDeprecation")) return e;
    var r = !1;

    function n() {
        if (!r) {
            if (Jt("throwDeprecation")) throw new Error(t);
            Jt("traceDeprecation") ? console.trace(t) : console.warn(t), r = !0
        }
        return e.apply(this, arguments)
    }
    return n
}

function Jt(e) {
    try {
        if (!me.localStorage) return !1
    } catch {
        return !1
    }
    var t = me.localStorage[e];
    return t == null ? !1 : String(t).toLowerCase() === "true"
}
var Qt, Ar;

function un() {
    if (Ar) return Qt;
    Ar = 1, Qt = D;

    function e(d) {
        var c = this;
        this.next = null, this.entry = null, this.finish = function() {
            ne(c, d)
        }
    }
    var t;
    D.WritableState = C;
    var r = {
            deprecate: ai
        },
        n = on,
        i = Pe.Buffer,
        f = (typeof me < "u" ? me : typeof window < "u" ? window : typeof self < "u" ? self : {}).Uint8Array || function() {};

    function l(d) {
        return i.from(d)
    }

    function h(d) {
        return i.isBuffer(d) || d instanceof f
    }
    var _ = fn,
        b = ln,
        w = b.getHighWaterMark,
        u = be.codes,
        m = u.ERR_INVALID_ARG_TYPE,
        v = u.ERR_METHOD_NOT_IMPLEMENTED,
        R = u.ERR_MULTIPLE_CALLBACK,
        A = u.ERR_STREAM_CANNOT_PIPE,
        x = u.ERR_STREAM_DESTROYED,
        s = u.ERR_STREAM_NULL_VALUES,
        p = u.ERR_STREAM_WRITE_AFTER_END,
        y = u.ERR_UNKNOWN_ENCODING,
        S = _.errorOrDestroy;
    J(D, n);

    function T() {}

    function C(d, c, E) {
        t = t || Se(), d = d || {}, typeof E != "boolean" && (E = c instanceof t), this.objectMode = !!d.objectMode, E && (this.objectMode = this.objectMode || !!d.writableObjectMode), this.highWaterMark = w(this, d, "writableHighWaterMark", E), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
        var k = d.decodeStrings === !1;
        this.decodeStrings = !k, this.defaultEncoding = d.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(P) {
            le(c, P)
        }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.emitClose = d.emitClose !== !1, this.autoDestroy = !!d.autoDestroy, this.bufferedRequestCount = 0, this.corkedRequestsFree = new e(this)
    }
    C.prototype.getBuffer = function() {
            for (var c = this.bufferedRequest, E = []; c;) E.push(c), c = c.next;
            return E
        },
        function() {
            try {
                Object.defineProperty(C.prototype, "buffer", {
                    get: r.deprecate(function() {
                        return this.getBuffer()
                    }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
                })
            } catch {}
        }();
    var O;
    typeof Symbol == "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] == "function" ? (O = Function.prototype[Symbol.hasInstance], Object.defineProperty(D, Symbol.hasInstance, {
        value: function(c) {
            return O.call(this, c) ? !0 : this !== D ? !1 : c && c._writableState instanceof C
        }
    })) : O = function(c) {
        return c instanceof this
    };

    function D(d) {
        t = t || Se();
        var c = this instanceof t;
        if (!c && !O.call(D, this)) return new D(d);
        this._writableState = new C(d, this, c), this.writable = !0, d && (typeof d.write == "function" && (this._write = d.write), typeof d.writev == "function" && (this._writev = d.writev), typeof d.destroy == "function" && (this._destroy = d.destroy), typeof d.final == "function" && (this._final = d.final)), n.call(this)
    }
    D.prototype.pipe = function() {
        S(this, new A)
    };

    function M(d, c) {
        var E = new p;
        S(d, E), process.nextTick(c, E)
    }

    function $(d, c, E, k) {
        var P;
        return E === null ? P = new s : typeof E != "string" && !c.objectMode && (P = new m("chunk", ["string", "Buffer"], E)), P ? (S(d, P), process.nextTick(k, P), !1) : !0
    }
    D.prototype.write = function(d, c, E) {
        var k = this._writableState,
            P = !1,
            a = !k.objectMode && h(d);
        return a && !i.isBuffer(d) && (d = l(d)), typeof c == "function" && (E = c, c = null), a ? c = "buffer" : c || (c = k.defaultEncoding), typeof E != "function" && (E = T), k.ending ? M(this, E) : (a || $(this, k, d, E)) && (k.pendingcb++, P = Z(this, k, a, d, c, E)), P
    }, D.prototype.cork = function() {
        this._writableState.corked++
    }, D.prototype.uncork = function() {
        var d = this._writableState;
        d.corked && (d.corked--, !d.writing && !d.corked && !d.bufferProcessing && d.bufferedRequest && Y(this, d))
    }, D.prototype.setDefaultEncoding = function(c) {
        if (typeof c == "string" && (c = c.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((c + "").toLowerCase()) > -1)) throw new y(c);
        return this._writableState.defaultEncoding = c, this
    }, Object.defineProperty(D.prototype, "writableBuffer", {
        enumerable: !1,
        get: function() {
            return this._writableState && this._writableState.getBuffer()
        }
    });

    function W(d, c, E) {
        return !d.objectMode && d.decodeStrings !== !1 && typeof c == "string" && (c = i.from(c, E)), c
    }
    Object.defineProperty(D.prototype, "writableHighWaterMark", {
        enumerable: !1,
        get: function() {
            return this._writableState.highWaterMark
        }
    });

    function Z(d, c, E, k, P, a) {
        if (!E) {
            var o = W(c, k, P);
            k !== o && (E = !0, P = "buffer", k = o)
        }
        var g = c.objectMode ? 1 : k.length;
        c.length += g;
        var B = c.length < c.highWaterMark;
        if (B || (c.needDrain = !0), c.writing || c.corked) {
            var F = c.lastBufferedRequest;
            c.lastBufferedRequest = {
                chunk: k,
                encoding: P,
                isBuf: E,
                callback: a,
                next: null
            }, F ? F.next = c.lastBufferedRequest : c.bufferedRequest = c.lastBufferedRequest, c.bufferedRequestCount += 1
        } else q(d, c, !1, g, k, P, a);
        return B
    }

    function q(d, c, E, k, P, a, o) {
        c.writelen = k, c.writecb = o, c.writing = !0, c.sync = !0, c.destroyed ? c.onwrite(new x("write")) : E ? d._writev(P, c.onwrite) : d._write(P, a, c.onwrite), c.sync = !1
    }

    function z(d, c, E, k, P) {
        --c.pendingcb, E ? (process.nextTick(P, k), process.nextTick(V, d, c), d._writableState.errorEmitted = !0, S(d, k)) : (P(k), d._writableState.errorEmitted = !0, S(d, k), V(d, c))
    }

    function G(d) {
        d.writing = !1, d.writecb = null, d.length -= d.writelen, d.writelen = 0
    }

    function le(d, c) {
        var E = d._writableState,
            k = E.sync,
            P = E.writecb;
        if (typeof P != "function") throw new R;
        if (G(E), c) z(d, E, k, c, P);
        else {
            var a = te(E) || d.destroyed;
            !a && !E.corked && !E.bufferProcessing && E.bufferedRequest && Y(d, E), k ? process.nextTick(K, d, E, a, P) : K(d, E, a, P)
        }
    }

    function K(d, c, E, k) {
        E || ee(d, c), c.pendingcb--, k(), V(d, c)
    }

    function ee(d, c) {
        c.length === 0 && c.needDrain && (c.needDrain = !1, d.emit("drain"))
    }

    function Y(d, c) {
        c.bufferProcessing = !0;
        var E = c.bufferedRequest;
        if (d._writev && E && E.next) {
            var k = c.bufferedRequestCount,
                P = new Array(k),
                a = c.corkedRequestsFree;
            a.entry = E;
            for (var o = 0, g = !0; E;) P[o] = E, E.isBuf || (g = !1), E = E.next, o += 1;
            P.allBuffers = g, q(d, c, !0, c.length, P, "", a.finish), c.pendingcb++, c.lastBufferedRequest = null, a.next ? (c.corkedRequestsFree = a.next, a.next = null) : c.corkedRequestsFree = new e(c), c.bufferedRequestCount = 0
        } else {
            for (; E;) {
                var B = E.chunk,
                    F = E.encoding,
                    N = E.callback,
                    L = c.objectMode ? 1 : B.length;
                if (q(d, c, !1, L, B, F, N), E = E.next, c.bufferedRequestCount--, c.writing) break
            }
            E === null && (c.lastBufferedRequest = null)
        }
        c.bufferedRequest = E, c.bufferProcessing = !1
    }
    D.prototype._write = function(d, c, E) {
        E(new v("_write()"))
    }, D.prototype._writev = null, D.prototype.end = function(d, c, E) {
        var k = this._writableState;
        return typeof d == "function" ? (E = d, d = null, c = null) : typeof c == "function" && (E = c, c = null), d != null && this.write(d, c), k.corked && (k.corked = 1, this.uncork()), k.ending || he(this, k, E), this
    }, Object.defineProperty(D.prototype, "writableLength", {
        enumerable: !1,
        get: function() {
            return this._writableState.length
        }
    });

    function te(d) {
        return d.ending && d.length === 0 && d.bufferedRequest === null && !d.finished && !d.writing
    }

    function ue(d, c) {
        d._final(function(E) {
            c.pendingcb--, E && S(d, E), c.prefinished = !0, d.emit("prefinish"), V(d, c)
        })
    }

    function re(d, c) {
        !c.prefinished && !c.finalCalled && (typeof d._final == "function" && !c.destroyed ? (c.pendingcb++, c.finalCalled = !0, process.nextTick(ue, d, c)) : (c.prefinished = !0, d.emit("prefinish")))
    }

    function V(d, c) {
        var E = te(c);
        if (E && (re(d, c), c.pendingcb === 0 && (c.finished = !0, d.emit("finish"), c.autoDestroy))) {
            var k = d._readableState;
            (!k || k.autoDestroy && k.endEmitted) && d.destroy()
        }
        return E
    }

    function he(d, c, E) {
        c.ending = !0, V(d, c), E && (c.finished ? process.nextTick(E) : d.once("finish", E)), c.ended = !0, d.writable = !1
    }

    function ne(d, c, E) {
        var k = d.entry;
        for (d.entry = null; k;) {
            var P = k.callback;
            c.pendingcb--, P(E), k = k.next
        }
        c.corkedRequestsFree.next = d
    }
    return Object.defineProperty(D.prototype, "destroyed", {
        enumerable: !1,
        get: function() {
            return this._writableState === void 0 ? !1 : this._writableState.destroyed
        },
        set: function(c) {
            this._writableState && (this._writableState.destroyed = c)
        }
    }), D.prototype.destroy = _.destroy, D.prototype._undestroy = _.undestroy, D.prototype._destroy = function(d, c) {
        c(d)
    }, Qt
}
var Zt, Br;

function Se() {
    if (Br) return Zt;
    Br = 1;
    var e = Object.keys || function(b) {
        var w = [];
        for (var u in b) w.push(u);
        return w
    };
    Zt = l;
    var t = cn(),
        r = un();
    J(l, t);
    for (var n = e(r.prototype), i = 0; i < n.length; i++) {
        var f = n[i];
        l.prototype[f] || (l.prototype[f] = r.prototype[f])
    }

    function l(b) {
        if (!(this instanceof l)) return new l(b);
        t.call(this, b), r.call(this, b), this.allowHalfOpen = !0, b && (b.readable === !1 && (this.readable = !1), b.writable === !1 && (this.writable = !1), b.allowHalfOpen === !1 && (this.allowHalfOpen = !1, this.once("end", h)))
    }
    Object.defineProperty(l.prototype, "writableHighWaterMark", {
        enumerable: !1,
        get: function() {
            return this._writableState.highWaterMark
        }
    }), Object.defineProperty(l.prototype, "writableBuffer", {
        enumerable: !1,
        get: function() {
            return this._writableState && this._writableState.getBuffer()
        }
    }), Object.defineProperty(l.prototype, "writableLength", {
        enumerable: !1,
        get: function() {
            return this._writableState.length
        }
    });

    function h() {
        this._writableState.ended || process.nextTick(_, this)
    }

    function _(b) {
        b.end()
    }
    return Object.defineProperty(l.prototype, "destroyed", {
        enumerable: !1,
        get: function() {
            return this._readableState === void 0 || this._writableState === void 0 ? !1 : this._readableState.destroyed && this._writableState.destroyed
        },
        set: function(w) {
            this._readableState === void 0 || this._writableState === void 0 || (this._readableState.destroyed = w, this._writableState.destroyed = w)
        }
    }), Zt
}
var er = {},
    qe = {
        exports: {}
    }; /*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
var Cr;

function fi() {
    return Cr || (Cr = 1, function(e, t) {
        var r = Pe,
            n = r.Buffer;

        function i(l, h) {
            for (var _ in l) h[_] = l[_]
        }
        n.from && n.alloc && n.allocUnsafe && n.allocUnsafeSlow ? e.exports = r : (i(r, t), t.Buffer = f);

        function f(l, h, _) {
            return n(l, h, _)
        }
        f.prototype = Object.create(n.prototype), i(n, f), f.from = function(l, h, _) {
            if (typeof l == "number") throw new TypeError("Argument must not be a number");
            return n(l, h, _)
        }, f.alloc = function(l, h, _) {
            if (typeof l != "number") throw new TypeError("Argument must be a number");
            var b = n(l);
            return h !== void 0 ? typeof _ == "string" ? b.fill(h, _) : b.fill(h) : b.fill(0), b
        }, f.allocUnsafe = function(l) {
            if (typeof l != "number") throw new TypeError("Argument must be a number");
            return n(l)
        }, f.allocUnsafeSlow = function(l) {
            if (typeof l != "number") throw new TypeError("Argument must be a number");
            return r.SlowBuffer(l)
        }
    }(qe, qe.exports)), qe.exports
}
var kr;

function Mr() {
    if (kr) return er;
    kr = 1;
    var e = fi().Buffer,
        t = e.isEncoding || function(s) {
            switch (s = "" + s, s && s.toLowerCase()) {
                case "hex":
                case "utf8":
                case "utf-8":
                case "ascii":
                case "binary":
                case "base64":
                case "ucs2":
                case "ucs-2":
                case "utf16le":
                case "utf-16le":
                case "raw":
                    return !0;
                default:
                    return !1
            }
        };

    function r(s) {
        if (!s) return "utf8";
        for (var p;;) switch (s) {
            case "utf8":
            case "utf-8":
                return "utf8";
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
                return "utf16le";
            case "latin1":
            case "binary":
                return "latin1";
            case "base64":
            case "ascii":
            case "hex":
                return s;
            default:
                if (p) return;
                s = ("" + s).toLowerCase(), p = !0
        }
    }

    function n(s) {
        var p = r(s);
        if (typeof p != "string" && (e.isEncoding === t || !t(s))) throw new Error("Unknown encoding: " + s);
        return p || s
    }
    er.StringDecoder = i;

    function i(s) {
        this.encoding = n(s);
        var p;
        switch (this.encoding) {
            case "utf16le":
                this.text = u, this.end = m, p = 4;
                break;
            case "utf8":
                this.fillLast = _, p = 4;
                break;
            case "base64":
                this.text = v, this.end = R, p = 3;
                break;
            default:
                this.write = A, this.end = x;
                return
        }
        this.lastNeed = 0, this.lastTotal = 0, this.lastChar = e.allocUnsafe(p)
    }
    i.prototype.write = function(s) {
        if (s.length === 0) return "";
        var p, y;
        if (this.lastNeed) {
            if (p = this.fillLast(s), p === void 0) return "";
            y = this.lastNeed, this.lastNeed = 0
        } else y = 0;
        return y < s.length ? p ? p + this.text(s, y) : this.text(s, y) : p || ""
    }, i.prototype.end = w, i.prototype.text = b, i.prototype.fillLast = function(s) {
        if (this.lastNeed <= s.length) return s.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
        s.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, s.length), this.lastNeed -= s.length
    };

    function f(s) {
        return s <= 127 ? 0 : s >> 5 === 6 ? 2 : s >> 4 === 14 ? 3 : s >> 3 === 30 ? 4 : s >> 6 === 2 ? -1 : -2
    }

    function l(s, p, y) {
        var S = p.length - 1;
        if (S < y) return 0;
        var T = f(p[S]);
        return T >= 0 ? (T > 0 && (s.lastNeed = T - 1), T) : --S < y || T === -2 ? 0 : (T = f(p[S]), T >= 0 ? (T > 0 && (s.lastNeed = T - 2), T) : --S < y || T === -2 ? 0 : (T = f(p[S]), T >= 0 ? (T > 0 && (T === 2 ? T = 0 : s.lastNeed = T - 3), T) : 0))
    }

    function h(s, p, y) {
        if ((p[0] & 192) !== 128) return s.lastNeed = 0, "�";
        if (s.lastNeed > 1 && p.length > 1) {
            if ((p[1] & 192) !== 128) return s.lastNeed = 1, "�";
            if (s.lastNeed > 2 && p.length > 2 && (p[2] & 192) !== 128) return s.lastNeed = 2, "�"
        }
    }

    function _(s) {
        var p = this.lastTotal - this.lastNeed,
            y = h(this, s);
        if (y !== void 0) return y;
        if (this.lastNeed <= s.length) return s.copy(this.lastChar, p, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
        s.copy(this.lastChar, p, 0, s.length), this.lastNeed -= s.length
    }

    function b(s, p) {
        var y = l(this, s, p);
        if (!this.lastNeed) return s.toString("utf8", p);
        this.lastTotal = y;
        var S = s.length - (y - this.lastNeed);
        return s.copy(this.lastChar, 0, S), s.toString("utf8", p, S)
    }

    function w(s) {
        var p = s && s.length ? this.write(s) : "";
        return this.lastNeed ? p + "�" : p
    }

    function u(s, p) {
        if ((s.length - p) % 2 === 0) {
            var y = s.toString("utf16le", p);
            if (y) {
                var S = y.charCodeAt(y.length - 1);
                if (S >= 55296 && S <= 56319) return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = s[s.length - 2], this.lastChar[1] = s[s.length - 1], y.slice(0, -1)
            }
            return y
        }
        return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = s[s.length - 1], s.toString("utf16le", p, s.length - 1)
    }

    function m(s) {
        var p = s && s.length ? this.write(s) : "";
        if (this.lastNeed) {
            var y = this.lastTotal - this.lastNeed;
            return p + this.lastChar.toString("utf16le", 0, y)
        }
        return p
    }

    function v(s, p) {
        var y = (s.length - p) % 3;
        return y === 0 ? s.toString("base64", p) : (this.lastNeed = 3 - y, this.lastTotal = 3, y === 1 ? this.lastChar[0] = s[s.length - 1] : (this.lastChar[0] = s[s.length - 2], this.lastChar[1] = s[s.length - 1]), s.toString("base64", p, s.length - y))
    }

    function R(s) {
        var p = s && s.length ? this.write(s) : "";
        return this.lastNeed ? p + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : p
    }

    function A(s) {
        return s.toString(this.encoding)
    }

    function x(s) {
        return s && s.length ? this.write(s) : ""
    }
    return er
}
var Dr = be.codes.ERR_STREAM_PREMATURE_CLOSE;

function si(e) {
    var t = !1;
    return function() {
        if (!t) {
            t = !0;
            for (var r = arguments.length, n = new Array(r), i = 0; i < r; i++) n[i] = arguments[i];
            e.apply(this, n)
        }
    }
}

function li() {}

function ui(e) {
    return e.setHeader && typeof e.abort == "function"
}

function hn(e, t, r) {
    if (typeof t == "function") return hn(e, null, t);
    t || (t = {}), r = si(r || li);
    var n = t.readable || t.readable !== !1 && e.readable,
        i = t.writable || t.writable !== !1 && e.writable,
        f = function() {
            e.writable || h()
        },
        l = e._writableState && e._writableState.finished,
        h = function() {
            i = !1, l = !0, n || r.call(e)
        },
        _ = e._readableState && e._readableState.endEmitted,
        b = function() {
            n = !1, _ = !0, i || r.call(e)
        },
        w = function(R) {
            r.call(e, R)
        },
        u = function() {
            var R;
            if (n && !_) return (!e._readableState || !e._readableState.ended) && (R = new Dr), r.call(e, R);
            if (i && !l) return (!e._writableState || !e._writableState.ended) && (R = new Dr), r.call(e, R)
        },
        m = function() {
            e.req.on("finish", h)
        };
    return ui(e) ? (e.on("complete", h), e.on("abort", u), e.req ? m() : e.on("request", m)) : i && !e._writableState && (e.on("end", f), e.on("close", f)), e.on("end", b), e.on("finish", h), t.error !== !1 && e.on("error", w), e.on("close", u),
        function() {
            e.removeListener("complete", h), e.removeListener("abort", u), e.removeListener("request", m), e.req && e.req.removeListener("finish", h), e.removeListener("end", f), e.removeListener("close", f), e.removeListener("finish", h), e.removeListener("end", b), e.removeListener("error", w), e.removeListener("close", u)
        }
}
var vr = hn,
    tr, Nr;

function hi() {
    if (Nr) return tr;
    Nr = 1;
    var e;

    function t(y, S, T) {
        return S = r(S), S in y ? Object.defineProperty(y, S, {
            value: T,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : y[S] = T, y
    }

    function r(y) {
        var S = n(y, "string");
        return typeof S == "symbol" ? S : String(S)
    }

    function n(y, S) {
        if (typeof y != "object" || y === null) return y;
        var T = y[Symbol.toPrimitive];
        if (T !== void 0) {
            var C = T.call(y, S || "default");
            if (typeof C != "object") return C;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return (S === "string" ? String : Number)(y)
    }
    var i = vr,
        f = Symbol("lastResolve"),
        l = Symbol("lastReject"),
        h = Symbol("error"),
        _ = Symbol("ended"),
        b = Symbol("lastPromise"),
        w = Symbol("handlePromise"),
        u = Symbol("stream");

    function m(y, S) {
        return {
            value: y,
            done: S
        }
    }

    function v(y) {
        var S = y[f];
        if (S !== null) {
            var T = y[u].read();
            T !== null && (y[b] = null, y[f] = null, y[l] = null, S(m(T, !1)))
        }
    }

    function R(y) {
        process.nextTick(v, y)
    }

    function A(y, S) {
        return function(T, C) {
            y.then(function() {
                if (S[_]) {
                    T(m(void 0, !0));
                    return
                }
                S[w](T, C)
            }, C)
        }
    }
    var x = Object.getPrototypeOf(function() {}),
        s = Object.setPrototypeOf((e = {
            get stream() {
                return this[u]
            },
            next: function() {
                var S = this,
                    T = this[h];
                if (T !== null) return Promise.reject(T);
                if (this[_]) return Promise.resolve(m(void 0, !0));
                if (this[u].destroyed) return new Promise(function(M, $) {
                    process.nextTick(function() {
                        S[h] ? $(S[h]) : M(m(void 0, !0))
                    })
                });
                var C = this[b],
                    O;
                if (C) O = new Promise(A(C, this));
                else {
                    var D = this[u].read();
                    if (D !== null) return Promise.resolve(m(D, !1));
                    O = new Promise(this[w])
                }
                return this[b] = O, O
            }
        }, t(e, Symbol.asyncIterator, function() {
            return this
        }), t(e, "return", function() {
            var S = this;
            return new Promise(function(T, C) {
                S[u].destroy(null, function(O) {
                    if (O) {
                        C(O);
                        return
                    }
                    T(m(void 0, !0))
                })
            })
        }), e), x),
        p = function(S) {
            var T, C = Object.create(s, (T = {}, t(T, u, {
                value: S,
                writable: !0
            }), t(T, f, {
                value: null,
                writable: !0
            }), t(T, l, {
                value: null,
                writable: !0
            }), t(T, h, {
                value: null,
                writable: !0
            }), t(T, _, {
                value: S._readableState.endEmitted,
                writable: !0
            }), t(T, w, {
                value: function(D, M) {
                    var $ = C[u].read();
                    $ ? (C[b] = null, C[f] = null, C[l] = null, D(m($, !1))) : (C[f] = D, C[l] = M)
                },
                writable: !0
            }), T));
            return C[b] = null, i(S, function(O) {
                if (O && O.code !== "ERR_STREAM_PREMATURE_CLOSE") {
                    var D = C[l];
                    D !== null && (C[b] = null, C[f] = null, C[l] = null, D(O)), C[h] = O;
                    return
                }
                var M = C[f];
                M !== null && (C[b] = null, C[f] = null, C[l] = null, M(m(void 0, !0))), C[_] = !0
            }), S.on("readable", R.bind(null, C)), C
        };
    return tr = p, tr
}
var rr, Pr;

function ci() {
    return Pr || (Pr = 1, rr = function() {
        throw new Error("Readable.from is not available in the browser")
    }), rr
}
var nr, Lr;

function cn() {
    if (Lr) return nr;
    Lr = 1, nr = M;
    var e;
    M.ReadableState = D, nn.EventEmitter;
    var t = function(o, g) {
            return o.listeners(g).length
        },
        r = on,
        n = Pe.Buffer,
        i = (typeof me < "u" ? me : typeof window < "u" ? window : typeof self < "u" ? self : {}).Uint8Array || function() {};

    function f(a) {
        return n.from(a)
    }

    function l(a) {
        return n.isBuffer(a) || a instanceof i
    }
    var h = an,
        _;
    h && h.debuglog ? _ = h.debuglog("stream") : _ = function() {};
    var b = Kn(),
        w = fn,
        u = ln,
        m = u.getHighWaterMark,
        v = be.codes,
        R = v.ERR_INVALID_ARG_TYPE,
        A = v.ERR_STREAM_PUSH_AFTER_EOF,
        x = v.ERR_METHOD_NOT_IMPLEMENTED,
        s = v.ERR_STREAM_UNSHIFT_AFTER_END_EVENT,
        p, y, S;
    J(M, r);
    var T = w.errorOrDestroy,
        C = ["error", "close", "destroy", "pause", "resume"];

    function O(a, o, g) {
        if (typeof a.prependListener == "function") return a.prependListener(o, g);
        !a._events || !a._events[o] ? a.on(o, g) : Array.isArray(a._events[o]) ? a._events[o].unshift(g) : a._events[o] = [g, a._events[o]]
    }

    function D(a, o, g) {
        e = e || Se(), a = a || {}, typeof g != "boolean" && (g = o instanceof e), this.objectMode = !!a.objectMode, g && (this.objectMode = this.objectMode || !!a.readableObjectMode), this.highWaterMark = m(this, a, "readableHighWaterMark", g), this.buffer = new b, this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.paused = !0, this.emitClose = a.emitClose !== !1, this.autoDestroy = !!a.autoDestroy, this.destroyed = !1, this.defaultEncoding = a.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, a.encoding && (p || (p = Mr().StringDecoder), this.decoder = new p(a.encoding), this.encoding = a.encoding)
    }

    function M(a) {
        if (e = e || Se(), !(this instanceof M)) return new M(a);
        var o = this instanceof e;
        this._readableState = new D(a, this, o), this.readable = !0, a && (typeof a.read == "function" && (this._read = a.read), typeof a.destroy == "function" && (this._destroy = a.destroy)), r.call(this)
    }
    Object.defineProperty(M.prototype, "destroyed", {
        enumerable: !1,
        get: function() {
            return this._readableState === void 0 ? !1 : this._readableState.destroyed
        },
        set: function(o) {
            this._readableState && (this._readableState.destroyed = o)
        }
    }), M.prototype.destroy = w.destroy, M.prototype._undestroy = w.undestroy, M.prototype._destroy = function(a, o) {
        o(a)
    }, M.prototype.push = function(a, o) {
        var g = this._readableState,
            B;
        return g.objectMode ? B = !0 : typeof a == "string" && (o = o || g.defaultEncoding, o !== g.encoding && (a = n.from(a, o), o = ""), B = !0), $(this, a, o, !1, B)
    }, M.prototype.unshift = function(a) {
        return $(this, a, null, !0, !1)
    };

    function $(a, o, g, B, F) {
        _("readableAddChunk", o);
        var N = a._readableState;
        if (o === null) N.reading = !1, le(a, N);
        else {
            var L;
            if (F || (L = Z(N, o)), L) T(a, L);
            else if (N.objectMode || o && o.length > 0)
                if (typeof o != "string" && !N.objectMode && Object.getPrototypeOf(o) !== n.prototype && (o = f(o)), B) N.endEmitted ? T(a, new s) : W(a, N, o, !0);
                else if (N.ended) T(a, new A);
            else {
                if (N.destroyed) return !1;
                N.reading = !1, N.decoder && !g ? (o = N.decoder.write(o), N.objectMode || o.length !== 0 ? W(a, N, o, !1) : Y(a, N)) : W(a, N, o, !1)
            } else B || (N.reading = !1, Y(a, N))
        }
        return !N.ended && (N.length < N.highWaterMark || N.length === 0)
    }

    function W(a, o, g, B) {
        o.flowing && o.length === 0 && !o.sync ? (o.awaitDrain = 0, a.emit("data", g)) : (o.length += o.objectMode ? 1 : g.length, B ? o.buffer.unshift(g) : o.buffer.push(g), o.needReadable && K(a)), Y(a, o)
    }

    function Z(a, o) {
        var g;
        return !l(o) && typeof o != "string" && o !== void 0 && !a.objectMode && (g = new R("chunk", ["string", "Buffer", "Uint8Array"], o)), g
    }
    M.prototype.isPaused = function() {
        return this._readableState.flowing === !1
    }, M.prototype.setEncoding = function(a) {
        p || (p = Mr().StringDecoder);
        var o = new p(a);
        this._readableState.decoder = o, this._readableState.encoding = this._readableState.decoder.encoding;
        for (var g = this._readableState.buffer.head, B = ""; g !== null;) B += o.write(g.data), g = g.next;
        return this._readableState.buffer.clear(), B !== "" && this._readableState.buffer.push(B), this._readableState.length = B.length, this
    };
    var q = 1073741824;

    function z(a) {
        return a >= q ? a = q : (a--, a |= a >>> 1, a |= a >>> 2, a |= a >>> 4, a |= a >>> 8, a |= a >>> 16, a++), a
    }

    function G(a, o) {
        return a <= 0 || o.length === 0 && o.ended ? 0 : o.objectMode ? 1 : a !== a ? o.flowing && o.length ? o.buffer.head.data.length : o.length : (a > o.highWaterMark && (o.highWaterMark = z(a)), a <= o.length ? a : o.ended ? o.length : (o.needReadable = !0, 0))
    }
    M.prototype.read = function(a) {
        _("read", a), a = parseInt(a, 10);
        var o = this._readableState,
            g = a;
        if (a !== 0 && (o.emittedReadable = !1), a === 0 && o.needReadable && ((o.highWaterMark !== 0 ? o.length >= o.highWaterMark : o.length > 0) || o.ended)) return _("read: emitReadable", o.length, o.ended), o.length === 0 && o.ended ? E(this) : K(this), null;
        if (a = G(a, o), a === 0 && o.ended) return o.length === 0 && E(this), null;
        var B = o.needReadable;
        _("need readable", B), (o.length === 0 || o.length - a < o.highWaterMark) && (B = !0, _("length less than watermark", B)), o.ended || o.reading ? (B = !1, _("reading or ended", B)) : B && (_("do read"), o.reading = !0, o.sync = !0, o.length === 0 && (o.needReadable = !0), this._read(o.highWaterMark), o.sync = !1, o.reading || (a = G(g, o)));
        var F;
        return a > 0 ? F = c(a, o) : F = null, F === null ? (o.needReadable = o.length <= o.highWaterMark, a = 0) : (o.length -= a, o.awaitDrain = 0), o.length === 0 && (o.ended || (o.needReadable = !0), g !== a && o.ended && E(this)), F !== null && this.emit("data", F), F
    };

    function le(a, o) {
        if (_("onEofChunk"), !o.ended) {
            if (o.decoder) {
                var g = o.decoder.end();
                g && g.length && (o.buffer.push(g), o.length += o.objectMode ? 1 : g.length)
            }
            o.ended = !0, o.sync ? K(a) : (o.needReadable = !1, o.emittedReadable || (o.emittedReadable = !0, ee(a)))
        }
    }

    function K(a) {
        var o = a._readableState;
        _("emitReadable", o.needReadable, o.emittedReadable), o.needReadable = !1, o.emittedReadable || (_("emitReadable", o.flowing), o.emittedReadable = !0, process.nextTick(ee, a))
    }

    function ee(a) {
        var o = a._readableState;
        _("emitReadable_", o.destroyed, o.length, o.ended), !o.destroyed && (o.length || o.ended) && (a.emit("readable"), o.emittedReadable = !1), o.needReadable = !o.flowing && !o.ended && o.length <= o.highWaterMark, d(a)
    }

    function Y(a, o) {
        o.readingMore || (o.readingMore = !0, process.nextTick(te, a, o))
    }

    function te(a, o) {
        for (; !o.reading && !o.ended && (o.length < o.highWaterMark || o.flowing && o.length === 0);) {
            var g = o.length;
            if (_("maybeReadMore read 0"), a.read(0), g === o.length) break
        }
        o.readingMore = !1
    }
    M.prototype._read = function(a) {
        T(this, new x("_read()"))
    }, M.prototype.pipe = function(a, o) {
        var g = this,
            B = this._readableState;
        switch (B.pipesCount) {
            case 0:
                B.pipes = a;
                break;
            case 1:
                B.pipes = [B.pipes, a];
                break;
            default:
                B.pipes.push(a);
                break
        }
        B.pipesCount += 1, _("pipe count=%d opts=%j", B.pipesCount, o);
        var F = (!o || o.end !== !1) && a !== process.stdout && a !== process.stderr,
            N = F ? ie : ce;
        B.endEmitted ? process.nextTick(N) : g.once("end", N), a.on("unpipe", L);

        function L(ae, Q) {
            _("onunpipe"), ae === g && Q && Q.hasUnpiped === !1 && (Q.hasUnpiped = !0, He())
        }

        function ie() {
            _("onend"), a.end()
        }
        var _e = ue(g);
        a.on("drain", _e);
        var Be = !1;

        function He() {
            _("cleanup"), a.removeListener("close", xe), a.removeListener("finish", Ee), a.removeListener("drain", _e), a.removeListener("error", we), a.removeListener("unpipe", L), g.removeListener("end", ie), g.removeListener("end", ce), g.removeListener("data", Ce), Be = !0, B.awaitDrain && (!a._writableState || a._writableState.needDrain) && _e()
        }
        g.on("data", Ce);

        function Ce(ae) {
            _("ondata");
            var Q = a.write(ae);
            _("dest.write", Q), Q === !1 && ((B.pipesCount === 1 && B.pipes === a || B.pipesCount > 1 && P(B.pipes, a) !== -1) && !Be && (_("false write response, pause", B.awaitDrain), B.awaitDrain++), g.pause())
        }

        function we(ae) {
            _("onerror", ae), ce(), a.removeListener("error", we), t(a, "error") === 0 && T(a, ae)
        }
        O(a, "error", we);

        function xe() {
            a.removeListener("finish", Ee), ce()
        }
        a.once("close", xe);

        function Ee() {
            _("onfinish"), a.removeListener("close", xe), ce()
        }
        a.once("finish", Ee);

        function ce() {
            _("unpipe"), g.unpipe(a)
        }
        return a.emit("pipe", g), B.flowing || (_("pipe resume"), g.resume()), a
    };

    function ue(a) {
        return function() {
            var g = a._readableState;
            _("pipeOnDrain", g.awaitDrain), g.awaitDrain && g.awaitDrain--, g.awaitDrain === 0 && t(a, "data") && (g.flowing = !0, d(a))
        }
    }
    M.prototype.unpipe = function(a) {
        var o = this._readableState,
            g = {
                hasUnpiped: !1
            };
        if (o.pipesCount === 0) return this;
        if (o.pipesCount === 1) return a && a !== o.pipes ? this : (a || (a = o.pipes), o.pipes = null, o.pipesCount = 0, o.flowing = !1, a && a.emit("unpipe", this, g), this);
        if (!a) {
            var B = o.pipes,
                F = o.pipesCount;
            o.pipes = null, o.pipesCount = 0, o.flowing = !1;
            for (var N = 0; N < F; N++) B[N].emit("unpipe", this, {
                hasUnpiped: !1
            });
            return this
        }
        var L = P(o.pipes, a);
        return L === -1 ? this : (o.pipes.splice(L, 1), o.pipesCount -= 1, o.pipesCount === 1 && (o.pipes = o.pipes[0]), a.emit("unpipe", this, g), this)
    }, M.prototype.on = function(a, o) {
        var g = r.prototype.on.call(this, a, o),
            B = this._readableState;
        return a === "data" ? (B.readableListening = this.listenerCount("readable") > 0, B.flowing !== !1 && this.resume()) : a === "readable" && !B.endEmitted && !B.readableListening && (B.readableListening = B.needReadable = !0, B.flowing = !1, B.emittedReadable = !1, _("on readable", B.length, B.reading), B.length ? K(this) : B.reading || process.nextTick(V, this)), g
    }, M.prototype.addListener = M.prototype.on, M.prototype.removeListener = function(a, o) {
        var g = r.prototype.removeListener.call(this, a, o);
        return a === "readable" && process.nextTick(re, this), g
    }, M.prototype.removeAllListeners = function(a) {
        var o = r.prototype.removeAllListeners.apply(this, arguments);
        return (a === "readable" || a === void 0) && process.nextTick(re, this), o
    };

    function re(a) {
        var o = a._readableState;
        o.readableListening = a.listenerCount("readable") > 0, o.resumeScheduled && !o.paused ? o.flowing = !0 : a.listenerCount("data") > 0 && a.resume()
    }

    function V(a) {
        _("readable nexttick read 0"), a.read(0)
    }
    M.prototype.resume = function() {
        var a = this._readableState;
        return a.flowing || (_("resume"), a.flowing = !a.readableListening, he(this, a)), a.paused = !1, this
    };

    function he(a, o) {
        o.resumeScheduled || (o.resumeScheduled = !0, process.nextTick(ne, a, o))
    }

    function ne(a, o) {
        _("resume", o.reading), o.reading || a.read(0), o.resumeScheduled = !1, a.emit("resume"), d(a), o.flowing && !o.reading && a.read(0)
    }
    M.prototype.pause = function() {
        return _("call pause flowing=%j", this._readableState.flowing), this._readableState.flowing !== !1 && (_("pause"), this._readableState.flowing = !1, this.emit("pause")), this._readableState.paused = !0, this
    };

    function d(a) {
        var o = a._readableState;
        for (_("flow", o.flowing); o.flowing && a.read() !== null;);
    }
    M.prototype.wrap = function(a) {
        var o = this,
            g = this._readableState,
            B = !1;
        a.on("end", function() {
            if (_("wrapped end"), g.decoder && !g.ended) {
                var L = g.decoder.end();
                L && L.length && o.push(L)
            }
            o.push(null)
        }), a.on("data", function(L) {
            if (_("wrapped data"), g.decoder && (L = g.decoder.write(L)), !(g.objectMode && L == null) && !(!g.objectMode && (!L || !L.length))) {
                var ie = o.push(L);
                ie || (B = !0, a.pause())
            }
        });
        for (var F in a) this[F] === void 0 && typeof a[F] == "function" && (this[F] = function(ie) {
            return function() {
                return a[ie].apply(a, arguments)
            }
        }(F));
        for (var N = 0; N < C.length; N++) a.on(C[N], this.emit.bind(this, C[N]));
        return this._read = function(L) {
            _("wrapped _read", L), B && (B = !1, a.resume())
        }, this
    }, typeof Symbol == "function" && (M.prototype[Symbol.asyncIterator] = function() {
        return y === void 0 && (y = hi()), y(this)
    }), Object.defineProperty(M.prototype, "readableHighWaterMark", {
        enumerable: !1,
        get: function() {
            return this._readableState.highWaterMark
        }
    }), Object.defineProperty(M.prototype, "readableBuffer", {
        enumerable: !1,
        get: function() {
            return this._readableState && this._readableState.buffer
        }
    }), Object.defineProperty(M.prototype, "readableFlowing", {
        enumerable: !1,
        get: function() {
            return this._readableState.flowing
        },
        set: function(o) {
            this._readableState && (this._readableState.flowing = o)
        }
    }), M._fromList = c, Object.defineProperty(M.prototype, "readableLength", {
        enumerable: !1,
        get: function() {
            return this._readableState.length
        }
    });

    function c(a, o) {
        if (o.length === 0) return null;
        var g;
        return o.objectMode ? g = o.buffer.shift() : !a || a >= o.length ? (o.decoder ? g = o.buffer.join("") : o.buffer.length === 1 ? g = o.buffer.first() : g = o.buffer.concat(o.length), o.buffer.clear()) : g = o.buffer.consume(a, o.decoder), g
    }

    function E(a) {
        var o = a._readableState;
        _("endReadable", o.endEmitted), o.endEmitted || (o.ended = !0, process.nextTick(k, o, a))
    }

    function k(a, o) {
        if (_("endReadableNT", a.endEmitted, a.length), !a.endEmitted && a.length === 0 && (a.endEmitted = !0, o.readable = !1, o.emit("end"), a.autoDestroy)) {
            var g = o._writableState;
            (!g || g.autoDestroy && g.finished) && o.destroy()
        }
    }
    typeof Symbol == "function" && (M.from = function(a, o) {
        return S === void 0 && (S = ci()), S(M, a, o)
    });

    function P(a, o) {
        for (var g = 0, B = a.length; g < B; g++)
            if (a[g] === o) return g;
        return -1
    }
    return nr
}
var _n = fe,
    Ye = be.codes,
    _i = Ye.ERR_METHOD_NOT_IMPLEMENTED,
    di = Ye.ERR_MULTIPLE_CALLBACK,
    pi = Ye.ERR_TRANSFORM_ALREADY_TRANSFORMING,
    bi = Ye.ERR_TRANSFORM_WITH_LENGTH_0,
    Xe = Se();
J(fe, Xe);

function vi(e, t) {
    var r = this._transformState;
    r.transforming = !1;
    var n = r.writecb;
    if (n === null) return this.emit("error", new di);
    r.writechunk = null, r.writecb = null, t != null && this.push(t), n(e);
    var i = this._readableState;
    i.reading = !1, (i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
}

function fe(e) {
    if (!(this instanceof fe)) return new fe(e);
    Xe.call(this, e), this._transformState = {
        afterTransform: vi.bind(this),
        needTransform: !1,
        transforming: !1,
        writecb: null,
        writechunk: null,
        writeencoding: null
    }, this._readableState.needReadable = !0, this._readableState.sync = !1, e && (typeof e.transform == "function" && (this._transform = e.transform), typeof e.flush == "function" && (this._flush = e.flush)), this.on("prefinish", gi)
}

function gi() {
    var e = this;
    typeof this._flush == "function" && !this._readableState.destroyed ? this._flush(function(t, r) {
        Or(e, t, r)
    }) : Or(this, null, null)
}
fe.prototype.push = function(e, t) {
    return this._transformState.needTransform = !1, Xe.prototype.push.call(this, e, t)
};
fe.prototype._transform = function(e, t, r) {
    r(new _i("_transform()"))
};
fe.prototype._write = function(e, t, r) {
    var n = this._transformState;
    if (n.writecb = r, n.writechunk = e, n.writeencoding = t, !n.transforming) {
        var i = this._readableState;
        (n.needTransform || i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
    }
};
fe.prototype._read = function(e) {
    var t = this._transformState;
    t.writechunk !== null && !t.transforming ? (t.transforming = !0, this._transform(t.writechunk, t.writeencoding, t.afterTransform)) : t.needTransform = !0
};
fe.prototype._destroy = function(e, t) {
    Xe.prototype._destroy.call(this, e, function(r) {
        t(r)
    })
};

function Or(e, t, r) {
    if (t) return e.emit("error", t);
    if (r != null && e.push(r), e._writableState.length) throw new bi;
    if (e._transformState.transforming) throw new pi;
    return e.push(null)
}
var yi = De,
    dn = _n;
J(De, dn);

function De(e) {
    if (!(this instanceof De)) return new De(e);
    dn.call(this, e)
}
De.prototype._transform = function(e, t, r) {
    r(null, e)
};
var ir;

function wi(e) {
    var t = !1;
    return function() {
        t || (t = !0, e.apply(void 0, arguments))
    }
}
var pn = be.codes,
    xi = pn.ERR_MISSING_ARGS,
    Ei = pn.ERR_STREAM_DESTROYED;

function Ir(e) {
    if (e) throw e
}

function mi(e) {
    return e.setHeader && typeof e.abort == "function"
}

function Si(e, t, r, n) {
    n = wi(n);
    var i = !1;
    e.on("close", function() {
        i = !0
    }), ir === void 0 && (ir = vr), ir(e, {
        readable: t,
        writable: r
    }, function(l) {
        if (l) return n(l);
        i = !0, n()
    });
    var f = !1;
    return function(l) {
        if (!i && !f) {
            if (f = !0, mi(e)) return e.abort();
            if (typeof e.destroy == "function") return e.destroy();
            n(l || new Ei("pipe"))
        }
    }
}

function $r(e) {
    e()
}

function Ri(e, t) {
    return e.pipe(t)
}

function Ti(e) {
    return !e.length || typeof e[e.length - 1] != "function" ? Ir : e.pop()
}

function Ai() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    var n = Ti(t);
    if (Array.isArray(t[0]) && (t = t[0]), t.length < 2) throw new xi("streams");
    var i, f = t.map(function(l, h) {
        var _ = h < t.length - 1,
            b = h > 0;
        return Si(l, _, b, function(w) {
            i || (i = w), w && f.forEach($r), !_ && (f.forEach($r), n(i))
        })
    });
    return t.reduce(Ri)
}
var Bi = Ai;
(function(e, t) {
    t = e.exports = cn(), t.Stream = t, t.Readable = t, t.Writable = un(), t.Duplex = Se(), t.Transform = _n, t.PassThrough = yi, t.finished = vr, t.pipeline = Bi
})(or, or.exports);
var bn = or.exports;
const {
    Transform: Ci
} = bn;
var ki = e => class vn extends Ci {
    constructor(r, n, i, f, l) {
        super(l), this._rate = r, this._capacity = n, this._delimitedSuffix = i, this._hashBitLength = f, this._options = l, this._state = new e, this._state.initialize(r, n), this._finalized = !1
    }
    _transform(r, n, i) {
        let f = null;
        try {
            this.update(r, n)
        } catch (l) {
            f = l
        }
        i(f)
    }
    _flush(r) {
        let n = null;
        try {
            this.push(this.digest())
        } catch (i) {
            n = i
        }
        r(n)
    }
    update(r, n) {
        if (!Buffer.isBuffer(r) && typeof r != "string") throw new TypeError("Data must be a string or a buffer");
        if (this._finalized) throw new Error("Digest already called");
        return Buffer.isBuffer(r) || (r = Buffer.from(r, n)), this._state.absorb(r), this
    }
    digest(r) {
        if (this._finalized) throw new Error("Digest already called");
        this._finalized = !0, this._delimitedSuffix && this._state.absorbLastFewBits(this._delimitedSuffix);
        let n = this._state.squeeze(this._hashBitLength / 8);
        return r !== void 0 && (n = n.toString(r)), this._resetState(), n
    }
    _resetState() {
        return this._state.initialize(this._rate, this._capacity), this
    }
    _clone() {
        const r = new vn(this._rate, this._capacity, this._delimitedSuffix, this._hashBitLength, this._options);
        return this._state.copy(r._state), r._finalized = this._finalized, r
    }
};
const {
    Transform: Mi
} = bn;
var Di = e => class gn extends Mi {
    constructor(r, n, i, f) {
        super(f), this._rate = r, this._capacity = n, this._delimitedSuffix = i, this._options = f, this._state = new e, this._state.initialize(r, n), this._finalized = !1
    }
    _transform(r, n, i) {
        let f = null;
        try {
            this.update(r, n)
        } catch (l) {
            f = l
        }
        i(f)
    }
    _flush() {}
    _read(r) {
        this.push(this.squeeze(r))
    }
    update(r, n) {
        if (!Buffer.isBuffer(r) && typeof r != "string") throw new TypeError("Data must be a string or a buffer");
        if (this._finalized) throw new Error("Squeeze already called");
        return Buffer.isBuffer(r) || (r = Buffer.from(r, n)), this._state.absorb(r), this
    }
    squeeze(r, n) {
        this._finalized || (this._finalized = !0, this._state.absorbLastFewBits(this._delimitedSuffix));
        let i = this._state.squeeze(r);
        return n !== void 0 && (i = i.toString(n)), i
    }
    _resetState() {
        return this._state.initialize(this._rate, this._capacity), this
    }
    _clone() {
        const r = new gn(this._rate, this._capacity, this._delimitedSuffix, this._options);
        return this._state.copy(r._state), r._finalized = this._finalized, r
    }
};
const Ni = ki,
    Pi = Di;
var Li = function(e) {
        const t = Ni(e),
            r = Pi(e);
        return function(n, i) {
            switch (typeof n == "string" ? n.toLowerCase() : n) {
                case "keccak224":
                    return new t(1152, 448, null, 224, i);
                case "keccak256":
                    return new t(1088, 512, null, 256, i);
                case "keccak384":
                    return new t(832, 768, null, 384, i);
                case "keccak512":
                    return new t(576, 1024, null, 512, i);
                case "sha3-224":
                    return new t(1152, 448, 6, 224, i);
                case "sha3-256":
                    return new t(1088, 512, 6, 256, i);
                case "sha3-384":
                    return new t(832, 768, 6, 384, i);
                case "sha3-512":
                    return new t(576, 1024, 6, 512, i);
                case "shake128":
                    return new r(1344, 256, 31, i);
                case "shake256":
                    return new r(1088, 512, 31, i);
                default:
                    throw new Error("Invald algorithm: " + n)
            }
        }
    },
    yn = {};
const Fr = [1, 0, 32898, 0, 32906, 2147483648, 2147516416, 2147483648, 32907, 0, 2147483649, 0, 2147516545, 2147483648, 32777, 2147483648, 138, 0, 136, 0, 2147516425, 0, 2147483658, 0, 2147516555, 0, 139, 2147483648, 32905, 2147483648, 32771, 2147483648, 32770, 2147483648, 128, 2147483648, 32778, 0, 2147483658, 2147483648, 2147516545, 2147483648, 32896, 2147483648, 2147483649, 0, 2147516424, 2147483648];
yn.p1600 = function(e) {
    for (let t = 0; t < 24; ++t) {
        const r = e[0] ^ e[10] ^ e[20] ^ e[30] ^ e[40],
            n = e[1] ^ e[11] ^ e[21] ^ e[31] ^ e[41],
            i = e[2] ^ e[12] ^ e[22] ^ e[32] ^ e[42],
            f = e[3] ^ e[13] ^ e[23] ^ e[33] ^ e[43],
            l = e[4] ^ e[14] ^ e[24] ^ e[34] ^ e[44],
            h = e[5] ^ e[15] ^ e[25] ^ e[35] ^ e[45],
            _ = e[6] ^ e[16] ^ e[26] ^ e[36] ^ e[46],
            b = e[7] ^ e[17] ^ e[27] ^ e[37] ^ e[47],
            w = e[8] ^ e[18] ^ e[28] ^ e[38] ^ e[48],
            u = e[9] ^ e[19] ^ e[29] ^ e[39] ^ e[49];
        let m = w ^ (i << 1 | f >>> 31),
            v = u ^ (f << 1 | i >>> 31);
        const R = e[0] ^ m,
            A = e[1] ^ v,
            x = e[10] ^ m,
            s = e[11] ^ v,
            p = e[20] ^ m,
            y = e[21] ^ v,
            S = e[30] ^ m,
            T = e[31] ^ v,
            C = e[40] ^ m,
            O = e[41] ^ v;
        m = r ^ (l << 1 | h >>> 31), v = n ^ (h << 1 | l >>> 31);
        const D = e[2] ^ m,
            M = e[3] ^ v,
            $ = e[12] ^ m,
            W = e[13] ^ v,
            Z = e[22] ^ m,
            q = e[23] ^ v,
            z = e[32] ^ m,
            G = e[33] ^ v,
            le = e[42] ^ m,
            K = e[43] ^ v;
        m = i ^ (_ << 1 | b >>> 31), v = f ^ (b << 1 | _ >>> 31);
        const ee = e[4] ^ m,
            Y = e[5] ^ v,
            te = e[14] ^ m,
            ue = e[15] ^ v,
            re = e[24] ^ m,
            V = e[25] ^ v,
            he = e[34] ^ m,
            ne = e[35] ^ v,
            d = e[44] ^ m,
            c = e[45] ^ v;
        m = l ^ (w << 1 | u >>> 31), v = h ^ (u << 1 | w >>> 31);
        const E = e[6] ^ m,
            k = e[7] ^ v,
            P = e[16] ^ m,
            a = e[17] ^ v,
            o = e[26] ^ m,
            g = e[27] ^ v,
            B = e[36] ^ m,
            F = e[37] ^ v,
            N = e[46] ^ m,
            L = e[47] ^ v;
        m = _ ^ (r << 1 | n >>> 31), v = b ^ (n << 1 | r >>> 31);
        const ie = e[8] ^ m,
            _e = e[9] ^ v,
            Be = e[18] ^ m,
            He = e[19] ^ v,
            Ce = e[28] ^ m,
            we = e[29] ^ v,
            xe = e[38] ^ m,
            Ee = e[39] ^ v,
            ce = e[48] ^ m,
            ae = e[49] ^ v,
            Q = R,
            tt = A,
            rt = s << 4 | x >>> 28,
            nt = x << 4 | s >>> 28,
            it = p << 3 | y >>> 29,
            at = y << 3 | p >>> 29,
            ot = T << 9 | S >>> 23,
            ft = S << 9 | T >>> 23,
            st = C << 18 | O >>> 14,
            lt = O << 18 | C >>> 14,
            ut = D << 1 | M >>> 31,
            ht = M << 1 | D >>> 31,
            ct = W << 12 | $ >>> 20,
            _t = $ << 12 | W >>> 20,
            dt = Z << 10 | q >>> 22,
            pt = q << 10 | Z >>> 22,
            bt = G << 13 | z >>> 19,
            vt = z << 13 | G >>> 19,
            gt = le << 2 | K >>> 30,
            yt = K << 2 | le >>> 30,
            wt = Y << 30 | ee >>> 2,
            xt = ee << 30 | Y >>> 2,
            Et = te << 6 | ue >>> 26,
            mt = ue << 6 | te >>> 26,
            St = V << 11 | re >>> 21,
            Rt = re << 11 | V >>> 21,
            Tt = he << 15 | ne >>> 17,
            At = ne << 15 | he >>> 17,
            Bt = c << 29 | d >>> 3,
            Ct = d << 29 | c >>> 3,
            kt = E << 28 | k >>> 4,
            Mt = k << 28 | E >>> 4,
            Dt = a << 23 | P >>> 9,
            Nt = P << 23 | a >>> 9,
            Pt = o << 25 | g >>> 7,
            Lt = g << 25 | o >>> 7,
            Ot = B << 21 | F >>> 11,
            It = F << 21 | B >>> 11,
            $t = L << 24 | N >>> 8,
            Ft = N << 24 | L >>> 8,
            Ut = ie << 27 | _e >>> 5,
            Ht = _e << 27 | ie >>> 5,
            qt = Be << 20 | He >>> 12,
            jt = He << 20 | Be >>> 12,
            Wt = we << 7 | Ce >>> 25,
            zt = Ce << 7 | we >>> 25,
            Gt = xe << 8 | Ee >>> 24,
            Vt = Ee << 8 | xe >>> 24,
            Kt = ce << 14 | ae >>> 18,
            Yt = ae << 14 | ce >>> 18;
        e[0] = Q ^ ~ct & St, e[1] = tt ^ ~_t & Rt, e[10] = kt ^ ~qt & it, e[11] = Mt ^ ~jt & at, e[20] = ut ^ ~Et & Pt, e[21] = ht ^ ~mt & Lt, e[30] = Ut ^ ~rt & dt, e[31] = Ht ^ ~nt & pt, e[40] = wt ^ ~Dt & Wt, e[41] = xt ^ ~Nt & zt, e[2] = ct ^ ~St & Ot, e[3] = _t ^ ~Rt & It, e[12] = qt ^ ~it & bt, e[13] = jt ^ ~at & vt, e[22] = Et ^ ~Pt & Gt, e[23] = mt ^ ~Lt & Vt, e[32] = rt ^ ~dt & Tt, e[33] = nt ^ ~pt & At, e[42] = Dt ^ ~Wt & ot, e[43] = Nt ^ ~zt & ft, e[4] = St ^ ~Ot & Kt, e[5] = Rt ^ ~It & Yt, e[14] = it ^ ~bt & Bt, e[15] = at ^ ~vt & Ct, e[24] = Pt ^ ~Gt & st, e[25] = Lt ^ ~Vt & lt, e[34] = dt ^ ~Tt & $t, e[35] = pt ^ ~At & Ft, e[44] = Wt ^ ~ot & gt, e[45] = zt ^ ~ft & yt, e[6] = Ot ^ ~Kt & Q, e[7] = It ^ ~Yt & tt, e[16] = bt ^ ~Bt & kt, e[17] = vt ^ ~Ct & Mt, e[26] = Gt ^ ~st & ut, e[27] = Vt ^ ~lt & ht, e[36] = Tt ^ ~$t & Ut, e[37] = At ^ ~Ft & Ht, e[46] = ot ^ ~gt & wt, e[47] = ft ^ ~yt & xt, e[8] = Kt ^ ~Q & ct, e[9] = Yt ^ ~tt & _t, e[18] = Bt ^ ~kt & qt, e[19] = Ct ^ ~Mt & jt, e[28] = st ^ ~ut & Et, e[29] = lt ^ ~ht & mt, e[38] = $t ^ ~Ut & rt, e[39] = Ft ^ ~Ht & nt, e[48] = gt ^ ~wt & Dt, e[49] = yt ^ ~xt & Nt, e[0] ^= Fr[t * 2], e[1] ^= Fr[t * 2 + 1]
    }
};
const Ge = yn;

function Te() {
    this.state = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], this.blockSize = null, this.count = 0, this.squeezing = !1
}
Te.prototype.initialize = function(e, t) {
    for (let r = 0; r < 50; ++r) this.state[r] = 0;
    this.blockSize = e / 8, this.count = 0, this.squeezing = !1
};
Te.prototype.absorb = function(e) {
    for (let t = 0; t < e.length; ++t) this.state[~~(this.count / 4)] ^= e[t] << 8 * (this.count % 4), this.count += 1, this.count === this.blockSize && (Ge.p1600(this.state), this.count = 0)
};
Te.prototype.absorbLastFewBits = function(e) {
    this.state[~~(this.count / 4)] ^= e << 8 * (this.count % 4), e & 128 && this.count === this.blockSize - 1 && Ge.p1600(this.state), this.state[~~((this.blockSize - 1) / 4)] ^= 128 << 8 * ((this.blockSize - 1) % 4), Ge.p1600(this.state), this.count = 0, this.squeezing = !0
};
Te.prototype.squeeze = function(e) {
    this.squeezing || this.absorbLastFewBits(1);
    const t = Buffer.alloc(e);
    for (let r = 0; r < e; ++r) t[r] = this.state[~~(this.count / 4)] >>> 8 * (this.count % 4) & 255, this.count += 1, this.count === this.blockSize && (Ge.p1600(this.state), this.count = 0);
    return t
};
Te.prototype.copy = function(e) {
    for (let t = 0; t < 50; ++t) e.state[t] = this.state[t];
    e.blockSize = this.blockSize, e.count = this.count, e.squeezing = this.squeezing
};
var Oi = Te,
    Za = Li(Oi),
    wn = {
        exports: {}
    },
    lr = {
        exports: {}
    };
(function(e, t) {
    var r = Pe,
        n = r.Buffer;

    function i(l, h) {
        for (var _ in l) h[_] = l[_]
    }
    n.from && n.alloc && n.allocUnsafe && n.allocUnsafeSlow ? e.exports = r : (i(r, t), t.Buffer = f);

    function f(l, h, _) {
        return n(l, h, _)
    }
    i(n, f), f.from = function(l, h, _) {
        if (typeof l == "number") throw new TypeError("Argument must not be a number");
        return n(l, h, _)
    }, f.alloc = function(l, h, _) {
        if (typeof l != "number") throw new TypeError("Argument must be a number");
        var b = n(l);
        return h !== void 0 ? typeof _ == "string" ? b.fill(h, _) : b.fill(h) : b.fill(0), b
    }, f.allocUnsafe = function(l) {
        if (typeof l != "number") throw new TypeError("Argument must be a number");
        return n(l)
    }, f.allocUnsafeSlow = function(l) {
        if (typeof l != "number") throw new TypeError("Argument must be a number");
        return r.SlowBuffer(l)
    }
})(lr, lr.exports);
var ve = lr.exports,
    xn = ve.Buffer;

function Je(e, t) {
    this._block = xn.alloc(e), this._finalSize = t, this._blockSize = e, this._len = 0
}
Je.prototype.update = function(e, t) {
    typeof e == "string" && (t = t || "utf8", e = xn.from(e, t));
    for (var r = this._block, n = this._blockSize, i = e.length, f = this._len, l = 0; l < i;) {
        for (var h = f % n, _ = Math.min(i - l, n - h), b = 0; b < _; b++) r[h + b] = e[l + b];
        f += _, l += _, f % n === 0 && this._update(r)
    }
    return this._len += i, this
};
Je.prototype.digest = function(e) {
    var t = this._len % this._blockSize;
    this._block[t] = 128, this._block.fill(0, t + 1), t >= this._finalSize && (this._update(this._block), this._block.fill(0));
    var r = this._len * 8;
    if (r <= 4294967295) this._block.writeUInt32BE(r, this._blockSize - 4);
    else {
        var n = (r & 4294967295) >>> 0,
            i = (r - n) / 4294967296;
        this._block.writeUInt32BE(i, this._blockSize - 8), this._block.writeUInt32BE(n, this._blockSize - 4)
    }
    this._update(this._block);
    var f = this._hash();
    return e ? f.toString(e) : f
};
Je.prototype._update = function() {
    throw new Error("_update must be implemented by subclass")
};
var Ae = Je,
    Ii = J,
    En = Ae,
    $i = ve.Buffer,
    Fi = [1518500249, 1859775393, -1894007588, -899497514],
    Ui = new Array(80);

function Le() {
    this.init(), this._w = Ui, En.call(this, 64, 56)
}
Ii(Le, En);
Le.prototype.init = function() {
    return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this
};

function Hi(e) {
    return e << 5 | e >>> 27
}

function qi(e) {
    return e << 30 | e >>> 2
}

function ji(e, t, r, n) {
    return e === 0 ? t & r | ~t & n : e === 2 ? t & r | t & n | r & n : t ^ r ^ n
}
Le.prototype._update = function(e) {
    for (var t = this._w, r = this._a | 0, n = this._b | 0, i = this._c | 0, f = this._d | 0, l = this._e | 0, h = 0; h < 16; ++h) t[h] = e.readInt32BE(h * 4);
    for (; h < 80; ++h) t[h] = t[h - 3] ^ t[h - 8] ^ t[h - 14] ^ t[h - 16];
    for (var _ = 0; _ < 80; ++_) {
        var b = ~~(_ / 20),
            w = Hi(r) + ji(b, n, i, f) + l + t[_] + Fi[b] | 0;
        l = f, f = i, i = qi(n), n = r, r = w
    }
    this._a = r + this._a | 0, this._b = n + this._b | 0, this._c = i + this._c | 0, this._d = f + this._d | 0, this._e = l + this._e | 0
};
Le.prototype._hash = function() {
    var e = $i.allocUnsafe(20);
    return e.writeInt32BE(this._a | 0, 0), e.writeInt32BE(this._b | 0, 4), e.writeInt32BE(this._c | 0, 8), e.writeInt32BE(this._d | 0, 12), e.writeInt32BE(this._e | 0, 16), e
};
var Wi = Le,
    zi = J,
    mn = Ae,
    Gi = ve.Buffer,
    Vi = [1518500249, 1859775393, -1894007588, -899497514],
    Ki = new Array(80);

function Oe() {
    this.init(), this._w = Ki, mn.call(this, 64, 56)
}
zi(Oe, mn);
Oe.prototype.init = function() {
    return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this
};

function Yi(e) {
    return e << 1 | e >>> 31
}

function Xi(e) {
    return e << 5 | e >>> 27
}

function Ji(e) {
    return e << 30 | e >>> 2
}

function Qi(e, t, r, n) {
    return e === 0 ? t & r | ~t & n : e === 2 ? t & r | t & n | r & n : t ^ r ^ n
}
Oe.prototype._update = function(e) {
    for (var t = this._w, r = this._a | 0, n = this._b | 0, i = this._c | 0, f = this._d | 0, l = this._e | 0, h = 0; h < 16; ++h) t[h] = e.readInt32BE(h * 4);
    for (; h < 80; ++h) t[h] = Yi(t[h - 3] ^ t[h - 8] ^ t[h - 14] ^ t[h - 16]);
    for (var _ = 0; _ < 80; ++_) {
        var b = ~~(_ / 20),
            w = Xi(r) + Qi(b, n, i, f) + l + t[_] + Vi[b] | 0;
        l = f, f = i, i = Ji(n), n = r, r = w
    }
    this._a = r + this._a | 0, this._b = n + this._b | 0, this._c = i + this._c | 0, this._d = f + this._d | 0, this._e = l + this._e | 0
};
Oe.prototype._hash = function() {
    var e = Gi.allocUnsafe(20);
    return e.writeInt32BE(this._a | 0, 0), e.writeInt32BE(this._b | 0, 4), e.writeInt32BE(this._c | 0, 8), e.writeInt32BE(this._d | 0, 12), e.writeInt32BE(this._e | 0, 16), e
};
var Zi = Oe,
    ea = J,
    Sn = Ae,
    ta = ve.Buffer,
    ra = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298],
    na = new Array(64);

function Ie() {
    this.init(), this._w = na, Sn.call(this, 64, 56)
}
ea(Ie, Sn);
Ie.prototype.init = function() {
    return this._a = 1779033703, this._b = 3144134277, this._c = 1013904242, this._d = 2773480762, this._e = 1359893119, this._f = 2600822924, this._g = 528734635, this._h = 1541459225, this
};

function ia(e, t, r) {
    return r ^ e & (t ^ r)
}

function aa(e, t, r) {
    return e & t | r & (e | t)
}

function oa(e) {
    return (e >>> 2 | e << 30) ^ (e >>> 13 | e << 19) ^ (e >>> 22 | e << 10)
}

function fa(e) {
    return (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7)
}

function sa(e) {
    return (e >>> 7 | e << 25) ^ (e >>> 18 | e << 14) ^ e >>> 3
}

function la(e) {
    return (e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10
}
Ie.prototype._update = function(e) {
    for (var t = this._w, r = this._a | 0, n = this._b | 0, i = this._c | 0, f = this._d | 0, l = this._e | 0, h = this._f | 0, _ = this._g | 0, b = this._h | 0, w = 0; w < 16; ++w) t[w] = e.readInt32BE(w * 4);
    for (; w < 64; ++w) t[w] = la(t[w - 2]) + t[w - 7] + sa(t[w - 15]) + t[w - 16] | 0;
    for (var u = 0; u < 64; ++u) {
        var m = b + fa(l) + ia(l, h, _) + ra[u] + t[u] | 0,
            v = oa(r) + aa(r, n, i) | 0;
        b = _, _ = h, h = l, l = f + m | 0, f = i, i = n, n = r, r = m + v | 0
    }
    this._a = r + this._a | 0, this._b = n + this._b | 0, this._c = i + this._c | 0, this._d = f + this._d | 0, this._e = l + this._e | 0, this._f = h + this._f | 0, this._g = _ + this._g | 0, this._h = b + this._h | 0
};
Ie.prototype._hash = function() {
    var e = ta.allocUnsafe(32);
    return e.writeInt32BE(this._a, 0), e.writeInt32BE(this._b, 4), e.writeInt32BE(this._c, 8), e.writeInt32BE(this._d, 12), e.writeInt32BE(this._e, 16), e.writeInt32BE(this._f, 20), e.writeInt32BE(this._g, 24), e.writeInt32BE(this._h, 28), e
};
var Rn = Ie,
    ua = J,
    ha = Rn,
    ca = Ae,
    _a = ve.Buffer,
    da = new Array(64);

function Qe() {
    this.init(), this._w = da, ca.call(this, 64, 56)
}
ua(Qe, ha);
Qe.prototype.init = function() {
    return this._a = 3238371032, this._b = 914150663, this._c = 812702999, this._d = 4144912697, this._e = 4290775857, this._f = 1750603025, this._g = 1694076839, this._h = 3204075428, this
};
Qe.prototype._hash = function() {
    var e = _a.allocUnsafe(28);
    return e.writeInt32BE(this._a, 0), e.writeInt32BE(this._b, 4), e.writeInt32BE(this._c, 8), e.writeInt32BE(this._d, 12), e.writeInt32BE(this._e, 16), e.writeInt32BE(this._f, 20), e.writeInt32BE(this._g, 24), e
};
var pa = Qe,
    ba = J,
    Tn = Ae,
    va = ve.Buffer,
    Ur = [1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591],
    ga = new Array(160);

function $e() {
    this.init(), this._w = ga, Tn.call(this, 128, 112)
}
ba($e, Tn);
$e.prototype.init = function() {
    return this._ah = 1779033703, this._bh = 3144134277, this._ch = 1013904242, this._dh = 2773480762, this._eh = 1359893119, this._fh = 2600822924, this._gh = 528734635, this._hh = 1541459225, this._al = 4089235720, this._bl = 2227873595, this._cl = 4271175723, this._dl = 1595750129, this._el = 2917565137, this._fl = 725511199, this._gl = 4215389547, this._hl = 327033209, this
};

function Hr(e, t, r) {
    return r ^ e & (t ^ r)
}

function qr(e, t, r) {
    return e & t | r & (e | t)
}

function jr(e, t) {
    return (e >>> 28 | t << 4) ^ (t >>> 2 | e << 30) ^ (t >>> 7 | e << 25)
}

function Wr(e, t) {
    return (e >>> 14 | t << 18) ^ (e >>> 18 | t << 14) ^ (t >>> 9 | e << 23)
}

function ya(e, t) {
    return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ e >>> 7
}

function wa(e, t) {
    return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ (e >>> 7 | t << 25)
}

function xa(e, t) {
    return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ e >>> 6
}

function Ea(e, t) {
    return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ (e >>> 6 | t << 26)
}

function j(e, t) {
    return e >>> 0 < t >>> 0 ? 1 : 0
}
$e.prototype._update = function(e) {
    for (var t = this._w, r = this._ah | 0, n = this._bh | 0, i = this._ch | 0, f = this._dh | 0, l = this._eh | 0, h = this._fh | 0, _ = this._gh | 0, b = this._hh | 0, w = this._al | 0, u = this._bl | 0, m = this._cl | 0, v = this._dl | 0, R = this._el | 0, A = this._fl | 0, x = this._gl | 0, s = this._hl | 0, p = 0; p < 32; p += 2) t[p] = e.readInt32BE(p * 4), t[p + 1] = e.readInt32BE(p * 4 + 4);
    for (; p < 160; p += 2) {
        var y = t[p - 30],
            S = t[p - 15 * 2 + 1],
            T = ya(y, S),
            C = wa(S, y);
        y = t[p - 2 * 2], S = t[p - 2 * 2 + 1];
        var O = xa(y, S),
            D = Ea(S, y),
            M = t[p - 7 * 2],
            $ = t[p - 7 * 2 + 1],
            W = t[p - 16 * 2],
            Z = t[p - 16 * 2 + 1],
            q = C + $ | 0,
            z = T + M + j(q, C) | 0;
        q = q + D | 0, z = z + O + j(q, D) | 0, q = q + Z | 0, z = z + W + j(q, Z) | 0, t[p] = z, t[p + 1] = q
    }
    for (var G = 0; G < 160; G += 2) {
        z = t[G], q = t[G + 1];
        var le = qr(r, n, i),
            K = qr(w, u, m),
            ee = jr(r, w),
            Y = jr(w, r),
            te = Wr(l, R),
            ue = Wr(R, l),
            re = Ur[G],
            V = Ur[G + 1],
            he = Hr(l, h, _),
            ne = Hr(R, A, x),
            d = s + ue | 0,
            c = b + te + j(d, s) | 0;
        d = d + ne | 0, c = c + he + j(d, ne) | 0, d = d + V | 0, c = c + re + j(d, V) | 0, d = d + q | 0, c = c + z + j(d, q) | 0;
        var E = Y + K | 0,
            k = ee + le + j(E, Y) | 0;
        b = _, s = x, _ = h, x = A, h = l, A = R, R = v + d | 0, l = f + c + j(R, v) | 0, f = i, v = m, i = n, m = u, n = r, u = w, w = d + E | 0, r = c + k + j(w, d) | 0
    }
    this._al = this._al + w | 0, this._bl = this._bl + u | 0, this._cl = this._cl + m | 0, this._dl = this._dl + v | 0, this._el = this._el + R | 0, this._fl = this._fl + A | 0, this._gl = this._gl + x | 0, this._hl = this._hl + s | 0, this._ah = this._ah + r + j(this._al, w) | 0, this._bh = this._bh + n + j(this._bl, u) | 0, this._ch = this._ch + i + j(this._cl, m) | 0, this._dh = this._dh + f + j(this._dl, v) | 0, this._eh = this._eh + l + j(this._el, R) | 0, this._fh = this._fh + h + j(this._fl, A) | 0, this._gh = this._gh + _ + j(this._gl, x) | 0, this._hh = this._hh + b + j(this._hl, s) | 0
};
$e.prototype._hash = function() {
    var e = va.allocUnsafe(64);

    function t(r, n, i) {
        e.writeInt32BE(r, i), e.writeInt32BE(n, i + 4)
    }
    return t(this._ah, this._al, 0), t(this._bh, this._bl, 8), t(this._ch, this._cl, 16), t(this._dh, this._dl, 24), t(this._eh, this._el, 32), t(this._fh, this._fl, 40), t(this._gh, this._gl, 48), t(this._hh, this._hl, 56), e
};
var An = $e,
    ma = J,
    Sa = An,
    Ra = Ae,
    Ta = ve.Buffer,
    Aa = new Array(160);

function Ze() {
    this.init(), this._w = Aa, Ra.call(this, 128, 112)
}
ma(Ze, Sa);
Ze.prototype.init = function() {
    return this._ah = 3418070365, this._bh = 1654270250, this._ch = 2438529370, this._dh = 355462360, this._eh = 1731405415, this._fh = 2394180231, this._gh = 3675008525, this._hh = 1203062813, this._al = 3238371032, this._bl = 914150663, this._cl = 812702999, this._dl = 4144912697, this._el = 4290775857, this._fl = 1750603025, this._gl = 1694076839, this._hl = 3204075428, this
};
Ze.prototype._hash = function() {
    var e = Ta.allocUnsafe(48);

    function t(r, n, i) {
        e.writeInt32BE(r, i), e.writeInt32BE(n, i + 4)
    }
    return t(this._ah, this._al, 0), t(this._bh, this._bl, 8), t(this._ch, this._cl, 16), t(this._dh, this._dl, 24), t(this._eh, this._el, 32), t(this._fh, this._fl, 40), e
};
var Ba = Ze,
    ge = wn.exports = function(t) {
        t = t.toLowerCase();
        var r = ge[t];
        if (!r) throw new Error(t + " is not supported (we accept pull requests)");
        return new r
    };
ge.sha = Wi;
ge.sha1 = Zi;
ge.sha224 = pa;
ge.sha256 = Rn;
ge.sha384 = Ba;
ge.sha512 = An;
var eo = wn.exports;

function Bn(e) {
    var t, r, n = "";
    if (typeof e == "string" || typeof e == "number") n += e;
    else if (typeof e == "object")
        if (Array.isArray(e))
            for (t = 0; t < e.length; t++) e[t] && (r = Bn(e[t])) && (n && (n += " "), n += r);
        else
            for (t in e) e[t] && (n && (n += " "), n += t);
    return n
}

function zr() {
    for (var e, t, r = 0, n = ""; r < arguments.length;)(e = arguments[r++]) && (t = Bn(e)) && (n && (n += " "), n += t);
    return n
}
const Ca = Object.freeze(Object.defineProperty({
        __proto__: null,
        clsx: zr,
        default: zr
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    to = Ke(Ca);
var Fe, U, Cn, kn, de, Gr, Mn, ur, gr, hr, cr, Dn, Ne = {},
    Nn = [],
    ka = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
    et = Array.isArray;

function oe(e, t) {
    for (var r in t) e[r] = t[r];
    return e
}

function Pn(e) {
    var t = e.parentNode;
    t && t.removeChild(e)
}

function _r(e, t, r) {
    var n, i, f, l = {};
    for (f in t) f == "key" ? n = t[f] : f == "ref" ? i = t[f] : l[f] = t[f];
    if (arguments.length > 2 && (l.children = arguments.length > 3 ? Fe.call(arguments, 2) : r), typeof e == "function" && e.defaultProps != null)
        for (f in e.defaultProps) l[f] === void 0 && (l[f] = e.defaultProps[f]);
    return ke(e, l, n, i, null)
}

function ke(e, t, r, n, i) {
    var f = {
        type: e,
        props: t,
        key: r,
        ref: n,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        constructor: void 0,
        __v: i ? ? ++Cn,
        __i: -1,
        __u: 0
    };
    return i == null && U.vnode != null && U.vnode(f), f
}

function Ma() {
    return {
        current: null
    }
}

function Ue(e) {
    return e.children
}

function Me(e, t) {
    this.props = e, this.context = t
}

function pe(e, t) {
    if (t == null) return e.__ ? pe(e.__, e.__i + 1) : null;
    for (var r; t < e.__k.length; t++)
        if ((r = e.__k[t]) != null && r.__e != null) return r.__e;
    return typeof e.type == "function" ? pe(e) : null
}

function Ln(e) {
    var t, r;
    if ((e = e.__) != null && e.__c != null) {
        for (e.__e = e.__c.base = null, t = 0; t < e.__k.length; t++)
            if ((r = e.__k[t]) != null && r.__e != null) {
                e.__e = e.__c.base = r.__e;
                break
            }
        return Ln(e)
    }
}

function dr(e) {
    (!e.__d && (e.__d = !0) && de.push(e) && !Ve.__r++ || Gr !== U.debounceRendering) && ((Gr = U.debounceRendering) || Mn)(Ve)
}

function Ve() {
    var e, t, r, n, i, f, l, h;
    for (de.sort(ur); e = de.shift();) e.__d && (t = de.length, n = void 0, f = (i = (r = e).__v).__e, l = [], h = [], r.__P && ((n = oe({}, i)).__v = i.__v + 1, U.vnode && U.vnode(n), yr(r.__P, n, i, r.__n, r.__P.namespaceURI, 32 & i.__u ? [f] : null, l, f ? ? pe(i), !!(32 & i.__u), h), n.__v = i.__v, n.__.__k[n.__i] = n, Fn(l, n, h), n.__e != f && Ln(n)), de.length > t && de.sort(ur));
    Ve.__r = 0
}

function On(e, t, r, n, i, f, l, h, _, b, w) {
    var u, m, v, R, A, x = n && n.__k || Nn,
        s = t.length;
    for (r.__d = _, Da(r, t, x), _ = r.__d, u = 0; u < s; u++)(v = r.__k[u]) != null && typeof v != "boolean" && typeof v != "function" && (m = v.__i === -1 ? Ne : x[v.__i] || Ne, v.__i = u, yr(e, v, m, i, f, l, h, _, b, w), R = v.__e, v.ref && m.ref != v.ref && (m.ref && wr(m.ref, null, v), w.push(v.ref, v.__c || R, v)), A == null && R != null && (A = R), 65536 & v.__u || m.__k === v.__k ? _ = In(v, _, e) : typeof v.type == "function" && v.__d !== void 0 ? _ = v.__d : R && (_ = R.nextSibling), v.__d = void 0, v.__u &= -196609);
    r.__d = _, r.__e = A
}

function Da(e, t, r) {
    var n, i, f, l, h, _ = t.length,
        b = r.length,
        w = b,
        u = 0;
    for (e.__k = [], n = 0; n < _; n++) l = n + u, (i = e.__k[n] = (i = t[n]) == null || typeof i == "boolean" || typeof i == "function" ? null : typeof i == "string" || typeof i == "number" || typeof i == "bigint" || i.constructor == String ? ke(null, i, null, null, null) : et(i) ? ke(Ue, {
        children: i
    }, null, null, null) : i.constructor === void 0 && i.__b > 0 ? ke(i.type, i.props, i.key, i.ref ? i.ref : null, i.__v) : i) != null ? (i.__ = e, i.__b = e.__b + 1, h = Na(i, r, l, w), i.__i = h, f = null, h !== -1 && (w--, (f = r[h]) && (f.__u |= 131072)), f == null || f.__v === null ? (h == -1 && u--, typeof i.type != "function" && (i.__u |= 65536)) : h !== l && (h == l - 1 ? u-- : h == l + 1 ? u++ : h > l ? w > _ - l ? u += h - l : u-- : h < l && (h == l - u ? u -= h - l : u++), h !== n + u && (i.__u |= 65536))) : (f = r[l]) && f.key == null && f.__e && !(131072 & f.__u) && (f.__e == e.__d && (e.__d = pe(f)), pr(f, f, !1), r[l] = null, w--);
    if (w)
        for (n = 0; n < b; n++)(f = r[n]) != null && !(131072 & f.__u) && (f.__e == e.__d && (e.__d = pe(f)), pr(f, f))
}

function In(e, t, r) {
    var n, i;
    if (typeof e.type == "function") {
        for (n = e.__k, i = 0; n && i < n.length; i++) n[i] && (n[i].__ = e, t = In(n[i], t, r));
        return t
    }
    e.__e != t && (t && e.type && !r.contains(t) && (t = pe(e)), r.insertBefore(e.__e, t || null), t = e.__e);
    do t = t && t.nextSibling; while (t != null && t.nodeType === 8);
    return t
}

function $n(e, t) {
    return t = t || [], e == null || typeof e == "boolean" || (et(e) ? e.some(function(r) {
        $n(r, t)
    }) : t.push(e)), t
}

function Na(e, t, r, n) {
    var i = e.key,
        f = e.type,
        l = r - 1,
        h = r + 1,
        _ = t[r];
    if (_ === null || _ && i == _.key && f === _.type && !(131072 & _.__u)) return r;
    if (n > (_ != null && !(131072 & _.__u) ? 1 : 0))
        for (; l >= 0 || h < t.length;) {
            if (l >= 0) {
                if ((_ = t[l]) && !(131072 & _.__u) && i == _.key && f === _.type) return l;
                l--
            }
            if (h < t.length) {
                if ((_ = t[h]) && !(131072 & _.__u) && i == _.key && f === _.type) return h;
                h++
            }
        }
    return -1
}

function Vr(e, t, r) {
    t[0] === "-" ? e.setProperty(t, r ? ? "") : e[t] = r == null ? "" : typeof r != "number" || ka.test(t) ? r : r + "px"
}

function je(e, t, r, n, i) {
    var f;
    e: if (t === "style")
        if (typeof r == "string") e.style.cssText = r;
        else {
            if (typeof n == "string" && (e.style.cssText = n = ""), n)
                for (t in n) r && t in r || Vr(e.style, t, "");
            if (r)
                for (t in r) n && r[t] === n[t] || Vr(e.style, t, r[t])
        }
    else if (t[0] === "o" && t[1] === "n") f = t !== (t = t.replace(/(PointerCapture)$|Capture$/i, "$1")), t = t.toLowerCase() in e || t === "onFocusOut" || t === "onFocusIn" ? t.toLowerCase().slice(2) : t.slice(2), e.l || (e.l = {}), e.l[t + f] = r, r ? n ? r.u = n.u : (r.u = gr, e.addEventListener(t, f ? cr : hr, f)) : e.removeEventListener(t, f ? cr : hr, f);
    else {
        if (i == "http://www.w3.org/2000/svg") t = t.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
        else if (t != "width" && t != "height" && t != "href" && t != "list" && t != "form" && t != "tabIndex" && t != "download" && t != "rowSpan" && t != "colSpan" && t != "role" && t != "popover" && t in e) try {
            e[t] = r ? ? "";
            break e
        } catch {}
        typeof r == "function" || (r == null || r === !1 && t[4] !== "-" ? e.removeAttribute(t) : e.setAttribute(t, t == "popover" && r == 1 ? "" : r))
    }
}

function Kr(e) {
    return function(t) {
        if (this.l) {
            var r = this.l[t.type + e];
            if (t.t == null) t.t = gr++;
            else if (t.t < r.u) return;
            return r(U.event ? U.event(t) : t)
        }
    }
}

function yr(e, t, r, n, i, f, l, h, _, b) {
    var w, u, m, v, R, A, x, s, p, y, S, T, C, O, D, M, $ = t.type;
    if (t.constructor !== void 0) return null;
    128 & r.__u && (_ = !!(32 & r.__u), f = [h = t.__e = r.__e]), (w = U.__b) && w(t);
    e: if (typeof $ == "function") try {
        if (s = t.props, p = "prototype" in $ && $.prototype.render, y = (w = $.contextType) && n[w.__c], S = w ? y ? y.props.value : w.__ : n, r.__c ? x = (u = t.__c = r.__c).__ = u.__E : (p ? t.__c = u = new $(s, S) : (t.__c = u = new Me(s, S), u.constructor = $, u.render = La), y && y.sub(u), u.props = s, u.state || (u.state = {}), u.context = S, u.__n = n, m = u.__d = !0, u.__h = [], u._sb = []), p && u.__s == null && (u.__s = u.state), p && $.getDerivedStateFromProps != null && (u.__s == u.state && (u.__s = oe({}, u.__s)), oe(u.__s, $.getDerivedStateFromProps(s, u.__s))), v = u.props, R = u.state, u.__v = t, m) p && $.getDerivedStateFromProps == null && u.componentWillMount != null && u.componentWillMount(), p && u.componentDidMount != null && u.__h.push(u.componentDidMount);
        else {
            if (p && $.getDerivedStateFromProps == null && s !== v && u.componentWillReceiveProps != null && u.componentWillReceiveProps(s, S), !u.__e && (u.shouldComponentUpdate != null && u.shouldComponentUpdate(s, u.__s, S) === !1 || t.__v === r.__v)) {
                for (t.__v !== r.__v && (u.props = s, u.state = u.__s, u.__d = !1), t.__e = r.__e, t.__k = r.__k, t.__k.forEach(function(W) {
                        W && (W.__ = t)
                    }), T = 0; T < u._sb.length; T++) u.__h.push(u._sb[T]);
                u._sb = [], u.__h.length && l.push(u);
                break e
            }
            u.componentWillUpdate != null && u.componentWillUpdate(s, u.__s, S), p && u.componentDidUpdate != null && u.__h.push(function() {
                u.componentDidUpdate(v, R, A)
            })
        }
        if (u.context = S, u.props = s, u.__P = e, u.__e = !1, C = U.__r, O = 0, p) {
            for (u.state = u.__s, u.__d = !1, C && C(t), w = u.render(u.props, u.state, u.context), D = 0; D < u._sb.length; D++) u.__h.push(u._sb[D]);
            u._sb = []
        } else
            do u.__d = !1, C && C(t), w = u.render(u.props, u.state, u.context), u.state = u.__s; while (u.__d && ++O < 25);
        u.state = u.__s, u.getChildContext != null && (n = oe(oe({}, n), u.getChildContext())), p && !m && u.getSnapshotBeforeUpdate != null && (A = u.getSnapshotBeforeUpdate(v, R)), On(e, et(M = w != null && w.type === Ue && w.key == null ? w.props.children : w) ? M : [M], t, r, n, i, f, l, h, _, b), u.base = t.__e, t.__u &= -161, u.__h.length && l.push(u), x && (u.__E = u.__ = null)
    } catch (W) {
        if (t.__v = null, _ || f != null) {
            for (t.__u |= _ ? 160 : 32; h && h.nodeType === 8 && h.nextSibling;) h = h.nextSibling;
            f[f.indexOf(h)] = null, t.__e = h
        } else t.__e = r.__e, t.__k = r.__k;
        U.__e(W, t, r)
    } else f == null && t.__v === r.__v ? (t.__k = r.__k, t.__e = r.__e) : t.__e = Pa(r.__e, t, r, n, i, f, l, _, b);
    (w = U.diffed) && w(t)
}

function Fn(e, t, r) {
    t.__d = void 0;
    for (var n = 0; n < r.length; n++) wr(r[n], r[++n], r[++n]);
    U.__c && U.__c(t, e), e.some(function(i) {
        try {
            e = i.__h, i.__h = [], e.some(function(f) {
                f.call(i)
            })
        } catch (f) {
            U.__e(f, i.__v)
        }
    })
}

function Pa(e, t, r, n, i, f, l, h, _) {
    var b, w, u, m, v, R, A, x = r.props,
        s = t.props,
        p = t.type;
    if (p === "svg" ? i = "http://www.w3.org/2000/svg" : p === "math" ? i = "http://www.w3.org/1998/Math/MathML" : i || (i = "http://www.w3.org/1999/xhtml"), f != null) {
        for (b = 0; b < f.length; b++)
            if ((v = f[b]) && "setAttribute" in v == !!p && (p ? v.localName === p : v.nodeType === 3)) {
                e = v, f[b] = null;
                break
            }
    }
    if (e == null) {
        if (p === null) return document.createTextNode(s);
        e = document.createElementNS(i, p, s.is && s), f = null, h = !1
    }
    if (p === null) x === s || h && e.data === s || (e.data = s);
    else {
        if (f = f && Fe.call(e.childNodes), x = r.props || Ne, !h && f != null)
            for (x = {}, b = 0; b < e.attributes.length; b++) x[(v = e.attributes[b]).name] = v.value;
        for (b in x)
            if (v = x[b], b != "children") {
                if (b == "dangerouslySetInnerHTML") u = v;
                else if (b !== "key" && !(b in s)) {
                    if (b == "value" && "defaultValue" in s || b == "checked" && "defaultChecked" in s) continue;
                    je(e, b, null, v, i)
                }
            }
        for (b in s) v = s[b], b == "children" ? m = v : b == "dangerouslySetInnerHTML" ? w = v : b == "value" ? R = v : b == "checked" ? A = v : b === "key" || h && typeof v != "function" || x[b] === v || je(e, b, v, x[b], i);
        if (w) h || u && (w.__html === u.__html || w.__html === e.innerHTML) || (e.innerHTML = w.__html), t.__k = [];
        else if (u && (e.innerHTML = ""), On(e, et(m) ? m : [m], t, r, n, p === "foreignObject" ? "http://www.w3.org/1999/xhtml" : i, f, l, f ? f[0] : r.__k && pe(r, 0), h, _), f != null)
            for (b = f.length; b--;) f[b] != null && Pn(f[b]);
        h || (b = "value", R !== void 0 && (R !== e[b] || p === "progress" && !R || p === "option" && R !== x[b]) && je(e, b, R, x[b], i), b = "checked", A !== void 0 && A !== e[b] && je(e, b, A, x[b], i))
    }
    return e
}

function wr(e, t, r) {
    try {
        if (typeof e == "function") {
            var n = typeof e.__u == "function";
            n && e.__u(), n && t == null || (e.__u = e(t))
        } else e.current = t
    } catch (i) {
        U.__e(i, r)
    }
}

function pr(e, t, r) {
    var n, i;
    if (U.unmount && U.unmount(e), (n = e.ref) && (n.current && n.current !== e.__e || wr(n, null, t)), (n = e.__c) != null) {
        if (n.componentWillUnmount) try {
            n.componentWillUnmount()
        } catch (f) {
            U.__e(f, t)
        }
        n.base = n.__P = null
    }
    if (n = e.__k)
        for (i = 0; i < n.length; i++) n[i] && pr(n[i], t, r || typeof e.type != "function");
    r || e.__e == null || Pn(e.__e), e.__c = e.__ = e.__e = e.__d = void 0
}

function La(e, t, r) {
    return this.constructor(e, r)
}

function Un(e, t, r) {
    var n, i, f, l;
    U.__ && U.__(e, t), i = (n = typeof r == "function") ? null : r && r.__k || t.__k, f = [], l = [], yr(t, e = (!n && r || t).__k = _r(Ue, null, [e]), i || Ne, Ne, t.namespaceURI, !n && r ? [r] : i ? null : t.firstChild ? Fe.call(t.childNodes) : null, f, !n && r ? r : i ? i.__e : t.firstChild, n, l), Fn(f, e, l)
}

function Hn(e, t) {
    Un(e, t, Hn)
}

function Oa(e, t, r) {
    var n, i, f, l, h = oe({}, e.props);
    for (f in e.type && e.type.defaultProps && (l = e.type.defaultProps), t) f == "key" ? n = t[f] : f == "ref" ? i = t[f] : h[f] = t[f] === void 0 && l !== void 0 ? l[f] : t[f];
    return arguments.length > 2 && (h.children = arguments.length > 3 ? Fe.call(arguments, 2) : r), ke(e.type, h, n || e.key, i || e.ref, null)
}

function Ia(e, t) {
    var r = {
        __c: t = "__cC" + Dn++,
        __: e,
        Consumer: function(n, i) {
            return n.children(i)
        },
        Provider: function(n) {
            var i, f;
            return this.getChildContext || (i = [], (f = {})[t] = this, this.getChildContext = function() {
                return f
            }, this.componentWillUnmount = function() {
                i = null
            }, this.shouldComponentUpdate = function(l) {
                this.props.value !== l.value && i.some(function(h) {
                    h.__e = !0, dr(h)
                })
            }, this.sub = function(l) {
                i.push(l);
                var h = l.componentWillUnmount;
                l.componentWillUnmount = function() {
                    i && i.splice(i.indexOf(l), 1), h && h.call(l)
                }
            }), n.children
        }
    };
    return r.Provider.__ = r.Consumer.contextType = r
}
Fe = Nn.slice, U = {
    __e: function(e, t, r, n) {
        for (var i, f, l; t = t.__;)
            if ((i = t.__c) && !i.__) try {
                if ((f = i.constructor) && f.getDerivedStateFromError != null && (i.setState(f.getDerivedStateFromError(e)), l = i.__d), i.componentDidCatch != null && (i.componentDidCatch(e, n || {}), l = i.__d), l) return i.__E = i
            } catch (h) {
                e = h
            }
        throw e
    }
}, Cn = 0, kn = function(e) {
    return e != null && e.constructor == null
}, Me.prototype.setState = function(e, t) {
    var r;
    r = this.__s != null && this.__s !== this.state ? this.__s : this.__s = oe({}, this.state), typeof e == "function" && (e = e(oe({}, r), this.props)), e && oe(r, e), e != null && this.__v && (t && this._sb.push(t), dr(this))
}, Me.prototype.forceUpdate = function(e) {
    this.__v && (this.__e = !0, e && this.__h.push(e), dr(this))
}, Me.prototype.render = Ue, de = [], Mn = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, ur = function(e, t) {
    return e.__v.__b - t.__v.__b
}, Ve.__r = 0, gr = 0, hr = Kr(!1), cr = Kr(!0), Dn = 0;
const $a = Object.freeze(Object.defineProperty({
        __proto__: null,
        Component: Me,
        Fragment: Ue,
        cloneElement: Oa,
        createContext: Ia,
        createElement: _r,
        createRef: Ma,
        h: _r,
        hydrate: Hn,
        get isValidElement() {
            return kn
        },
        get options() {
            return U
        },
        render: Un,
        toChildArray: $n
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ro = Ke($a);
var se, I, ar, Yr, Re = 0,
    qn = [],
    H = U,
    Xr = H.__b,
    Jr = H.__r,
    Qr = H.diffed,
    Zr = H.__c,
    en = H.unmount,
    tn = H.__;

function ye(e, t) {
    H.__h && H.__h(I, e, Re || t), Re = 0;
    var r = I.__H || (I.__H = {
        __: [],
        __h: []
    });
    return e >= r.__.length && r.__.push({}), r.__[e]
}

function jn(e) {
    return Re = 1, Wn(Gn, e)
}

function Wn(e, t, r) {
    var n = ye(se++, 2);
    if (n.t = e, !n.__c && (n.__ = [r ? r(t) : Gn(void 0, t), function(h) {
            var _ = n.__N ? n.__N[0] : n.__[0],
                b = n.t(_, h);
            _ !== b && (n.__N = [b, n.__[1]], n.__c.setState({}))
        }], n.__c = I, !I.u)) {
        var i = function(h, _, b) {
            if (!n.__c.__H) return !0;
            var w = n.__c.__H.__.filter(function(m) {
                return !!m.__c
            });
            if (w.every(function(m) {
                    return !m.__N
                })) return !f || f.call(this, h, _, b);
            var u = !1;
            return w.forEach(function(m) {
                if (m.__N) {
                    var v = m.__[0];
                    m.__ = m.__N, m.__N = void 0, v !== m.__[0] && (u = !0)
                }
            }), !(!u && n.__c.props === h) && (!f || f.call(this, h, _, b))
        };
        I.u = !0;
        var f = I.shouldComponentUpdate,
            l = I.componentWillUpdate;
        I.componentWillUpdate = function(h, _, b) {
            if (this.__e) {
                var w = f;
                f = void 0, i(h, _, b), f = w
            }
            l && l.call(this, h, _, b)
        }, I.shouldComponentUpdate = i
    }
    return n.__N || n.__
}

function Fa(e, t) {
    var r = ye(se++, 3);
    !H.__s && Er(r.__H, t) && (r.__ = e, r.i = t, I.__H.__h.push(r))
}

function zn(e, t) {
    var r = ye(se++, 4);
    !H.__s && Er(r.__H, t) && (r.__ = e, r.i = t, I.__h.push(r))
}

function Ua(e) {
    return Re = 5, xr(function() {
        return {
            current: e
        }
    }, [])
}

function Ha(e, t, r) {
    Re = 6, zn(function() {
        return typeof e == "function" ? (e(t()), function() {
            return e(null)
        }) : e ? (e.current = t(), function() {
            return e.current = null
        }) : void 0
    }, r == null ? r : r.concat(e))
}

function xr(e, t) {
    var r = ye(se++, 7);
    return Er(r.__H, t) && (r.__ = e(), r.__H = t, r.__h = e), r.__
}

function qa(e, t) {
    return Re = 8, xr(function() {
        return e
    }, t)
}

function ja(e) {
    var t = I.context[e.__c],
        r = ye(se++, 9);
    return r.c = e, t ? (r.__ == null && (r.__ = !0, t.sub(I)), t.props.value) : e.__
}

function Wa(e, t) {
    H.useDebugValue && H.useDebugValue(t ? t(e) : e)
}

function za(e) {
    var t = ye(se++, 10),
        r = jn();
    return t.__ = e, I.componentDidCatch || (I.componentDidCatch = function(n, i) {
        t.__ && t.__(n, i), r[1](n)
    }), [r[0], function() {
        r[1](void 0)
    }]
}

function Ga() {
    var e = ye(se++, 11);
    if (!e.__) {
        for (var t = I.__v; t !== null && !t.__m && t.__ !== null;) t = t.__;
        var r = t.__m || (t.__m = [0, 0]);
        e.__ = "P" + r[0] + "-" + r[1]++
    }
    return e.__
}

function Va() {
    for (var e; e = qn.shift();)
        if (e.__P && e.__H) try {
            e.__H.__h.forEach(ze), e.__H.__h.forEach(br), e.__H.__h = []
        } catch (t) {
            e.__H.__h = [], H.__e(t, e.__v)
        }
}
H.__b = function(e) {
    I = null, Xr && Xr(e)
}, H.__ = function(e, t) {
    e && t.__k && t.__k.__m && (e.__m = t.__k.__m), tn && tn(e, t)
}, H.__r = function(e) {
    Jr && Jr(e), se = 0;
    var t = (I = e.__c).__H;
    t && (ar === I ? (t.__h = [], I.__h = [], t.__.forEach(function(r) {
        r.__N && (r.__ = r.__N), r.i = r.__N = void 0
    })) : (t.__h.forEach(ze), t.__h.forEach(br), t.__h = [], se = 0)), ar = I
}, H.diffed = function(e) {
    Qr && Qr(e);
    var t = e.__c;
    t && t.__H && (t.__H.__h.length && (qn.push(t) !== 1 && Yr === H.requestAnimationFrame || ((Yr = H.requestAnimationFrame) || Ka)(Va)), t.__H.__.forEach(function(r) {
        r.i && (r.__H = r.i), r.i = void 0
    })), ar = I = null
}, H.__c = function(e, t) {
    t.some(function(r) {
        try {
            r.__h.forEach(ze), r.__h = r.__h.filter(function(n) {
                return !n.__ || br(n)
            })
        } catch (n) {
            t.some(function(i) {
                i.__h && (i.__h = [])
            }), t = [], H.__e(n, r.__v)
        }
    }), Zr && Zr(e, t)
}, H.unmount = function(e) {
    en && en(e);
    var t, r = e.__c;
    r && r.__H && (r.__H.__.forEach(function(n) {
        try {
            ze(n)
        } catch (i) {
            t = i
        }
    }), r.__H = void 0, t && H.__e(t, r.__v))
};
var rn = typeof requestAnimationFrame == "function";

function Ka(e) {
    var t, r = function() {
            clearTimeout(n), rn && cancelAnimationFrame(t), setTimeout(e)
        },
        n = setTimeout(r, 100);
    rn && (t = requestAnimationFrame(r))
}

function ze(e) {
    var t = I,
        r = e.__c;
    typeof r == "function" && (e.__c = void 0, r()), I = t
}

function br(e) {
    var t = I;
    e.__c = e.__(), I = t
}

function Er(e, t) {
    return !e || e.length !== t.length || t.some(function(r, n) {
        return r !== e[n]
    })
}

function Gn(e, t) {
    return typeof t == "function" ? t(e) : t
}
const Ya = Object.freeze(Object.defineProperty({
        __proto__: null,
        useCallback: qa,
        useContext: ja,
        useDebugValue: Wa,
        useEffect: Fa,
        useErrorBoundary: za,
        useId: Ga,
        useImperativeHandle: Ha,
        useLayoutEffect: zn,
        useMemo: xr,
        useReducer: Wn,
        useRef: Ua,
        useState: jn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    no = Ke(Ya);
export {
    ro as a, no as b, Qa as c, Za as j, to as r, eo as s
};