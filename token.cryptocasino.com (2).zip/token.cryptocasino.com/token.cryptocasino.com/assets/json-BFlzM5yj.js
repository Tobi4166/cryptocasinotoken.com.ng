import {
    q as Bt
} from "./index-B7sV4wI7.js";
import {
    r as It
} from "./___vite-browser-external_commonjs-proxy-C_4t5wKq.js";
var Rt = {};
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var We = function(e, r) {
    return We = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(n, a) {
        n.__proto__ = a
    } || function(n, a) {
        for (var D in a) a.hasOwnProperty(D) && (n[D] = a[D])
    }, We(e, r)
};

function Pt(e, r) {
    We(e, r);

    function n() {
        this.constructor = e
    }
    e.prototype = r === null ? Object.create(r) : (n.prototype = r.prototype, new n)
}
var Ge = function() {
    return Ge = Object.assign || function(r) {
        for (var n, a = 1, D = arguments.length; a < D; a++) {
            n = arguments[a];
            for (var l in n) Object.prototype.hasOwnProperty.call(n, l) && (r[l] = n[l])
        }
        return r
    }, Ge.apply(this, arguments)
};

function Ht(e, r) {
    var n = {};
    for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && r.indexOf(a) < 0 && (n[a] = e[a]);
    if (e != null && typeof Object.getOwnPropertySymbols == "function")
        for (var D = 0, a = Object.getOwnPropertySymbols(e); D < a.length; D++) r.indexOf(a[D]) < 0 && Object.prototype.propertyIsEnumerable.call(e, a[D]) && (n[a[D]] = e[a[D]]);
    return n
}

function Kt(e, r, n, a) {
    var D = arguments.length,
        l = D < 3 ? r : a === null ? a = Object.getOwnPropertyDescriptor(r, n) : a,
        v;
    if (typeof Reflect == "object" && typeof Reflect.decorate == "function") l = Reflect.decorate(e, r, n, a);
    else
        for (var o = e.length - 1; o >= 0; o--)(v = e[o]) && (l = (D < 3 ? v(l) : D > 3 ? v(r, n, l) : v(r, n)) || l);
    return D > 3 && l && Object.defineProperty(r, n, l), l
}

function qt(e, r) {
    return function(n, a) {
        r(n, a, e)
    }
}

function $t(e, r) {
    if (typeof Reflect == "object" && typeof Reflect.metadata == "function") return Reflect.metadata(e, r)
}

function zt(e, r, n, a) {
    function D(l) {
        return l instanceof n ? l : new n(function(v) {
            v(l)
        })
    }
    return new(n || (n = Promise))(function(l, v) {
        function o(E) {
            try {
                d(a.next(E))
            } catch (g) {
                v(g)
            }
        }

        function c(E) {
            try {
                d(a.throw(E))
            } catch (g) {
                v(g)
            }
        }

        function d(E) {
            E.done ? l(E.value) : D(E.value).then(o, c)
        }
        d((a = a.apply(e, r || [])).next())
    })
}

function Yt(e, r) {
    var n = {
            label: 0,
            sent: function() {
                if (l[0] & 1) throw l[1];
                return l[1]
            },
            trys: [],
            ops: []
        },
        a, D, l, v;
    return v = {
        next: o(0),
        throw: o(1),
        return: o(2)
    }, typeof Symbol == "function" && (v[Symbol.iterator] = function() {
        return this
    }), v;

    function o(d) {
        return function(E) {
            return c([d, E])
        }
    }

    function c(d) {
        if (a) throw new TypeError("Generator is already executing.");
        for (; n;) try {
            if (a = 1, D && (l = d[0] & 2 ? D.return : d[0] ? D.throw || ((l = D.return) && l.call(D), 0) : D.next) && !(l = l.call(D, d[1])).done) return l;
            switch (D = 0, l && (d = [d[0] & 2, l.value]), d[0]) {
                case 0:
                case 1:
                    l = d;
                    break;
                case 4:
                    return n.label++, {
                        value: d[1],
                        done: !1
                    };
                case 5:
                    n.label++, D = d[1], d = [0];
                    continue;
                case 7:
                    d = n.ops.pop(), n.trys.pop();
                    continue;
                default:
                    if (l = n.trys, !(l = l.length > 0 && l[l.length - 1]) && (d[0] === 6 || d[0] === 2)) {
                        n = 0;
                        continue
                    }
                    if (d[0] === 3 && (!l || d[1] > l[0] && d[1] < l[3])) {
                        n.label = d[1];
                        break
                    }
                    if (d[0] === 6 && n.label < l[1]) {
                        n.label = l[1], l = d;
                        break
                    }
                    if (l && n.label < l[2]) {
                        n.label = l[2], n.ops.push(d);
                        break
                    }
                    l[2] && n.ops.pop(), n.trys.pop();
                    continue
            }
            d = r.call(e, n)
        } catch (E) {
            d = [6, E], D = 0
        } finally {
            a = l = 0
        }
        if (d[0] & 5) throw d[1];
        return {
            value: d[0] ? d[1] : void 0,
            done: !0
        }
    }
}

function Wt(e, r, n, a) {
    a === void 0 && (a = n), e[a] = r[n]
}

function Gt(e, r) {
    for (var n in e) n !== "default" && !r.hasOwnProperty(n) && (r[n] = e[n])
}

function Ve(e) {
    var r = typeof Symbol == "function" && Symbol.iterator,
        n = r && e[r],
        a = 0;
    if (n) return n.call(e);
    if (e && typeof e.length == "number") return {
        next: function() {
            return e && a >= e.length && (e = void 0), {
                value: e && e[a++],
                done: !e
            }
        }
    };
    throw new TypeError(r ? "Object is not iterable." : "Symbol.iterator is not defined.")
}

function vt(e, r) {
    var n = typeof Symbol == "function" && e[Symbol.iterator];
    if (!n) return e;
    var a = n.call(e),
        D, l = [],
        v;
    try {
        for (;
            (r === void 0 || r-- > 0) && !(D = a.next()).done;) l.push(D.value)
    } catch (o) {
        v = {
            error: o
        }
    } finally {
        try {
            D && !D.done && (n = a.return) && n.call(a)
        } finally {
            if (v) throw v.error
        }
    }
    return l
}

function Vt() {
    for (var e = [], r = 0; r < arguments.length; r++) e = e.concat(vt(arguments[r]));
    return e
}

function Xt() {
    for (var e = 0, r = 0, n = arguments.length; r < n; r++) e += arguments[r].length;
    for (var a = Array(e), D = 0, r = 0; r < n; r++)
        for (var l = arguments[r], v = 0, o = l.length; v < o; v++, D++) a[D] = l[v];
    return a
}

function Fe(e) {
    return this instanceof Fe ? (this.v = e, this) : new Fe(e)
}

function Jt(e, r, n) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var a = n.apply(e, r || []),
        D, l = [];
    return D = {}, v("next"), v("throw"), v("return"), D[Symbol.asyncIterator] = function() {
        return this
    }, D;

    function v(w) {
        a[w] && (D[w] = function(b) {
            return new Promise(function(y, p) {
                l.push([w, b, y, p]) > 1 || o(w, b)
            })
        })
    }

    function o(w, b) {
        try {
            c(a[w](b))
        } catch (y) {
            g(l[0][3], y)
        }
    }

    function c(w) {
        w.value instanceof Fe ? Promise.resolve(w.value.v).then(d, E) : g(l[0][2], w)
    }

    function d(w) {
        o("next", w)
    }

    function E(w) {
        o("throw", w)
    }

    function g(w, b) {
        w(b), l.shift(), l.length && o(l[0][0], l[0][1])
    }
}

function Qt(e) {
    var r, n;
    return r = {}, a("next"), a("throw", function(D) {
        throw D
    }), a("return"), r[Symbol.iterator] = function() {
        return this
    }, r;

    function a(D, l) {
        r[D] = e[D] ? function(v) {
            return (n = !n) ? {
                value: Fe(e[D](v)),
                done: D === "return"
            } : l ? l(v) : v
        } : l
    }
}

function Zt(e) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var r = e[Symbol.asyncIterator],
        n;
    return r ? r.call(e) : (e = typeof Ve == "function" ? Ve(e) : e[Symbol.iterator](), n = {}, a("next"), a("throw"), a("return"), n[Symbol.asyncIterator] = function() {
        return this
    }, n);

    function a(l) {
        n[l] = e[l] && function(v) {
            return new Promise(function(o, c) {
                v = e[l](v), D(o, c, v.done, v.value)
            })
        }
    }

    function D(l, v, o, c) {
        Promise.resolve(c).then(function(d) {
            l({
                value: d,
                done: o
            })
        }, v)
    }
}

function kt(e, r) {
    return Object.defineProperty ? Object.defineProperty(e, "raw", {
        value: r
    }) : e.raw = r, e
}

function er(e) {
    if (e && e.__esModule) return e;
    var r = {};
    if (e != null)
        for (var n in e) Object.hasOwnProperty.call(e, n) && (r[n] = e[n]);
    return r.default = e, r
}

function tr(e) {
    return e && e.__esModule ? e : {
        default: e
    }
}

function rr(e, r) {
    if (!r.has(e)) throw new TypeError("attempted to get private field on non-instance");
    return r.get(e)
}

function nr(e, r, n) {
    if (!r.has(e)) throw new TypeError("attempted to set private field on non-instance");
    return r.set(e, n), n
}
const ir = Object.freeze(Object.defineProperty({
        __proto__: null,
        get __assign() {
            return Ge
        },
        __asyncDelegator: Qt,
        __asyncGenerator: Jt,
        __asyncValues: Zt,
        __await: Fe,
        __awaiter: zt,
        __classPrivateFieldGet: rr,
        __classPrivateFieldSet: nr,
        __createBinding: Wt,
        __decorate: Kt,
        __exportStar: Gt,
        __extends: Pt,
        __generator: Yt,
        __importDefault: tr,
        __importStar: er,
        __makeTemplateObject: kt,
        __metadata: $t,
        __param: qt,
        __read: vt,
        __rest: Ht,
        __spread: Vt,
        __spreadArrays: Xt,
        __values: Ve
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    je = Bt(ir);
var qe = {},
    Ae = {},
    it;

function ar() {
    if (it) return Ae;
    it = 1, Object.defineProperty(Ae, "__esModule", {
        value: !0
    }), Ae.delay = void 0;

    function e(r) {
        return new Promise(n => {
            setTimeout(() => {
                n(!0)
            }, r)
        })
    }
    return Ae.delay = e, Ae
}
var ge = {},
    $e = {},
    ye = {},
    at;

function ur() {
    return at || (at = 1, Object.defineProperty(ye, "__esModule", {
        value: !0
    }), ye.ONE_THOUSAND = ye.ONE_HUNDRED = void 0, ye.ONE_HUNDRED = 100, ye.ONE_THOUSAND = 1e3), ye
}
var ze = {},
    ut;

function or() {
    return ut || (ut = 1, function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.ONE_YEAR = e.FOUR_WEEKS = e.THREE_WEEKS = e.TWO_WEEKS = e.ONE_WEEK = e.THIRTY_DAYS = e.SEVEN_DAYS = e.FIVE_DAYS = e.THREE_DAYS = e.ONE_DAY = e.TWENTY_FOUR_HOURS = e.TWELVE_HOURS = e.SIX_HOURS = e.THREE_HOURS = e.ONE_HOUR = e.SIXTY_MINUTES = e.THIRTY_MINUTES = e.TEN_MINUTES = e.FIVE_MINUTES = e.ONE_MINUTE = e.SIXTY_SECONDS = e.THIRTY_SECONDS = e.TEN_SECONDS = e.FIVE_SECONDS = e.ONE_SECOND = void 0, e.ONE_SECOND = 1, e.FIVE_SECONDS = 5, e.TEN_SECONDS = 10, e.THIRTY_SECONDS = 30, e.SIXTY_SECONDS = 60, e.ONE_MINUTE = e.SIXTY_SECONDS, e.FIVE_MINUTES = e.ONE_MINUTE * 5, e.TEN_MINUTES = e.ONE_MINUTE * 10, e.THIRTY_MINUTES = e.ONE_MINUTE * 30, e.SIXTY_MINUTES = e.ONE_MINUTE * 60, e.ONE_HOUR = e.SIXTY_MINUTES, e.THREE_HOURS = e.ONE_HOUR * 3, e.SIX_HOURS = e.ONE_HOUR * 6, e.TWELVE_HOURS = e.ONE_HOUR * 12, e.TWENTY_FOUR_HOURS = e.ONE_HOUR * 24, e.ONE_DAY = e.TWENTY_FOUR_HOURS, e.THREE_DAYS = e.ONE_DAY * 3, e.FIVE_DAYS = e.ONE_DAY * 5, e.SEVEN_DAYS = e.ONE_DAY * 7, e.THIRTY_DAYS = e.ONE_DAY * 30, e.ONE_WEEK = e.SEVEN_DAYS, e.TWO_WEEKS = e.ONE_WEEK * 2, e.THREE_WEEKS = e.ONE_WEEK * 3, e.FOUR_WEEKS = e.ONE_WEEK * 4, e.ONE_YEAR = e.ONE_DAY * 365
    }(ze)), ze
}
var ot;

function gt() {
    return ot || (ot = 1, function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        const r = je;
        r.__exportStar(ur(), e), r.__exportStar(or(), e)
    }($e)), $e
}
var ft;

function fr() {
    if (ft) return ge;
    ft = 1, Object.defineProperty(ge, "__esModule", {
        value: !0
    }), ge.fromMiliseconds = ge.toMiliseconds = void 0;
    const e = gt();

    function r(a) {
        return a * e.ONE_THOUSAND
    }
    ge.toMiliseconds = r;

    function n(a) {
        return Math.floor(a / e.ONE_THOUSAND)
    }
    return ge.fromMiliseconds = n, ge
}
var st;

function sr() {
    return st || (st = 1, function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        const r = je;
        r.__exportStar(ar(), e), r.__exportStar(fr(), e)
    }(qe)), qe
}
var pe = {},
    ht;

function hr() {
    if (ht) return pe;
    ht = 1, Object.defineProperty(pe, "__esModule", {
        value: !0
    }), pe.Watch = void 0;
    class e {
        constructor() {
            this.timestamps = new Map
        }
        start(n) {
            if (this.timestamps.has(n)) throw new Error(`Watch already started for label: ${n}`);
            this.timestamps.set(n, {
                started: Date.now()
            })
        }
        stop(n) {
            const a = this.get(n);
            if (typeof a.elapsed < "u") throw new Error(`Watch already stopped for label: ${n}`);
            const D = Date.now() - a.started;
            this.timestamps.set(n, {
                started: a.started,
                elapsed: D
            })
        }
        get(n) {
            const a = this.timestamps.get(n);
            if (typeof a > "u") throw new Error(`No timestamp found for label: ${n}`);
            return a
        }
        elapsed(n) {
            const a = this.get(n);
            return a.elapsed || Date.now() - a.started
        }
    }
    return pe.Watch = e, pe.default = e, pe
}
var Ye = {},
    Ue = {},
    ct;

function cr() {
    if (ct) return Ue;
    ct = 1, Object.defineProperty(Ue, "__esModule", {
        value: !0
    }), Ue.IWatch = void 0;
    class e {}
    return Ue.IWatch = e, Ue
}
var lt;

function lr() {
    return lt || (lt = 1, function(e) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), je.__exportStar(cr(), e)
    }(Ye)), Ye
}(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    const r = je;
    r.__exportStar(sr(), e), r.__exportStar(hr(), e), r.__exportStar(lr(), e), r.__exportStar(gt(), e)
})(Rt);
var Y = {};
Object.defineProperty(Y, "__esModule", {
    value: !0
});
Y.getLocalStorage = Y.getLocalStorageOrThrow = Y.getCrypto = Y.getCryptoOrThrow = yr = Y.getLocation = Y.getLocationOrThrow = wr = Y.getNavigator = Y.getNavigatorOrThrow = dr = Y.getDocument = Y.getDocumentOrThrow = Y.getFromWindowOrThrow = Y.getFromWindow = void 0;

function me(e) {
    let r;
    return typeof window < "u" && typeof window[e] < "u" && (r = window[e]), r
}
Y.getFromWindow = me;

function Ce(e) {
    const r = me(e);
    if (!r) throw new Error(`${e} is not defined in Window`);
    return r
}
Y.getFromWindowOrThrow = Ce;

function Dr() {
    return Ce("document")
}
Y.getDocumentOrThrow = Dr;

function _r() {
    return me("document")
}
var dr = Y.getDocument = _r;

function Er() {
    return Ce("navigator")
}
Y.getNavigatorOrThrow = Er;

function br() {
    return me("navigator")
}
var wr = Y.getNavigator = br;

function vr() {
    return Ce("location")
}
Y.getLocationOrThrow = vr;

function gr() {
    return me("location")
}
var yr = Y.getLocation = gr;

function mr() {
    return Ce("crypto")
}
Y.getCryptoOrThrow = mr;

function Sr() {
    return me("crypto")
}
Y.getCrypto = Sr;

function pr() {
    return Ce("localStorage")
}
Y.getLocalStorageOrThrow = pr;

function Cr() {
    return me("localStorage")
}
Y.getLocalStorage = Cr;
var tt = {};
Object.defineProperty(tt, "__esModule", {
    value: !0
});
var Or = tt.getWindowMetadata = void 0;
const Dt = Y;

function Ar() {
    let e, r;
    try {
        e = Dt.getDocumentOrThrow(), r = Dt.getLocationOrThrow()
    } catch {
        return null
    }

    function n() {
        const g = e.getElementsByTagName("link"),
            w = [];
        for (let b = 0; b < g.length; b++) {
            const y = g[b],
                p = y.getAttribute("rel");
            if (p && p.toLowerCase().indexOf("icon") > -1) {
                const m = y.getAttribute("href");
                if (m)
                    if (m.toLowerCase().indexOf("https:") === -1 && m.toLowerCase().indexOf("http:") === -1 && m.indexOf("//") !== 0) {
                        let U = r.protocol + "//" + r.host;
                        if (m.indexOf("/") === 0) U += m;
                        else {
                            const h = r.pathname.split("/");
                            h.pop();
                            const _ = h.join("/");
                            U += _ + "/" + m
                        }
                        w.push(U)
                    } else if (m.indexOf("//") === 0) {
                    const U = r.protocol + m;
                    w.push(U)
                } else w.push(m)
            }
        }
        return w
    }

    function a(...g) {
        const w = e.getElementsByTagName("meta");
        for (let b = 0; b < w.length; b++) {
            const y = w[b],
                p = ["itemprop", "property", "name"].map(m => y.getAttribute(m)).filter(m => m ? g.includes(m) : !1);
            if (p.length && p) {
                const m = y.getAttribute("content");
                if (m) return m
            }
        }
        return ""
    }

    function D() {
        let g = a("name", "og:site_name", "og:title", "twitter:title");
        return g || (g = e.title), g
    }

    function l() {
        return a("description", "og:description", "twitter:description", "keywords")
    }
    const v = D(),
        o = l(),
        c = r.origin,
        d = n();
    return {
        description: o,
        url: c,
        icons: d,
        name: v
    }
}
Or = tt.getWindowMetadata = Ar;
var Ur = {},
    Fr = e => encodeURIComponent(e).replace(/[!'()*]/g, r => `%${r.charCodeAt(0).toString(16).toUpperCase()}`),
    yt = "%[a-f0-9]{2}",
    _t = new RegExp("(" + yt + ")|([^%]+?)", "gi"),
    dt = new RegExp("(" + yt + ")+", "gi");

function Xe(e, r) {
    try {
        return [decodeURIComponent(e.join(""))]
    } catch {}
    if (e.length === 1) return e;
    r = r || 1;
    var n = e.slice(0, r),
        a = e.slice(r);
    return Array.prototype.concat.call([], Xe(n), Xe(a))
}

function Tr(e) {
    try {
        return decodeURIComponent(e)
    } catch {
        for (var r = e.match(_t) || [], n = 1; n < r.length; n++) e = Xe(r, n).join(""), r = e.match(_t) || [];
        return e
    }
}

function Nr(e) {
    for (var r = {
            "%FE%FF": "��",
            "%FF%FE": "��"
        }, n = dt.exec(e); n;) {
        try {
            r[n[0]] = decodeURIComponent(n[0])
        } catch {
            var a = Tr(n[0]);
            a !== n[0] && (r[n[0]] = a)
        }
        n = dt.exec(e)
    }
    r["%C2"] = "�";
    for (var D = Object.keys(r), l = 0; l < D.length; l++) {
        var v = D[l];
        e = e.replace(new RegExp(v, "g"), r[v])
    }
    return e
}
var Lr = function(e) {
        if (typeof e != "string") throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof e + "`");
        try {
            return e = e.replace(/\+/g, " "), decodeURIComponent(e)
        } catch {
            return Nr(e)
        }
    },
    Mr = (e, r) => {
        if (!(typeof e == "string" && typeof r == "string")) throw new TypeError("Expected the arguments to be of type `string`");
        if (r === "") return [e];
        const n = e.indexOf(r);
        return n === -1 ? [e] : [e.slice(0, n), e.slice(n + r.length)]
    },
    xr = function(e, r) {
        for (var n = {}, a = Object.keys(e), D = Array.isArray(r), l = 0; l < a.length; l++) {
            var v = a[l],
                o = e[v];
            (D ? r.indexOf(v) !== -1 : r(v, o, e)) && (n[v] = o)
        }
        return n
    };
(function(e) {
    const r = Fr,
        n = Lr,
        a = Mr,
        D = xr,
        l = h => h == null,
        v = Symbol("encodeFragmentIdentifier");

    function o(h) {
        switch (h.arrayFormat) {
            case "index":
                return _ => (u, s) => {
                    const f = u.length;
                    return s === void 0 || h.skipNull && s === null || h.skipEmptyString && s === "" ? u : s === null ? [...u, [E(_, h), "[", f, "]"].join("")] : [...u, [E(_, h), "[", E(f, h), "]=", E(s, h)].join("")]
                };
            case "bracket":
                return _ => (u, s) => s === void 0 || h.skipNull && s === null || h.skipEmptyString && s === "" ? u : s === null ? [...u, [E(_, h), "[]"].join("")] : [...u, [E(_, h), "[]=", E(s, h)].join("")];
            case "colon-list-separator":
                return _ => (u, s) => s === void 0 || h.skipNull && s === null || h.skipEmptyString && s === "" ? u : s === null ? [...u, [E(_, h), ":list="].join("")] : [...u, [E(_, h), ":list=", E(s, h)].join("")];
            case "comma":
            case "separator":
            case "bracket-separator":
                {
                    const _ = h.arrayFormat === "bracket-separator" ? "[]=" : "=";
                    return u => (s, f) => f === void 0 || h.skipNull && f === null || h.skipEmptyString && f === "" ? s : (f = f === null ? "" : f, s.length === 0 ? [
                        [E(u, h), _, E(f, h)].join("")
                    ] : [
                        [s, E(f, h)].join(h.arrayFormatSeparator)
                    ])
                }
            default:
                return _ => (u, s) => s === void 0 || h.skipNull && s === null || h.skipEmptyString && s === "" ? u : s === null ? [...u, E(_, h)] : [...u, [E(_, h), "=", E(s, h)].join("")]
        }
    }

    function c(h) {
        let _;
        switch (h.arrayFormat) {
            case "index":
                return (u, s, f) => {
                    if (_ = /\[(\d*)\]$/.exec(u), u = u.replace(/\[\d*\]$/, ""), !_) {
                        f[u] = s;
                        return
                    }
                    f[u] === void 0 && (f[u] = {}), f[u][_[1]] = s
                };
            case "bracket":
                return (u, s, f) => {
                    if (_ = /(\[\])$/.exec(u), u = u.replace(/\[\]$/, ""), !_) {
                        f[u] = s;
                        return
                    }
                    if (f[u] === void 0) {
                        f[u] = [s];
                        return
                    }
                    f[u] = [].concat(f[u], s)
                };
            case "colon-list-separator":
                return (u, s, f) => {
                    if (_ = /(:list)$/.exec(u), u = u.replace(/:list$/, ""), !_) {
                        f[u] = s;
                        return
                    }
                    if (f[u] === void 0) {
                        f[u] = [s];
                        return
                    }
                    f[u] = [].concat(f[u], s)
                };
            case "comma":
            case "separator":
                return (u, s, f) => {
                    const t = typeof s == "string" && s.includes(h.arrayFormatSeparator),
                        i = typeof s == "string" && !t && g(s, h).includes(h.arrayFormatSeparator);
                    s = i ? g(s, h) : s;
                    const S = t || i ? s.split(h.arrayFormatSeparator).map(O => g(O, h)) : s === null ? s : g(s, h);
                    f[u] = S
                };
            case "bracket-separator":
                return (u, s, f) => {
                    const t = /(\[\])$/.test(u);
                    if (u = u.replace(/\[\]$/, ""), !t) {
                        f[u] = s && g(s, h);
                        return
                    }
                    const i = s === null ? [] : s.split(h.arrayFormatSeparator).map(S => g(S, h));
                    if (f[u] === void 0) {
                        f[u] = i;
                        return
                    }
                    f[u] = [].concat(f[u], i)
                };
            default:
                return (u, s, f) => {
                    if (f[u] === void 0) {
                        f[u] = s;
                        return
                    }
                    f[u] = [].concat(f[u], s)
                }
        }
    }

    function d(h) {
        if (typeof h != "string" || h.length !== 1) throw new TypeError("arrayFormatSeparator must be single character string")
    }

    function E(h, _) {
        return _.encode ? _.strict ? r(h) : encodeURIComponent(h) : h
    }

    function g(h, _) {
        return _.decode ? n(h) : h
    }

    function w(h) {
        return Array.isArray(h) ? h.sort() : typeof h == "object" ? w(Object.keys(h)).sort((_, u) => Number(_) - Number(u)).map(_ => h[_]) : h
    }

    function b(h) {
        const _ = h.indexOf("#");
        return _ !== -1 && (h = h.slice(0, _)), h
    }

    function y(h) {
        let _ = "";
        const u = h.indexOf("#");
        return u !== -1 && (_ = h.slice(u)), _
    }

    function p(h) {
        h = b(h);
        const _ = h.indexOf("?");
        return _ === -1 ? "" : h.slice(_ + 1)
    }

    function m(h, _) {
        return _.parseNumbers && !Number.isNaN(Number(h)) && typeof h == "string" && h.trim() !== "" ? h = Number(h) : _.parseBooleans && h !== null && (h.toLowerCase() === "true" || h.toLowerCase() === "false") && (h = h.toLowerCase() === "true"), h
    }

    function U(h, _) {
        _ = Object.assign({
            decode: !0,
            sort: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ",",
            parseNumbers: !1,
            parseBooleans: !1
        }, _), d(_.arrayFormatSeparator);
        const u = c(_),
            s = Object.create(null);
        if (typeof h != "string" || (h = h.trim().replace(/^[?#&]/, ""), !h)) return s;
        for (const f of h.split("&")) {
            if (f === "") continue;
            let [t, i] = a(_.decode ? f.replace(/\+/g, " ") : f, "=");
            i = i === void 0 ? null : ["comma", "separator", "bracket-separator"].includes(_.arrayFormat) ? i : g(i, _), u(g(t, _), i, s)
        }
        for (const f of Object.keys(s)) {
            const t = s[f];
            if (typeof t == "object" && t !== null)
                for (const i of Object.keys(t)) t[i] = m(t[i], _);
            else s[f] = m(t, _)
        }
        return _.sort === !1 ? s : (_.sort === !0 ? Object.keys(s).sort() : Object.keys(s).sort(_.sort)).reduce((f, t) => {
            const i = s[t];
            return i && typeof i == "object" && !Array.isArray(i) ? f[t] = w(i) : f[t] = i, f
        }, Object.create(null))
    }
    e.extract = p, e.parse = U, e.stringify = (h, _) => {
        if (!h) return "";
        _ = Object.assign({
            encode: !0,
            strict: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ","
        }, _), d(_.arrayFormatSeparator);
        const u = i => _.skipNull && l(h[i]) || _.skipEmptyString && h[i] === "",
            s = o(_),
            f = {};
        for (const i of Object.keys(h)) u(i) || (f[i] = h[i]);
        const t = Object.keys(f);
        return _.sort !== !1 && t.sort(_.sort), t.map(i => {
            const S = h[i];
            return S === void 0 ? "" : S === null ? E(i, _) : Array.isArray(S) ? S.length === 0 && _.arrayFormat === "bracket-separator" ? E(i, _) + "[]" : S.reduce(s(i), []).join("&") : E(i, _) + "=" + E(S, _)
        }).filter(i => i.length > 0).join("&")
    }, e.parseUrl = (h, _) => {
        _ = Object.assign({
            decode: !0
        }, _);
        const [u, s] = a(h, "#");
        return Object.assign({
            url: u.split("?")[0] || "",
            query: U(p(h), _)
        }, _ && _.parseFragmentIdentifier && s ? {
            fragmentIdentifier: g(s, _)
        } : {})
    }, e.stringifyUrl = (h, _) => {
        _ = Object.assign({
            encode: !0,
            strict: !0,
            [v]: !0
        }, _);
        const u = b(h.url).split("?")[0] || "",
            s = e.extract(h.url),
            f = e.parse(s, {
                sort: !1
            }),
            t = Object.assign(f, h.query);
        let i = e.stringify(t, _);
        i && (i = `?${i}`);
        let S = y(h.url);
        return h.fragmentIdentifier && (S = `#${_[v]?E(h.fragmentIdentifier,_):h.fragmentIdentifier}`), `${u}${i}${S}`
    }, e.pick = (h, _, u) => {
        u = Object.assign({
            parseFragmentIdentifier: !0,
            [v]: !1
        }, u);
        const {
            url: s,
            query: f,
            fragmentIdentifier: t
        } = e.parseUrl(h, u);
        return e.stringifyUrl({
            url: s,
            query: D(f, _),
            fragmentIdentifier: t
        }, u)
    }, e.exclude = (h, _, u) => {
        const s = Array.isArray(_) ? f => !_.includes(f) : (f, t) => !_(f, t);
        return e.pick(h, s, u)
    }
})(Ur);
var jr = {},
    Be = {},
    j = {},
    mt = {};
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    });

    function r(o, c) {
        var d = o >>> 16 & 65535,
            E = o & 65535,
            g = c >>> 16 & 65535,
            w = c & 65535;
        return E * w + (d * w + E * g << 16 >>> 0) | 0
    }
    e.mul = Math.imul || r;

    function n(o, c) {
        return o + c | 0
    }
    e.add = n;

    function a(o, c) {
        return o - c | 0
    }
    e.sub = a;

    function D(o, c) {
        return o << c | o >>> 32 - c
    }
    e.rotl = D;

    function l(o, c) {
        return o << 32 - c | o >>> c
    }
    e.rotr = l;

    function v(o) {
        return typeof o == "number" && isFinite(o) && Math.floor(o) === o
    }
    e.isInteger = Number.isInteger || v, e.MAX_SAFE_INTEGER = 9007199254740991, e.isSafeInteger = function(o) {
        return e.isInteger(o) && o >= -e.MAX_SAFE_INTEGER && o <= e.MAX_SAFE_INTEGER
    }
})(mt);
Object.defineProperty(j, "__esModule", {
    value: !0
});
var St = mt;

function Br(e, r) {
    return r === void 0 && (r = 0), (e[r + 0] << 8 | e[r + 1]) << 16 >> 16
}
j.readInt16BE = Br;

function Ir(e, r) {
    return r === void 0 && (r = 0), (e[r + 0] << 8 | e[r + 1]) >>> 0
}
j.readUint16BE = Ir;

function Rr(e, r) {
    return r === void 0 && (r = 0), (e[r + 1] << 8 | e[r]) << 16 >> 16
}
j.readInt16LE = Rr;

function Pr(e, r) {
    return r === void 0 && (r = 0), (e[r + 1] << 8 | e[r]) >>> 0
}
j.readUint16LE = Pr;

function pt(e, r, n) {
    return r === void 0 && (r = new Uint8Array(2)), n === void 0 && (n = 0), r[n + 0] = e >>> 8, r[n + 1] = e >>> 0, r
}
j.writeUint16BE = pt;
j.writeInt16BE = pt;

function Ct(e, r, n) {
    return r === void 0 && (r = new Uint8Array(2)), n === void 0 && (n = 0), r[n + 0] = e >>> 0, r[n + 1] = e >>> 8, r
}
j.writeUint16LE = Ct;
j.writeInt16LE = Ct;

function Je(e, r) {
    return r === void 0 && (r = 0), e[r] << 24 | e[r + 1] << 16 | e[r + 2] << 8 | e[r + 3]
}
j.readInt32BE = Je;

function Qe(e, r) {
    return r === void 0 && (r = 0), (e[r] << 24 | e[r + 1] << 16 | e[r + 2] << 8 | e[r + 3]) >>> 0
}
j.readUint32BE = Qe;

function Ze(e, r) {
    return r === void 0 && (r = 0), e[r + 3] << 24 | e[r + 2] << 16 | e[r + 1] << 8 | e[r]
}
j.readInt32LE = Ze;

function ke(e, r) {
    return r === void 0 && (r = 0), (e[r + 3] << 24 | e[r + 2] << 16 | e[r + 1] << 8 | e[r]) >>> 0
}
j.readUint32LE = ke;

function Me(e, r, n) {
    return r === void 0 && (r = new Uint8Array(4)), n === void 0 && (n = 0), r[n + 0] = e >>> 24, r[n + 1] = e >>> 16, r[n + 2] = e >>> 8, r[n + 3] = e >>> 0, r
}
j.writeUint32BE = Me;
j.writeInt32BE = Me;

function xe(e, r, n) {
    return r === void 0 && (r = new Uint8Array(4)), n === void 0 && (n = 0), r[n + 0] = e >>> 0, r[n + 1] = e >>> 8, r[n + 2] = e >>> 16, r[n + 3] = e >>> 24, r
}
j.writeUint32LE = xe;
j.writeInt32LE = xe;

function Hr(e, r) {
    r === void 0 && (r = 0);
    var n = Je(e, r),
        a = Je(e, r + 4);
    return n * 4294967296 + a - (a >> 31) * 4294967296
}
j.readInt64BE = Hr;

function Kr(e, r) {
    r === void 0 && (r = 0);
    var n = Qe(e, r),
        a = Qe(e, r + 4);
    return n * 4294967296 + a
}
j.readUint64BE = Kr;

function qr(e, r) {
    r === void 0 && (r = 0);
    var n = Ze(e, r),
        a = Ze(e, r + 4);
    return a * 4294967296 + n - (n >> 31) * 4294967296
}
j.readInt64LE = qr;

function $r(e, r) {
    r === void 0 && (r = 0);
    var n = ke(e, r),
        a = ke(e, r + 4);
    return a * 4294967296 + n
}
j.readUint64LE = $r;

function Ot(e, r, n) {
    return r === void 0 && (r = new Uint8Array(8)), n === void 0 && (n = 0), Me(e / 4294967296 >>> 0, r, n), Me(e >>> 0, r, n + 4), r
}
j.writeUint64BE = Ot;
j.writeInt64BE = Ot;

function At(e, r, n) {
    return r === void 0 && (r = new Uint8Array(8)), n === void 0 && (n = 0), xe(e >>> 0, r, n), xe(e / 4294967296 >>> 0, r, n + 4), r
}
j.writeUint64LE = At;
j.writeInt64LE = At;

function zr(e, r, n) {
    if (n === void 0 && (n = 0), e % 8 !== 0) throw new Error("readUintBE supports only bitLengths divisible by 8");
    if (e / 8 > r.length - n) throw new Error("readUintBE: array is too short for the given bitLength");
    for (var a = 0, D = 1, l = e / 8 + n - 1; l >= n; l--) a += r[l] * D, D *= 256;
    return a
}
j.readUintBE = zr;

function Yr(e, r, n) {
    if (n === void 0 && (n = 0), e % 8 !== 0) throw new Error("readUintLE supports only bitLengths divisible by 8");
    if (e / 8 > r.length - n) throw new Error("readUintLE: array is too short for the given bitLength");
    for (var a = 0, D = 1, l = n; l < n + e / 8; l++) a += r[l] * D, D *= 256;
    return a
}
j.readUintLE = Yr;

function Wr(e, r, n, a) {
    if (n === void 0 && (n = new Uint8Array(e / 8)), a === void 0 && (a = 0), e % 8 !== 0) throw new Error("writeUintBE supports only bitLengths divisible by 8");
    if (!St.isSafeInteger(r)) throw new Error("writeUintBE value must be an integer");
    for (var D = 1, l = e / 8 + a - 1; l >= a; l--) n[l] = r / D & 255, D *= 256;
    return n
}
j.writeUintBE = Wr;

function Gr(e, r, n, a) {
    if (n === void 0 && (n = new Uint8Array(e / 8)), a === void 0 && (a = 0), e % 8 !== 0) throw new Error("writeUintLE supports only bitLengths divisible by 8");
    if (!St.isSafeInteger(r)) throw new Error("writeUintLE value must be an integer");
    for (var D = 1, l = a; l < a + e / 8; l++) n[l] = r / D & 255, D *= 256;
    return n
}
j.writeUintLE = Gr;

function Vr(e, r) {
    r === void 0 && (r = 0);
    var n = new DataView(e.buffer, e.byteOffset, e.byteLength);
    return n.getFloat32(r)
}
j.readFloat32BE = Vr;

function Xr(e, r) {
    r === void 0 && (r = 0);
    var n = new DataView(e.buffer, e.byteOffset, e.byteLength);
    return n.getFloat32(r, !0)
}
j.readFloat32LE = Xr;

function Jr(e, r) {
    r === void 0 && (r = 0);
    var n = new DataView(e.buffer, e.byteOffset, e.byteLength);
    return n.getFloat64(r)
}
j.readFloat64BE = Jr;

function Qr(e, r) {
    r === void 0 && (r = 0);
    var n = new DataView(e.buffer, e.byteOffset, e.byteLength);
    return n.getFloat64(r, !0)
}
j.readFloat64LE = Qr;

function Zr(e, r, n) {
    r === void 0 && (r = new Uint8Array(4)), n === void 0 && (n = 0);
    var a = new DataView(r.buffer, r.byteOffset, r.byteLength);
    return a.setFloat32(n, e), r
}
j.writeFloat32BE = Zr;

function kr(e, r, n) {
    r === void 0 && (r = new Uint8Array(4)), n === void 0 && (n = 0);
    var a = new DataView(r.buffer, r.byteOffset, r.byteLength);
    return a.setFloat32(n, e, !0), r
}
j.writeFloat32LE = kr;

function en(e, r, n) {
    r === void 0 && (r = new Uint8Array(8)), n === void 0 && (n = 0);
    var a = new DataView(r.buffer, r.byteOffset, r.byteLength);
    return a.setFloat64(n, e), r
}
j.writeFloat64BE = en;

function tn(e, r, n) {
    r === void 0 && (r = new Uint8Array(8)), n === void 0 && (n = 0);
    var a = new DataView(r.buffer, r.byteOffset, r.byteLength);
    return a.setFloat64(n, e, !0), r
}
j.writeFloat64LE = tn;
var Ee = {};
Object.defineProperty(Ee, "__esModule", {
    value: !0
});

function rn(e) {
    for (var r = 0; r < e.length; r++) e[r] = 0;
    return e
}
Ee.wipe = rn;
Object.defineProperty(Be, "__esModule", {
    value: !0
});
var de = j,
    et = Ee,
    nn = 20;

function an(e, r, n) {
    for (var a = 1634760805, D = 857760878, l = 2036477234, v = 1797285236, o = n[3] << 24 | n[2] << 16 | n[1] << 8 | n[0], c = n[7] << 24 | n[6] << 16 | n[5] << 8 | n[4], d = n[11] << 24 | n[10] << 16 | n[9] << 8 | n[8], E = n[15] << 24 | n[14] << 16 | n[13] << 8 | n[12], g = n[19] << 24 | n[18] << 16 | n[17] << 8 | n[16], w = n[23] << 24 | n[22] << 16 | n[21] << 8 | n[20], b = n[27] << 24 | n[26] << 16 | n[25] << 8 | n[24], y = n[31] << 24 | n[30] << 16 | n[29] << 8 | n[28], p = r[3] << 24 | r[2] << 16 | r[1] << 8 | r[0], m = r[7] << 24 | r[6] << 16 | r[5] << 8 | r[4], U = r[11] << 24 | r[10] << 16 | r[9] << 8 | r[8], h = r[15] << 24 | r[14] << 16 | r[13] << 8 | r[12], _ = a, u = D, s = l, f = v, t = o, i = c, S = d, O = E, F = g, M = w, B = b, x = y, N = p, L = m, C = U, T = h, G = 0; G < nn; G += 2) _ = _ + t | 0, N ^= _, N = N >>> 16 | N << 16, F = F + N | 0, t ^= F, t = t >>> 20 | t << 12, u = u + i | 0, L ^= u, L = L >>> 16 | L << 16, M = M + L | 0, i ^= M, i = i >>> 20 | i << 12, s = s + S | 0, C ^= s, C = C >>> 16 | C << 16, B = B + C | 0, S ^= B, S = S >>> 20 | S << 12, f = f + O | 0, T ^= f, T = T >>> 16 | T << 16, x = x + T | 0, O ^= x, O = O >>> 20 | O << 12, s = s + S | 0, C ^= s, C = C >>> 24 | C << 8, B = B + C | 0, S ^= B, S = S >>> 25 | S << 7, f = f + O | 0, T ^= f, T = T >>> 24 | T << 8, x = x + T | 0, O ^= x, O = O >>> 25 | O << 7, u = u + i | 0, L ^= u, L = L >>> 24 | L << 8, M = M + L | 0, i ^= M, i = i >>> 25 | i << 7, _ = _ + t | 0, N ^= _, N = N >>> 24 | N << 8, F = F + N | 0, t ^= F, t = t >>> 25 | t << 7, _ = _ + i | 0, T ^= _, T = T >>> 16 | T << 16, B = B + T | 0, i ^= B, i = i >>> 20 | i << 12, u = u + S | 0, N ^= u, N = N >>> 16 | N << 16, x = x + N | 0, S ^= x, S = S >>> 20 | S << 12, s = s + O | 0, L ^= s, L = L >>> 16 | L << 16, F = F + L | 0, O ^= F, O = O >>> 20 | O << 12, f = f + t | 0, C ^= f, C = C >>> 16 | C << 16, M = M + C | 0, t ^= M, t = t >>> 20 | t << 12, s = s + O | 0, L ^= s, L = L >>> 24 | L << 8, F = F + L | 0, O ^= F, O = O >>> 25 | O << 7, f = f + t | 0, C ^= f, C = C >>> 24 | C << 8, M = M + C | 0, t ^= M, t = t >>> 25 | t << 7, u = u + S | 0, N ^= u, N = N >>> 24 | N << 8, x = x + N | 0, S ^= x, S = S >>> 25 | S << 7, _ = _ + i | 0, T ^= _, T = T >>> 24 | T << 8, B = B + T | 0, i ^= B, i = i >>> 25 | i << 7;
    de.writeUint32LE(_ + a | 0, e, 0), de.writeUint32LE(u + D | 0, e, 4), de.writeUint32LE(s + l | 0, e, 8), de.writeUint32LE(f + v | 0, e, 12), de.writeUint32LE(t + o | 0, e, 16), de.writeUint32LE(i + c | 0, e, 20), de.writeUint32LE(S + d | 0, e, 24), de.writeUint32LE(O + E | 0, e, 28), de.writeUint32LE(F + g | 0, e, 32), de.writeUint32LE(M + w | 0, e, 36), de.writeUint32LE(B + b | 0, e, 40), de.writeUint32LE(x + y | 0, e, 44), de.writeUint32LE(N + p | 0, e, 48), de.writeUint32LE(L + m | 0, e, 52), de.writeUint32LE(C + U | 0, e, 56), de.writeUint32LE(T + h | 0, e, 60)
}

function Ut(e, r, n, a, D) {
    if (D === void 0 && (D = 0), e.length !== 32) throw new Error("ChaCha: key size must be 32 bytes");
    if (a.length < n.length) throw new Error("ChaCha: destination is shorter than source");
    var l, v;
    if (D === 0) {
        if (r.length !== 8 && r.length !== 12) throw new Error("ChaCha nonce must be 8 or 12 bytes");
        l = new Uint8Array(16), v = l.length - r.length, l.set(r, v)
    } else {
        if (r.length !== 16) throw new Error("ChaCha nonce with counter must be 16 bytes");
        l = r, v = D
    }
    for (var o = new Uint8Array(64), c = 0; c < n.length; c += 64) {
        an(o, l, e);
        for (var d = c; d < c + 64 && d < n.length; d++) a[d] = n[d] ^ o[d - c];
        on(l, 0, v)
    }
    return et.wipe(o), D === 0 && et.wipe(l), a
}
Be.streamXOR = Ut;

function un(e, r, n, a) {
    return a === void 0 && (a = 0), et.wipe(n), Ut(e, r, n, n, a)
}
Be.stream = un;

function on(e, r, n) {
    for (var a = 1; n--;) a = a + (e[r] & 255) | 0, e[r] = a & 255, a >>>= 8, r++;
    if (a > 0) throw new Error("ChaCha: counter overflow")
}
var Ft = {},
    we = {};
Object.defineProperty(we, "__esModule", {
    value: !0
});

function fn(e, r, n) {
    return ~(e - 1) & r | e - 1 & n
}
we.select = fn;

function sn(e, r) {
    return (e | 0) - (r | 0) - 1 >>> 31 & 1
}
we.lessOrEqual = sn;

function Tt(e, r) {
    if (e.length !== r.length) return 0;
    for (var n = 0, a = 0; a < e.length; a++) n |= e[a] ^ r[a];
    return 1 & n - 1 >>> 8
}
we.compare = Tt;

function hn(e, r) {
    return e.length === 0 || r.length === 0 ? !1 : Tt(e, r) !== 0
}
we.equal = hn;
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var r = we,
        n = Ee;
    e.DIGEST_LENGTH = 16;
    var a = function() {
        function v(o) {
            this.digestLength = e.DIGEST_LENGTH, this._buffer = new Uint8Array(16), this._r = new Uint16Array(10), this._h = new Uint16Array(10), this._pad = new Uint16Array(8), this._leftover = 0, this._fin = 0, this._finished = !1;
            var c = o[0] | o[1] << 8;
            this._r[0] = c & 8191;
            var d = o[2] | o[3] << 8;
            this._r[1] = (c >>> 13 | d << 3) & 8191;
            var E = o[4] | o[5] << 8;
            this._r[2] = (d >>> 10 | E << 6) & 7939;
            var g = o[6] | o[7] << 8;
            this._r[3] = (E >>> 7 | g << 9) & 8191;
            var w = o[8] | o[9] << 8;
            this._r[4] = (g >>> 4 | w << 12) & 255, this._r[5] = w >>> 1 & 8190;
            var b = o[10] | o[11] << 8;
            this._r[6] = (w >>> 14 | b << 2) & 8191;
            var y = o[12] | o[13] << 8;
            this._r[7] = (b >>> 11 | y << 5) & 8065;
            var p = o[14] | o[15] << 8;
            this._r[8] = (y >>> 8 | p << 8) & 8191, this._r[9] = p >>> 5 & 127, this._pad[0] = o[16] | o[17] << 8, this._pad[1] = o[18] | o[19] << 8, this._pad[2] = o[20] | o[21] << 8, this._pad[3] = o[22] | o[23] << 8, this._pad[4] = o[24] | o[25] << 8, this._pad[5] = o[26] | o[27] << 8, this._pad[6] = o[28] | o[29] << 8, this._pad[7] = o[30] | o[31] << 8
        }
        return v.prototype._blocks = function(o, c, d) {
            for (var E = this._fin ? 0 : 2048, g = this._h[0], w = this._h[1], b = this._h[2], y = this._h[3], p = this._h[4], m = this._h[5], U = this._h[6], h = this._h[7], _ = this._h[8], u = this._h[9], s = this._r[0], f = this._r[1], t = this._r[2], i = this._r[3], S = this._r[4], O = this._r[5], F = this._r[6], M = this._r[7], B = this._r[8], x = this._r[9]; d >= 16;) {
                var N = o[c + 0] | o[c + 1] << 8;
                g += N & 8191;
                var L = o[c + 2] | o[c + 3] << 8;
                w += (N >>> 13 | L << 3) & 8191;
                var C = o[c + 4] | o[c + 5] << 8;
                b += (L >>> 10 | C << 6) & 8191;
                var T = o[c + 6] | o[c + 7] << 8;
                y += (C >>> 7 | T << 9) & 8191;
                var G = o[c + 8] | o[c + 9] << 8;
                p += (T >>> 4 | G << 12) & 8191, m += G >>> 1 & 8191;
                var Q = o[c + 10] | o[c + 11] << 8;
                U += (G >>> 14 | Q << 2) & 8191;
                var J = o[c + 12] | o[c + 13] << 8;
                h += (Q >>> 11 | J << 5) & 8191;
                var X = o[c + 14] | o[c + 15] << 8;
                _ += (J >>> 8 | X << 8) & 8191, u += X >>> 5 | E;
                var A = 0,
                    I = A;
                I += g * s, I += w * (5 * x), I += b * (5 * B), I += y * (5 * M), I += p * (5 * F), A = I >>> 13, I &= 8191, I += m * (5 * O), I += U * (5 * S), I += h * (5 * i), I += _ * (5 * t), I += u * (5 * f), A += I >>> 13, I &= 8191;
                var R = A;
                R += g * f, R += w * s, R += b * (5 * x), R += y * (5 * B), R += p * (5 * M), A = R >>> 13, R &= 8191, R += m * (5 * F), R += U * (5 * O), R += h * (5 * S), R += _ * (5 * i), R += u * (5 * t), A += R >>> 13, R &= 8191;
                var P = A;
                P += g * t, P += w * f, P += b * s, P += y * (5 * x), P += p * (5 * B), A = P >>> 13, P &= 8191, P += m * (5 * M), P += U * (5 * F), P += h * (5 * O), P += _ * (5 * S), P += u * (5 * i), A += P >>> 13, P &= 8191;
                var H = A;
                H += g * i, H += w * t, H += b * f, H += y * s, H += p * (5 * x), A = H >>> 13, H &= 8191, H += m * (5 * B), H += U * (5 * M), H += h * (5 * F), H += _ * (5 * O), H += u * (5 * S), A += H >>> 13, H &= 8191;
                var K = A;
                K += g * S, K += w * i, K += b * t, K += y * f, K += p * s, A = K >>> 13, K &= 8191, K += m * (5 * x), K += U * (5 * B), K += h * (5 * M), K += _ * (5 * F), K += u * (5 * O), A += K >>> 13, K &= 8191;
                var q = A;
                q += g * O, q += w * S, q += b * i, q += y * t, q += p * f, A = q >>> 13, q &= 8191, q += m * s, q += U * (5 * x), q += h * (5 * B), q += _ * (5 * M), q += u * (5 * F), A += q >>> 13, q &= 8191;
                var $ = A;
                $ += g * F, $ += w * O, $ += b * S, $ += y * i, $ += p * t, A = $ >>> 13, $ &= 8191, $ += m * f, $ += U * s, $ += h * (5 * x), $ += _ * (5 * B), $ += u * (5 * M), A += $ >>> 13, $ &= 8191;
                var z = A;
                z += g * M, z += w * F, z += b * O, z += y * S, z += p * i, A = z >>> 13, z &= 8191, z += m * t, z += U * f, z += h * s, z += _ * (5 * x), z += u * (5 * B), A += z >>> 13, z &= 8191;
                var W = A;
                W += g * B, W += w * M, W += b * F, W += y * O, W += p * S, A = W >>> 13, W &= 8191, W += m * i, W += U * t, W += h * f, W += _ * s, W += u * (5 * x), A += W >>> 13, W &= 8191;
                var V = A;
                V += g * x, V += w * B, V += b * M, V += y * F, V += p * O, A = V >>> 13, V &= 8191, V += m * S, V += U * i, V += h * t, V += _ * f, V += u * s, A += V >>> 13, V &= 8191, A = (A << 2) + A | 0, A = A + I | 0, I = A & 8191, A = A >>> 13, R += A, g = I, w = R, b = P, y = H, p = K, m = q, U = $, h = z, _ = W, u = V, c += 16, d -= 16
            }
            this._h[0] = g, this._h[1] = w, this._h[2] = b, this._h[3] = y, this._h[4] = p, this._h[5] = m, this._h[6] = U, this._h[7] = h, this._h[8] = _, this._h[9] = u
        }, v.prototype.finish = function(o, c) {
            c === void 0 && (c = 0);
            var d = new Uint16Array(10),
                E, g, w, b;
            if (this._leftover) {
                for (b = this._leftover, this._buffer[b++] = 1; b < 16; b++) this._buffer[b] = 0;
                this._fin = 1, this._blocks(this._buffer, 0, 16)
            }
            for (E = this._h[1] >>> 13, this._h[1] &= 8191, b = 2; b < 10; b++) this._h[b] += E, E = this._h[b] >>> 13, this._h[b] &= 8191;
            for (this._h[0] += E * 5, E = this._h[0] >>> 13, this._h[0] &= 8191, this._h[1] += E, E = this._h[1] >>> 13, this._h[1] &= 8191, this._h[2] += E, d[0] = this._h[0] + 5, E = d[0] >>> 13, d[0] &= 8191, b = 1; b < 10; b++) d[b] = this._h[b] + E, E = d[b] >>> 13, d[b] &= 8191;
            for (d[9] -= 8192, g = (E ^ 1) - 1, b = 0; b < 10; b++) d[b] &= g;
            for (g = ~g, b = 0; b < 10; b++) this._h[b] = this._h[b] & g | d[b];
            for (this._h[0] = (this._h[0] | this._h[1] << 13) & 65535, this._h[1] = (this._h[1] >>> 3 | this._h[2] << 10) & 65535, this._h[2] = (this._h[2] >>> 6 | this._h[3] << 7) & 65535, this._h[3] = (this._h[3] >>> 9 | this._h[4] << 4) & 65535, this._h[4] = (this._h[4] >>> 12 | this._h[5] << 1 | this._h[6] << 14) & 65535, this._h[5] = (this._h[6] >>> 2 | this._h[7] << 11) & 65535, this._h[6] = (this._h[7] >>> 5 | this._h[8] << 8) & 65535, this._h[7] = (this._h[8] >>> 8 | this._h[9] << 5) & 65535, w = this._h[0] + this._pad[0], this._h[0] = w & 65535, b = 1; b < 8; b++) w = (this._h[b] + this._pad[b] | 0) + (w >>> 16) | 0, this._h[b] = w & 65535;
            return o[c + 0] = this._h[0] >>> 0, o[c + 1] = this._h[0] >>> 8, o[c + 2] = this._h[1] >>> 0, o[c + 3] = this._h[1] >>> 8, o[c + 4] = this._h[2] >>> 0, o[c + 5] = this._h[2] >>> 8, o[c + 6] = this._h[3] >>> 0, o[c + 7] = this._h[3] >>> 8, o[c + 8] = this._h[4] >>> 0, o[c + 9] = this._h[4] >>> 8, o[c + 10] = this._h[5] >>> 0, o[c + 11] = this._h[5] >>> 8, o[c + 12] = this._h[6] >>> 0, o[c + 13] = this._h[6] >>> 8, o[c + 14] = this._h[7] >>> 0, o[c + 15] = this._h[7] >>> 8, this._finished = !0, this
        }, v.prototype.update = function(o) {
            var c = 0,
                d = o.length,
                E;
            if (this._leftover) {
                E = 16 - this._leftover, E > d && (E = d);
                for (var g = 0; g < E; g++) this._buffer[this._leftover + g] = o[c + g];
                if (d -= E, c += E, this._leftover += E, this._leftover < 16) return this;
                this._blocks(this._buffer, 0, 16), this._leftover = 0
            }
            if (d >= 16 && (E = d - d % 16, this._blocks(o, c, E), c += E, d -= E), d) {
                for (var g = 0; g < d; g++) this._buffer[this._leftover + g] = o[c + g];
                this._leftover += d
            }
            return this
        }, v.prototype.digest = function() {
            if (this._finished) throw new Error("Poly1305 was finished");
            var o = new Uint8Array(16);
            return this.finish(o), o
        }, v.prototype.clean = function() {
            return n.wipe(this._buffer), n.wipe(this._r), n.wipe(this._h), n.wipe(this._pad), this._leftover = 0, this._fin = 0, this._finished = !0, this
        }, v
    }();
    e.Poly1305 = a;

    function D(v, o) {
        var c = new a(v);
        c.update(o);
        var d = c.digest();
        return c.clean(), d
    }
    e.oneTimeAuth = D;

    function l(v, o) {
        return v.length !== e.DIGEST_LENGTH || o.length !== e.DIGEST_LENGTH ? !1 : r.equal(v, o)
    }
    e.equal = l
})(Ft);
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var r = Be,
        n = Ft,
        a = Ee,
        D = j,
        l = we;
    e.KEY_LENGTH = 32, e.NONCE_LENGTH = 12, e.TAG_LENGTH = 16;
    var v = new Uint8Array(16),
        o = function() {
            function c(d) {
                if (this.nonceLength = e.NONCE_LENGTH, this.tagLength = e.TAG_LENGTH, d.length !== e.KEY_LENGTH) throw new Error("ChaCha20Poly1305 needs 32-byte key");
                this._key = new Uint8Array(d)
            }
            return c.prototype.seal = function(d, E, g, w) {
                if (d.length > 16) throw new Error("ChaCha20Poly1305: incorrect nonce length");
                var b = new Uint8Array(16);
                b.set(d, b.length - d.length);
                var y = new Uint8Array(32);
                r.stream(this._key, b, y, 4);
                var p = E.length + this.tagLength,
                    m;
                if (w) {
                    if (w.length !== p) throw new Error("ChaCha20Poly1305: incorrect destination length");
                    m = w
                } else m = new Uint8Array(p);
                return r.streamXOR(this._key, b, E, m, 4), this._authenticate(m.subarray(m.length - this.tagLength, m.length), y, m.subarray(0, m.length - this.tagLength), g), a.wipe(b), m
            }, c.prototype.open = function(d, E, g, w) {
                if (d.length > 16) throw new Error("ChaCha20Poly1305: incorrect nonce length");
                if (E.length < this.tagLength) return null;
                var b = new Uint8Array(16);
                b.set(d, b.length - d.length);
                var y = new Uint8Array(32);
                r.stream(this._key, b, y, 4);
                var p = new Uint8Array(this.tagLength);
                if (this._authenticate(p, y, E.subarray(0, E.length - this.tagLength), g), !l.equal(p, E.subarray(E.length - this.tagLength, E.length))) return null;
                var m = E.length - this.tagLength,
                    U;
                if (w) {
                    if (w.length !== m) throw new Error("ChaCha20Poly1305: incorrect destination length");
                    U = w
                } else U = new Uint8Array(m);
                return r.streamXOR(this._key, b, E.subarray(0, E.length - this.tagLength), U, 4), a.wipe(b), U
            }, c.prototype.clean = function() {
                return a.wipe(this._key), this
            }, c.prototype._authenticate = function(d, E, g, w) {
                var b = new n.Poly1305(E);
                w && (b.update(w), w.length % 16 > 0 && b.update(v.subarray(w.length % 16))), b.update(g), g.length % 16 > 0 && b.update(v.subarray(g.length % 16));
                var y = new Uint8Array(8);
                w && D.writeUint64LE(w.length, y), b.update(y), D.writeUint64LE(g.length, y), b.update(y);
                for (var p = b.digest(), m = 0; m < p.length; m++) d[m] = p[m];
                b.clean(), a.wipe(p), a.wipe(y)
            }, c
        }();
    e.ChaCha20Poly1305 = o
})(jr);
var Nt = {},
    Te = {},
    rt = {};
Object.defineProperty(rt, "__esModule", {
    value: !0
});

function cn(e) {
    return typeof e.saveState < "u" && typeof e.restoreState < "u" && typeof e.cleanSavedState < "u"
}
rt.isSerializableHash = cn;
Object.defineProperty(Te, "__esModule", {
    value: !0
});
var be = rt,
    ln = we,
    Dn = Ee,
    Lt = function() {
        function e(r, n) {
            this._finished = !1, this._inner = new r, this._outer = new r, this.blockSize = this._outer.blockSize, this.digestLength = this._outer.digestLength;
            var a = new Uint8Array(this.blockSize);
            n.length > this.blockSize ? this._inner.update(n).finish(a).clean() : a.set(n);
            for (var D = 0; D < a.length; D++) a[D] ^= 54;
            this._inner.update(a);
            for (var D = 0; D < a.length; D++) a[D] ^= 106;
            this._outer.update(a), be.isSerializableHash(this._inner) && be.isSerializableHash(this._outer) && (this._innerKeyedState = this._inner.saveState(), this._outerKeyedState = this._outer.saveState()), Dn.wipe(a)
        }
        return e.prototype.reset = function() {
            if (!be.isSerializableHash(this._inner) || !be.isSerializableHash(this._outer)) throw new Error("hmac: can't reset() because hash doesn't implement restoreState()");
            return this._inner.restoreState(this._innerKeyedState), this._outer.restoreState(this._outerKeyedState), this._finished = !1, this
        }, e.prototype.clean = function() {
            be.isSerializableHash(this._inner) && this._inner.cleanSavedState(this._innerKeyedState), be.isSerializableHash(this._outer) && this._outer.cleanSavedState(this._outerKeyedState), this._inner.clean(), this._outer.clean()
        }, e.prototype.update = function(r) {
            return this._inner.update(r), this
        }, e.prototype.finish = function(r) {
            return this._finished ? (this._outer.finish(r), this) : (this._inner.finish(r), this._outer.update(r.subarray(0, this.digestLength)).finish(r), this._finished = !0, this)
        }, e.prototype.digest = function() {
            var r = new Uint8Array(this.digestLength);
            return this.finish(r), r
        }, e.prototype.saveState = function() {
            if (!be.isSerializableHash(this._inner)) throw new Error("hmac: can't saveState() because hash doesn't implement it");
            return this._inner.saveState()
        }, e.prototype.restoreState = function(r) {
            if (!be.isSerializableHash(this._inner) || !be.isSerializableHash(this._outer)) throw new Error("hmac: can't restoreState() because hash doesn't implement it");
            return this._inner.restoreState(r), this._outer.restoreState(this._outerKeyedState), this._finished = !1, this
        }, e.prototype.cleanSavedState = function(r) {
            if (!be.isSerializableHash(this._inner)) throw new Error("hmac: can't cleanSavedState() because hash doesn't implement it");
            this._inner.cleanSavedState(r)
        }, e
    }();
Te.HMAC = Lt;

function _n(e, r, n) {
    var a = new Lt(e, r);
    a.update(n);
    var D = a.digest();
    return a.clean(), D
}
Te.hmac = _n;
Te.equal = ln.equal;
Object.defineProperty(Nt, "__esModule", {
    value: !0
});
var Et = Te,
    bt = Ee,
    dn = function() {
        function e(r, n, a, D) {
            a === void 0 && (a = new Uint8Array(0)), this._counter = new Uint8Array(1), this._hash = r, this._info = D;
            var l = Et.hmac(this._hash, a, n);
            this._hmac = new Et.HMAC(r, l), this._buffer = new Uint8Array(this._hmac.digestLength), this._bufpos = this._buffer.length
        }
        return e.prototype._fillBuffer = function() {
            this._counter[0]++;
            var r = this._counter[0];
            if (r === 0) throw new Error("hkdf: cannot expand more");
            this._hmac.reset(), r > 1 && this._hmac.update(this._buffer), this._info && this._hmac.update(this._info), this._hmac.update(this._counter), this._hmac.finish(this._buffer), this._bufpos = 0
        }, e.prototype.expand = function(r) {
            for (var n = new Uint8Array(r), a = 0; a < n.length; a++) this._bufpos === this._buffer.length && this._fillBuffer(), n[a] = this._buffer[this._bufpos++];
            return n
        }, e.prototype.clean = function() {
            this._hmac.clean(), bt.wipe(this._buffer), bt.wipe(this._counter), this._bufpos = 0
        }, e
    }(),
    Di = Nt.HKDF = dn,
    Mt = {},
    Ie = {},
    Re = {};
Object.defineProperty(Re, "__esModule", {
    value: !0
});
Re.BrowserRandomSource = void 0;
const wt = 65536;
class En {
    constructor() {
        this.isAvailable = !1, this.isInstantiated = !1;
        const r = typeof self < "u" ? self.crypto || self.msCrypto : null;
        r && r.getRandomValues !== void 0 && (this._crypto = r, this.isAvailable = !0, this.isInstantiated = !0)
    }
    randomBytes(r) {
        if (!this.isAvailable || !this._crypto) throw new Error("Browser random byte generator is not available.");
        const n = new Uint8Array(r);
        for (let a = 0; a < n.length; a += wt) this._crypto.getRandomValues(n.subarray(a, a + Math.min(n.length - a, wt)));
        return n
    }
}
Re.BrowserRandomSource = En;

function bn(e) {
    throw new Error('Could not dynamically require "' + e + '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')
}
var Pe = {};
Object.defineProperty(Pe, "__esModule", {
    value: !0
});
Pe.NodeRandomSource = void 0;
const wn = Ee;
class vn {
    constructor() {
        if (this.isAvailable = !1, this.isInstantiated = !1, typeof bn < "u") {
            const r = It;
            r && r.randomBytes && (this._crypto = r, this.isAvailable = !0, this.isInstantiated = !0)
        }
    }
    randomBytes(r) {
        if (!this.isAvailable || !this._crypto) throw new Error("Node.js random byte generator is not available.");
        let n = this._crypto.randomBytes(r);
        if (n.length !== r) throw new Error("NodeRandomSource: got fewer bytes than requested");
        const a = new Uint8Array(r);
        for (let D = 0; D < a.length; D++) a[D] = n[D];
        return (0, wn.wipe)(n), a
    }
}
Pe.NodeRandomSource = vn;
Object.defineProperty(Ie, "__esModule", {
    value: !0
});
Ie.SystemRandomSource = void 0;
const gn = Re,
    yn = Pe;
class mn {
    constructor() {
        if (this.isAvailable = !1, this.name = "", this._source = new gn.BrowserRandomSource, this._source.isAvailable) {
            this.isAvailable = !0, this.name = "Browser";
            return
        }
        if (this._source = new yn.NodeRandomSource, this._source.isAvailable) {
            this.isAvailable = !0, this.name = "Node";
            return
        }
    }
    randomBytes(r) {
        if (!this.isAvailable) throw new Error("System random byte generator is not available.");
        return this._source.randomBytes(r)
    }
}
Ie.SystemRandomSource = mn;
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.randomStringForEntropy = e.randomString = e.randomUint32 = e.randomBytes = e.defaultRandomSource = void 0;
    const r = Ie,
        n = j,
        a = Ee;
    e.defaultRandomSource = new r.SystemRandomSource;

    function D(d, E = e.defaultRandomSource) {
        return E.randomBytes(d)
    }
    e.randomBytes = D;

    function l(d = e.defaultRandomSource) {
        const E = D(4, d),
            g = (0, n.readUint32LE)(E);
        return (0, a.wipe)(E), g
    }
    e.randomUint32 = l;
    const v = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    function o(d, E = v, g = e.defaultRandomSource) {
        if (E.length < 2) throw new Error("randomString charset is too short");
        if (E.length > 256) throw new Error("randomString charset is too long");
        let w = "";
        const b = E.length,
            y = 256 - 256 % b;
        for (; d > 0;) {
            const p = D(Math.ceil(d * 256 / y), g);
            for (let m = 0; m < p.length && d > 0; m++) {
                const U = p[m];
                U < y && (w += E.charAt(U % b), d--)
            }(0, a.wipe)(p)
        }
        return w
    }
    e.randomString = o;

    function c(d, E = v, g = e.defaultRandomSource) {
        const w = Math.ceil(d / (Math.log(E.length) / Math.LN2));
        return o(w, E, g)
    }
    e.randomStringForEntropy = c
})(Mt);
var Sn = {};
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    });
    var r = j,
        n = Ee;
    e.DIGEST_LENGTH = 32, e.BLOCK_SIZE = 64;
    var a = function() {
        function o() {
            this.digestLength = e.DIGEST_LENGTH, this.blockSize = e.BLOCK_SIZE, this._state = new Int32Array(8), this._temp = new Int32Array(64), this._buffer = new Uint8Array(128), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this.reset()
        }
        return o.prototype._initState = function() {
            this._state[0] = 1779033703, this._state[1] = 3144134277, this._state[2] = 1013904242, this._state[3] = 2773480762, this._state[4] = 1359893119, this._state[5] = 2600822924, this._state[6] = 528734635, this._state[7] = 1541459225
        }, o.prototype.reset = function() {
            return this._initState(), this._bufferLength = 0, this._bytesHashed = 0, this._finished = !1, this
        }, o.prototype.clean = function() {
            n.wipe(this._buffer), n.wipe(this._temp), this.reset()
        }, o.prototype.update = function(c, d) {
            if (d === void 0 && (d = c.length), this._finished) throw new Error("SHA256: can't update because hash was finished.");
            var E = 0;
            if (this._bytesHashed += d, this._bufferLength > 0) {
                for (; this._bufferLength < this.blockSize && d > 0;) this._buffer[this._bufferLength++] = c[E++], d--;
                this._bufferLength === this.blockSize && (l(this._temp, this._state, this._buffer, 0, this.blockSize), this._bufferLength = 0)
            }
            for (d >= this.blockSize && (E = l(this._temp, this._state, c, E, d), d %= this.blockSize); d > 0;) this._buffer[this._bufferLength++] = c[E++], d--;
            return this
        }, o.prototype.finish = function(c) {
            if (!this._finished) {
                var d = this._bytesHashed,
                    E = this._bufferLength,
                    g = d / 536870912 | 0,
                    w = d << 3,
                    b = d % 64 < 56 ? 64 : 128;
                this._buffer[E] = 128;
                for (var y = E + 1; y < b - 8; y++) this._buffer[y] = 0;
                r.writeUint32BE(g, this._buffer, b - 8), r.writeUint32BE(w, this._buffer, b - 4), l(this._temp, this._state, this._buffer, 0, b), this._finished = !0
            }
            for (var y = 0; y < this.digestLength / 4; y++) r.writeUint32BE(this._state[y], c, y * 4);
            return this
        }, o.prototype.digest = function() {
            var c = new Uint8Array(this.digestLength);
            return this.finish(c), c
        }, o.prototype.saveState = function() {
            if (this._finished) throw new Error("SHA256: cannot save finished state");
            return {
                state: new Int32Array(this._state),
                buffer: this._bufferLength > 0 ? new Uint8Array(this._buffer) : void 0,
                bufferLength: this._bufferLength,
                bytesHashed: this._bytesHashed
            }
        }, o.prototype.restoreState = function(c) {
            return this._state.set(c.state), this._bufferLength = c.bufferLength, c.buffer && this._buffer.set(c.buffer), this._bytesHashed = c.bytesHashed, this._finished = !1, this
        }, o.prototype.cleanSavedState = function(c) {
            n.wipe(c.state), c.buffer && n.wipe(c.buffer), c.bufferLength = 0, c.bytesHashed = 0
        }, o
    }();
    e.SHA256 = a;
    var D = new Int32Array([1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298]);

    function l(o, c, d, E, g) {
        for (; g >= 64;) {
            for (var w = c[0], b = c[1], y = c[2], p = c[3], m = c[4], U = c[5], h = c[6], _ = c[7], u = 0; u < 16; u++) {
                var s = E + u * 4;
                o[u] = r.readUint32BE(d, s)
            }
            for (var u = 16; u < 64; u++) {
                var f = o[u - 2],
                    t = (f >>> 17 | f << 15) ^ (f >>> 19 | f << 13) ^ f >>> 10;
                f = o[u - 15];
                var i = (f >>> 7 | f << 25) ^ (f >>> 18 | f << 14) ^ f >>> 3;
                o[u] = (t + o[u - 7] | 0) + (i + o[u - 16] | 0)
            }
            for (var u = 0; u < 64; u++) {
                var t = (((m >>> 6 | m << 26) ^ (m >>> 11 | m << 21) ^ (m >>> 25 | m << 7)) + (m & U ^ ~m & h) | 0) + (_ + (D[u] + o[u] | 0) | 0) | 0,
                    i = ((w >>> 2 | w << 30) ^ (w >>> 13 | w << 19) ^ (w >>> 22 | w << 10)) + (w & b ^ w & y ^ b & y) | 0;
                _ = h, h = U, U = m, m = p + t | 0, p = y, y = b, b = w, w = t + i | 0
            }
            c[0] += w, c[1] += b, c[2] += y, c[3] += p, c[4] += m, c[5] += U, c[6] += h, c[7] += _, E += 64, g -= 64
        }
        return E
    }

    function v(o) {
        var c = new a;
        c.update(o);
        var d = c.digest();
        return c.clean(), d
    }
    e.hash = v
})(Sn);
var pn = {};
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.sharedKey = e.generateKeyPair = e.generateKeyPairFromSeed = e.scalarMultBase = e.scalarMult = e.SHARED_KEY_LENGTH = e.SECRET_KEY_LENGTH = e.PUBLIC_KEY_LENGTH = void 0;
    const r = Mt,
        n = Ee;
    e.PUBLIC_KEY_LENGTH = 32, e.SECRET_KEY_LENGTH = 32, e.SHARED_KEY_LENGTH = 32;

    function a(u) {
        const s = new Float64Array(16);
        if (u)
            for (let f = 0; f < u.length; f++) s[f] = u[f];
        return s
    }
    const D = new Uint8Array(32);
    D[0] = 9;
    const l = a([56129, 1]);

    function v(u) {
        let s = 1;
        for (let f = 0; f < 16; f++) {
            let t = u[f] + s + 65535;
            s = Math.floor(t / 65536), u[f] = t - s * 65536
        }
        u[0] += s - 1 + 37 * (s - 1)
    }

    function o(u, s, f) {
        const t = ~(f - 1);
        for (let i = 0; i < 16; i++) {
            const S = t & (u[i] ^ s[i]);
            u[i] ^= S, s[i] ^= S
        }
    }

    function c(u, s) {
        const f = a(),
            t = a();
        for (let i = 0; i < 16; i++) t[i] = s[i];
        v(t), v(t), v(t);
        for (let i = 0; i < 2; i++) {
            f[0] = t[0] - 65517;
            for (let O = 1; O < 15; O++) f[O] = t[O] - 65535 - (f[O - 1] >> 16 & 1), f[O - 1] &= 65535;
            f[15] = t[15] - 32767 - (f[14] >> 16 & 1);
            const S = f[15] >> 16 & 1;
            f[14] &= 65535, o(t, f, 1 - S)
        }
        for (let i = 0; i < 16; i++) u[2 * i] = t[i] & 255, u[2 * i + 1] = t[i] >> 8
    }

    function d(u, s) {
        for (let f = 0; f < 16; f++) u[f] = s[2 * f] + (s[2 * f + 1] << 8);
        u[15] &= 32767
    }

    function E(u, s, f) {
        for (let t = 0; t < 16; t++) u[t] = s[t] + f[t]
    }

    function g(u, s, f) {
        for (let t = 0; t < 16; t++) u[t] = s[t] - f[t]
    }

    function w(u, s, f) {
        let t, i, S = 0,
            O = 0,
            F = 0,
            M = 0,
            B = 0,
            x = 0,
            N = 0,
            L = 0,
            C = 0,
            T = 0,
            G = 0,
            Q = 0,
            J = 0,
            X = 0,
            A = 0,
            I = 0,
            R = 0,
            P = 0,
            H = 0,
            K = 0,
            q = 0,
            $ = 0,
            z = 0,
            W = 0,
            V = 0,
            ve = 0,
            Se = 0,
            Oe = 0,
            Le = 0,
            Ke = 0,
            nt = 0,
            k = f[0],
            ee = f[1],
            te = f[2],
            re = f[3],
            ne = f[4],
            ie = f[5],
            ae = f[6],
            ue = f[7],
            oe = f[8],
            fe = f[9],
            se = f[10],
            he = f[11],
            ce = f[12],
            le = f[13],
            De = f[14],
            _e = f[15];
        t = s[0], S += t * k, O += t * ee, F += t * te, M += t * re, B += t * ne, x += t * ie, N += t * ae, L += t * ue, C += t * oe, T += t * fe, G += t * se, Q += t * he, J += t * ce, X += t * le, A += t * De, I += t * _e, t = s[1], O += t * k, F += t * ee, M += t * te, B += t * re, x += t * ne, N += t * ie, L += t * ae, C += t * ue, T += t * oe, G += t * fe, Q += t * se, J += t * he, X += t * ce, A += t * le, I += t * De, R += t * _e, t = s[2], F += t * k, M += t * ee, B += t * te, x += t * re, N += t * ne, L += t * ie, C += t * ae, T += t * ue, G += t * oe, Q += t * fe, J += t * se, X += t * he, A += t * ce, I += t * le, R += t * De, P += t * _e, t = s[3], M += t * k, B += t * ee, x += t * te, N += t * re, L += t * ne, C += t * ie, T += t * ae, G += t * ue, Q += t * oe, J += t * fe, X += t * se, A += t * he, I += t * ce, R += t * le, P += t * De, H += t * _e, t = s[4], B += t * k, x += t * ee, N += t * te, L += t * re, C += t * ne, T += t * ie, G += t * ae, Q += t * ue, J += t * oe, X += t * fe, A += t * se, I += t * he, R += t * ce, P += t * le, H += t * De, K += t * _e, t = s[5], x += t * k, N += t * ee, L += t * te, C += t * re, T += t * ne, G += t * ie, Q += t * ae, J += t * ue, X += t * oe, A += t * fe, I += t * se, R += t * he, P += t * ce, H += t * le, K += t * De, q += t * _e, t = s[6], N += t * k, L += t * ee, C += t * te, T += t * re, G += t * ne, Q += t * ie, J += t * ae, X += t * ue, A += t * oe, I += t * fe, R += t * se, P += t * he, H += t * ce, K += t * le, q += t * De, $ += t * _e, t = s[7], L += t * k, C += t * ee, T += t * te, G += t * re, Q += t * ne, J += t * ie, X += t * ae, A += t * ue, I += t * oe, R += t * fe, P += t * se, H += t * he, K += t * ce, q += t * le, $ += t * De, z += t * _e, t = s[8], C += t * k, T += t * ee, G += t * te, Q += t * re, J += t * ne, X += t * ie, A += t * ae, I += t * ue, R += t * oe, P += t * fe, H += t * se, K += t * he, q += t * ce, $ += t * le, z += t * De, W += t * _e, t = s[9], T += t * k, G += t * ee, Q += t * te, J += t * re, X += t * ne, A += t * ie, I += t * ae, R += t * ue, P += t * oe, H += t * fe, K += t * se, q += t * he, $ += t * ce, z += t * le, W += t * De, V += t * _e, t = s[10], G += t * k, Q += t * ee, J += t * te, X += t * re, A += t * ne, I += t * ie, R += t * ae, P += t * ue, H += t * oe, K += t * fe, q += t * se, $ += t * he, z += t * ce, W += t * le, V += t * De, ve += t * _e, t = s[11], Q += t * k, J += t * ee, X += t * te, A += t * re, I += t * ne, R += t * ie, P += t * ae, H += t * ue, K += t * oe, q += t * fe, $ += t * se, z += t * he, W += t * ce, V += t * le, ve += t * De, Se += t * _e, t = s[12], J += t * k, X += t * ee, A += t * te, I += t * re, R += t * ne, P += t * ie, H += t * ae, K += t * ue, q += t * oe, $ += t * fe, z += t * se, W += t * he, V += t * ce, ve += t * le, Se += t * De, Oe += t * _e, t = s[13], X += t * k, A += t * ee, I += t * te, R += t * re, P += t * ne, H += t * ie, K += t * ae, q += t * ue, $ += t * oe, z += t * fe, W += t * se, V += t * he, ve += t * ce, Se += t * le, Oe += t * De, Le += t * _e, t = s[14], A += t * k, I += t * ee, R += t * te, P += t * re, H += t * ne, K += t * ie, q += t * ae, $ += t * ue, z += t * oe, W += t * fe, V += t * se, ve += t * he, Se += t * ce, Oe += t * le, Le += t * De, Ke += t * _e, t = s[15], I += t * k, R += t * ee, P += t * te, H += t * re, K += t * ne, q += t * ie, $ += t * ae, z += t * ue, W += t * oe, V += t * fe, ve += t * se, Se += t * he, Oe += t * ce, Le += t * le, Ke += t * De, nt += t * _e, S += 38 * R, O += 38 * P, F += 38 * H, M += 38 * K, B += 38 * q, x += 38 * $, N += 38 * z, L += 38 * W, C += 38 * V, T += 38 * ve, G += 38 * Se, Q += 38 * Oe, J += 38 * Le, X += 38 * Ke, A += 38 * nt, i = 1, t = S + i + 65535, i = Math.floor(t / 65536), S = t - i * 65536, t = O + i + 65535, i = Math.floor(t / 65536), O = t - i * 65536, t = F + i + 65535, i = Math.floor(t / 65536), F = t - i * 65536, t = M + i + 65535, i = Math.floor(t / 65536), M = t - i * 65536, t = B + i + 65535, i = Math.floor(t / 65536), B = t - i * 65536, t = x + i + 65535, i = Math.floor(t / 65536), x = t - i * 65536, t = N + i + 65535, i = Math.floor(t / 65536), N = t - i * 65536, t = L + i + 65535, i = Math.floor(t / 65536), L = t - i * 65536, t = C + i + 65535, i = Math.floor(t / 65536), C = t - i * 65536, t = T + i + 65535, i = Math.floor(t / 65536), T = t - i * 65536, t = G + i + 65535, i = Math.floor(t / 65536), G = t - i * 65536, t = Q + i + 65535, i = Math.floor(t / 65536), Q = t - i * 65536, t = J + i + 65535, i = Math.floor(t / 65536), J = t - i * 65536, t = X + i + 65535, i = Math.floor(t / 65536), X = t - i * 65536, t = A + i + 65535, i = Math.floor(t / 65536), A = t - i * 65536, t = I + i + 65535, i = Math.floor(t / 65536), I = t - i * 65536, S += i - 1 + 37 * (i - 1), i = 1, t = S + i + 65535, i = Math.floor(t / 65536), S = t - i * 65536, t = O + i + 65535, i = Math.floor(t / 65536), O = t - i * 65536, t = F + i + 65535, i = Math.floor(t / 65536), F = t - i * 65536, t = M + i + 65535, i = Math.floor(t / 65536), M = t - i * 65536, t = B + i + 65535, i = Math.floor(t / 65536), B = t - i * 65536, t = x + i + 65535, i = Math.floor(t / 65536), x = t - i * 65536, t = N + i + 65535, i = Math.floor(t / 65536), N = t - i * 65536, t = L + i + 65535, i = Math.floor(t / 65536), L = t - i * 65536, t = C + i + 65535, i = Math.floor(t / 65536), C = t - i * 65536, t = T + i + 65535, i = Math.floor(t / 65536), T = t - i * 65536, t = G + i + 65535, i = Math.floor(t / 65536), G = t - i * 65536, t = Q + i + 65535, i = Math.floor(t / 65536), Q = t - i * 65536, t = J + i + 65535, i = Math.floor(t / 65536), J = t - i * 65536, t = X + i + 65535, i = Math.floor(t / 65536), X = t - i * 65536, t = A + i + 65535, i = Math.floor(t / 65536), A = t - i * 65536, t = I + i + 65535, i = Math.floor(t / 65536), I = t - i * 65536, S += i - 1 + 37 * (i - 1), u[0] = S, u[1] = O, u[2] = F, u[3] = M, u[4] = B, u[5] = x, u[6] = N, u[7] = L, u[8] = C, u[9] = T, u[10] = G, u[11] = Q, u[12] = J, u[13] = X, u[14] = A, u[15] = I
    }

    function b(u, s) {
        w(u, s, s)
    }

    function y(u, s) {
        const f = a();
        for (let t = 0; t < 16; t++) f[t] = s[t];
        for (let t = 253; t >= 0; t--) b(f, f), t !== 2 && t !== 4 && w(f, f, s);
        for (let t = 0; t < 16; t++) u[t] = f[t]
    }

    function p(u, s) {
        const f = new Uint8Array(32),
            t = new Float64Array(80),
            i = a(),
            S = a(),
            O = a(),
            F = a(),
            M = a(),
            B = a();
        for (let C = 0; C < 31; C++) f[C] = u[C];
        f[31] = u[31] & 127 | 64, f[0] &= 248, d(t, s);
        for (let C = 0; C < 16; C++) S[C] = t[C];
        i[0] = F[0] = 1;
        for (let C = 254; C >= 0; --C) {
            const T = f[C >>> 3] >>> (C & 7) & 1;
            o(i, S, T), o(O, F, T), E(M, i, O), g(i, i, O), E(O, S, F), g(S, S, F), b(F, M), b(B, i), w(i, O, i), w(O, S, M), E(M, i, O), g(i, i, O), b(S, i), g(O, F, B), w(i, O, l), E(i, i, F), w(O, O, i), w(i, F, B), w(F, S, t), b(S, M), o(i, S, T), o(O, F, T)
        }
        for (let C = 0; C < 16; C++) t[C + 16] = i[C], t[C + 32] = O[C], t[C + 48] = S[C], t[C + 64] = F[C];
        const x = t.subarray(32),
            N = t.subarray(16);
        y(x, x), w(N, N, x);
        const L = new Uint8Array(32);
        return c(L, N), L
    }
    e.scalarMult = p;

    function m(u) {
        return p(u, D)
    }
    e.scalarMultBase = m;

    function U(u) {
        if (u.length !== e.SECRET_KEY_LENGTH) throw new Error(`x25519: seed must be ${e.SECRET_KEY_LENGTH} bytes`);
        const s = new Uint8Array(u);
        return {
            publicKey: m(s),
            secretKey: s
        }
    }
    e.generateKeyPairFromSeed = U;

    function h(u) {
        const s = (0, r.randomBytes)(32, u),
            f = U(s);
        return (0, n.wipe)(s), f
    }
    e.generateKeyPair = h;

    function _(u, s, f = !1) {
        if (u.length !== e.PUBLIC_KEY_LENGTH) throw new Error("X25519: incorrect secret key length");
        if (s.length !== e.PUBLIC_KEY_LENGTH) throw new Error("X25519: incorrect public key length");
        const t = p(u, s);
        if (f) {
            let i = 0;
            for (let S = 0; S < t.length; S++) i |= t[S];
            if (i === 0) throw new Error("X25519: invalid shared key")
        }
        return t
    }
    e.sharedKey = _
})(pn);

function Cn(e, r) {
    if (e.length >= 255) throw new TypeError("Alphabet too long");
    for (var n = new Uint8Array(256), a = 0; a < n.length; a++) n[a] = 255;
    for (var D = 0; D < e.length; D++) {
        var l = e.charAt(D),
            v = l.charCodeAt(0);
        if (n[v] !== 255) throw new TypeError(l + " is ambiguous");
        n[v] = D
    }
    var o = e.length,
        c = e.charAt(0),
        d = Math.log(o) / Math.log(256),
        E = Math.log(256) / Math.log(o);

    function g(y) {
        if (y instanceof Uint8Array || (ArrayBuffer.isView(y) ? y = new Uint8Array(y.buffer, y.byteOffset, y.byteLength) : Array.isArray(y) && (y = Uint8Array.from(y))), !(y instanceof Uint8Array)) throw new TypeError("Expected Uint8Array");
        if (y.length === 0) return "";
        for (var p = 0, m = 0, U = 0, h = y.length; U !== h && y[U] === 0;) U++, p++;
        for (var _ = (h - U) * E + 1 >>> 0, u = new Uint8Array(_); U !== h;) {
            for (var s = y[U], f = 0, t = _ - 1;
                (s !== 0 || f < m) && t !== -1; t--, f++) s += 256 * u[t] >>> 0, u[t] = s % o >>> 0, s = s / o >>> 0;
            if (s !== 0) throw new Error("Non-zero carry");
            m = f, U++
        }
        for (var i = _ - m; i !== _ && u[i] === 0;) i++;
        for (var S = c.repeat(p); i < _; ++i) S += e.charAt(u[i]);
        return S
    }

    function w(y) {
        if (typeof y != "string") throw new TypeError("Expected String");
        if (y.length === 0) return new Uint8Array;
        var p = 0;
        if (y[p] !== " ") {
            for (var m = 0, U = 0; y[p] === c;) m++, p++;
            for (var h = (y.length - p) * d + 1 >>> 0, _ = new Uint8Array(h); y[p];) {
                var u = n[y.charCodeAt(p)];
                if (u === 255) return;
                for (var s = 0, f = h - 1;
                    (u !== 0 || s < U) && f !== -1; f--, s++) u += o * _[f] >>> 0, _[f] = u % 256 >>> 0, u = u / 256 >>> 0;
                if (u !== 0) throw new Error("Non-zero carry");
                U = s, p++
            }
            if (y[p] !== " ") {
                for (var t = h - U; t !== h && _[t] === 0;) t++;
                for (var i = new Uint8Array(m + (h - t)), S = m; t !== h;) i[S++] = _[t++];
                return i
            }
        }
    }

    function b(y) {
        var p = w(y);
        if (p) return p;
        throw new Error(`Non-${r} character`)
    }
    return {
        encode: g,
        decodeUnsafe: w,
        decode: b
    }
}
var On = Cn,
    An = On;
const Un = e => {
        if (e instanceof Uint8Array && e.constructor.name === "Uint8Array") return e;
        if (e instanceof ArrayBuffer) return new Uint8Array(e);
        if (ArrayBuffer.isView(e)) return new Uint8Array(e.buffer, e.byteOffset, e.byteLength);
        throw new Error("Unknown type, must be binary type")
    },
    Fn = e => new TextEncoder().encode(e),
    Tn = e => new TextDecoder().decode(e);
class Nn {
    constructor(r, n, a) {
        this.name = r, this.prefix = n, this.baseEncode = a
    }
    encode(r) {
        if (r instanceof Uint8Array) return `${this.prefix}${this.baseEncode(r)}`;
        throw Error("Unknown type, must be binary type")
    }
}
class Ln {
    constructor(r, n, a) {
        if (this.name = r, this.prefix = n, n.codePointAt(0) === void 0) throw new Error("Invalid prefix character");
        this.prefixCodePoint = n.codePointAt(0), this.baseDecode = a
    }
    decode(r) {
        if (typeof r == "string") {
            if (r.codePointAt(0) !== this.prefixCodePoint) throw Error(`Unable to decode multibase string ${JSON.stringify(r)}, ${this.name} decoder only supports inputs prefixed with ${this.prefix}`);
            return this.baseDecode(r.slice(this.prefix.length))
        } else throw Error("Can only multibase decode strings")
    }
    or(r) {
        return xt(this, r)
    }
}
class Mn {
    constructor(r) {
        this.decoders = r
    }
    or(r) {
        return xt(this, r)
    }
    decode(r) {
        const n = r[0],
            a = this.decoders[n];
        if (a) return a.decode(r);
        throw RangeError(`Unable to decode multibase string ${JSON.stringify(r)}, only inputs prefixed with ${Object.keys(this.decoders)} are supported`)
    }
}
const xt = (e, r) => new Mn({ ...e.decoders || {
        [e.prefix]: e
    },
    ...r.decoders || {
        [r.prefix]: r
    }
});
class xn {
    constructor(r, n, a, D) {
        this.name = r, this.prefix = n, this.baseEncode = a, this.baseDecode = D, this.encoder = new Nn(r, n, a), this.decoder = new Ln(r, n, D)
    }
    encode(r) {
        return this.encoder.encode(r)
    }
    decode(r) {
        return this.decoder.decode(r)
    }
}
const He = ({
        name: e,
        prefix: r,
        encode: n,
        decode: a
    }) => new xn(e, r, n, a),
    Ne = ({
        prefix: e,
        name: r,
        alphabet: n
    }) => {
        const {
            encode: a,
            decode: D
        } = An(n, r);
        return He({
            prefix: e,
            name: r,
            encode: a,
            decode: l => Un(D(l))
        })
    },
    jn = (e, r, n, a) => {
        const D = {};
        for (let E = 0; E < r.length; ++E) D[r[E]] = E;
        let l = e.length;
        for (; e[l - 1] === "=";) --l;
        const v = new Uint8Array(l * n / 8 | 0);
        let o = 0,
            c = 0,
            d = 0;
        for (let E = 0; E < l; ++E) {
            const g = D[e[E]];
            if (g === void 0) throw new SyntaxError(`Non-${a} character`);
            c = c << n | g, o += n, o >= 8 && (o -= 8, v[d++] = 255 & c >> o)
        }
        if (o >= n || 255 & c << 8 - o) throw new SyntaxError("Unexpected end of data");
        return v
    },
    Bn = (e, r, n) => {
        const a = r[r.length - 1] === "=",
            D = (1 << n) - 1;
        let l = "",
            v = 0,
            o = 0;
        for (let c = 0; c < e.length; ++c)
            for (o = o << 8 | e[c], v += 8; v > n;) v -= n, l += r[D & o >> v];
        if (v && (l += r[D & o << n - v]), a)
            for (; l.length * n & 7;) l += "=";
        return l
    },
    Z = ({
        name: e,
        prefix: r,
        bitsPerChar: n,
        alphabet: a
    }) => He({
        prefix: r,
        name: e,
        encode(D) {
            return Bn(D, a, n)
        },
        decode(D) {
            return jn(D, a, n, e)
        }
    }),
    In = He({
        prefix: "\0",
        name: "identity",
        encode: e => Tn(e),
        decode: e => Fn(e)
    }),
    _i = Object.freeze(Object.defineProperty({
        __proto__: null,
        identity: In
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Rn = Z({
        prefix: "0",
        name: "base2",
        alphabet: "01",
        bitsPerChar: 1
    }),
    di = Object.freeze(Object.defineProperty({
        __proto__: null,
        base2: Rn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Pn = Z({
        prefix: "7",
        name: "base8",
        alphabet: "01234567",
        bitsPerChar: 3
    }),
    Ei = Object.freeze(Object.defineProperty({
        __proto__: null,
        base8: Pn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Hn = Ne({
        prefix: "9",
        name: "base10",
        alphabet: "0123456789"
    }),
    bi = Object.freeze(Object.defineProperty({
        __proto__: null,
        base10: Hn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Kn = Z({
        prefix: "f",
        name: "base16",
        alphabet: "0123456789abcdef",
        bitsPerChar: 4
    }),
    qn = Z({
        prefix: "F",
        name: "base16upper",
        alphabet: "0123456789ABCDEF",
        bitsPerChar: 4
    }),
    wi = Object.freeze(Object.defineProperty({
        __proto__: null,
        base16: Kn,
        base16upper: qn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    $n = Z({
        prefix: "b",
        name: "base32",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567",
        bitsPerChar: 5
    }),
    zn = Z({
        prefix: "B",
        name: "base32upper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
        bitsPerChar: 5
    }),
    Yn = Z({
        prefix: "c",
        name: "base32pad",
        alphabet: "abcdefghijklmnopqrstuvwxyz234567=",
        bitsPerChar: 5
    }),
    Wn = Z({
        prefix: "C",
        name: "base32padupper",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567=",
        bitsPerChar: 5
    }),
    Gn = Z({
        prefix: "v",
        name: "base32hex",
        alphabet: "0123456789abcdefghijklmnopqrstuv",
        bitsPerChar: 5
    }),
    Vn = Z({
        prefix: "V",
        name: "base32hexupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV",
        bitsPerChar: 5
    }),
    Xn = Z({
        prefix: "t",
        name: "base32hexpad",
        alphabet: "0123456789abcdefghijklmnopqrstuv=",
        bitsPerChar: 5
    }),
    Jn = Z({
        prefix: "T",
        name: "base32hexpadupper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV=",
        bitsPerChar: 5
    }),
    Qn = Z({
        prefix: "h",
        name: "base32z",
        alphabet: "ybndrfg8ejkmcpqxot1uwisza345h769",
        bitsPerChar: 5
    }),
    vi = Object.freeze(Object.defineProperty({
        __proto__: null,
        base32: $n,
        base32hex: Gn,
        base32hexpad: Xn,
        base32hexpadupper: Jn,
        base32hexupper: Vn,
        base32pad: Yn,
        base32padupper: Wn,
        base32upper: zn,
        base32z: Qn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Zn = Ne({
        prefix: "k",
        name: "base36",
        alphabet: "0123456789abcdefghijklmnopqrstuvwxyz"
    }),
    kn = Ne({
        prefix: "K",
        name: "base36upper",
        alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    }),
    gi = Object.freeze(Object.defineProperty({
        __proto__: null,
        base36: Zn,
        base36upper: kn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ei = Ne({
        name: "base58btc",
        prefix: "z",
        alphabet: "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    }),
    ti = Ne({
        name: "base58flickr",
        prefix: "Z",
        alphabet: "123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ"
    }),
    yi = Object.freeze(Object.defineProperty({
        __proto__: null,
        base58btc: ei,
        base58flickr: ti
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ri = Z({
        prefix: "m",
        name: "base64",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        bitsPerChar: 6
    }),
    ni = Z({
        prefix: "M",
        name: "base64pad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        bitsPerChar: 6
    }),
    ii = Z({
        prefix: "u",
        name: "base64url",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
        bitsPerChar: 6
    }),
    ai = Z({
        prefix: "U",
        name: "base64urlpad",
        alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=",
        bitsPerChar: 6
    }),
    mi = Object.freeze(Object.defineProperty({
        __proto__: null,
        base64: ri,
        base64pad: ni,
        base64url: ii,
        base64urlpad: ai
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    jt = Array.from("🚀🪐☄🛰🌌🌑🌒🌓🌔🌕🌖🌗🌘🌍🌏🌎🐉☀💻🖥💾💿😂❤😍🤣😊🙏💕😭😘👍😅👏😁🔥🥰💔💖💙😢🤔😆🙄💪😉☺👌🤗💜😔😎😇🌹🤦🎉💞✌✨🤷😱😌🌸🙌😋💗💚😏💛🙂💓🤩😄😀🖤😃💯🙈👇🎶😒🤭❣😜💋👀😪😑💥🙋😞😩😡🤪👊🥳😥🤤👉💃😳✋😚😝😴🌟😬🙃🍀🌷😻😓⭐✅🥺🌈😈🤘💦✔😣🏃💐☹🎊💘😠☝😕🌺🎂🌻😐🖕💝🙊😹🗣💫💀👑🎵🤞😛🔴😤🌼😫⚽🤙☕🏆🤫👈😮🙆🍻🍃🐶💁😲🌿🧡🎁⚡🌞🎈❌✊👋😰🤨😶🤝🚶💰🍓💢🤟🙁🚨💨🤬✈🎀🍺🤓😙💟🌱😖👶🥴▶➡❓💎💸⬇😨🌚🦋😷🕺⚠🙅😟😵👎🤲🤠🤧📌🔵💅🧐🐾🍒😗🤑🌊🤯🐷☎💧😯💆👆🎤🙇🍑❄🌴💣🐸💌📍🥀🤢👅💡💩👐📸👻🤐🤮🎼🥵🚩🍎🍊👼💍📣🥂"),
    ui = jt.reduce((e, r, n) => (e[n] = r, e), []),
    oi = jt.reduce((e, r, n) => (e[r.codePointAt(0)] = n, e), []);

function fi(e) {
    return e.reduce((r, n) => (r += ui[n], r), "")
}

function si(e) {
    const r = [];
    for (const n of e) {
        const a = oi[n.codePointAt(0)];
        if (a === void 0) throw new Error(`Non-base256emoji character: ${n}`);
        r.push(a)
    }
    return new Uint8Array(r)
}
const hi = He({
        prefix: "🚀",
        name: "base256emoji",
        encode: fi,
        decode: si
    }),
    Si = Object.freeze(Object.defineProperty({
        __proto__: null,
        base256emoji: hi
    }, Symbol.toStringTag, {
        value: "Module"
    }));
new TextEncoder;
new TextDecoder;
export {
    Di as H, Ei as a, di as b, bi as c, wi as d, vi as e, gi as f, yi as g, mi as h, _i as i, Si as j, Rt as k, j as l, Or as m, wr as n, dr as o, jr as p, Ur as q, Mt as r, Sn as s, yr as t, Ee as w, pn as x
};